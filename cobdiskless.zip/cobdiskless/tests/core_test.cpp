#if defined(_WIN32)
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#endif
#include <thread>
#include <iostream>
#include <vector>
#include <string>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <filesystem>
#include <fstream>

#include "CobDisklessCore/core.hpp"
#include "CobDisklessCore/types/common_types.hpp"
#include "CobDisklessCore/types/network_address.hpp"
#include "CobDisklessCore/errors/result.hpp"
#include "CobDisklessCore/logging/logger.hpp"
#include "CobDisklessCore/config/configuration.hpp"
#include "CobDisklessCore/subsystem/subsystem.hpp"
#include "CobDisklessCore/storage/block_device.hpp"
#include "CobDisklessCore/storage/read_only_block_device.hpp"
#include "CobDisklessCore/storage/raw_image_backend.hpp"
#include "CobDisklessCore/storage/vhd_image_backend.hpp"
#include "CobDisklessCore/image/image_format.hpp"
#include "CobDisklessCore/image/partition_info.hpp"
#include "CobDisklessCore/image/image_inspector.hpp"
#include "CobDisklessCore/image/golden_image.hpp"
#include "CobDisklessCore/image/image_registry.hpp"
#include "CobDisklessCore/image/image_manager.hpp"
#include "CobDisklessCore/storage/storage_tester.hpp"
#include "CobDisklessCore/storage/cow_block_device.hpp"
#include "CobDisklessCore/client/client_session.hpp"
#include "CobDisklessCore/client/client_manager.hpp"
#include "CobDisklessCore/storage/storage_manager.hpp"
#include "CobDisklessCore/network/dhcp_server.hpp"
#include "CobDisklessCore/network/tftp_server.hpp"
#include "CobDisklessCore/network/iscsi_target.hpp"
#include "CobDisklessCore/storage/block_cache.hpp"

using namespace cobdiskless;

// =============================================================================
// Helper Mock Subsystem for Lifecycle Testing
// =============================================================================
class MockSubsystem : public ISubsystem {
public:
    MockSubsystem(std::string name, bool should_succeed, std::vector<std::string>& event_log)
        : name_(std::move(name)), should_succeed_(should_succeed), event_log_(event_log) {}

    [[nodiscard]] std::string_view name() const noexcept override { return name_; }

    [[nodiscard]] Result<void> initialize() override {
        event_log_.push_back(name_ + ":init");
        if (!should_succeed_) {
            state_ = SubsystemState::Failed;
            return Error(ErrorCode::InitializationFailure, name_ + " simulated failure");
        }
        state_ = SubsystemState::Running;
        return {};
    }

    void shutdown() override {
        event_log_.push_back(name_ + ":shutdown");
        state_ = SubsystemState::Stopped;
    }

    [[nodiscard]] bool is_initialized() const noexcept override {
        return state_ == SubsystemState::Running;
    }

    [[nodiscard]] SubsystemState state() const noexcept override {
        return state_;
    }

private:
    std::string name_;
    bool should_succeed_{true};
    std::vector<std::string>& event_log_;
    SubsystemState state_{SubsystemState::Uninitialized};
};

// =============================================================================
// Helper In-Memory Block Device for Storage Interface Testing
// =============================================================================
class MemoryBlockDevice : public BlockDevice {
public:
    explicit MemoryBlockDevice(uint64_t size_bytes)
        : storage_(static_cast<size_t>(size_bytes), std::byte{0}) {}

    [[nodiscard]] Result<size_t> read(uint64_t offset, std::span<std::byte> destination) override {
        if (offset + destination.size() > storage_.size()) {
            return Error(ErrorCode::StorageFailure, "Out of bounds read request");
        }
        std::memcpy(destination.data(), storage_.data() + offset, destination.size());
        return destination.size();
    }

    [[nodiscard]] Result<size_t> write(uint64_t offset, std::span<const std::byte> source) override {
        if (offset + source.size() > storage_.size()) {
            return Error(ErrorCode::StorageFailure, "Out of bounds write request");
        }
        std::memcpy(storage_.data() + offset, source.data(), source.size());
        return source.size();
    }

    [[nodiscard]] Result<void> flush() override {
        flushed_ = true;
        return {};
    }

    [[nodiscard]] uint64_t size() const noexcept override {
        return storage_.size();
    }

    [[nodiscard]] bool was_flushed() const noexcept {
        return flushed_;
    }

    [[nodiscard]] std::span<std::byte> raw_data() noexcept {
        return storage_;
    }

private:
    std::vector<std::byte> storage_;
    bool flushed_{false};
};

// =============================================================================
// Synthesis Helpers for Disk Structures
// =============================================================================

inline void write_le16(uint8_t* p, uint16_t val) {
    p[0] = static_cast<uint8_t>(val & 0xFF);
    p[1] = static_cast<uint8_t>((val >> 8) & 0xFF);
}

inline void write_le32(uint8_t* p, uint32_t val) {
    p[0] = static_cast<uint8_t>(val & 0xFF);
    p[1] = static_cast<uint8_t>((val >> 8) & 0xFF);
    p[2] = static_cast<uint8_t>((val >> 16) & 0xFF);
    p[3] = static_cast<uint8_t>((val >> 24) & 0xFF);
}

inline void write_le64(uint8_t* p, uint64_t val) {
    write_le32(p, static_cast<uint32_t>(val & 0xFFFFFFFF));
    write_le32(p + 4, static_cast<uint32_t>((val >> 32) & 0xFFFFFFFF));
}

inline void write_be32(uint8_t* p, uint32_t val) {
    p[0] = static_cast<uint8_t>((val >> 24) & 0xFF);
    p[1] = static_cast<uint8_t>((val >> 16) & 0xFF);
    p[2] = static_cast<uint8_t>((val >> 8) & 0xFF);
    p[3] = static_cast<uint8_t>(val & 0xFF);
}

inline void write_be64(uint8_t* p, uint64_t val) {
    write_be32(p, static_cast<uint32_t>((val >> 32) & 0xFFFFFFFF));
    write_be32(p + 4, static_cast<uint32_t>(val & 0xFFFFFFFF));
}

// =============================================================================
// Phase 3 Architecture Test Cases
// =============================================================================

void test_common_types() {
    std::cout << "[RUN] test_common_types\n";

    constexpr ByteSize b1 = 512_KiB;
    constexpr ByteSize b2 = 10_MiB;
    constexpr ByteSize b3 = 2_GiB;

    assert(b1.bytes() == 512 * 1024);
    assert(b2.bytes() == 10 * 1024 * 1024);
    assert(b3.bytes() == 2ULL * 1024 * 1024 * 1024);
    assert(b1 < b2);
    assert(b2 < b3);

    ClientId c1{"client-001"};
    ClientId c2{"client-001"};
    ClientId c3{"client-002"};
    assert(c1 == c2);
    assert(c1 != c3);
    assert(c1.value() == "client-001");

    ImageId img{"win10-golden.vhd"};
    assert(img.value() == "win10-golden.vhd");

    NetworkAddress addr(192, 168, 1, 100, 3260);
    assert(addr.octet(0) == 192);
    assert(addr.octet(1) == 168);
    assert(addr.octet(2) == 1);
    assert(addr.octet(3) == 100);
    assert(addr.port() == 3260);
    assert(addr.to_string() == "192.168.1.100:3260");

    NetworkAddress parsed = NetworkAddress::parse("10.0.0.1:8080");
    assert(parsed.octet(0) == 10);
    assert(parsed.octet(3) == 1);
    assert(parsed.port() == 8080);

    std::cout << "  PASS: test_common_types\n";
}

void test_errors_and_results() {
    std::cout << "[RUN] test_errors_and_results\n";

    Error err(ErrorCode::NetworkFailure, "Failed to bind UDP socket on 67");
    assert(!err.is_success());
    assert(err.code() == ErrorCode::NetworkFailure);
    assert(err.message().find("UDP socket") != std::string_view::npos);

    Result<int> res_ok(42);
    assert(res_ok.is_ok());
    assert(!res_ok.is_err());
    assert(res_ok.has_value());
    assert(res_ok.value() == 42);

    Result<int> res_err(ErrorCode::StorageFailure, "Disk sector read error");
    assert(!res_ok.is_err());
    assert(res_err.is_err());
    assert(!res_err.has_value());
    assert(res_err.error().code() == ErrorCode::StorageFailure);

    Result<void> void_ok;
    assert(void_ok.is_ok());

    Result<void> void_err(ErrorCode::InvalidConfiguration, "Missing path");
    assert(void_err.is_err());
    assert(void_err.error().code() == ErrorCode::InvalidConfiguration);

    std::cout << "  PASS: test_errors_and_results\n";
}

void test_logging() {
    std::cout << "[RUN] test_logging\n";

    Logger logger(LogLevel::Debug);
    std::vector<std::string> captured_logs;

    logger.set_sink([&captured_logs](LogLevel /*level*/, std::string_view /*category*/,
                                     std::string_view /*message*/, std::string_view formatted) {
        captured_logs.emplace_back(formatted);
    });

    logger.trace("CORE", "Trace message - should be filtered");
    logger.debug("STORAGE", "Debug message - should be captured");
    logger.info("NETWORK", "Info message - should be captured");
    logger.warn("BOOT", "Warn message - should be captured");
    logger.error("CLIENT", "Error message - should be captured");

    assert(captured_logs.size() == 4);
    assert(captured_logs[0].find("[DEBUG] [STORAGE]") != std::string::npos);
    assert(captured_logs[1].find("[INFO] [NETWORK]") != std::string::npos);
    assert(captured_logs[2].find("[WARN] [BOOT]") != std::string::npos);
    assert(captured_logs[3].find("[ERROR] [CLIENT]") != std::string::npos);

    std::cout << "  PASS: test_logging\n";
}

void test_configuration_validation() {
    std::cout << "[RUN] test_configuration_validation\n";

    Configuration valid_cfg = Configuration::create_default();
    auto valid_res = valid_cfg.validate();
    assert(valid_res.is_ok());

    Configuration invalid_cfg = valid_cfg;
    invalid_cfg.set_storage_path("");
    auto invalid_res1 = invalid_cfg.validate();
    assert(invalid_res1.is_err());
    assert(invalid_res1.error().code() == ErrorCode::InvalidConfiguration);

    invalid_cfg = valid_cfg;
    invalid_cfg.set_max_clients(0);
    auto invalid_res2 = invalid_cfg.validate();
    assert(invalid_res2.is_err());
    assert(invalid_res2.error().code() == ErrorCode::InvalidConfiguration);

    invalid_cfg = valid_cfg;
    invalid_cfg.set_default_cache_size(ByteSize(0));
    auto invalid_res3 = invalid_cfg.validate();
    assert(invalid_res3.is_err());

    std::cout << "  PASS: test_configuration_validation\n";
}

void test_subsystem_deterministic_lifecycle() {
    std::cout << "[RUN] test_subsystem_deterministic_lifecycle\n";

    Core core;
    std::vector<std::string> events;

    auto sub1 = std::make_shared<MockSubsystem>("SubsystemA", true, events);
    auto sub2 = std::make_shared<MockSubsystem>("SubsystemB", true, events);
    auto sub3 = std::make_shared<MockSubsystem>("SubsystemC", true, events);

    assert(core.register_subsystem(sub1).is_ok());
    assert(core.register_subsystem(sub2).is_ok());
    assert(core.register_subsystem(sub3).is_ok());

    assert(core.subsystem_count() == 3);

    auto init_res = core.initialize();
    assert(init_res.is_ok());
    assert(core.is_initialized());

    assert(events.size() == 3);
    assert(events[0] == "SubsystemA:init");
    assert(events[1] == "SubsystemB:init");
    assert(events[2] == "SubsystemC:init");

    core.shutdown();
    assert(!core.is_initialized());

    assert(events.size() == 6);
    assert(events[3] == "SubsystemC:shutdown");
    assert(events[4] == "SubsystemB:shutdown");
    assert(events[5] == "SubsystemA:shutdown");

    std::cout << "  PASS: test_subsystem_deterministic_lifecycle\n";
}

void test_subsystem_failure_rollback() {
    std::cout << "[RUN] test_subsystem_failure_rollback\n";

    Core core;
    std::vector<std::string> events;

    auto sub1 = std::make_shared<MockSubsystem>("Subsystem1_OK", true, events);
    auto sub2 = std::make_shared<MockSubsystem>("Subsystem2_FAIL", false, events);
    auto sub3 = std::make_shared<MockSubsystem>("Subsystem3_SKIPPED", true, events);

    assert(core.register_subsystem(sub1).is_ok());
    assert(core.register_subsystem(sub2).is_ok());
    assert(core.register_subsystem(sub3).is_ok());

    auto init_res = core.initialize();
    assert(init_res.is_err());
    assert(init_res.error().code() == ErrorCode::InitializationFailure);
    assert(!core.is_initialized());

    assert(events.size() == 3);
    assert(events[0] == "Subsystem1_OK:init");
    assert(events[1] == "Subsystem2_FAIL:init");
    assert(events[2] == "Subsystem1_OK:shutdown");

    core.shutdown();
    assert(events.size() == 3);

    std::cout << "  PASS: test_subsystem_failure_rollback\n";
}

void test_storage_block_device() {
    std::cout << "[RUN] test_storage_block_device\n";

    constexpr uint64_t dev_size = 4096;
    MemoryBlockDevice device(dev_size);

    assert(device.size() == dev_size);
    assert(device.block_size() == 512);
    assert(!device.is_read_only());

    const char message[] = "CobDiskless Block Storage Test Data";
    const size_t msg_len = std::strlen(message);

    std::span<const std::byte> write_span(
        reinterpret_cast<const std::byte*>(message),
        msg_len
    );

    auto write_res = device.write(512, write_span);
    assert(write_res.is_ok());
    assert(write_res.value() == msg_len);

    std::vector<std::byte> read_buf(msg_len);
    auto read_res = device.read(512, std::span<std::byte>(read_buf.data(), read_buf.size()));
    assert(read_res.is_ok());
    assert(read_res.value() == msg_len);
    assert(std::memcmp(read_buf.data(), message, msg_len) == 0);

    // Out of bounds write
    auto oob_write = device.write(4080, write_span);
    assert(oob_write.is_err());
    assert(oob_write.error().code() == ErrorCode::StorageFailure);

    // Out of bounds read
    auto oob_read = device.read(4080, std::span<std::byte>(read_buf.data(), read_buf.size()));
    assert(oob_read.is_err());
    assert(oob_read.error().code() == ErrorCode::StorageFailure);

    // Flush
    assert(device.flush().is_ok());
    assert(device.was_flushed());

    std::cout << "  PASS: test_storage_block_device\n";
}

// =============================================================================
// Phase 4 Golden Image Engine Test Cases
// =============================================================================

void test_mbr_detection() {
    std::cout << "[RUN] test_mbr_detection\n";

    // 1. Valid MBR with 2 partitions
    auto dev = std::make_shared<MemoryBlockDevice>(100 * 1024 * 1024); // 100 MiB
    uint8_t* raw = reinterpret_cast<uint8_t*>(dev->raw_data().data());

    // Bootstrap code in bytes 0..445
    raw[0] = 0xFA; // cli
    raw[1] = 0x31; // xor eax, eax
    raw[2] = 0xC0;

    // Partition 1: Active, NTFS (0x07), start LBA 2048, size 100,000 sectors
    uint8_t* p1 = raw + 446;
    p1[0] = 0x80; // Bootable
    p1[4] = 0x07; // NTFS / exFAT
    write_le32(p1 + 8, 2048);
    write_le32(p1 + 12, 100000);

    // Write NTFS boot sector signature at LBA 2048 (offset 2048 * 512 = 1,048,576)
    uint8_t* vbr1 = raw + (2048 * 512);
    std::memcpy(vbr1 + 3, "NTFS    ", 8);
    vbr1[510] = 0x55;
    vbr1[511] = 0xAA;

    // Partition 2: Inactive, FAT32 (0x0B), start LBA 102048, size 50,000 sectors
    uint8_t* p2 = raw + 446 + 16;
    p2[0] = 0x00;
    p2[4] = 0x0B; // FAT32
    write_le32(p2 + 8, 102048);
    write_le32(p2 + 12, 50000);

    // Write FAT32 boot sector signature at LBA 102048
    uint8_t* vbr2 = raw + (102048 * 512);
    std::memcpy(vbr2 + 82, "FAT32   ", 8);
    vbr2[510] = 0x55;
    vbr2[511] = 0xAA;

    // MBR Signature
    raw[510] = 0x55;
    raw[511] = 0xAA;

    auto inspect_res = ImageInspector::inspect(dev, "test_mbr.img");
    assert(inspect_res.is_ok());
    const auto& report = inspect_res.value();

    assert(report.partition_scheme == PartitionScheme::Mbr);
    assert(report.boot_mode == BootMode::Bios);
    assert(report.has_active_boot_partition);
    assert(report.has_mbr_bootstrap_code);
    assert(!report.has_esp);
    assert(report.partitions.size() == 2);

    assert(report.partitions[0].index == 1);
    assert(report.partitions[0].is_bootable);
    assert(report.partitions[0].mbr_type == 0x07);
    assert(report.partitions[0].start_lba == 2048);
    assert(report.partitions[0].filesystem == FilesystemType::Ntfs);

    assert(report.partitions[1].index == 2);
    assert(!report.partitions[1].is_bootable);
    assert(report.partitions[1].mbr_type == 0x0B);
    assert(report.partitions[1].start_lba == 102048);
    assert(report.partitions[1].filesystem == FilesystemType::Fat32);

    // 2. Corrupted signature -> Unpartitioned
    raw[510] = 0x00;
    raw[511] = 0x00;
    auto corrupt_res = ImageInspector::inspect(dev, "corrupt.img");
    assert(corrupt_res.is_ok());
    assert(corrupt_res.value().partition_scheme == PartitionScheme::Unpartitioned);

    std::cout << "  PASS: test_mbr_detection\n";
}

void test_gpt_detection() {
    std::cout << "[RUN] test_gpt_detection\n";

    auto dev = std::make_shared<MemoryBlockDevice>(50 * 1024 * 1024); // 50 MiB
    uint8_t* raw = reinterpret_cast<uint8_t*>(dev->raw_data().data());

    // LBA 0: Protective MBR
    raw[510] = 0x55;
    raw[511] = 0xAA;
    uint8_t* pmbr_p1 = raw + 446;
    pmbr_p1[4] = 0xEE; // GPT Protective type
    write_le32(pmbr_p1 + 8, 1);
    write_le32(pmbr_p1 + 12, 102399);

    // LBA 1: GPT Header
    uint8_t* gpt_hdr = raw + 512;
    std::memcpy(gpt_hdr, "EFI PART", 8); // Signature
    write_le32(gpt_hdr + 8, 0x00010000);  // Revision
    write_le32(gpt_hdr + 12, 92);         // Header size
    write_le64(gpt_hdr + 24, 1);          // Current LBA
    write_le64(gpt_hdr + 32, 102399);     // Backup LBA
    write_le64(gpt_hdr + 40, 34);         // First usable LBA
    write_le64(gpt_hdr + 48, 102366);     // Last usable LBA
    write_le64(gpt_hdr + 72, 2);          // Partition entry LBA
    write_le32(gpt_hdr + 80, 128);        // Number of partition entries
    write_le32(gpt_hdr + 84, 128);        // Size of partition entry

    // LBA 2: Partition Entry 0 -> EFI System Partition (ESP)
    // GUID: C12A7328-F81F-11D2-BA4B-00A0C93EC93B
    // Bytes: 28 73 2A C1, 1F F8, D2 11, BA, 4B, 00, A0, C9, 3E, C9, 3B
    uint8_t* e0 = raw + (2 * 512);
    write_le32(e0, 0xC12A7328);
    write_le16(e0 + 4, 0xF81F);
    write_le16(e0 + 6, 0x11D2);
    e0[8] = 0xBA; e0[9] = 0x4B; e0[10] = 0x00; e0[11] = 0xA0;
    e0[12] = 0xC9; e0[13] = 0x3E; e0[14] = 0xC9; e0[15] = 0x3B;

    write_le64(e0 + 32, 2048); // Start LBA
    write_le64(e0 + 40, 4095); // End LBA (2048 sectors)

    // Partition Name in UTF-16LE: "EFI System"
    const char name1[] = "EFI System";
    for (size_t i = 0; i < std::strlen(name1); ++i) {
        e0[56 + (i * 2)] = static_cast<uint8_t>(name1[i]);
    }

    // Write FAT32 filesystem signature at LBA 2048
    uint8_t* esp_vbr = raw + (2048 * 512);
    std::memcpy(esp_vbr + 82, "FAT32   ", 8);

    // LBA 2 Entry 1 -> Microsoft Basic Data (NTFS)
    // GUID: EBD0A0A2-B9E5-4433-87C0-68B6B72699C7
    uint8_t* e1 = e0 + 128;
    write_le32(e1, 0xEBD0A0A2);
    write_le16(e1 + 4, 0xB9E5);
    write_le16(e1 + 6, 0x4433);
    e1[8] = 0x87; e1[9] = 0xC0; e1[10] = 0x68; e1[11] = 0xB6;
    e1[12] = 0xB7; e1[13] = 0x26; e1[14] = 0x99; e1[15] = 0xC7;

    write_le64(e1 + 32, 4096);
    write_le64(e1 + 40, 20479);

    const char name2[] = "Basic data partition";
    for (size_t i = 0; i < std::strlen(name2); ++i) {
        e1[56 + (i * 2)] = static_cast<uint8_t>(name2[i]);
    }

    // Write NTFS filesystem signature at LBA 4096
    uint8_t* ntfs_vbr = raw + (4096 * 512);
    std::memcpy(ntfs_vbr + 3, "NTFS    ", 8);

    auto inspect_res = ImageInspector::inspect(dev, "test_gpt.raw");
    assert(inspect_res.is_ok());
    const auto& report = inspect_res.value();

    assert(report.partition_scheme == PartitionScheme::Gpt);
    assert(report.boot_mode == BootMode::Uefi);
    assert(report.has_esp);
    assert(!report.has_active_boot_partition);
    assert(report.partitions.size() == 2);

    assert(report.partitions[0].name == "EFI System");
    assert(report.partitions[0].is_esp);
    assert(report.partitions[0].filesystem == FilesystemType::Fat32);
    assert(report.partitions[0].start_lba == 2048);
    assert(report.partitions[0].sector_count == 2048);

    assert(report.partitions[1].name == "Basic data partition");
    assert(!report.partitions[1].is_esp);
    assert(report.partitions[1].filesystem == FilesystemType::Ntfs);
    assert(report.partitions[1].start_lba == 4096);

    std::cout << "  PASS: test_gpt_detection\n";
}

void test_boot_mode_recognition() {
    std::cout << "[RUN] test_boot_mode_recognition\n";

    // 1. BIOS boot image: MBR bootstrap code + active partition
    {
        auto dev = std::make_shared<MemoryBlockDevice>(10 * 1024 * 1024);
        uint8_t* raw = reinterpret_cast<uint8_t*>(dev->raw_data().data());
        raw[0] = 0xEB; // JMP opcode
        raw[510] = 0x55; raw[511] = 0xAA;
        raw[446] = 0x80; // active boot flag
        raw[450] = 0x07; // NTFS
        write_le32(raw + 446 + 8, 2048);
        write_le32(raw + 446 + 12, 1000);

        auto rep = ImageInspector::inspect(dev).value();
        assert(rep.boot_mode == BootMode::Bios);
    }

    // 2. UEFI boot image: MBR with 0xEF partition (ESP)
    {
        auto dev = std::make_shared<MemoryBlockDevice>(10 * 1024 * 1024);
        uint8_t* raw = reinterpret_cast<uint8_t*>(dev->raw_data().data());
        raw[510] = 0x55; raw[511] = 0xAA;
        raw[446] = 0x00; // not active
        raw[450] = 0xEF; // EFI System Partition in MBR
        write_le32(raw + 446 + 8, 2048);
        write_le32(raw + 446 + 12, 1000);

        auto rep = ImageInspector::inspect(dev).value();
        assert(rep.boot_mode == BootMode::Uefi);
    }

    // 3. Dual / Hybrid image: Active BIOS partition + ESP partition
    {
        auto dev = std::make_shared<MemoryBlockDevice>(10 * 1024 * 1024);
        uint8_t* raw = reinterpret_cast<uint8_t*>(dev->raw_data().data());
        raw[0] = 0xFA; // bootstrap code
        raw[510] = 0x55; raw[511] = 0xAA;
        // Partition 1: Active BIOS NTFS
        raw[446] = 0x80;
        raw[450] = 0x07;
        write_le32(raw + 446 + 8, 2048);
        write_le32(raw + 446 + 12, 1000);
        // Partition 2: ESP
        raw[446 + 16] = 0x00;
        raw[446 + 16 + 4] = 0xEF;
        write_le32(raw + 446 + 16 + 8, 3048);
        write_le32(raw + 446 + 16 + 12, 1000);

        auto rep = ImageInspector::inspect(dev).value();
        assert(rep.boot_mode == BootMode::Dual);
    }

    std::cout << "  PASS: test_boot_mode_recognition\n";
}

void test_filesystem_recognition() {
    std::cout << "[RUN] test_filesystem_recognition\n";

    auto dev = std::make_shared<MemoryBlockDevice>(20 * 1024 * 1024);
    uint8_t* raw = reinterpret_cast<uint8_t*>(dev->raw_data().data());
    raw[510] = 0x55; raw[511] = 0xAA;

    // Partition 1: NTFS at sector 2048
    raw[446] = 0x80;
    raw[450] = 0x07;
    write_le32(raw + 446 + 8, 2048);
    write_le32(raw + 446 + 12, 2000);
    std::memcpy(raw + (2048 * 512) + 3, "NTFS    ", 8);

    // Partition 2: exFAT at sector 4096
    raw[446 + 16] = 0x00;
    raw[446 + 16 + 4] = 0x07;
    write_le32(raw + 446 + 16 + 8, 4096);
    write_le32(raw + 446 + 16 + 12, 2000);
    std::memcpy(raw + (4096 * 512) + 3, "EXFAT   ", 8);

    // Partition 3: FAT16 at sector 6144
    raw[446 + 32] = 0x00;
    raw[446 + 32 + 4] = 0x06;
    write_le32(raw + 446 + 32 + 8, 6144);
    write_le32(raw + 446 + 32 + 12, 2000);
    std::memcpy(raw + (6144 * 512) + 54, "FAT16   ", 8);

    auto rep = ImageInspector::inspect(dev).value();
    assert(rep.partitions.size() == 3);
    assert(rep.partitions[0].filesystem == FilesystemType::Ntfs);
    assert(rep.partitions[1].filesystem == FilesystemType::ExFat);
    assert(rep.partitions[2].filesystem == FilesystemType::Fat16);

    std::cout << "  PASS: test_filesystem_recognition\n";
}

void test_raw_image_backend() {
    std::cout << "[RUN] test_raw_image_backend\n";

    const std::filesystem::path temp_img = "test_raw_image.img";
    if (std::filesystem::exists(temp_img)) {
        std::filesystem::remove(temp_img);
    }

    // Create a 64 KiB test file
    {
        std::ofstream out(temp_img, std::ios_base::binary);
        std::vector<char> dummy(65536, 0x41); // 'A'
        out.write(dummy.data(), dummy.size());
    }

    auto raw_res = RawImageBackend::open(temp_img, true);
    assert(raw_res.is_ok());
    auto raw_dev = raw_res.value();

    assert(raw_dev->size() == 65536);
    assert(raw_dev->is_read_only());

    // Read payload
    std::vector<std::byte> buf(16);
    auto read_res = raw_dev->read(100, buf);
    assert(read_res.is_ok());
    assert(read_res.value() == 16);
    for (auto b : buf) {
        assert(static_cast<char>(b) == 'A');
    }

    // Out of bounds read
    auto oob = raw_dev->read(65530, buf);
    assert(oob.is_err());
    assert(oob.error().code() == ErrorCode::StorageFailure);

    // Reject write on read-only backend
    auto wr = raw_dev->write(0, buf);
    assert(wr.is_err());

    raw_dev.reset();
    std::filesystem::remove(temp_img);

    std::cout << "  PASS: test_raw_image_backend\n";
}

void test_vhd_image_backend() {
    std::cout << "[RUN] test_vhd_image_backend\n";

    const std::filesystem::path temp_vhd = "test_fixed.vhd";
    if (std::filesystem::exists(temp_vhd)) {
        std::filesystem::remove(temp_vhd);
    }

    constexpr uint64_t virtual_size = 1048576; // 1 MiB
    // Create Fixed VHD: 1 MiB payload + 512 byte footer
    {
        std::ofstream out(temp_vhd, std::ios_base::binary);
        std::vector<uint8_t> payload(virtual_size, 0x20); // space
        // Put MBR signature at byte 510
        payload[510] = 0x55;
        payload[511] = 0xAA;
        out.write(reinterpret_cast<const char*>(payload.data()), payload.size());

        // Craft 512-byte VHD footer
        uint8_t footer[512] = {0};
        std::memcpy(footer, "conectix", 8);
        write_be32(footer + 8, 0x00000002);          // Features
        write_be32(footer + 12, 0x00010000);         // Format version 1.0
        write_be64(footer + 16, 0xFFFFFFFFFFFFFFFF); // Data offset (fixed disk)
        write_be64(footer + 48, virtual_size);       // Current size
        write_be32(footer + 60, 2);                  // Disk type = 2 (Fixed)

        // Calculate ones-complement checksum
        uint32_t sum = 0;
        for (size_t i = 0; i < 512; ++i) {
            sum += footer[i];
        }
        write_be32(footer + 64, ~sum);

        out.write(reinterpret_cast<const char*>(footer), 512);
    }

    assert(VhdImageBackend::is_vhd(temp_vhd));

    auto vhd_res = VhdImageBackend::open(temp_vhd, true);
    assert(vhd_res.is_ok());
    auto vhd = vhd_res.value();

    assert(vhd->size() == virtual_size);
    assert(vhd->metadata().format == ImageFormat::VhdFixed);
    assert(vhd->metadata().checksum_valid);

    // Read virtual sector 0 through VHD translation
    uint8_t sector0[512];
    auto read_res = vhd->read(0, std::span<std::byte>(reinterpret_cast<std::byte*>(sector0), 512));
    assert(read_res.is_ok());
    assert(read_res.value() == 512);
    assert(sector0[510] == 0x55);
    assert(sector0[511] == 0xAA);

    vhd.reset();
    std::filesystem::remove(temp_vhd);

    std::cout << "  PASS: test_vhd_image_backend\n";
}

void test_golden_image_readonly_invariant() {
    std::cout << "[RUN] test_golden_image_readonly_invariant\n";

    const std::filesystem::path temp_path = "golden_win10.raw";
    if (std::filesystem::exists(temp_path)) {
        std::filesystem::remove(temp_path);
    }

    // Create 1 MiB image
    {
        std::ofstream out(temp_path, std::ios_base::binary);
        std::vector<char> data(1048576, 0x55);
        out.write(data.data(), data.size());
    }

    auto golden_res = GoldenImage::open(temp_path, ImageId("win10_pro_gold"));
    assert(golden_res.is_ok());
    auto golden = golden_res.value();

    assert(golden->id().value() == "win10_pro_gold");
    assert(golden->is_read_only());
    assert(golden->device()->is_read_only());
    assert(golden->virtual_size() == 1048576);

    // Attempting write MUST be rejected
    const char write_data[] = "Malicious or accidental write from client";
    std::span<const std::byte> bad_write(
        reinterpret_cast<const std::byte*>(write_data),
        std::strlen(write_data)
    );

    auto write_attempt = golden->device()->write(0, bad_write);
    assert(write_attempt.is_err());
    assert(write_attempt.error().code() == ErrorCode::StorageFailure);

    // Prove file remains untouched on disk
    golden.reset();
    {
        std::ifstream in(temp_path, std::ios_base::binary);
        char ch;
        in.read(&ch, 1);
        assert(ch == 0x55);
    }
    std::filesystem::remove(temp_path);

    std::cout << "  PASS: test_golden_image_readonly_invariant\n";
}

void test_golden_image_registry() {
    std::cout << "[RUN] test_golden_image_registry\n";

    const std::filesystem::path img1 = "reg_test1.raw";
    const std::filesystem::path img2 = "reg_test2.raw";

    {
        std::ofstream o1(img1, std::ios_base::binary);
        std::vector<char> d1(4096, 0x01);
        o1.write(d1.data(), d1.size());

        std::ofstream o2(img2, std::ios_base::binary);
        std::vector<char> d2(4096, 0x02);
        o2.write(d2.data(), d2.size());
    }

    GoldenImageRegistry registry;
    assert(registry.count() == 0);

    auto g1 = registry.register_image(img1, ImageId("img-01"));
    assert(g1.is_ok());
    assert(registry.count() == 1);
    assert(registry.has_image(ImageId("img-01")));

    auto g2 = registry.register_image(img2, ImageId("img-02"));
    assert(g2.is_ok());
    assert(registry.count() == 2);

    // Reject duplicate ID
    auto dup = registry.register_image(img1, ImageId("img-01"));
    assert(dup.is_err());
    assert(registry.count() == 2);

    // Lookup
    auto found = registry.find_image(ImageId("img-01"));
    assert(found != nullptr);
    assert(found->id().value() == "img-01");

    auto not_found = registry.find_image(ImageId("img-99"));
    assert(not_found == nullptr);

    // List IDs
    auto list = registry.list_images();
    assert(list.size() == 2);

    // Unregister
    assert(registry.unregister_image(ImageId("img-01")).is_ok());
    assert(registry.count() == 1);
    assert(!registry.has_image(ImageId("img-01")));

    registry.clear();
    assert(registry.count() == 0);

    std::filesystem::remove(img1);
    std::filesystem::remove(img2);

    std::cout << "  PASS: test_golden_image_registry\n";
}

// =============================================================================
// Phase 5 Setup Wizard, Persistence & Storage Benchmarking Tests
// =============================================================================

void test_configuration_persistence_and_directories() {
    std::cout << "[RUN] test_configuration_persistence_and_directories\n";

    const std::filesystem::path cfg_file = "test_persist.conf";
    const std::filesystem::path test_wb = "./test_persist_wb";
    const std::filesystem::path test_os = "./test_persist_os";
    const std::filesystem::path test_gm = "./test_persist_gm";
    const std::filesystem::path test_ch = "./test_persist_ch";

    if (std::filesystem::exists(cfg_file)) std::filesystem::remove(cfg_file);

    Configuration cfg;
    cfg.set_server_address(NetworkAddress(192, 168, 1, 100, 3260));
    cfg.set_network_interface("eth0");
    cfg.set_writeback_dir(test_wb);
    cfg.set_os_images_dir(test_os);
    cfg.set_games_dir(test_gm);
    cfg.set_cache_dir(test_ch);
    cfg.set_first_run_completed(true);
    cfg.set_max_clients(128);

    assert(cfg.validate().is_ok());

    // Ensure directories exist
    auto dir_res = cfg.ensure_directories_exist();
    assert(dir_res.is_ok());
    assert(std::filesystem::exists(test_wb));
    assert(std::filesystem::exists(test_os));
    assert(std::filesystem::exists(test_gm));
    assert(std::filesystem::exists(test_ch));

    // Save to file
    auto save_res = cfg.save_to_file(cfg_file);
    assert(save_res.is_ok());
    assert(std::filesystem::exists(cfg_file));

    // Load from file into new configuration
    Configuration loaded;
    auto load_res = loaded.load_from_file(cfg_file);
    assert(load_res.is_ok());

    assert(loaded.server_address().ip_string() == "192.168.1.100");
    assert(loaded.server_address().port() == 3260);
    assert(loaded.network_interface() == "eth0");
    assert(loaded.writeback_dir() == test_wb);
    assert(loaded.os_images_dir() == test_os);
    assert(loaded.games_dir() == test_gm);
    assert(loaded.cache_dir() == test_ch);
    assert(loaded.first_run_completed() == true);
    assert(loaded.max_clients() == 128);

    // Cleanup
    std::filesystem::remove(cfg_file);
    std::filesystem::remove_all(test_wb);
    std::filesystem::remove_all(test_os);
    std::filesystem::remove_all(test_gm);
    std::filesystem::remove_all(test_ch);

    std::cout << "  PASS: test_configuration_persistence_and_directories\n";
}

void test_storage_tester_health_and_benchmark() {
    std::cout << "[RUN] test_storage_tester_health_and_benchmark\n";

    const std::filesystem::path bench_dir = "./test_storage_bench";
    std::error_code ec;
    std::filesystem::remove_all(bench_dir, ec);

    // 1. Health check (creates dir if missing, checks free space, validates write probe)
    auto health_res = StorageTester::check_storage_health(bench_dir);
    assert(health_res.is_ok());
    const auto& health = health_res.value();
    assert(health.passed);
    assert(health.total_space_bytes > 0);
    assert(health.free_space_bytes > 0);

    // 2. Fast benchmark (1 MiB with 64 KiB blocks for fast test execution)
    auto bench_res = StorageTester::run_benchmark(bench_dir, 1024 * 1024, 64 * 1024);
    assert(bench_res.is_ok());
    const auto& bench = bench_res.value();
    assert(bench.passed);
    assert(bench.sequential_write_mbps > 0.0);
    assert(bench.sequential_read_mbps > 0.0);

    // Cleanup
    std::filesystem::remove_all(bench_dir, ec);

    std::cout << "  PASS: test_storage_tester_health_and_benchmark\n";
}

// =============================================================================
// Phase 6 Image Management, Validation & Safe Handling Tests
// =============================================================================

void test_image_manager_lifecycle_and_safe_handling() {
    std::cout << "[RUN] test_image_manager_lifecycle_and_safe_handling\n";

    const std::filesystem::path test_dir = "./test_img_mgr";
    const std::filesystem::path os_dir = test_dir / "os";
    const std::filesystem::path games_dir = test_dir / "games";
    const std::filesystem::path wb_dir = test_dir / "wb";
    const std::filesystem::path cache_dir = test_dir / "cache";

    std::error_code ec;
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(os_dir, ec);
    std::filesystem::create_directories(games_dir, ec);
    std::filesystem::create_directories(wb_dir, ec);
    std::filesystem::create_directories(cache_dir, ec);

    // Create a mock OS image
    const std::filesystem::path win11_path = os_dir / "win11_pro.raw";
    {
        std::ofstream out(win11_path, std::ios::binary);
        std::vector<char> dummy(1048576, 0x11);
        out.write(dummy.data(), dummy.size());
    }

    // Create a mock Game image
    const std::filesystem::path game_path = games_dir / "cyberpunk.raw";
    {
        std::ofstream out(game_path, std::ios::binary);
        std::vector<char> dummy(2097152, 0x22);
        out.write(dummy.data(), dummy.size());
    }

    Configuration cfg;
    cfg.set_os_images_dir(os_dir);
    cfg.set_games_dir(games_dir);
    cfg.set_writeback_dir(wb_dir);
    cfg.set_cache_dir(cache_dir);

    auto registry = std::make_shared<GoldenImageRegistry>();
    ImageManager manager(registry);
    manager.configure(cfg);

    // 1. Directory scan
    auto scan_res = manager.scan_directories();
    assert(scan_res.is_ok());
    assert(scan_res.value() == 2);

    assert(manager.list_all_images().size() == 2);
    assert(manager.list_images(ImageRole::OsImage).size() == 1);
    assert(manager.list_images(ImageRole::GameDisk).size() == 1);

    // 2. Storage usage report
    auto usage = manager.get_storage_usage();
    assert(usage.os_images_bytes == 1048576);
    assert(usage.game_images_bytes == 2097152);

    // 3. Image validation
    auto val_res = manager.validate_image(ImageId("win11_pro"));
    assert(val_res.is_ok());
    assert(val_res.value().health_status == ImageHealthStatus::Healthy);

    // 4. Safe image handling: Acquire reference
    auto acq_res = manager.acquire_image(ImageId("win11_pro"));
    assert(acq_res.is_ok());
    assert(acq_res.value() != nullptr);

    // Verify info shows active reference
    auto info_res = manager.get_image_info(ImageId("win11_pro"));
    assert(info_res.is_ok());
    assert(info_res.value().active_references == 1);

    // 5. Invariant: Attempting to remove an image with active client references MUST FAIL
    auto remove_fail = manager.remove_image(ImageId("win11_pro"), false);
    assert(remove_fail.is_err());
    assert(remove_fail.error().code() == ErrorCode::StorageFailure);

    // 6. Release reference and remove safely
    assert(manager.release_image(ImageId("win11_pro")).is_ok());
    auto remove_ok = manager.remove_image(ImageId("win11_pro"), true); // delete file on disk
    assert(remove_ok.is_ok());
    assert(!std::filesystem::exists(win11_path));
    assert(manager.list_images(ImageRole::OsImage).empty());

    // Cleanup
    std::filesystem::remove_all(test_dir, ec);

    std::cout << "  PASS: test_image_manager_lifecycle_and_safe_handling\n";
}

// =============================================================================
// Phase 7 Client Copy-On-Write (COW) & Writeback Tests
// =============================================================================

void test_cow_block_device_lifecycle() {
    std::cout << "[RUN] test_cow_block_device_lifecycle\n";

    const std::filesystem::path base_path = "golden_base.raw";
    const std::filesystem::path cow_path = "client_test.cow";

    std::error_code ec;
    std::filesystem::remove(base_path, ec);
    std::filesystem::remove(cow_path, ec);

    // 1. Create 1 MiB base image filled with 0x11
    {
        std::ofstream base_out(base_path, std::ios::binary);
        std::vector<uint8_t> base_data(1024 * 1024, 0x11);
        base_out.write(reinterpret_cast<const char*>(base_data.data()), base_data.size());
    }

    auto base_dev_res = RawImageBackend::open(base_path, true);
    assert(base_dev_res.is_ok());
    auto base_dev = base_dev_res.value();

    // 2. Create CowBlockDevice
    auto cow_res = CowBlockDevice::create(base_dev, cow_path, 4096);
    assert(cow_res.is_ok());
    auto cow = cow_res.value();

    assert(cow->is_open());
    assert(!cow->is_read_only());
    assert(cow->size_bytes() == 1024 * 1024);
    assert(cow->allocated_chunks() == 0);

    // 3. Read before write: should read through to base image (0x11)
    std::vector<std::byte> buf(4096, std::byte{0});
    auto r1 = cow->read(0, buf);
    assert(r1.is_ok());
    assert(r1.value() == 4096);
    assert(std::to_integer<int>(buf[0]) == 0x11);

    // 4. Write modified data to chunk 0
    std::vector<std::byte> write_data(4096, std::byte{0xAA});
    auto w1 = cow->write(0, write_data);
    assert(w1.is_ok());
    assert(w1.value() == 4096);
    assert(cow->allocated_chunks() == 1);
    assert(cow->dirty_bytes() == 4096);

    // 5. Read back modified chunk: should return 0xAA
    std::fill(buf.begin(), buf.end(), std::byte{0});
    auto r2 = cow->read(0, buf);
    assert(r2.is_ok());
    assert(std::to_integer<int>(buf[0]) == 0xAA);

    // 6. Read unmodified chunk 1: should still return 0x11 from base image
    std::fill(buf.begin(), buf.end(), std::byte{0});
    auto r3 = cow->read(4096, buf);
    assert(r3.is_ok());
    assert(std::to_integer<int>(buf[0]) == 0x11);

    // 7. Verify base image file is STRICTLY UNTOUCHED
    {
        std::ifstream verify_base(base_path, std::ios::binary);
        char ch;
        verify_base.read(&ch, 1);
        assert(static_cast<uint8_t>(ch) == 0x11);
    }

    // 8. Client Reset: wipe overlay and restore pristine state
    assert(cow->reset().is_ok());
    assert(cow->allocated_chunks() == 0);

    std::fill(buf.begin(), buf.end(), std::byte{0});
    auto r4 = cow->read(0, buf);
    assert(r4.is_ok());
    assert(std::to_integer<int>(buf[0]) == 0x11); // Restored!

    // Cleanup
    cow->close();
    base_dev.reset();
    std::filesystem::remove(base_path, ec);
    std::filesystem::remove(cow_path, ec);

    std::cout << "  PASS: test_cow_block_device_lifecycle\n";
}

void test_client_session_manager_isolation() {
    std::cout << "[RUN] test_client_session_manager_isolation\n";

    const std::filesystem::path test_dir = "./test_sessions";
    const std::filesystem::path os_dir = test_dir / "os";
    const std::filesystem::path wb_dir = test_dir / "wb";

    std::error_code ec;
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(os_dir, ec);
    std::filesystem::create_directories(wb_dir, ec);

    const std::filesystem::path win10_path = os_dir / "win10.raw";
    {
        std::ofstream out(win10_path, std::ios::binary);
        std::vector<uint8_t> base_data(512 * 1024, 0x55);
        out.write(reinterpret_cast<const char*>(base_data.data()), base_data.size());
    }

    Configuration cfg;
    cfg.set_os_images_dir(os_dir);
    cfg.set_writeback_dir(wb_dir);

    auto registry = std::make_shared<GoldenImageRegistry>();
    auto image_mgr = std::make_shared<ImageManager>(registry);
    image_mgr->configure(cfg);
    auto import_res = image_mgr->import_image(win10_path, ImageRole::OsImage, ImageId("win10"));
    assert(import_res.is_ok());

    ClientSessionManager session_mgr(image_mgr, wb_dir);

    // Client 1 (PC-01) connects
    ClientId c1("00:11:22:33:44:01");
    auto s1_res = session_mgr.get_or_create_session(c1, NetworkAddress(192, 168, 1, 101), ImageId("win10"));
    assert(s1_res.is_ok());
    auto s1 = s1_res.value();

    // Client 2 (PC-02) connects
    ClientId c2("00:11:22:33:44:02");
    auto s2_res = session_mgr.get_or_create_session(c2, NetworkAddress(192, 168, 1, 102), ImageId("win10"));
    assert(s2_res.is_ok());
    auto s2 = s2_res.value();

    assert(session_mgr.active_clients_count() == 2);

    // Client 1 writes 0xAA to block 0
    std::vector<std::byte> c1_write(512, std::byte{0xAA});
    assert(s1->cow_device()->write(0, c1_write).is_ok());

    // Client 2 writes 0xBB to block 0
    std::vector<std::byte> c2_write(512, std::byte{0xBB});
    assert(s2->cow_device()->write(0, c2_write).is_ok());

    // Verify isolation: Client 1 reads 0xAA, Client 2 reads 0xBB
    std::vector<std::byte> read_buf(512, std::byte{0});
    assert(s1->cow_device()->read(0, read_buf).is_ok());
    assert(std::to_integer<int>(read_buf[0]) == 0xAA);

    assert(s2->cow_device()->read(0, read_buf).is_ok());
    assert(std::to_integer<int>(read_buf[0]) == 0xBB);

    // Reset Client 1
    assert(session_mgr.reset_client(c1).is_ok());
    assert(s1->cow_device()->read(0, read_buf).is_ok());
    assert(std::to_integer<int>(read_buf[0]) == 0x55); // Restored to base image

    // Client 2 remains unaffected (still 0xBB)
    assert(s2->cow_device()->read(0, read_buf).is_ok());
    assert(std::to_integer<int>(read_buf[0]) == 0xBB);

    // Terminate both
    assert(session_mgr.terminate_session(c1).is_ok());
    assert(session_mgr.terminate_session(c2).is_ok());
    assert(session_mgr.active_clients_count() == 0);

    // Cleanup
    std::filesystem::remove_all(test_dir, ec);

    std::cout << "  PASS: test_client_session_manager_isolation\n";
}

// =============================================================================
// Phase 8 Network Boot (DHCP, PXE, TFTP & iPXE Architecture Detection) Tests
// =============================================================================

void test_dhcp_architecture_detection_and_pxe_provisioning() {
    std::cout << "[RUN] test_dhcp_architecture_detection_and_pxe_provisioning\n";

    DhcpServer server(NetworkAddress(192, 168, 1, 1));

    // 1. BIOS Client (Arch 0): DHCPDISCOVER with Option 93 = 0
    DhcpHeader bios_hdr{};
    bios_hdr.op = 1;
    bios_hdr.htype = 1;
    bios_hdr.hlen = 6;
    bios_hdr.xid = 0x12345678;
    bios_hdr.magic_cookie[0] = 99; bios_hdr.magic_cookie[1] = 130;
    bios_hdr.magic_cookie[2] = 83; bios_hdr.magic_cookie[3] = 99;
    bios_hdr.chaddr[0] = 0x00; bios_hdr.chaddr[1] = 0x11; bios_hdr.chaddr[2] = 0x22;
    bios_hdr.chaddr[3] = 0x33; bios_hdr.chaddr[4] = 0x44; bios_hdr.chaddr[5] = 0x55;

    std::vector<uint8_t> bios_packet(reinterpret_cast<const uint8_t*>(&bios_hdr),
                                      reinterpret_cast<const uint8_t*>(&bios_hdr) + sizeof(DhcpHeader));

    // Option 53 (Discover)
    bios_packet.push_back(53); bios_packet.push_back(1); bios_packet.push_back(1);
    // Option 93 (Client Arch: 0 = BIOS x86)
    bios_packet.push_back(93); bios_packet.push_back(2); bios_packet.push_back(0); bios_packet.push_back(0);
    bios_packet.push_back(255); // End

    auto bios_parse = DhcpServer::parse_packet(bios_packet);
    assert(bios_parse.is_ok());
    assert(bios_parse.value().client_arch == ClientArch::Bios_x86);
    assert(!bios_parse.value().is_ipxe_client);
    assert(bios_parse.value().client_mac == "00:11:22:33:44:55");

    auto bios_reply = server.build_reply(bios_hdr, bios_parse.value(), 2, NetworkAddress(192, 168, 1, 100));
    assert(bios_reply.is_ok());
    const auto* reply_hdr = reinterpret_cast<const DhcpHeader*>(bios_reply.value().data());
    assert(std::string(reinterpret_cast<const char*>(reply_hdr->file)) == "undionly.kpxe");

    // 2. UEFI Client (Arch 7): DHCPDISCOVER with Option 93 = 7
    DhcpHeader uefi_hdr{};
    uefi_hdr.op = 1;
    uefi_hdr.htype = 1;
    uefi_hdr.hlen = 6;
    uefi_hdr.xid = 0x87654321;
    uefi_hdr.magic_cookie[0] = 99; uefi_hdr.magic_cookie[1] = 130;
    uefi_hdr.magic_cookie[2] = 83; uefi_hdr.magic_cookie[3] = 99;
    uefi_hdr.chaddr[0] = 0xAA; uefi_hdr.chaddr[1] = 0xBB; uefi_hdr.chaddr[2] = 0xCC;
    uefi_hdr.chaddr[3] = 0xDD; uefi_hdr.chaddr[4] = 0xEE; uefi_hdr.chaddr[5] = 0xFF;

    std::vector<uint8_t> uefi_packet(reinterpret_cast<const uint8_t*>(&uefi_hdr),
                                      reinterpret_cast<const uint8_t*>(&uefi_hdr) + sizeof(DhcpHeader));

    uefi_packet.push_back(53); uefi_packet.push_back(1); uefi_packet.push_back(1);
    uefi_packet.push_back(93); uefi_packet.push_back(2); uefi_packet.push_back(0); uefi_packet.push_back(7); // Arch 7
    uefi_packet.push_back(255);

    auto uefi_parse = DhcpServer::parse_packet(uefi_packet);
    assert(uefi_parse.is_ok());
    assert(uefi_parse.value().client_arch == ClientArch::Efi_x64);

    auto uefi_reply = server.build_reply(uefi_hdr, uefi_parse.value(), 2, NetworkAddress(192, 168, 1, 101));
    assert(uefi_reply.is_ok());
    const auto* uefi_reply_hdr = reinterpret_cast<const DhcpHeader*>(uefi_reply.value().data());
    assert(std::string(reinterpret_cast<const char*>(uefi_reply_hdr->file)) == "ipxe.efi");

    // 3. iPXE Client Stage 2: DHCPREQUEST with Option 175
    DhcpHeader ipxe_hdr{};
    ipxe_hdr.op = 1;
    ipxe_hdr.htype = 1;
    ipxe_hdr.hlen = 6;
    ipxe_hdr.xid = 0x99999999;
    ipxe_hdr.magic_cookie[0] = 99; ipxe_hdr.magic_cookie[1] = 130;
    ipxe_hdr.magic_cookie[2] = 83; ipxe_hdr.magic_cookie[3] = 99;
    std::memcpy(ipxe_hdr.chaddr, uefi_hdr.chaddr, 16);

    std::vector<uint8_t> ipxe_packet(reinterpret_cast<const uint8_t*>(&ipxe_hdr),
                                      reinterpret_cast<const uint8_t*>(&ipxe_hdr) + sizeof(DhcpHeader));

    ipxe_packet.push_back(53); ipxe_packet.push_back(1); ipxe_packet.push_back(3); // Request
    ipxe_packet.push_back(175); ipxe_packet.push_back(1); ipxe_packet.push_back(1); // iPXE option
    ipxe_packet.push_back(255);

    auto ipxe_parse = DhcpServer::parse_packet(ipxe_packet);
    assert(ipxe_parse.is_ok());
    assert(ipxe_parse.value().is_ipxe_client);

    auto ipxe_reply = server.build_reply(ipxe_hdr, ipxe_parse.value(), 5, NetworkAddress(192, 168, 1, 101));
    assert(ipxe_reply.is_ok());
    const auto* ipxe_reply_hdr = reinterpret_cast<const DhcpHeader*>(ipxe_reply.value().data());
    assert(std::string(reinterpret_cast<const char*>(ipxe_reply_hdr->file)) == "boot.ipxe");

    std::cout << "  PASS: test_dhcp_architecture_detection_and_pxe_provisioning\n";
}

void test_tftp_server_virtual_payloads_and_ipxe_script() {
    std::cout << "[RUN] test_tftp_server_virtual_payloads_and_ipxe_script\n";

    TftpServer server(NetworkAddress(192, 168, 1, 1));

    // 1. Dynamic iPXE script generation
    std::string script = server.generate_ipxe_script("iqn.2026-09.com.cobdiskless:storage");
    assert(script.find("#!ipxe") != std::string::npos);
    assert(script.find("sanboot iscsi:192.168.1.1::::iqn.2026-09.com.cobdiskless:storage") != std::string::npos);

    // 2. Virtual file content checks
    auto ipxe_res = server.get_file_content("boot.ipxe");
    assert(ipxe_res.is_ok());
    assert(!ipxe_res.value().empty());

    auto bios_stage1 = server.get_file_content("undionly.kpxe");
    assert(bios_stage1.is_ok());
    assert(!bios_stage1.value().empty());

    auto uefi_stage1 = server.get_file_content("ipxe.efi");
    assert(uefi_stage1.is_ok());
    assert(!uefi_stage1.value().empty());

    // 3. TFTP Packet serialization
    std::vector<uint8_t> payload = {0x01, 0x02, 0x03, 0x04};
    auto data_pkt = TftpServer::create_data_packet(1, payload);
    assert(data_pkt.size() == 8);
    assert(data_pkt[1] == 0x03); // DATA opcode
    assert(data_pkt[3] == 0x01); // Block 1

    auto ack_pkt = TftpServer::create_ack_packet(1);
    assert(ack_pkt.size() == 4);
    assert(ack_pkt[1] == 0x04); // ACK opcode
    assert(ack_pkt[3] == 0x01); // Block 1

    auto err_pkt = TftpServer::create_error_packet(1, "File not found");
    assert(err_pkt.size() > 5);
    assert(err_pkt[1] == 0x05); // ERROR opcode

    std::cout << "  PASS: test_tftp_server_virtual_payloads_and_ipxe_script\n";
}

// =============================================================================
// Phase 9 Network Disk Service (iSCSI Target & Multi-Client Transport) Tests
// =============================================================================

void test_iscsi_target_scsi_emulation_and_client_dispatch() {
    std::cout << "[RUN] test_iscsi_target_scsi_emulation_and_client_dispatch\n";

    // 1. Test INQUIRY response
    uint8_t cdb_inquiry[16] = {0x12, 0, 0, 0, 36, 0};
    auto inq_res = IscsiTarget::handle_inquiry(cdb_inquiry);
    assert(inq_res.is_ok());
    const auto& inq = inq_res.value();
    assert(inq.size() == 36);
    assert(inq[0] == 0x00); // Direct access block device
    assert(std::string(reinterpret_cast<const char*>(inq.data() + 8), 8) == "COB     ");
    assert(std::string(reinterpret_cast<const char*>(inq.data() + 16), 16) == "CobDiskless SAN ");

    // 2. Test READ CAPACITY (10)
    // 1000 sectors, 512 bytes each
    auto cap_res = IscsiTarget::handle_read_capacity(1000, 512);
    assert(cap_res.is_ok());
    const auto& cap = cap_res.value();
    assert(cap.size() == 8);
    // Last LBA = 999 (0x000003E7)
    uint32_t last_lba = (cap[0] << 24) | (cap[1] << 16) | (cap[2] << 8) | cap[3];
    assert(last_lba == 999);
    // Block size = 512 (0x00000200)
    uint32_t blk_size = (cap[4] << 24) | (cap[5] << 16) | (cap[6] << 8) | cap[7];
    assert(blk_size == 512);

    // 3. Test SCSI Read/Write dispatch through ClientSession and COW overlay
    const std::filesystem::path test_dir = "./test_iscsi_dispatch";
    const std::filesystem::path base_path = test_dir / "golden_os.raw";
    const std::filesystem::path wb_dir = test_dir / "wb";

    std::error_code ec;
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);
    std::filesystem::create_directories(wb_dir, ec);

    // Create 1 MiB base image filled with 0x33
    {
        std::ofstream base_out(base_path, std::ios::binary);
        std::vector<uint8_t> data(1024 * 1024, 0x33);
        base_out.write(reinterpret_cast<const char*>(data.data()), data.size());
    }

    Configuration cfg;
    cfg.set_os_images_dir(test_dir);
    cfg.set_writeback_dir(wb_dir);

    auto registry = std::make_shared<GoldenImageRegistry>();
    auto img_mgr = std::make_shared<ImageManager>(registry);
    img_mgr->configure(cfg);
    assert(img_mgr->import_image(base_path, ImageRole::OsImage, ImageId("os_image")).is_ok());

    auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, wb_dir);

    IscsiTargetConfig target_cfg;
    target_cfg.default_os_image_id = ImageId("os_image");
    IscsiTarget target(target_cfg, sess_mgr);

    ClientId client_id("00:50:56:C0:00:08");
    auto session_res = sess_mgr->get_or_create_session(client_id, NetworkAddress(192, 168, 1, 150), ImageId("os_image"));
    assert(session_res.is_ok());
    auto session = session_res.value();

    // Read Sector 10 before write -> should return base image byte 0x33
    std::vector<std::byte> read_buf(512, std::byte{0});
    auto r1 = IscsiTarget::execute_read(*session, 10, 1, read_buf);
    assert(r1.is_ok());
    assert(r1.value() == 512);
    assert(std::to_integer<int>(read_buf[0]) == 0x33);
    assert(session->bytes_read() == 512);

    // Write Sector 10 with 0x77
    std::vector<std::byte> write_buf(512, std::byte{0x77});
    auto w1 = IscsiTarget::execute_write(*session, 10, 1, write_buf);
    assert(w1.is_ok());
    assert(w1.value() == 512);
    assert(session->bytes_written() == 512);

    // Read Sector 10 after write -> should return modified byte 0x77 from COW overlay
    std::fill(read_buf.begin(), read_buf.end(), std::byte{0});
    auto r2 = IscsiTarget::execute_read(*session, 10, 1, read_buf);
    assert(r2.is_ok());
    assert(std::to_integer<int>(read_buf[0]) == 0x77);

    // Read Sector 11 -> untouched, still 0x33
    std::fill(read_buf.begin(), read_buf.end(), std::byte{0});
    auto r3 = IscsiTarget::execute_read(*session, 11, 1, read_buf);
    assert(r3.is_ok());
    assert(std::to_integer<int>(read_buf[0]) == 0x33);

    // Terminate session and cleanup
    assert(sess_mgr->terminate_session(client_id).is_ok());
    std::filesystem::remove_all(test_dir, ec);

    std::cout << "  PASS: test_iscsi_target_scsi_emulation_and_client_dispatch\n";
}

static void test_block_cache_lru_and_read_ahead() {
    std::cout << "Running test_block_cache_lru_and_read_ahead...\n";
    std::error_code ec;
    auto test_dir = std::filesystem::current_path() / "test_scratch_cache";
    std::filesystem::create_directories(test_dir, ec);
    auto raw_path = test_dir / "cache_backing.raw";

    // 16 KiB backing file
    const size_t total_size = 16 * 1024;
    {
        std::ofstream ofs(raw_path, std::ios::binary);
        std::vector<uint8_t> init_data(total_size);
        for (size_t i = 0; i < total_size; ++i) {
            init_data[i] = static_cast<uint8_t>(i % 251);
        }
        ofs.write(reinterpret_cast<const char*>(init_data.data()), init_data.size());
    }

    auto raw_backend = RawImageBackend::open(raw_path.string(), false).value();

    // Cache: 4 pages total (1024 bytes / 256 bytes per page), read-ahead window of 2 pages
    const size_t max_cache_bytes = 1024;
    const size_t page_size = 256;
    const size_t read_ahead_pages = 2;

    auto cached_dev = CachedBlockDevice::create(raw_backend, max_cache_bytes, page_size, read_ahead_pages).value();
    assert(cached_dev != nullptr);
    assert(cached_dev->size() == total_size);

    CacheStats s = cached_dev->stats();
    assert(s.hits == 0);
    assert(s.misses == 0);
    assert(s.active_pages == 0);
    assert(s.max_pages == 4);

    // 1. Read first page (256 bytes) -> Miss
    std::vector<std::byte> buf(page_size);
    auto r1 = cached_dev->read(0, buf);
    assert(r1.is_ok() && r1.value() == page_size);
    assert(static_cast<uint8_t>(buf[0]) == 0);
    assert(static_cast<uint8_t>(buf[10]) == 10);

    s = cached_dev->stats();
    assert(s.misses == 1);
    assert(s.hits == 0);
    assert(s.active_pages == 1);

    // 2. Read first page again -> Hit
    auto r2 = cached_dev->read(0, buf);
    assert(r2.is_ok() && r2.value() == page_size);
    s = cached_dev->stats();
    assert(s.misses == 1);
    assert(s.hits == 1);
    assert(s.hit_ratio() == 50.0);

    // 3. Read page 1 sequentially (offset 256) -> Triggers read-ahead for page 2 and page 3!
    auto r3 = cached_dev->read(256, buf);
    assert(r3.is_ok() && r3.value() == page_size);
    s = cached_dev->stats();
    assert(s.misses == 2);
    assert(s.read_ahead_prefetches >= 1);
    // Page 0, 1, 2, 3 should now be cached (active_pages == 4, maxed out)
    assert(s.active_pages == 4);

    // 4. Reading page 2 (offset 512) and page 3 (offset 768) should be hits because of read-ahead!
    auto r4 = cached_dev->read(512, buf);
    assert(r4.is_ok());
    auto r5 = cached_dev->read(768, buf);
    assert(r5.is_ok());
    s = cached_dev->stats();
    assert(s.hits >= 3);

    // 5. Read page 4 (offset 1024) -> Must evict oldest page from LRU
    auto r6 = cached_dev->read(1024, buf);
    assert(r6.is_ok());
    s = cached_dev->stats();
    assert(s.evictions >= 1);
    assert(s.active_pages <= 4);

    // 6. Test write-through and cache invalidation
    std::vector<std::byte> write_data(64, std::byte{0x7F});
    auto w1 = cached_dev->write(1024, write_data);
    assert(w1.is_ok() && w1.value() == 64);

    // Read back modified area
    std::vector<std::byte> read_back(64);
    auto r7 = cached_dev->read(1024, read_back);
    assert(r7.is_ok());
    assert(read_back[0] == std::byte{0x7F});
    assert(read_back[63] == std::byte{0x7F});

    // 7. Clear cache
    cached_dev->clear_cache();
    s = cached_dev->stats();
    assert(s.active_pages == 0);

    raw_backend.reset();
    cached_dev.reset();
    std::filesystem::remove_all(test_dir, ec);

    std::cout << "  PASS: test_block_cache_lru_and_read_ahead\n";
}

static void test_production_hardening_and_recovery() {
    std::cout << "Running test_production_hardening_and_recovery...\n";
    std::error_code ec;
    auto test_dir = std::filesystem::current_path() / "test_scratch_hardening";
    std::filesystem::create_directories(test_dir, ec);

    // 1. Create a dummy base raw image (64 KiB)
    auto base_path = test_dir / "base_img.raw";
    {
        std::ofstream ofs(base_path, std::ios::binary);
        std::vector<uint8_t> zeros(64 * 1024, 0xAA);
        ofs.write(reinterpret_cast<const char*>(zeros.data()), zeros.size());
    }
    auto base_dev = RawImageBackend::open(base_path.string(), false).value();

    // 2. Corrupt COW file test (bad magic)
    auto corrupt_cow_path = test_dir / "bad_magic.cow";
    {
        std::ofstream ofs(corrupt_cow_path, std::ios::binary);
        ofs.write("BAD!CORRUPT_DATA", 16);
    }
    // Attempting to open bad_magic.cow directly fails
    auto dev_fail = CowBlockDevice::create(base_dev, corrupt_cow_path);
    assert(!dev_fail.is_ok());

    // 3. Quarantine corrupted overlay test
    assert(CowBlockDevice::quarantine_corrupted_overlay(corrupt_cow_path).is_ok());
    assert(!std::filesystem::exists(corrupt_cow_path));
    auto quarantined_path = std::filesystem::path(corrupt_cow_path.string() + ".corrupted");
    assert(std::filesystem::exists(quarantined_path));

    // 4. Truncated COW file auto-recovery test (power failure simulation)
    // Create header specifying 5 allocated chunks, but only write 2 chunk slots to disk
    auto trunc_cow_path = test_dir / "truncated.cow";
    const uint32_t chunk_size = 4096;
    {
        std::ofstream ofs(trunc_cow_path, std::ios::binary);
        // Direct write of CowHeader layout
        struct RawHdr {
            char magic[4];
            uint32_t version;
            uint32_t chunk_size;
            uint32_t reserved;
            uint64_t virtual_capacity;
            uint64_t allocated_chunks;
            uint64_t checksum;
            uint8_t pad[472];
        } hdr{};
        std::memcpy(hdr.magic, "COWB", 4);
        hdr.version = 1;
        hdr.chunk_size = chunk_size;
        hdr.virtual_capacity = base_dev->size();
        hdr.allocated_chunks = 5; // Claims 5 slots exist
        ofs.write(reinterpret_cast<const char*>(&hdr), sizeof(hdr));

        // Write only 2 valid slots:
        // Slot 0: virtual chunk 1
        uint64_t v0 = 1;
        ofs.write(reinterpret_cast<const char*>(&v0), sizeof(v0));
        std::vector<uint8_t> payload0(chunk_size, 0x11);
        ofs.write(reinterpret_cast<const char*>(payload0.data()), payload0.size());

        // Slot 1: virtual chunk 3
        uint64_t v1 = 3;
        ofs.write(reinterpret_cast<const char*>(&v1), sizeof(v1));
        std::vector<uint8_t> payload1(chunk_size, 0x33);
        ofs.write(reinterpret_cast<const char*>(payload1.data()), payload1.size());
        // Abrupt termination here! File truncated before slots 2, 3, 4!
    }

    // Opening truncated.cow should auto-repair and clamp allocated chunks to 2
    auto recovered_cow = CowBlockDevice::create(base_dev, trunc_cow_path, chunk_size);
    assert(recovered_cow.is_ok());
    auto r_dev = recovered_cow.value();
    assert(r_dev->allocated_chunks() == 2);

    // Verify chunk 1 data was preserved
    std::vector<std::byte> read_buf(chunk_size);
    auto read_res = r_dev->read(1 * chunk_size, read_buf);
    assert(read_res.is_ok());
    assert(read_buf[0] == std::byte{0x11});

    // Verify unwritten chunk reads from base device (0xAA)
    read_res = r_dev->read(0, read_buf);
    assert(read_res.is_ok());
    assert(read_buf[0] == std::byte{0xAA});

    r_dev->close();
    r_dev.reset();

    // 5. ClientSessionManager auto-quarantine test
    Configuration cfg;
    cfg.set_os_images_dir(test_dir);
    cfg.set_writeback_dir(test_dir / "writeback");
    auto registry = std::make_shared<GoldenImageRegistry>();
    auto img_mgr = std::make_shared<ImageManager>(registry);
    img_mgr->configure(cfg);
    auto import_res = img_mgr->import_image(base_path, ImageRole::OsImage, ImageId("base_img"));
    assert(import_res.is_ok());
    auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, test_dir / "writeback");

    // Pre-create a corrupt writeback file for client "faulty_pc"
    auto client_wb = test_dir / "writeback" / "wb_faulty_pc.cow";
    std::filesystem::create_directories(client_wb.parent_path(), ec);
    {
        std::ofstream ofs(client_wb, std::ios::binary);
        ofs.write("CORRUPT_HEADER_GARBAGE", 22);
    }
    assert(std::filesystem::exists(client_wb));

    // ClientSessionManager must auto-quarantine faulty_pc.cow and succeed in creating session!
    ClientId cid("faulty_pc");
    NetworkAddress client_ip(192, 168, 1, 99);
    ImageId os_id("base_img");
    auto sess_res = sess_mgr->get_or_create_session(cid, client_ip, os_id);
    assert(sess_res.is_ok());
    assert(std::filesystem::exists(test_dir / "writeback" / "wb_faulty_pc.cow.corrupted"));
    assert(std::filesystem::exists(client_wb));
    assert(sess_res.value()->cow_device()->allocated_chunks() == 0);
    assert(sess_mgr->terminate_session(cid).is_ok());

    // 6. TFTP RRQ safety checks
    // Malformed: no null terminator
    std::vector<uint8_t> malformed_rrq = {0x00, 0x01, 'b', 'o', 'o', 't'};
    auto fn_res = TftpServer::parse_rrq_filename(malformed_rrq);
    assert(!fn_res.is_ok());

    // Traversal attack rejected
    std::vector<uint8_t> traversal_rrq = {0x00, 0x01, '.', '.', '/', 'e', 't', 'c', '/', 'p', 'a', 's', 's', 'w', 'd', 0x00, 'o', 'c', 't', 'e', 't', 0x00};
    fn_res = TftpServer::parse_rrq_filename(traversal_rrq);
    assert(!fn_res.is_ok());

    // Valid RRQ accepted
    std::vector<uint8_t> valid_rrq = {0x00, 0x01, 'b', 'o', 'o', 't', '.', 'i', 'p', 'x', 'e', 0x00, 'o', 'c', 't', 'e', 't', 0x00};
    fn_res = TftpServer::parse_rrq_filename(valid_rrq);
    assert(fn_res.is_ok());
    assert(fn_res.value() == "boot.ipxe");

    // 7. iSCSI Target bounds validation
    IscsiTargetConfig iscsi_cfg;
    iscsi_cfg.default_os_image_id = os_id;
    auto target = std::make_shared<IscsiTarget>(iscsi_cfg, sess_mgr);
    auto sess_ok = sess_mgr->get_or_create_session(cid, client_ip, os_id).value();

    // Out of bounds read: base image is 64 KiB = 128 sectors. Try reading at LBA 130!
    std::vector<std::byte> oob_buf(512);
    auto oob_read = target->execute_read(*sess_ok, 130, 1, oob_buf);
    assert(!oob_read.is_ok());

    auto oob_write = target->execute_write(*sess_ok, 130, 1, oob_buf);
    assert(!oob_write.is_ok());

    assert(sess_mgr->terminate_session(cid).is_ok());
    base_dev.reset();
    std::filesystem::remove_all(test_dir, ec);

    std::cout << "  PASS: test_production_hardening_and_recovery\n";
}

static void test_end_to_end_diskless_boot_pipeline() {
    std::cout << "Running test_end_to_end_diskless_boot_pipeline...\n";
    std::error_code ec;
    auto test_dir = std::filesystem::current_path() / "test_scratch_e2e";
    std::filesystem::create_directories(test_dir / "os_images", ec);
    std::filesystem::create_directories(test_dir / "games", ec);
    std::filesystem::create_directories(test_dir / "writeback", ec);
    std::filesystem::create_directories(test_dir / "cache", ec);

    // 1. Create a pristine golden OS image (256 KiB)
    auto os_image_path = test_dir / "os_images" / "win11_pro.raw";
    const size_t img_size = 256 * 1024;
    {
        std::ofstream ofs(os_image_path, std::ios::binary);
        std::vector<uint8_t> base_data(img_size, 0xEE);
        // Put boot signature at sector 0
        base_data[510] = 0x55;
        base_data[511] = 0xAA;
        ofs.write(reinterpret_cast<const char*>(base_data.data()), base_data.size());
    }

    // 2. Configure system
    Configuration config;
    config.set_server_address(NetworkAddress(192, 168, 1, 10));
    config.set_os_images_dir(test_dir / "os_images");
    config.set_games_dir(test_dir / "games");
    config.set_writeback_dir(test_dir / "writeback");
    config.set_cache_dir(test_dir / "cache");

    // 3. Image Registry & Management
    auto registry = std::make_shared<GoldenImageRegistry>();
    auto img_mgr = std::make_shared<ImageManager>(registry);
    img_mgr->configure(config);
    auto import_res = img_mgr->import_image(os_image_path, ImageRole::OsImage, ImageId("win11_pro"));
    assert(import_res.is_ok());
    assert(registry->count() == 1);

    // 4. Client Session Manager (Multi-tenant COW)
    auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, config.writeback_dir());

    // 5. Build Subsystems
    auto dhcp = std::make_shared<DhcpServer>(
        config.server_address(),
        NetworkAddress(255, 255, 255, 0),
        NetworkAddress(192, 168, 1, 100),
        NetworkAddress(192, 168, 1, 200)
    );

    auto tftp = std::make_shared<TftpServer>(
        config.server_address(),
        config.os_images_dir(),
        10069
    );

    IscsiTargetConfig iscsi_cfg;
    iscsi_cfg.listen_address = NetworkAddress(127, 0, 0, 1, 13260);
    iscsi_cfg.target_iqn = "iqn.2026-09.com.cobdiskless:storage";
    iscsi_cfg.default_os_image_id = ImageId("win11_pro");
    auto iscsi = std::make_shared<IscsiTarget>(iscsi_cfg, sess_mgr);

    // 6. Host in Core and initialize
    Core core(config);
    assert(core.register_subsystem(dhcp).is_ok());
    assert(core.register_subsystem(tftp).is_ok());
    assert(core.register_subsystem(iscsi).is_ok());
    assert(core.initialize().is_ok());
    assert(core.is_initialized());
    assert(dhcp->is_initialized());
    assert(tftp->is_initialized());
    assert(iscsi->is_initialized());

    // =========================================================================
    // PIPELINE STEP 1: DHCP Architecture Detection (UEFI vs BIOS)
    // =========================================================================
    // Client boots with UEFI x64 firmware: DHCPDISCOVER with Option 93 = 7
    DhcpHeader uefi_hdr{};
    uefi_hdr.op = 1;
    uefi_hdr.htype = 1;
    uefi_hdr.hlen = 6;
    uefi_hdr.xid = 0xCAFEBABE;
    uefi_hdr.magic_cookie[0] = 99; uefi_hdr.magic_cookie[1] = 130;
    uefi_hdr.magic_cookie[2] = 83; uefi_hdr.magic_cookie[3] = 99;
    uefi_hdr.chaddr[0] = 0xAA; uefi_hdr.chaddr[1] = 0xBB; uefi_hdr.chaddr[2] = 0xCC;
    uefi_hdr.chaddr[3] = 0x11; uefi_hdr.chaddr[4] = 0x22; uefi_hdr.chaddr[5] = 0x33;

    std::vector<uint8_t> uefi_packet(reinterpret_cast<const uint8_t*>(&uefi_hdr),
                                     reinterpret_cast<const uint8_t*>(&uefi_hdr) + sizeof(uefi_hdr));
    // Option 53: DHCPDISCOVER
    uefi_packet.push_back(53); uefi_packet.push_back(1); uefi_packet.push_back(1);
    // Option 93: UEFI x64
    uefi_packet.push_back(93); uefi_packet.push_back(2); uefi_packet.push_back(0); uefi_packet.push_back(7);
    uefi_packet.push_back(255); // END

    auto uefi_opts = dhcp->parse_packet(uefi_packet);
    assert(uefi_opts.is_ok());
    assert(uefi_opts.value().client_arch == ClientArch::Efi_x64);
    assert(!uefi_opts.value().is_ipxe_client);

    // DHCP Offer responds with ipxe.efi stage-1 loader
    auto uefi_offer = dhcp->build_reply(uefi_hdr, uefi_opts.value(), 2, NetworkAddress(192, 168, 1, 150));
    assert(uefi_offer.is_ok());
    const auto* uefi_reply = reinterpret_cast<const DhcpHeader*>(uefi_offer.value().data());
    assert(std::string(reinterpret_cast<const char*>(uefi_reply->file)) == "ipxe.efi");

    // =========================================================================
    // PIPELINE STEP 2: iPXE Client Identification
    // =========================================================================
    // Client boots ipxe.efi, which sends second DHCPDISCOVER with Option 175
    std::vector<uint8_t> ipxe_packet(reinterpret_cast<const uint8_t*>(&uefi_hdr),
                                     reinterpret_cast<const uint8_t*>(&uefi_hdr) + sizeof(uefi_hdr));
    ipxe_packet.push_back(53); ipxe_packet.push_back(1); ipxe_packet.push_back(1);
    ipxe_packet.push_back(175); ipxe_packet.push_back(1); ipxe_packet.push_back(1);
    ipxe_packet.push_back(255);

    auto ipxe_opts = dhcp->parse_packet(ipxe_packet);
    assert(ipxe_opts.is_ok());
    assert(ipxe_opts.value().is_ipxe_client);

    auto ipxe_offer = dhcp->build_reply(uefi_hdr, ipxe_opts.value(), 2, NetworkAddress(192, 168, 1, 150));
    assert(ipxe_offer.is_ok());
    const auto* ipxe_reply = reinterpret_cast<const DhcpHeader*>(ipxe_offer.value().data());
    assert(std::string(reinterpret_cast<const char*>(ipxe_reply->file)) == "boot.ipxe");

    // =========================================================================
    // PIPELINE STEP 3: TFTP Boot Script Retrieval
    // =========================================================================
    auto script_res = tftp->get_file_content("boot.ipxe");
    assert(script_res.is_ok());
    std::string script_str(script_res.value().begin(), script_res.value().end());
    assert(script_str.find("sanboot iscsi:") != std::string::npos);

    // =========================================================================
    // PIPELINE STEP 4: iSCSI Multi-client Session & Cache Verification
    // =========================================================================
    ClientId client_a("AA:BB:CC:11:22:33");
    NetworkAddress client_a_ip(192, 168, 1, 150);
    auto sess_a_res = sess_mgr->get_or_create_session(client_a, client_a_ip, ImageId("win11_pro"));
    assert(sess_a_res.is_ok());
    auto sess_a = sess_a_res.value();
    sess_a->set_state(ClientState::Online);

    ClientId client_b("AA:BB:CC:99:88:77");
    NetworkAddress client_b_ip(192, 168, 1, 151);
    auto sess_b_res = sess_mgr->get_or_create_session(client_b, client_b_ip, ImageId("win11_pro"));
    assert(sess_b_res.is_ok());
    auto sess_b = sess_b_res.value();
    sess_b->set_state(ClientState::Online);

    assert(sess_mgr->active_clients_count() == 2);

    // Wrap Client A device with CachedBlockDevice
    auto cached_dev_a = CachedBlockDevice::create(sess_a->cow_device(), 32768, 4096, 2).value();

    // Client A: Read sector 0 (MBR)
    std::vector<std::byte> sector_buf(512);
    auto r_a = cached_dev_a->read(0, sector_buf);
    assert(r_a.is_ok() && r_a.value() == 512);
    assert(static_cast<uint8_t>(sector_buf[510]) == 0x55);
    assert(static_cast<uint8_t>(sector_buf[511]) == 0xAA);

    // Cache hit on second read
    assert(cached_dev_a->read(0, sector_buf).is_ok());
    assert(cached_dev_a->stats().hits >= 1);

    // Client A writes 0x42 to sector 10
    std::vector<std::byte> write_buf(512, std::byte{0x42});
    auto w_a = iscsi->execute_write(*sess_a, 10, 1, write_buf);
    assert(w_a.is_ok());

    // Client B reads sector 10 -> MUST get pristine 0xEE from golden image!
    std::vector<std::byte> read_b(512);
    auto r_b = iscsi->execute_read(*sess_b, 10, 1, read_b);
    assert(r_b.is_ok());
    assert(read_b[0] == std::byte{0xEE}); // Completely isolated!

    // Client A reads sector 10 -> MUST get 0x42
    std::vector<std::byte> read_a(512);
    auto r_a2 = iscsi->execute_read(*sess_a, 10, 1, read_a);
    assert(r_a2.is_ok());
    assert(read_a[0] == std::byte{0x42});

    // =========================================================================
    // PIPELINE STEP 5: Instant Zero-Cost Reset
    // =========================================================================
    assert(sess_mgr->reset_client(client_a).is_ok());
    auto r_a_reset = iscsi->execute_read(*sess_a, 10, 1, read_a);
    assert(r_a_reset.is_ok());
    assert(read_a[0] == std::byte{0xEE}); // Restored!

    // =========================================================================
    // PIPELINE STEP 6: Deterministic Core Shutdown
    // =========================================================================
    cached_dev_a.reset();
    assert(sess_mgr->terminate_session(client_a).is_ok());
    assert(sess_mgr->terminate_session(client_b).is_ok());
    core.shutdown();
    assert(!core.is_initialized());

    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_end_to_end_diskless_boot_pipeline\n";
}

// =============================================================================
// PHASE 13: Reality Verification & Hardening Tests
// =============================================================================

void test_vhdx_rejection_and_vhd_handling() {
    std::cout << "[RUN] test_vhdx_rejection_and_vhd_handling\n";
    std::error_code ec;
    std::filesystem::path test_dir = "test_vhdx_env";
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);

    // 1. Synthesize a mock VHDX file with "vhdxfile" header
    std::filesystem::path vhdx_file = test_dir / "test_image.vhdx";
    {
        std::ofstream out(vhdx_file, std::ios::binary);
        std::vector<uint8_t> header(1024 * 1024, 0); // 1 MB
        const char* magic = "vhdxfile";
        std::memcpy(header.data(), magic, 8);
        out.write(reinterpret_cast<const char*>(header.data()), static_cast<std::streamsize>(header.size()));
    }

    // Verify format detection explicitly identifies ImageFormat::Vhdx
    auto format = ImageInspector::detect_format(vhdx_file);
    assert(format == ImageFormat::Vhdx);

    // Verify GoldenImage::open attempts VHDX parsing and rejects corrupted headers with StorageFailure
    auto open_res = GoldenImage::open(vhdx_file, ImageId("vhdx_test"));
    assert(!open_res.is_ok());
    assert(open_res.error().code() == ErrorCode::StorageFailure);

    // 2. Synthesize a valid Fixed VHD with "conectix" footer
    std::filesystem::path vhd_file = test_dir / "test_image.vhd";
    {
        std::ofstream out(vhd_file, std::ios::binary);
        std::vector<uint8_t> disk_data(65536, 0x5A); // 64 KB data
        out.write(reinterpret_cast<const char*>(disk_data.data()), static_cast<std::streamsize>(disk_data.size()));

        // 512-byte conectix footer
        std::vector<uint8_t> footer(512, 0);
        std::memcpy(footer.data(), "conectix", 8);
        // disk_type = 2 (Fixed) at offset 0x3C (big-endian)
        footer[0x3C] = 0x00; footer[0x3D] = 0x00; footer[0x3E] = 0x00; footer[0x3F] = 0x02;
        // current_size at offset 0x30
        uint64_t v_size = 65536;
        for (int i = 0; i < 8; ++i) {
            footer[0x30 + i] = static_cast<uint8_t>((v_size >> ((7 - i) * 8)) & 0xFF);
        }
        uint32_t sum = 0;
        for (size_t i = 0; i < 512; ++i) {
            sum += footer[i];
        }
        uint32_t csum = ~sum;
        footer[64] = static_cast<uint8_t>((csum >> 24) & 0xFF);
        footer[65] = static_cast<uint8_t>((csum >> 16) & 0xFF);
        footer[66] = static_cast<uint8_t>((csum >> 8) & 0xFF);
        footer[67] = static_cast<uint8_t>(csum & 0xFF);
        out.write(reinterpret_cast<const char*>(footer.data()), static_cast<std::streamsize>(footer.size()));
    }

    auto vhd_format = ImageInspector::detect_format(vhd_file);
    assert(vhd_format == ImageFormat::VhdFixed);

    auto vhd_open = GoldenImage::open(vhd_file, ImageId("vhd_fixed_test"));
    assert(vhd_open.is_ok());
    assert(vhd_open.value()->virtual_size() == 65536);

    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_vhdx_rejection_and_vhd_handling\n";
}

void test_real_socket_networking() {
    std::cout << "[RUN] test_real_socket_networking\n";

#if defined(_WIN32)
    WSADATA wsa;
    int wsa_res = WSAStartup(MAKEWORD(2, 2), &wsa);
    assert(wsa_res == 0);
#endif

    std::error_code ec;
    std::filesystem::path test_dir = "test_socket_env";
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);

    // =========================================================================
    // 1. TFTP Server Real UDP Socket Test
    // =========================================================================
    {
        uint16_t tftp_port = 10069;
        TftpServer tftp(NetworkAddress(127, 0, 0, 1), test_dir, tftp_port);
        assert(tftp.initialize().is_ok());
        std::this_thread::sleep_for(std::chrono::milliseconds(50));

        // Create client UDP socket
        SOCKET s_tftp = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        assert(s_tftp != INVALID_SOCKET);

        DWORD tv_ms = 3000;
        setsockopt(s_tftp, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv_ms), sizeof(tv_ms));

        sockaddr_in tftp_srv_addr{};
        tftp_srv_addr.sin_family = AF_INET;
        tftp_srv_addr.sin_port = htons(tftp_port);
        tftp_srv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

        // Send TFTP RRQ for "boot.ipxe" (opcode 1, "boot.ipxe\0octet\0")
        std::vector<uint8_t> rrq = {0x00, 0x01, 'b', 'o', 'o', 't', '.', 'i', 'p', 'x', 'e', 0x00, 'o', 'c', 't', 'e', 't', 0x00};
        int sent = sendto(s_tftp, reinterpret_cast<const char*>(rrq.data()), static_cast<int>(rrq.size()), 0,
                          reinterpret_cast<const sockaddr*>(&tftp_srv_addr), sizeof(tftp_srv_addr));
        assert(sent == static_cast<int>(rrq.size()));

        // Receive real DATA packet
        std::vector<uint8_t> recv_buf(2048);
        sockaddr_in from_addr{};
        int from_len = sizeof(from_addr);
        int recvd = recvfrom(s_tftp, reinterpret_cast<char*>(recv_buf.data()), static_cast<int>(recv_buf.size()), 0,
                             reinterpret_cast<sockaddr*>(&from_addr), &from_len);
        assert(recvd >= 4);
        assert(recv_buf[0] == 0x00 && recv_buf[1] == 0x03); // Opcode 3 (DATA)
        assert(recv_buf[2] == 0x00 && recv_buf[3] == 0x01); // Block 1
        std::string payload(recv_buf.begin() + 4, recv_buf.begin() + recvd);
        assert(payload.find("#!ipxe") != std::string::npos);

        // Test path traversal security rejection
        std::vector<uint8_t> bad_rrq = {0x00, 0x01, '.', '.', '/', 'e', 't', 'c', 0x00, 'o', 'c', 't', 'e', 't', 0x00};
        sent = sendto(s_tftp, reinterpret_cast<const char*>(bad_rrq.data()), static_cast<int>(bad_rrq.size()), 0,
                      reinterpret_cast<const sockaddr*>(&tftp_srv_addr), sizeof(tftp_srv_addr));
        assert(sent == static_cast<int>(bad_rrq.size()));

        recvd = recvfrom(s_tftp, reinterpret_cast<char*>(recv_buf.data()), static_cast<int>(recv_buf.size()), 0,
                         reinterpret_cast<sockaddr*>(&from_addr), &from_len);
        assert(recvd >= 4);
        assert(recv_buf[0] == 0x00 && recv_buf[1] == 0x05); // Opcode 5 (ERROR)

        closesocket(s_tftp);
        tftp.shutdown();
    }

    // =========================================================================
    // 2. DHCP Server Real UDP Socket Test
    // =========================================================================
    {
        uint16_t dhcp_port = 16767;
        DhcpServer dhcp(
            NetworkAddress(127, 0, 0, 1),
            NetworkAddress(255, 255, 255, 0),
            NetworkAddress(192, 168, 1, 100),
            NetworkAddress(192, 168, 1, 200),
            dhcp_port
        );
        assert(dhcp.initialize().is_ok());
        std::this_thread::sleep_for(std::chrono::milliseconds(50));

        SOCKET s_dhcp = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        assert(s_dhcp != INVALID_SOCKET);

        DWORD tv_ms = 3000;
        setsockopt(s_dhcp, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv_ms), sizeof(tv_ms));

        sockaddr_in dhcp_srv_addr{};
        dhcp_srv_addr.sin_family = AF_INET;
        dhcp_srv_addr.sin_port = htons(dhcp_port);
        dhcp_srv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

        // Send real DHCPDISCOVER with Option 93 = 7 (UEFI x64)
        std::vector<uint8_t> d_pkt(sizeof(DhcpHeader) + 64, 0);
        auto* hdr = reinterpret_cast<DhcpHeader*>(d_pkt.data());
        hdr->op = 1; // BOOTREQUEST
        hdr->htype = 1;
        hdr->hlen = 6;
        hdr->xid = htonl(0x11223344);
        hdr->flags = htons(0x8000);
        hdr->chaddr[0] = 0xAA; hdr->chaddr[1] = 0xBB; hdr->chaddr[2] = 0xCC;
        hdr->chaddr[3] = 0xDD; hdr->chaddr[4] = 0xEE; hdr->chaddr[5] = 0xFF;
        hdr->magic_cookie[0] = 99; hdr->magic_cookie[1] = 130; hdr->magic_cookie[2] = 83; hdr->magic_cookie[3] = 99;

        size_t opt_pos = sizeof(DhcpHeader);
        d_pkt[opt_pos++] = 53; d_pkt[opt_pos++] = 1; d_pkt[opt_pos++] = 1; // DHCPDISCOVER
        d_pkt[opt_pos++] = 93; d_pkt[opt_pos++] = 2; d_pkt[opt_pos++] = 0; d_pkt[opt_pos++] = 7; // UEFI x64
        d_pkt[opt_pos++] = 255; // END
        d_pkt.resize(opt_pos);

        int sent = sendto(s_dhcp, reinterpret_cast<const char*>(d_pkt.data()), static_cast<int>(d_pkt.size()), 0,
                          reinterpret_cast<const sockaddr*>(&dhcp_srv_addr), sizeof(dhcp_srv_addr));
        assert(sent == static_cast<int>(d_pkt.size()));

        std::vector<uint8_t> offer_buf(2048);
        sockaddr_in from_addr{};
        int from_len = sizeof(from_addr);
        int recvd = recvfrom(s_dhcp, reinterpret_cast<char*>(offer_buf.data()), static_cast<int>(offer_buf.size()), 0,
                             reinterpret_cast<sockaddr*>(&from_addr), &from_len);
        assert(recvd >= static_cast<int>(sizeof(DhcpHeader)));
        const auto* reply_hdr = reinterpret_cast<const DhcpHeader*>(offer_buf.data());
        assert(reply_hdr->op == 2); // BOOTREPLY
        assert(reply_hdr->xid == htonl(0x11223344));
        assert(std::string(reinterpret_cast<const char*>(reply_hdr->file)) == "ipxe.efi");

        // Test truncated/malformed DHCP packet (must not crash server)
        std::vector<uint8_t> short_pkt = {0x01, 0x01, 0x06, 0x00};
        sendto(s_dhcp, reinterpret_cast<const char*>(short_pkt.data()), static_cast<int>(short_pkt.size()), 0,
               reinterpret_cast<const sockaddr*>(&dhcp_srv_addr), sizeof(dhcp_srv_addr));

        closesocket(s_dhcp);
        dhcp.shutdown();
    }

    // =========================================================================
    // 3. iSCSI Target Real TCP Socket Test
    // =========================================================================
    {
        uint16_t iscsi_port = 13260;
        auto reg = std::make_shared<GoldenImageRegistry>();
        auto img_mgr = std::make_shared<ImageManager>(reg);
        auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, test_dir);

        IscsiTargetConfig cfg;
        cfg.listen_address = NetworkAddress(127, 0, 0, 1, iscsi_port);
        cfg.target_iqn = "iqn.2026-09.com.cobdiskless:storage";
        IscsiTarget target(cfg, sess_mgr);
        assert(target.initialize().is_ok());
        std::this_thread::sleep_for(std::chrono::milliseconds(50));

        SOCKET s_iscsi = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        assert(s_iscsi != INVALID_SOCKET);

        DWORD tv_ms = 3000;
        setsockopt(s_iscsi, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv_ms), sizeof(tv_ms));

        sockaddr_in iscsi_srv_addr{};
        iscsi_srv_addr.sin_family = AF_INET;
        iscsi_srv_addr.sin_port = htons(iscsi_port);
        iscsi_srv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

        int conn = connect(s_iscsi, reinterpret_cast<const sockaddr*>(&iscsi_srv_addr), sizeof(iscsi_srv_addr));
        assert(conn == 0);

        // Send iSCSI Login Request
        IscsiBhs login_req{};
        login_req.opcode = 0x03; // Login Request
        login_req.flags = 0x80;  // Transit bit
        login_req.initiator_task_tag = 0x44332211;
        int sent = send(s_iscsi, reinterpret_cast<const char*>(&login_req), sizeof(login_req), 0);
        assert(sent == sizeof(login_req));

        IscsiBhs login_resp{};
        int recvd = recv(s_iscsi, reinterpret_cast<char*>(&login_resp), sizeof(login_resp), 0);
        assert(recvd == sizeof(login_resp));
        assert((login_resp.opcode & 0x3F) == 0x23); // Login Response
        assert(login_resp.initiator_task_tag == 0x44332211);

        // Send SCSI INQUIRY
        IscsiBhs inq_req{};
        inq_req.opcode = 0x01; // SCSI Command
        inq_req.flags = 0x40;  // Read
        inq_req.initiator_task_tag = 0x55667788;
        inq_req.cdb[0] = 0x12; // INQUIRY
        inq_req.cdb[4] = 36;
        sent = send(s_iscsi, reinterpret_cast<const char*>(&inq_req), sizeof(inq_req), 0);
        assert(sent == sizeof(inq_req));

        IscsiBhs data_in_bhs{};
        recvd = recv(s_iscsi, reinterpret_cast<char*>(&data_in_bhs), sizeof(data_in_bhs), 0);
        assert(recvd == sizeof(data_in_bhs));
        assert((data_in_bhs.opcode & 0x3F) == 0x25); // SCSI Data-In
        assert(data_in_bhs.initiator_task_tag == 0x55667788);

        std::vector<uint8_t> inq_payload(36);
        recvd = recv(s_iscsi, reinterpret_cast<char*>(inq_payload.data()), static_cast<int>(inq_payload.size()), 0);
        assert(recvd == 36);
        std::string vendor(reinterpret_cast<char*>(inq_payload.data() + 8), 8);
        assert(vendor == "COB     ");

        // Send iSCSI Logout Request
        IscsiBhs logout_req{};
        logout_req.opcode = 0x06;
        logout_req.flags = 0x80;
        logout_req.initiator_task_tag = 0x9999;
        send(s_iscsi, reinterpret_cast<const char*>(&logout_req), sizeof(logout_req), 0);

        IscsiBhs logout_resp{};
        recvd = recv(s_iscsi, reinterpret_cast<char*>(&logout_resp), sizeof(logout_resp), 0);
        assert(recvd == sizeof(logout_resp));
        assert((logout_resp.opcode & 0x3F) == 0x26);

        closesocket(s_iscsi);
        target.shutdown();
    }

    std::filesystem::remove_all(test_dir, ec);

#if defined(_WIN32)
    WSACleanup();
#endif

    std::cout << "  PASS: test_real_socket_networking\n";
}

void test_concurrency_and_stress() {
    std::cout << "[RUN] test_concurrency_and_stress\n";
    std::error_code ec;
    std::filesystem::path test_dir = "test_concurrency_env";
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);

    // Create 1 MB base image filled with 0xAA
    auto base_mem = std::make_shared<MemoryBlockDevice>(1024 * 1024);
    std::vector<std::byte> init_fill(1024 * 1024, std::byte{0xAA});
    (void)base_mem->write(0, init_fill);

    auto base_ro = std::make_shared<ReadOnlyBlockDevice>(base_mem);
    auto cow_file = test_dir / "cow_stress.bin";
    auto cow_dev = CowBlockDevice::create(base_ro, cow_file, 4096).value();

    auto cached_dev = CachedBlockDevice::create(cow_dev, 65536, 4096, 2).value();

    constexpr size_t num_threads = 8;
    std::vector<std::thread> workers;
    workers.reserve(num_threads);

    std::atomic<bool> start_gate{false};
    std::atomic<bool> failure{false};

    // 4 reader threads
    for (size_t t = 0; t < 4; ++t) {
        workers.emplace_back([&, t]() {
            while (!start_gate.load()) {
                std::this_thread::yield();
            }
            std::vector<std::byte> buf(4096);
            for (size_t iter = 0; iter < 100; ++iter) {
                uint64_t offset = ((t * 10 + iter) % 200) * 4096;
                auto read_res = cached_dev->read(offset, buf);
                if (!read_res.is_ok() || read_res.value() != 4096) {
                    failure.store(true);
                    break;
                }
            }
        });
    }

    // 4 writer threads, each writing unique byte patterns to independent non-overlapping ranges
    for (size_t t = 0; t < 4; ++t) {
        workers.emplace_back([&, t]() {
            while (!start_gate.load()) {
                std::this_thread::yield();
            }
            uint8_t pattern = static_cast<uint8_t>(0x10 + t);
            std::vector<std::byte> buf(4096, std::byte{pattern});
            for (size_t iter = 0; iter < 20; ++iter) {
                uint64_t offset = (t * 20 + iter) * 4096;
                auto write_res = cached_dev->write(offset, buf);
                if (!write_res.is_ok() || write_res.value() != 4096) {
                    failure.store(true);
                    break;
                }
            }
        });
    }

    start_gate.store(true);
    for (auto& w : workers) {
        w.join();
    }

    assert(!failure.load());

    // Flush and verify all written patterns
    assert(cached_dev->flush().is_ok());

    for (size_t t = 0; t < 4; ++t) {
        uint8_t expected_pattern = static_cast<uint8_t>(0x10 + t);
        std::vector<std::byte> verify_buf(4096);
        for (size_t iter = 0; iter < 20; ++iter) {
            uint64_t offset = (t * 20 + iter) * 4096;
            auto read_res = cached_dev->read(offset, verify_buf);
            assert(read_res.is_ok());
            for (auto b : verify_buf) {
                assert(b == std::byte{expected_pattern});
            }
        }
    }

    // Verify untouched area retains original 0xAA
    std::vector<std::byte> untouched_buf(4096);
    auto untouched_res = cached_dev->read(150 * 4096, untouched_buf);
    assert(untouched_res.is_ok());
    for (auto b : untouched_buf) {
        assert(b == std::byte{0xAA});
    }

    // Verify cache hits occurred
    assert(cached_dev->stats().hits > 0);

    cached_dev.reset();
    cow_dev.reset();
    base_ro.reset();
    base_mem.reset();

    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_concurrency_and_stress\n";
}

// =============================================================================
// Complete Diskless Management & Deep Virtual Disk Inspection Tests
// =============================================================================

void test_client_manager_lifecycle_and_persistence() {
    std::cout << "[RUN] test_client_manager_lifecycle_and_persistence\n";

    const std::filesystem::path test_conf = "test_clients.conf";
    std::error_code ec;
    std::filesystem::remove(test_conf, ec);

    ClientManager mgr(test_conf);
    mgr.set_dhcp_pool_range(NetworkAddress(192, 168, 1, 101), NetworkAddress(192, 168, 1, 105));

    // Auto-register first client from unknown MAC
    auto r1 = mgr.get_or_register_client("00:11:22:33:44:01");
    assert(r1.is_ok());
    assert(r1.value().pc_name == "PC01");
    assert(r1.value().ip_address == NetworkAddress(192, 168, 1, 101));
    assert(r1.value().mac_address == "00:11:22:33:44:01");
    assert(mgr.client_count() == 1);

    // Auto-register second client
    auto r2 = mgr.get_or_register_client("00:11:22:33:44:02");
    assert(r2.is_ok());
    assert(r2.value().pc_name == "PC02");
    assert(r2.value().ip_address == NetworkAddress(192, 168, 1, 102));
    assert(mgr.client_count() == 2);

    // Calling get_or_register_client for existing MAC returns same record
    auto r1_again = mgr.get_or_register_client("00:11:22:33:44:01");
    assert(r1_again.is_ok());
    assert(r1_again.value().pc_name == "PC01");
    assert(r1_again.value().ip_address == NetworkAddress(192, 168, 1, 101));
    assert(mgr.client_count() == 2);

    // Duplicate collision rejection: attempting to add a client with duplicate PC name
    ClientRecord bad_name;
    bad_name.mac_address = "00:11:22:33:44:99";
    bad_name.pc_name = "PC01"; // Already used
    bad_name.ip_address = NetworkAddress(192, 168, 1, 103);
    auto rej1 = mgr.add_or_update_client(bad_name);
    assert(rej1.is_err());
    assert(rej1.error().code() == ErrorCode::InvalidConfiguration);

    // Duplicate collision rejection: attempting to add a client with duplicate IP
    ClientRecord bad_ip;
    bad_ip.mac_address = "00:11:22:33:44:99";
    bad_ip.pc_name = "PC99";
    bad_ip.ip_address = NetworkAddress(192, 168, 1, 101); // Already used
    auto rej2 = mgr.add_or_update_client(bad_ip);
    assert(rej2.is_err());
    assert(rej2.error().code() == ErrorCode::InvalidConfiguration);

    // Update client 1 properties
    auto c1_rec = *mgr.get_client_by_mac("00:11:22:33:44:01");
    c1_rec.os_image_id = "win10-pro-vhd";
    c1_rec.writeback_dir = "D:/CustomWriteback";
    c1_rec.game_dir = "E:/Games";
    c1_rec.ram_cache_mb = 2048;
    c1_rec.ssd_cache_mb = 32768;
    c1_rec.enable_write_cache = true;
    assert(mgr.add_or_update_client(c1_rec).is_ok());

    // Save to file
    assert(mgr.save_to_file(test_conf).is_ok());
    assert(std::filesystem::exists(test_conf));

    // Load in fresh manager
    ClientManager loaded_mgr;
    assert(loaded_mgr.load_from_file(test_conf).is_ok());
    assert(loaded_mgr.client_count() == 2);

    auto loaded_c1 = loaded_mgr.get_client_by_mac("00:11:22:33:44:01");
    assert(loaded_c1.has_value());
    assert(loaded_c1->pc_name == "PC01");
    assert(loaded_c1->ip_address == NetworkAddress(192, 168, 1, 101));
    assert(loaded_c1->os_image_id == "win10-pro-vhd");
    assert(loaded_c1->writeback_dir == "D:/CustomWriteback");
    assert(loaded_c1->game_dir == "E:/Games");
    assert(loaded_c1->ram_cache_mb == 2048);
    assert(loaded_c1->ssd_cache_mb == 32768);
    assert(loaded_c1->enable_write_cache == true);

    auto loaded_c2 = loaded_mgr.get_client_by_mac("00:11:22:33:44:02");
    assert(loaded_c2.has_value());
    assert(loaded_c2->pc_name == "PC02");
    assert(loaded_c2->ip_address == NetworkAddress(192, 168, 1, 102));

    std::filesystem::remove(test_conf, ec);
    std::cout << "  PASS: test_client_manager_lifecycle_and_persistence\n";
}

void test_storage_manager_drive_roles_and_validation() {
    std::cout << "[RUN] test_storage_manager_drive_roles_and_validation\n";

    const std::filesystem::path test_roles_conf = "test_roles.conf";
    std::error_code ec;
    std::filesystem::remove(test_roles_conf, ec);

    StorageManager sm(test_roles_conf);
    auto drives = sm.scan_drives();
    assert(!drives.empty()); // At least C:\ should be present

    const auto& d0 = drives[0];
    assert(!d0.path.empty());
    assert(d0.total_bytes > 0);

    // Assign roles
    assert(sm.set_drive_role(d0.path, StorageRole::Writeback).is_ok());
    assert(sm.get_drive_role(d0.path) == StorageRole::Writeback);

    // Write probe validation on valid directory
    const std::filesystem::path probe_dir = "test_probe_dir";
    std::filesystem::create_directories(probe_dir, ec);
    auto val_ok = sm.validate_storage_path(probe_dir);
    assert(val_ok.is_ok());

    // Invalid path validation
    auto val_err = sm.validate_storage_path("Z:\\NonExistent_Invalid_Path_12345");
    assert(val_err.is_err());

    // Persistence test
    assert(sm.save_to_file(test_roles_conf).is_ok());
    assert(std::filesystem::exists(test_roles_conf));

    StorageManager loaded_sm(test_roles_conf);
    assert(loaded_sm.load_from_file(test_roles_conf).is_ok());
    assert(loaded_sm.get_drive_role(d0.path) == StorageRole::Writeback);

    std::filesystem::remove_all(probe_dir, ec);
    std::filesystem::remove(test_roles_conf, ec);
    std::cout << "  PASS: test_storage_manager_drive_roles_and_validation\n";
}

void test_vhd_windows_deep_inspection() {
    std::cout << "[RUN] test_vhd_windows_deep_inspection\n";

    // Synthetic Fixed VHD with GPT + ESP (FAT32) + bootmgfw.efi + NTFS Windows markers
    constexpr uint64_t virtual_size = 20 * 1024 * 1024;
    auto dev = std::make_shared<MemoryBlockDevice>(virtual_size);
    uint8_t* raw = reinterpret_cast<uint8_t*>(dev->raw_data().data());

    // LBA 0: Protective MBR
    raw[510] = 0x55; raw[511] = 0xAA;
    uint8_t* pmbr_p1 = raw + 446;
    pmbr_p1[4] = 0xEE; // GPT Protective type
    write_le32(pmbr_p1 + 8, 1);
    write_le32(pmbr_p1 + 12, static_cast<uint32_t>((virtual_size / 512) - 1));

    // LBA 1: GPT Header
    uint8_t* gpt_hdr = raw + 512;
    std::memcpy(gpt_hdr, "EFI PART", 8);
    write_le32(gpt_hdr + 8, 0x00010000);
    write_le32(gpt_hdr + 12, 92);
    write_le64(gpt_hdr + 24, 1);
    write_le64(gpt_hdr + 32, (virtual_size / 512) - 1);
    write_le64(gpt_hdr + 40, 34);
    write_le64(gpt_hdr + 48, (virtual_size / 512) - 34);
    write_le64(gpt_hdr + 72, 2); // Entries at LBA 2
    write_le32(gpt_hdr + 80, 128);
    write_le32(gpt_hdr + 84, 128);

    // LBA 2 Entry 0: ESP (EFI System Partition)
    // GUID: C12A7328-F81F-11D2-BA4B-00A0C93EC93B
    uint8_t* e0 = raw + (2 * 512);
    write_le32(e0, 0xC12A7328);
    write_le16(e0 + 4, 0xF81F);
    write_le16(e0 + 6, 0x11D2);
    e0[8] = 0xBA; e0[9] = 0x4B; e0[10] = 0x00; e0[11] = 0xA0;
    e0[12] = 0xC9; e0[13] = 0x3E; e0[14] = 0xC9; e0[15] = 0x3B;
    write_le64(e0 + 32, 2048); // Start LBA 2048 (1 MiB)
    write_le64(e0 + 40, 4095); // End LBA 4095 (2048 sectors = 1 MiB ESP)

    // Write FAT32 filesystem signature in ESP VBR (LBA 2048)
    uint8_t* esp_vbr = raw + (2048 * 512);
    std::memcpy(esp_vbr + 82, "FAT32   ", 8);

    // Write bootmgfw.efi and bootx64.efi file markers in ESP clusters
    uint8_t* esp_data = raw + (2050 * 512);
    std::memcpy(esp_data, "\\EFI\\Microsoft\\Boot\\bootmgfw.efi", 32);
    std::memcpy(esp_data + 128, "bootx64.efi", 11);

    // LBA 2 Entry 1: Basic Data Partition (Windows NTFS)
    // GUID: EBD0A0A2-B9E5-4433-87C0-68B6B72699C7
    uint8_t* e1 = e0 + 128;
    write_le32(e1, 0xEBD0A0A2);
    write_le16(e1 + 4, 0xB9E5);
    write_le16(e1 + 6, 0x4433);
    e1[8] = 0x87; e1[9] = 0xC0; e1[10] = 0x68; e1[11] = 0xB6;
    e1[12] = 0xB7; e1[13] = 0x26; e1[14] = 0x99; e1[15] = 0xC7;
    write_le64(e1 + 32, 4096);
    write_le64(e1 + 40, 30000);

    // Write NTFS filesystem signature in NTFS VBR (LBA 4096)
    uint8_t* ntfs_vbr = raw + (4096 * 512);
    std::memcpy(ntfs_vbr + 3, "NTFS    ", 8);

    // Write Windows directory markers in NTFS data sectors
    uint8_t* ntfs_data = raw + (4100 * 512);
    std::memcpy(ntfs_data, "\\Windows\\System32\\ntoskrnl.exe", 30);

    auto rep_res = ImageInspector::inspect(dev, "win10_production.vhd");
    assert(rep_res.is_ok());
    const auto& rep = rep_res.value();

    assert(rep.format == ImageFormat::VhdFixed);
    assert(rep.partition_scheme == PartitionScheme::Gpt);
    assert(rep.has_esp == true);
    assert(rep.has_efi_boot_files == true);
    assert(rep.has_windows_dir == true);
    assert(rep.has_windows_partition == true);
    assert(rep.boot_mode == BootMode::Uefi); // Confirmed by EFI boot files

    std::string summary = rep.detailed_inspection_summary();
    assert(summary.find("ESP FAT32: YES") != std::string::npos);
    assert(summary.find("EFI Bootloader: YES") != std::string::npos);
    assert(summary.find("Windows Directory Marker: YES") != std::string::npos);
    assert(summary.find("Determined Boot Mode: UEFI") != std::string::npos);

    std::cout << "  PASS: test_vhd_windows_deep_inspection\n";
}

void test_dhcp_client_auto_registration_pipeline() {
    std::cout << "[RUN] test_dhcp_client_auto_registration_pipeline\n";

    const std::filesystem::path test_dhcp_conf = "test_dhcp_clients.conf";
    std::error_code ec;
    std::filesystem::remove(test_dhcp_conf, ec);

    auto client_mgr = std::make_shared<ClientManager>(test_dhcp_conf);
    client_mgr->set_dhcp_pool_range(NetworkAddress(192, 168, 1, 150), NetworkAddress(192, 168, 1, 160));

    DhcpServer server(NetworkAddress(192, 168, 1, 1));
    server.set_client_manager(client_mgr);
    server.set_pool_range(NetworkAddress(192, 168, 1, 150), NetworkAddress(192, 168, 1, 160));
    server.set_gateway(NetworkAddress(192, 168, 1, 1));
    server.set_dns_server(NetworkAddress(1, 1, 1, 1));
    server.set_lease_duration_seconds(86400);

    // Verify initially no clients
    assert(client_mgr->client_count() == 0);

    // Simulate unknown client broadcasting DHCPDISCOVER
    DhcpHeader disc_hdr{};
    disc_hdr.op = 1;
    disc_hdr.htype = 1;
    disc_hdr.hlen = 6;
    disc_hdr.xid = 0x55AA1122;
    disc_hdr.magic_cookie[0] = 99; disc_hdr.magic_cookie[1] = 130;
    disc_hdr.magic_cookie[2] = 83; disc_hdr.magic_cookie[3] = 99;
    disc_hdr.chaddr[0] = 0x00; disc_hdr.chaddr[1] = 0x50; disc_hdr.chaddr[2] = 0x56;
    disc_hdr.chaddr[3] = 0xC0; disc_hdr.chaddr[4] = 0x00; disc_hdr.chaddr[5] = 0x08;

    std::vector<uint8_t> disc_packet(reinterpret_cast<const uint8_t*>(&disc_hdr),
                                      reinterpret_cast<const uint8_t*>(&disc_hdr) + sizeof(DhcpHeader));
    // Option 53 = 1 (Discover)
    disc_packet.push_back(53); disc_packet.push_back(1); disc_packet.push_back(1);
    // Option 93 = 7 (UEFI x64)
    disc_packet.push_back(93); disc_packet.push_back(2); disc_packet.push_back(0); disc_packet.push_back(7);
    disc_packet.push_back(255);

    auto parsed_opt = DhcpServer::parse_packet(disc_packet);
    assert(parsed_opt.is_ok());
    const auto& parsed = parsed_opt.value();
    assert(parsed.client_mac == "00:50:56:C0:00:08");

    // Process reply (DHCPOFFER) - Server auto-registers client into ClientManager
    auto reg_res = client_mgr->get_or_register_client(parsed.client_mac);
    assert(reg_res.is_ok());
    assert(reg_res.value().pc_name == "PC01");
    assert(reg_res.value().ip_address == NetworkAddress(192, 168, 1, 150));
    assert(client_mgr->client_count() == 1);

    auto assigned_ip = reg_res.value().ip_address;
    auto offer_res = server.build_reply(disc_hdr, parsed, 2, assigned_ip);
    assert(offer_res.is_ok());
    const auto* offer_hdr = reinterpret_cast<const DhcpHeader*>(offer_res.value().data());
    const auto* yiaddr_bytes = reinterpret_cast<const uint8_t*>(&offer_hdr->yiaddr);
    assert(yiaddr_bytes[0] == assigned_ip.octet(0));
    assert(yiaddr_bytes[1] == assigned_ip.octet(1));
    assert(yiaddr_bytes[2] == assigned_ip.octet(2));
    assert(yiaddr_bytes[3] == assigned_ip.octet(3));
    assert(std::string(reinterpret_cast<const char*>(offer_hdr->file)) == "ipxe.efi");

    // Verify lease table records
    auto leases = server.list_leases();
    assert(leases.size() >= 1);
    assert(leases[0].pc_name == "PC01");
    assert(leases[0].ip_address == NetworkAddress(192, 168, 1, 150));
    assert(leases[0].mac_address == "00:50:56:C0:00:08");

    std::filesystem::remove(test_dhcp_conf, ec);
    std::cout << "  PASS: test_dhcp_client_auto_registration_pipeline\n";
}

// Helpers for end-to-end iSCSI and storage tests
static bool send_all_bytes(SOCKET s, const void* data, size_t len) {
    const char* ptr = reinterpret_cast<const char*>(data);
    while (len > 0) {
        int res = send(s, ptr, static_cast<int>(len), 0);
        if (res <= 0) return false;
        ptr += res;
        len -= static_cast<size_t>(res);
    }
    return true;
}

static bool recv_all_bytes(SOCKET s, void* data, size_t len) {
    char* ptr = reinterpret_cast<char*>(data);
    while (len > 0) {
        int res = recv(s, ptr, static_cast<int>(len), 0);
        if (res <= 0) return false;
        ptr += res;
        len -= static_cast<size_t>(res);
    }
    return true;
}

static void test_write_be32(uint8_t* p, uint32_t val) {
    p[0] = static_cast<uint8_t>((val >> 24) & 0xFF);
    p[1] = static_cast<uint8_t>((val >> 16) & 0xFF);
    p[2] = static_cast<uint8_t>((val >> 8) & 0xFF);
    p[3] = static_cast<uint8_t>(val & 0xFF);
}

static void test_write_be16(uint8_t* p, uint16_t val) {
    p[0] = static_cast<uint8_t>((val >> 8) & 0xFF);
    p[1] = static_cast<uint8_t>(val & 0xFF);
}

static std::vector<uint8_t> recv_scsi_data_in(SOCKET s, IscsiBhs& out_bhs) {
    bool ok = recv_all_bytes(s, &out_bhs, sizeof(out_bhs));
    assert(ok);
    assert((out_bhs.opcode & 0x3F) == 0x25); // SCSI Data-In
    uint32_t dlen = (static_cast<uint32_t>(out_bhs.data_seg_len[0]) << 16) |
                    (static_cast<uint32_t>(out_bhs.data_seg_len[1]) << 8) |
                    static_cast<uint32_t>(out_bhs.data_seg_len[2]);
    std::vector<uint8_t> data(dlen, 0);
    if (dlen > 0) {
        ok = recv_all_bytes(s, data.data(), dlen);
        assert(ok);
        uint32_t pad = (4 - (dlen % 4)) % 4;
        if (pad > 0) {
            uint8_t pad_buf[4];
            ok = recv_all_bytes(s, pad_buf, pad);
            assert(ok);
        }
    }
    return data;
}

static IscsiBhs recv_scsi_response(SOCKET s) {
    IscsiBhs resp{};
    bool ok = recv_all_bytes(s, &resp, sizeof(resp));
    assert(ok);
    assert((resp.opcode & 0x3F) == 0x21); // SCSI Response
    return resp;
}

static void perform_test_login(SOCKET s, const std::string& initiator_name, uint32_t task_tag = 0x1000) {
    std::string text;
    text += "InitiatorName=" + initiator_name;
    text.push_back('\0');
    text += "SessionType=Normal";
    text.push_back('\0');
    text += "AuthMethod=None";
    text.push_back('\0');

    IscsiBhs bhs{};
    bhs.opcode = 0x03;
    bhs.flags = 0x87;
    bhs.initiator_task_tag = task_tag;
    uint32_t d_len = static_cast<uint32_t>(text.size());
    bhs.data_seg_len[0] = static_cast<uint8_t>((d_len >> 16) & 0xFF);
    bhs.data_seg_len[1] = static_cast<uint8_t>((d_len >> 8) & 0xFF);
    bhs.data_seg_len[2] = static_cast<uint8_t>(d_len & 0xFF);

    assert(send_all_bytes(s, &bhs, sizeof(bhs)));
    assert(send_all_bytes(s, text.data(), text.size()));
    uint32_t pad = (4 - (text.size() % 4)) % 4;
    if (pad > 0) {
        char pad_buf[4] = {0};
        assert(send_all_bytes(s, pad_buf, pad));
    }

    IscsiBhs resp{};
    assert(recv_all_bytes(s, &resp, sizeof(resp)));
    assert((resp.opcode & 0x3F) == 0x23);

    uint32_t resp_dlen = (static_cast<uint32_t>(resp.data_seg_len[0]) << 16) |
                         (static_cast<uint32_t>(resp.data_seg_len[1]) << 8) |
                         static_cast<uint32_t>(resp.data_seg_len[2]);
    uint32_t resp_padded = (resp_dlen + 3) & ~3;
    if (resp_padded > 0) {
        std::vector<char> discard(resp_padded);
        assert(recv_all_bytes(s, discard.data(), resp_padded));
    }
}

void test_storage_roles_explicit_confirmation_requirement() {
    std::cout << "[RUN] test_storage_roles_explicit_confirmation_requirement\n";
    std::error_code ec;
    std::filesystem::path scratch = "test_scratch_storage_roles";
    std::filesystem::remove_all(scratch, ec);
    std::filesystem::create_directories(scratch, ec);

    std::filesystem::path config_file = scratch / "cobdiskless.json";
    StorageManager sm(config_file);

    // Invariant 1: Fresh StorageManager MUST NOT auto-assign paths
    assert(sm.get_role_path(StorageRole::OsImages).empty());
    assert(sm.get_role_path(StorageRole::Writeback).empty());
    assert(sm.get_role_path(StorageRole::Games).empty());
    assert(sm.get_role_path(StorageRole::Cache).empty());

    // Invariant 2: Suggested defaults must be non-empty paths for UI/CLI presentation
    auto def_os = StorageManager::get_suggested_default(StorageRole::OsImages);
    auto def_wb = StorageManager::get_suggested_default(StorageRole::Writeback);
    auto def_game = StorageManager::get_suggested_default(StorageRole::Games);
    auto def_cache = StorageManager::get_suggested_default(StorageRole::Cache);
    assert(!def_os.empty());
    assert(!def_wb.empty());
    assert(!def_game.empty());
    assert(!def_cache.empty());

    // Invariant 3: Explicit assignment and validation
    std::filesystem::path os_dir = scratch / "os_images";
    std::filesystem::create_directories(os_dir, ec);

    // Assigning to non-existent directory fails validation
    std::filesystem::path non_existent = scratch / "does_not_exist";
    assert(StorageManager::validate_storage_path(non_existent, false).is_err());

    // Assigning to valid created directory succeeds validation
    assert(sm.assign_role(StorageRole::OsImages, os_dir).is_ok());
    assert(StorageManager::validate_storage_path(sm.get_role_path(StorageRole::OsImages)).is_ok());

    // Persist and reload: only explicitly assigned roles are persisted
    assert(sm.save_to_file().is_ok());

    StorageManager sm2(config_file);
    assert(sm2.load_from_file().is_ok());
    assert(sm2.get_role_path(StorageRole::OsImages) == os_dir);
    assert(sm2.get_role_path(StorageRole::Writeback).empty());

    std::filesystem::remove_all(scratch, ec);
    std::cout << "  PASS: test_storage_roles_explicit_confirmation_requirement\n";
}

void test_iscsi_rfc3720_login_and_data_segment_drainage() {
    std::cout << "[RUN] test_iscsi_rfc3720_login_and_data_segment_drainage\n";
#if defined(_WIN32)
    WSADATA wsa;
    assert(WSAStartup(MAKEWORD(2, 2), &wsa) == 0);
#endif
    std::error_code ec;
    std::filesystem::path test_dir = "test_scratch_iscsi_login";
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);

    std::filesystem::path os_path = test_dir / "golden.raw";
    {
        std::ofstream ofs(os_path, std::ios::binary);
        std::vector<uint8_t> dummy(64 * 1024, 0x11);
        ofs.write(reinterpret_cast<const char*>(dummy.data()), dummy.size());
    }

    auto registry = std::make_shared<GoldenImageRegistry>();
    auto img_mgr = std::make_shared<ImageManager>(registry);
    Configuration cfg;
    cfg.set_os_images_dir(test_dir);
    cfg.set_writeback_dir(test_dir);
    img_mgr->configure(cfg);
    assert(img_mgr->import_image(os_path, ImageRole::OsImage, ImageId("os_image")).is_ok());

    auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, test_dir);

    uint16_t port = 13261;
    IscsiTargetConfig tcfg;
    tcfg.listen_address = NetworkAddress(127, 0, 0, 1, port);
    tcfg.default_os_image_id = ImageId("os_image");
    tcfg.target_iqn = "iqn.2026-09.com.cobdiskless:storage";
    IscsiTarget target(tcfg, sess_mgr);
    assert(target.initialize().is_ok());
    std::this_thread::sleep_for(std::chrono::milliseconds(50));

    SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    assert(s != INVALID_SOCKET);
    DWORD tv = 3000;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv), sizeof(tv));

    sockaddr_in srv{};
    srv.sin_family = AF_INET;
    srv.sin_port = htons(port);
    srv.sin_addr.s_addr = inet_addr("127.0.0.1");
    assert(connect(s, reinterpret_cast<const sockaddr*>(&srv), sizeof(srv)) == 0);

    // RFC 3720 Login Request with text data segment
    std::string text_params;
    text_params += "InitiatorName=iqn.1991-05.com.microsoft:client-pc01";
    text_params.push_back('\0');
    text_params += "SessionType=Normal";
    text_params.push_back('\0');
    text_params += "AuthMethod=None";
    text_params.push_back('\0');
    text_params += "HeaderDigest=None";
    text_params.push_back('\0');
    text_params += "DataDigest=None";
    text_params.push_back('\0');
    text_params += "MaxRecvDataSegmentLength=65536";
    text_params.push_back('\0');

    IscsiBhs login_bhs{};
    login_bhs.opcode = 0x03; // Login Request
    login_bhs.flags = 0x87;  // Transit=1, CSG=0, NSG=3
    login_bhs.initiator_task_tag = 0x778899AA;
    uint32_t d_len = static_cast<uint32_t>(text_params.size());
    login_bhs.data_seg_len[0] = static_cast<uint8_t>((d_len >> 16) & 0xFF);
    login_bhs.data_seg_len[1] = static_cast<uint8_t>((d_len >> 8) & 0xFF);
    login_bhs.data_seg_len[2] = static_cast<uint8_t>(d_len & 0xFF);

    assert(send_all_bytes(s, &login_bhs, sizeof(login_bhs)));
    assert(send_all_bytes(s, text_params.data(), text_params.size()));
    uint32_t pad = (4 - (text_params.size() % 4)) % 4;
    if (pad > 0) {
        char pad_buf[4] = {0};
        assert(send_all_bytes(s, pad_buf, pad));
    }

    IscsiBhs resp_bhs{};
    assert(recv_all_bytes(s, &resp_bhs, sizeof(resp_bhs)));
    assert((resp_bhs.opcode & 0x3F) == 0x23); // Login Response
    assert(resp_bhs.initiator_task_tag == 0x778899AA);
    assert(resp_bhs.cdb[0] == 0); // Status-Class: Success

    uint32_t resp_dlen = (static_cast<uint32_t>(resp_bhs.data_seg_len[0]) << 16) |
                         (static_cast<uint32_t>(resp_bhs.data_seg_len[1]) << 8) |
                         static_cast<uint32_t>(resp_bhs.data_seg_len[2]);
    assert(resp_dlen > 0);
    uint32_t resp_padded = (resp_dlen + 3) & ~3;
    std::vector<char> resp_payload(resp_padded, 0);
    assert(recv_all_bytes(s, resp_payload.data(), resp_padded));

    std::string resp_text(resp_payload.data(), resp_dlen);
    assert(resp_text.find("TargetName=") != std::string::npos);
    assert(resp_text.find("AuthMethod=None") != std::string::npos);
    assert(resp_text.find("InitialR2T=Yes") != std::string::npos);

    IscsiBhs logout_req{};
    logout_req.opcode = 0x06;
    logout_req.flags = 0x80;
    logout_req.initiator_task_tag = 0x112233;
    assert(send_all_bytes(s, &logout_req, sizeof(logout_req)));

    IscsiBhs logout_resp{};
    assert(recv_all_bytes(s, &logout_resp, sizeof(logout_resp)));
    assert((logout_resp.opcode & 0x3F) == 0x26);

    closesocket(s);
    target.shutdown();
    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_iscsi_rfc3720_login_and_data_segment_drainage\n";
}

void test_iscsi_windows_boot_scsi_command_suite() {
    std::cout << "[RUN] test_iscsi_windows_boot_scsi_command_suite\n";
#if defined(_WIN32)
    WSADATA wsa;
    assert(WSAStartup(MAKEWORD(2, 2), &wsa) == 0);
#endif
    std::error_code ec;
    std::filesystem::path test_dir = "test_scratch_win_boot_scsi";
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);

    std::filesystem::path os_path = test_dir / "golden_win.raw";
    {
        std::ofstream ofs(os_path, std::ios::binary);
        std::vector<uint8_t> dummy(64 * 1024, 0x00);
        ofs.write(reinterpret_cast<const char*>(dummy.data()), dummy.size());
    }

    auto registry = std::make_shared<GoldenImageRegistry>();
    auto img_mgr = std::make_shared<ImageManager>(registry);
    Configuration cfg;
    cfg.set_os_images_dir(test_dir);
    cfg.set_writeback_dir(test_dir);
    img_mgr->configure(cfg);
    assert(img_mgr->import_image(os_path, ImageRole::OsImage, ImageId("win_os")).is_ok());

    auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, test_dir);

    uint16_t port = 13262;
    IscsiTargetConfig tcfg;
    tcfg.listen_address = NetworkAddress(127, 0, 0, 1, port);
    tcfg.default_os_image_id = ImageId("win_os");
    IscsiTarget target(tcfg, sess_mgr);
    assert(target.initialize().is_ok());
    std::this_thread::sleep_for(std::chrono::milliseconds(50));

    SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    assert(s != INVALID_SOCKET);
    DWORD tv = 3000;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv), sizeof(tv));

    sockaddr_in srv{};
    srv.sin_family = AF_INET;
    srv.sin_port = htons(port);
    srv.sin_addr.s_addr = inet_addr("127.0.0.1");
    assert(connect(s, reinterpret_cast<const sockaddr*>(&srv), sizeof(srv)) == 0);

    perform_test_login(s, "iqn.1991-05.com.microsoft:win-boot-client", 0x2001);

    // 1. Standard INQUIRY
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40; // Read
        cmd.initiator_task_tag = 0x3001;
        cmd.cdb[0] = 0x12; // INQUIRY
        cmd.cdb[4] = 36;
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() == 36);
        assert(data[0] == 0x00); // Direct-access block device
        assert(std::string(reinterpret_cast<const char*>(data.data() + 8), 8) == "COB     ");
        assert(std::string(reinterpret_cast<const char*>(data.data() + 16), 16) == "CobDiskless SAN ");
    }

    // 2. INQUIRY VPD Page 0x00 (Supported VPD Pages)
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x3002;
        cmd.cdb[0] = 0x12;
        cmd.cdb[1] = 0x01; // EVPD
        cmd.cdb[2] = 0x00; // Supported Pages
        cmd.cdb[4] = 64;
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() >= 4);
        assert(data[1] == 0x00);
        bool has_80 = false, has_83 = false;
        for (size_t i = 4; i < data.size(); ++i) {
            if (data[i] == 0x80) has_80 = true;
            if (data[i] == 0x83) has_83 = true;
        }
        assert(has_80 && has_83);
    }

    // 3. INQUIRY VPD Page 0x80 (Unit Serial Number)
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x3003;
        cmd.cdb[0] = 0x12;
        cmd.cdb[1] = 0x01;
        cmd.cdb[2] = 0x80;
        cmd.cdb[4] = 64;
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() >= 4);
        assert(data[1] == 0x80);
        std::string sn(reinterpret_cast<const char*>(data.data() + 4), data[3]);
        assert(sn.rfind("COB-SAN-", 0) == 0);
    }

    // 4. INQUIRY VPD Page 0x83 (Device Identification for Windows disk.sys)
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x3004;
        cmd.cdb[0] = 0x12;
        cmd.cdb[1] = 0x01;
        cmd.cdb[2] = 0x83;
        cmd.cdb[4] = 64;
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() >= 4);
        assert(data[1] == 0x83);
        assert(data.size() >= 44);
    }

    // 5. REPORT LUNS (Opcode 0xA0)
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x3005;
        cmd.cdb[0] = 0xA0; // REPORT LUNS
        test_write_be32(cmd.cdb + 6, 64);
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() >= 16);
        uint32_t list_len = (static_cast<uint32_t>(data[0]) << 24) |
                            (static_cast<uint32_t>(data[1]) << 16) |
                            (static_cast<uint32_t>(data[2]) << 8)  |
                            static_cast<uint32_t>(data[3]);
        assert(list_len >= 8); // At least LUN 0
    }

    // 6. READ CAPACITY (10)
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x3006;
        cmd.cdb[0] = 0x25; // READ CAPACITY (10)
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() == 8);
        uint32_t blk_size = (static_cast<uint32_t>(data[4]) << 24) |
                            (static_cast<uint32_t>(data[5]) << 16) |
                            (static_cast<uint32_t>(data[6]) << 8)  |
                            static_cast<uint32_t>(data[7]);
        assert(blk_size == 512);
    }

    // 7. SERVICE ACTION IN 16 (READ CAPACITY 16)
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x3007;
        cmd.cdb[0] = 0x9E; // SERVICE ACTION IN 16
        cmd.cdb[1] = 0x10; // READ CAPACITY (16)
        test_write_be32(cmd.cdb + 10, 32);
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() == 32);
        uint32_t blk_size = (static_cast<uint32_t>(data[8]) << 24) |
                            (static_cast<uint32_t>(data[9]) << 16) |
                            (static_cast<uint32_t>(data[10]) << 8) |
                            static_cast<uint32_t>(data[11]);
        assert(blk_size == 512);
    }

    // 8. MODE SENSE (6) and (10)
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x3008;
        cmd.cdb[0] = 0x1A; // MODE SENSE (6)
        cmd.cdb[2] = 0x08; // Caching page
        cmd.cdb[4] = 64;
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() >= 12);

        // MODE SENSE (10)
        IscsiBhs cmd10{};
        cmd10.opcode = 0x01;
        cmd10.flags = 0x40;
        cmd10.initiator_task_tag = 0x3009;
        cmd10.cdb[0] = 0x5A; // MODE SENSE (10)
        cmd10.cdb[2] = 0x08;
        test_write_be16(cmd10.cdb + 7, 64);
        assert(send_all_bytes(s, &cmd10, sizeof(cmd10)));

        IscsiBhs in_bhs10{};
        auto data10 = recv_scsi_data_in(s, in_bhs10);
        assert(data10.size() >= 16);
    }

    // 9. TEST UNIT READY
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.initiator_task_tag = 0x300A;
        cmd.cdb[0] = 0x00; // TEST UNIT READY
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        auto resp = recv_scsi_response(s);
        assert(resp.initiator_task_tag == 0x300A);
        assert(resp.cdb[0] == 0x00); // SCSI Status: Good
    }

    closesocket(s);
    target.shutdown();
    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_iscsi_windows_boot_scsi_command_suite\n";
}

void test_iscsi_write10_and_sync_cache_persistence() {
    std::cout << "[RUN] test_iscsi_write10_and_sync_cache_persistence\n";
#if defined(_WIN32)
    WSADATA wsa;
    assert(WSAStartup(MAKEWORD(2, 2), &wsa) == 0);
#endif
    std::error_code ec;
    std::filesystem::path test_dir = "test_scratch_iscsi_write";
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);

    std::filesystem::path os_path = test_dir / "golden_base.raw";
    {
        std::ofstream ofs(os_path, std::ios::binary);
        std::vector<uint8_t> base_data(64 * 1024, 0x33);
        ofs.write(reinterpret_cast<const char*>(base_data.data()), base_data.size());
    }

    auto registry = std::make_shared<GoldenImageRegistry>();
    auto img_mgr = std::make_shared<ImageManager>(registry);
    Configuration cfg;
    cfg.set_os_images_dir(test_dir);
    cfg.set_writeback_dir(test_dir);
    img_mgr->configure(cfg);
    assert(img_mgr->import_image(os_path, ImageRole::OsImage, ImageId("os_base")).is_ok());

    auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, test_dir);

    uint16_t port = 13263;
    IscsiTargetConfig tcfg;
    tcfg.listen_address = NetworkAddress(127, 0, 0, 1, port);
    tcfg.default_os_image_id = ImageId("os_base");
    IscsiTarget target(tcfg, sess_mgr);
    assert(target.initialize().is_ok());
    std::this_thread::sleep_for(std::chrono::milliseconds(50));

    SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    assert(s != INVALID_SOCKET);
    DWORD tv = 3000;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv), sizeof(tv));

    sockaddr_in srv{};
    srv.sin_family = AF_INET;
    srv.sin_port = htons(port);
    srv.sin_addr.s_addr = inet_addr("127.0.0.1");
    assert(connect(s, reinterpret_cast<const sockaddr*>(&srv), sizeof(srv)) == 0);

    perform_test_login(s, "iqn.1991-05.com.microsoft:write-client", 0x4001);

    // 1. Send WRITE 10 with 2 sectors (1024 bytes) of distinct pattern 0x77
    {
        uint32_t write_len = 1024;
        std::vector<uint8_t> write_data(write_len, 0x77);

        IscsiBhs cmd{};
        cmd.opcode = 0x01; // SCSI Command
        cmd.flags = 0x20 | 0x80; // Write bit | Final
        cmd.initiator_task_tag = 0x4002;
        cmd.data_seg_len[0] = static_cast<uint8_t>((write_len >> 16) & 0xFF);
        cmd.data_seg_len[1] = static_cast<uint8_t>((write_len >> 8) & 0xFF);
        cmd.data_seg_len[2] = static_cast<uint8_t>(write_len & 0xFF);

        cmd.cdb[0] = 0x2A; // WRITE 10
        test_write_be32(cmd.cdb + 2, 20); // LBA = 20
        test_write_be16(cmd.cdb + 7, 2);  // Sectors = 2

        assert(send_all_bytes(s, &cmd, sizeof(cmd)));
        assert(send_all_bytes(s, write_data.data(), write_data.size()));

        auto resp = recv_scsi_response(s);
        assert(resp.initiator_task_tag == 0x4002);
        assert(resp.cdb[0] == 0x00); // SCSI Status Good
    }

    // 2. Send SYNCHRONIZE CACHE 10
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.initiator_task_tag = 0x4003;
        cmd.cdb[0] = 0x35; // SYNCHRONIZE CACHE 10
        test_write_be32(cmd.cdb + 2, 20);
        test_write_be16(cmd.cdb + 7, 2);

        assert(send_all_bytes(s, &cmd, sizeof(cmd)));
        auto resp = recv_scsi_response(s);
        assert(resp.initiator_task_tag == 0x4003);
        assert(resp.cdb[0] == 0x00);
    }

    // 3. Send READ 10 for the written sectors (LBA 20, 2 sectors) -> must return 0x77
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40; // Read
        cmd.initiator_task_tag = 0x4004;
        cmd.cdb[0] = 0x28; // READ 10
        test_write_be32(cmd.cdb + 2, 20);
        test_write_be16(cmd.cdb + 7, 2);

        assert(send_all_bytes(s, &cmd, sizeof(cmd)));
        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() == 1024);
        for (size_t i = 0; i < data.size(); ++i) {
            assert(data[i] == 0x77);
        }
    }

    // 4. Send READ 10 for an untouched sector (LBA 0, 1 sector) -> must return 0x33 from base image
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x4005;
        cmd.cdb[0] = 0x28;
        test_write_be32(cmd.cdb + 2, 0);
        test_write_be16(cmd.cdb + 7, 1);

        assert(send_all_bytes(s, &cmd, sizeof(cmd)));
        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() == 512);
        for (size_t i = 0; i < data.size(); ++i) {
            assert(data[i] == 0x33);
        }
    }

    closesocket(s);
    target.shutdown();
    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_iscsi_write10_and_sync_cache_persistence\n";
}

void test_iscsi_multi_lun_os_and_game_dispatch() {
    std::cout << "[RUN] test_iscsi_multi_lun_os_and_game_dispatch\n";
#if defined(_WIN32)
    WSADATA wsa;
    assert(WSAStartup(MAKEWORD(2, 2), &wsa) == 0);
#endif
    std::error_code ec;
    std::filesystem::path test_dir = "test_scratch_multi_lun";
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);

    std::filesystem::path os_path = test_dir / "os.raw";
    {
        std::ofstream ofs(os_path, std::ios::binary);
        std::vector<uint8_t> os_data(64 * 1024, 0x11);
        ofs.write(reinterpret_cast<const char*>(os_data.data()), os_data.size());
    }

    std::filesystem::path game_path = test_dir / "game.raw";
    {
        std::ofstream ofs(game_path, std::ios::binary);
        std::vector<uint8_t> game_data(64 * 1024, 0x47); // 'G'
        ofs.write(reinterpret_cast<const char*>(game_data.data()), game_data.size());
    }

    auto registry = std::make_shared<GoldenImageRegistry>();
    auto img_mgr = std::make_shared<ImageManager>(registry);
    Configuration cfg;
    cfg.set_os_images_dir(test_dir);
    cfg.set_writeback_dir(test_dir);
    img_mgr->configure(cfg);
    assert(img_mgr->import_image(os_path, ImageRole::OsImage, ImageId("os_image")).is_ok());
    assert(img_mgr->import_image(game_path, ImageRole::GameDisk, ImageId("game_image")).is_ok());

    auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, test_dir);

    uint16_t port = 13264;
    IscsiTargetConfig tcfg;
    tcfg.listen_address = NetworkAddress(127, 0, 0, 1, port);
    tcfg.default_os_image_id = ImageId("os_image");
    IscsiTarget target(tcfg, sess_mgr);
    assert(target.initialize().is_ok());
    std::this_thread::sleep_for(std::chrono::milliseconds(50));

    SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    assert(s != INVALID_SOCKET);
    DWORD tv = 3000;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv), sizeof(tv));

    sockaddr_in srv{};
    srv.sin_family = AF_INET;
    srv.sin_port = htons(port);
    srv.sin_addr.s_addr = inet_addr("127.0.0.1");
    assert(connect(s, reinterpret_cast<const sockaddr*>(&srv), sizeof(srv)) == 0);

    perform_test_login(s, "iqn.1991-05.com.microsoft:multi-lun-client", 0x5001);

    // 1. REPORT LUNS -> Should report at least LUN 0 and LUN 1
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x5002;
        cmd.cdb[0] = 0xA0; // REPORT LUNS
        test_write_be32(cmd.cdb + 6, 64);
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() >= 24); // 8-byte header + 2 * 8-byte LUN descriptors
        uint32_t list_len = (static_cast<uint32_t>(data[0]) << 24) |
                            (static_cast<uint32_t>(data[1]) << 16) |
                            (static_cast<uint32_t>(data[2]) << 8)  |
                            static_cast<uint32_t>(data[3]);
        assert(list_len >= 16);
    }

    // 2. READ 10 from LUN 1 -> Should return 0x47 ('G')
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x5003;
        reinterpret_cast<uint8_t*>(&cmd.lun)[1] = 1; // LUN 1 in network byte order
        cmd.cdb[0] = 0x28; // READ 10
        test_write_be32(cmd.cdb + 2, 0);
        test_write_be16(cmd.cdb + 7, 1);

        assert(send_all_bytes(s, &cmd, sizeof(cmd)));
        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() == 512);
        for (size_t i = 0; i < data.size(); ++i) {
            assert(data[i] == 0x47);
        }
    }

    // 3. WRITE 10 to LUN 1 -> Must be rejected with Check Condition (Write Protected)
    {
        uint32_t write_len = 512;
        std::vector<uint8_t> write_data(write_len, 0xFF);

        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x20 | 0x80;
        cmd.initiator_task_tag = 0x5004;
        reinterpret_cast<uint8_t*>(&cmd.lun)[1] = 1; // LUN 1
        cmd.data_seg_len[0] = static_cast<uint8_t>((write_len >> 16) & 0xFF);
        cmd.data_seg_len[1] = static_cast<uint8_t>((write_len >> 8) & 0xFF);
        cmd.data_seg_len[2] = static_cast<uint8_t>(write_len & 0xFF);
        cmd.cdb[0] = 0x2A; // WRITE 10
        test_write_be32(cmd.cdb + 2, 0);
        test_write_be16(cmd.cdb + 7, 1);

        assert(send_all_bytes(s, &cmd, sizeof(cmd)));
        assert(send_all_bytes(s, write_data.data(), write_data.size()));

        auto resp = recv_scsi_response(s);
        assert(resp.initiator_task_tag == 0x5004);
        assert(resp.rsvd1[1] == 0x02 || resp.cdb[0] == 0x02); // Check Condition (Data Protect)
    }

    // 4. READ 10 from LUN 1 again -> Data must be intact (still 0x47)
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x5005;
        reinterpret_cast<uint8_t*>(&cmd.lun)[1] = 1;
        cmd.cdb[0] = 0x28;
        test_write_be32(cmd.cdb + 2, 0);
        test_write_be16(cmd.cdb + 7, 1);

        assert(send_all_bytes(s, &cmd, sizeof(cmd)));
        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() == 512);
        for (size_t i = 0; i < data.size(); ++i) {
            assert(data[i] == 0x47);
        }
    }

    // 5. READ 10 from LUN 0 -> Should return 0x11 (OS image) and confirms socket stream is synced
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x5006;
        cmd.lun = 0; // LUN 0
        cmd.cdb[0] = 0x28;
        test_write_be32(cmd.cdb + 2, 0);
        test_write_be16(cmd.cdb + 7, 1);

        assert(send_all_bytes(s, &cmd, sizeof(cmd)));
        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() == 512);
        for (size_t i = 0; i < data.size(); ++i) {
            assert(data[i] == 0x11);
        }
    }

    closesocket(s);
    target.shutdown();
    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_iscsi_multi_lun_os_and_game_dispatch\n";
}

void test_real_hardware_recovery_dhcp_tftp_cache() {
    std::cout << "[RUN] test_real_hardware_recovery_dhcp_tftp_cache\n";

    // 1. DHCP Option 60 ("PXEClient"), Broadcast Flag 0x8000, and Boot Server Info
    {
        DhcpServer server(NetworkAddress(192, 168, 1, 100));

        DhcpHeader pxe_req_hdr{};
        pxe_req_hdr.op = 1;
        pxe_req_hdr.htype = 1;
        pxe_req_hdr.hlen = 6;
        pxe_req_hdr.xid = 0x55AA1122;
        pxe_req_hdr.magic_cookie[0] = 99; pxe_req_hdr.magic_cookie[1] = 130;
        pxe_req_hdr.magic_cookie[2] = 83; pxe_req_hdr.magic_cookie[3] = 99;
        pxe_req_hdr.chaddr[0] = 0x52; pxe_req_hdr.chaddr[1] = 0x54; pxe_req_hdr.chaddr[2] = 0x00;
        pxe_req_hdr.chaddr[3] = 0x12; pxe_req_hdr.chaddr[4] = 0x34; pxe_req_hdr.chaddr[5] = 0x56;

        std::vector<uint8_t> pxe_discover(reinterpret_cast<const uint8_t*>(&pxe_req_hdr),
                                          reinterpret_cast<const uint8_t*>(&pxe_req_hdr) + sizeof(DhcpHeader));

        // Option 53: Discover
        pxe_discover.push_back(53); pxe_discover.push_back(1); pxe_discover.push_back(1);
        // Option 60: "PXEClient:Arch:00000:UNDI:002001"
        std::string pxe_vendor = "PXEClient:Arch:00000:UNDI:002001";
        pxe_discover.push_back(60); pxe_discover.push_back(static_cast<uint8_t>(pxe_vendor.size()));
        pxe_discover.insert(pxe_discover.end(), pxe_vendor.begin(), pxe_vendor.end());
        // Option 93: 0 (BIOS x86)
        pxe_discover.push_back(93); pxe_discover.push_back(2); pxe_discover.push_back(0); pxe_discover.push_back(0);
        pxe_discover.push_back(255); // End

        auto parsed = DhcpServer::parse_packet(pxe_discover);
        assert(parsed.is_ok());
        assert(parsed.value().is_pxe_client);
        assert(parsed.value().vendor_class.find("PXEClient") != std::string::npos);

        auto offer_res = server.build_reply(pxe_req_hdr, parsed.value(), 2, NetworkAddress(192, 168, 1, 150));
        assert(offer_res.is_ok());
        const auto& offer = offer_res.value();
        assert(offer.size() > sizeof(DhcpHeader));

        const auto* reply_hdr = reinterpret_cast<const DhcpHeader*>(offer.data());
        // Verify broadcast flag is set (crucial for physical PXE ROMs)
        assert((ntohs(reply_hdr->flags) & 0x8000) != 0);
        // Verify next-server (siaddr) is set to server IP (192.168.1.100)
        assert(reply_hdr->siaddr != 0);
        // Verify your-IP (yiaddr) is set to 192.168.1.150
        uint8_t yiaddr_octets[4];
        std::memcpy(yiaddr_octets, &reply_hdr->yiaddr, 4);
        assert(yiaddr_octets[0] == 192 && yiaddr_octets[1] == 168 && yiaddr_octets[2] == 1 && yiaddr_octets[3] == 150);

        // Verify Magic Cookie at offset 236..239 (0x63825363 = 99, 130, 83, 99)
        assert(reply_hdr->magic_cookie[0] == 99);
        assert(reply_hdr->magic_cookie[1] == 130);
        assert(reply_hdr->magic_cookie[2] == 83);
        assert(reply_hdr->magic_cookie[3] == 99);

        // Verify options payload contains:
        // Option 53 (Message Type = 2 / Offer)
        // Option 54 (Server Identifier = server_ip_)
        // Option 1 (Subnet Mask = 255.255.255.0)
        // Option 60 (Vendor Class Identifier = "PXEClient")
        // Option 43 (PXE Discovery Control = 8)
        // Option 66 (TFTP Server)
        // Option 67 (Bootfile Name)
        bool found_opt53 = false;
        bool found_opt54 = false;
        bool found_opt1 = false;
        bool found_opt43 = false;
        bool found_opt60 = false;
        bool found_opt66 = false;
        bool found_opt67 = false;
        size_t opt_idx = sizeof(DhcpHeader);
        while (opt_idx < offer.size()) {
            uint8_t code = offer[opt_idx++];
            if (code == 255) break;
            if (code == 0) continue;
            if (opt_idx >= offer.size()) break;
            uint8_t len = offer[opt_idx++];
            if (opt_idx + len > offer.size()) break;

            if (code == 53 && len == 1) {
                assert(offer[opt_idx] == 2); // Offer
                found_opt53 = true;
            } else if (code == 54 && len == 4) {
                assert(offer[opt_idx] == 192 && offer[opt_idx + 1] == 168 && offer[opt_idx + 2] == 1 && offer[opt_idx + 3] == 100);
                found_opt54 = true;
            } else if (code == 1 && len == 4) {
                assert(offer[opt_idx] == 255 && offer[opt_idx + 1] == 255 && offer[opt_idx + 2] == 255 && offer[opt_idx + 3] == 0);
                found_opt1 = true;
            } else if (code == 43) {
                // Verify Sub-option 6 (PXE Discovery Control) = 8
                if (len >= 3 && offer[opt_idx] == 6 && offer[opt_idx + 1] == 1 && offer[opt_idx + 2] == 8) {
                    found_opt43 = true;
                }
            } else if (code == 60) {
                std::string v(reinterpret_cast<const char*>(offer.data() + opt_idx), len);
                if (v == "PXEClient") {
                    found_opt60 = true;
                }
            } else if (code == 66) {
                found_opt66 = true;
            } else if (code == 67) {
                found_opt67 = true;
            }
            opt_idx += len;
        }
        assert(found_opt53);
        assert(found_opt54);
        assert(found_opt1);
        assert(found_opt43);
        assert(found_opt60);
        assert(found_opt66);
        assert(found_opt67);
        // Verify minimum BOOTP size padding (>= 300 bytes)
        assert(offer.size() >= 300);
    }

    // 2. Real TFTP Bootloader Payloads and Multi-Block Delivery
    {
        TftpServer tftp_srv(NetworkAddress(192, 168, 1, 100), "tftp_boot");

        auto ipxe_efi = tftp_srv.get_file_content("ipxe.efi");
        assert(ipxe_efi.is_ok());
        // Verify real binary size (must be > 500 KB, not a 13-byte stub)
        assert(ipxe_efi.value().size() > 500000);

        auto undi = tftp_srv.get_file_content("undionly.kpxe");
        assert(undi.is_ok());
        assert(undi.value().size() > 50000);

        auto snp = tftp_srv.get_file_content("snponly.efi");
        assert(snp.is_ok());
        assert(snp.value().size() > 100000);

        auto boot_ipxe = tftp_srv.get_file_content("boot.ipxe");
        assert(boot_ipxe.is_ok());
        std::string ipxe_script(reinterpret_cast<const char*>(boot_ipxe.value().data()), boot_ipxe.value().size());
        assert(ipxe_script.find("#!ipxe") != std::string::npos);
        assert(ipxe_script.find("sanboot iscsi:") != std::string::npos);
    }

    // 3. StorageManager Attached Cache Configuration & Persistence
    {
        std::error_code ec;
        std::filesystem::path cfg_path = "test_hardware_recovery_storage_roles.conf";
        std::filesystem::remove(cfg_path, ec);

        StorageManager sm1(cfg_path);
        (void)sm1.scan_drives();

        TargetCacheConfig os_cache{};
        os_cache.ram_cache_enabled = true;
        os_cache.ram_cache_mb = 2048;
        os_cache.ssd_cache_enabled = true;
        os_cache.ssd_cache_path = "D:\\ssd_cache";
        os_cache.ssd_cache_size_gb = 64;
        sm1.set_cache_config(StorageRole::OsImages, os_cache);

        TargetCacheConfig games_cache{};
        games_cache.ram_cache_enabled = true;
        games_cache.ram_cache_mb = 8192;
        games_cache.ssd_cache_enabled = false;
        sm1.set_cache_config(StorageRole::Games, games_cache);

        auto save_res = sm1.save_to_file(cfg_path);
        assert(save_res.is_ok());

        // Load back into separate StorageManager instance
        StorageManager sm2(cfg_path);
        auto load_res = sm2.load_from_file(cfg_path);
        assert(load_res.is_ok());

        auto loaded_os = sm2.get_cache_config(StorageRole::OsImages);
        assert(loaded_os.ram_cache_enabled);
        assert(loaded_os.ram_cache_mb == 2048);
        assert(loaded_os.ssd_cache_enabled);
        assert(loaded_os.ssd_cache_path == "D:\\ssd_cache");
        assert(loaded_os.ssd_cache_size_gb == 64);

        auto loaded_games = sm2.get_cache_config(StorageRole::Games);
        assert(loaded_games.ram_cache_enabled);
        assert(loaded_games.ram_cache_mb == 8192);
        assert(!loaded_games.ssd_cache_enabled);

        std::filesystem::remove(cfg_path, ec);
    }

    // 4. GoldenImage Attached Cache Verification
    {
        std::error_code ec;
        std::filesystem::path img_file = "test_recovery_golden.raw";
        std::filesystem::remove(img_file, ec);

        // Create a 4 MB raw image file with test pattern
        {
            std::ofstream out(img_file, std::ios::binary);
            std::vector<uint8_t> block(4096, 0x77);
            for (size_t i = 0; i < 1024; ++i) {
                out.write(reinterpret_cast<const char*>(block.data()), block.size());
            }
        }

        // Open with 2 MB RAM cache
        auto img_res = GoldenImage::open(img_file, ImageId("rec_img"), 2 * 1024 * 1024);
        assert(img_res.is_ok());
        auto img = img_res.value();
        assert(img->has_cache());
        assert(img->cache_size_bytes() == 2 * 1024 * 1024);

        // Read through cached device
        std::vector<std::byte> read_buf(4096);
        auto read_res = img->device()->read(0, read_buf);
        assert(read_res.is_ok());
        assert(read_res.value() == 4096);
        assert(static_cast<uint8_t>(read_buf[0]) == 0x77);

        std::filesystem::remove(img_file, ec);
    }

    std::cout << "  PASS: test_real_hardware_recovery_dhcp_tftp_cache\n";
}

void test_vhd_vhdx_import_suite() {
    std::cout << "[RUN] test_vhd_vhdx_import_suite\n";

    std::error_code ec;
    std::filesystem::path test_dir = "test_vhd_import_env";
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);

    auto reg = std::make_shared<GoldenImageRegistry>();
    auto img_mgr = std::make_shared<ImageManager>(reg);

    // 1. Fixed VHD Import (Valid MBR/NTFS sector, valid conectix footer)
    {
        std::filesystem::path fixed_vhd = test_dir / "valid_fixed.vhd";
        constexpr uint64_t v_size = 2 * 1024 * 1024; // 2 MiB
        std::vector<uint8_t> disk_data(v_size, 0);

        // MBR at Sector 0
        disk_data[510] = 0x55; disk_data[511] = 0xAA;
        disk_data[0] = 0xEB; // Bootstrap jump
        uint8_t* p1 = disk_data.data() + 446;
        p1[0] = 0x80; // Bootable
        p1[4] = 0x07; // NTFS
        write_le32(p1 + 8, 2048); // Start LBA 2048
        write_le32(p1 + 12, 2048); // 2048 sectors (1 MiB)

        // NTFS VBR at Sector 2048
        std::memcpy(disk_data.data() + (2048 * 512) + 3, "NTFS    ", 8);

        // Windows directory marker at Sector 2050
        std::memcpy(disk_data.data() + (2050 * 512), "\\Windows\\System32\\ntoskrnl.exe", 30);

        // Conectix footer at EOF (512 bytes)
        std::vector<uint8_t> footer(512, 0);
        std::memcpy(footer.data(), "conectix", 8);
        write_be32(footer.data() + 8, 0x00000002);
        write_be32(footer.data() + 12, 0x00010000);
        write_be64(footer.data() + 16, 0xFFFFFFFFFFFFFFFFULL);
        write_be64(footer.data() + 48, v_size);
        write_be32(footer.data() + 60, 2); // Fixed

        uint32_t sum = 0;
        for (size_t i = 0; i < 512; ++i) {
            sum += footer[i];
        }
        write_be32(footer.data() + 64, ~sum);

        {
            std::ofstream out(fixed_vhd, std::ios::binary);
            out.write(reinterpret_cast<const char*>(disk_data.data()), static_cast<std::streamsize>(disk_data.size()));
            out.write(reinterpret_cast<const char*>(footer.data()), static_cast<std::streamsize>(footer.size()));
        }

        auto res = img_mgr->import_image(fixed_vhd, ImageRole::OsImage);
        assert(res.is_ok());
        const auto& info = res.value();
        assert(info.is_valid);
        assert(info.format == ImageFormat::VhdFixed);
        assert(info.partition_scheme == PartitionScheme::Mbr);
        assert(info.boot_mode == BootMode::Bios);
        assert(info.virtual_size_bytes == v_size);

        // Mount on ClientSession and verify LUN 0 block read
        auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, test_dir / "wb");
        auto sess_res = sess_mgr->get_or_create_session(ClientId("PC01"), NetworkAddress(192, 168, 1, 101), info.id);
        assert(sess_res.is_ok());
        auto session = sess_res.value();
        auto lun0_dev = session->get_device_for_lun(0);
        assert(lun0_dev != nullptr);

        std::vector<std::byte> read_mbr(512);
        auto r_res = lun0_dev->read(0, read_mbr);
        assert(r_res.is_ok());
        assert(static_cast<uint8_t>(read_mbr[510]) == 0x55 && static_cast<uint8_t>(read_mbr[511]) == 0xAA);

        (void)img_mgr->release_image(info.id);
    }

    // 2. Dynamic VHD Import (Valid dynamic header + BAT)
    {
        std::filesystem::path dyn_vhd = test_dir / "valid_dynamic.vhd";
        constexpr uint64_t v_size = 2097152; // 2 MiB
        constexpr uint32_t blk_size = 2097152; // 2 MiB block size

        // 1. Footer at start (512 bytes)
        std::vector<uint8_t> footer(512, 0);
        std::memcpy(footer.data(), "conectix", 8);
        write_be32(footer.data() + 8, 0x00000002);
        write_be32(footer.data() + 12, 0x00010000);
        write_be64(footer.data() + 16, 512); // Dynamic header at 512
        write_be64(footer.data() + 48, v_size);
        write_be32(footer.data() + 60, 3); // Dynamic

        uint32_t sum = 0;
        for (size_t i = 0; i < 512; ++i) sum += footer[i];
        write_be32(footer.data() + 64, ~sum);

        // 2. Dynamic header (1024 bytes)
        std::vector<uint8_t> dyn_hdr(1024, 0);
        std::memcpy(dyn_hdr.data(), "cxsparse", 8);
        write_be64(dyn_hdr.data() + 16, 1536); // BAT offset at 1536
        write_be32(dyn_hdr.data() + 28, 1);    // 1 block
        write_be32(dyn_hdr.data() + 32, blk_size);

        // 3. BAT table (padded to 512 bytes)
        std::vector<uint8_t> bat(512, 0xFF); // 0xFFFFFFFF = unallocated block

        {
            std::ofstream out(dyn_vhd, std::ios::binary);
            out.write(reinterpret_cast<const char*>(footer.data()), 512);
            out.write(reinterpret_cast<const char*>(dyn_hdr.data()), 1024);
            out.write(reinterpret_cast<const char*>(bat.data()), 512);
            // Copy of footer at EOF
            out.write(reinterpret_cast<const char*>(footer.data()), 512);
        }

        auto res = img_mgr->import_image(dyn_vhd, ImageRole::OsImage);
        assert(res.is_ok());
        const auto& info = res.value();
        assert(info.is_valid);
        assert(info.format == ImageFormat::VhdDynamic);
        assert(info.virtual_size_bytes == v_size);

        auto acq = img_mgr->acquire_image(info.id);
        assert(acq.is_ok());
        std::vector<std::byte> buf(512);
        auto r_res = acq.value()->device()->read(0, buf);
        assert(r_res.is_ok());
        // Unallocated block returns zeros
        for (auto b : buf) {
            assert(static_cast<uint8_t>(b) == 0);
        }
        (void)img_mgr->release_image(info.id);
    }

    // 3. VHDX Image Import & Validation
    {
        std::filesystem::path vhdx_file = test_dir / "test_import.vhdx";
        {
            std::ofstream out(vhdx_file, std::ios::binary);
            std::vector<uint8_t> header(1024 * 1024, 0);
            std::memcpy(header.data(), "vhdxfile", 8);
            out.write(reinterpret_cast<const char*>(header.data()), static_cast<std::streamsize>(header.size()));
        }

        auto res = img_mgr->import_image(vhdx_file, ImageRole::OsImage);
        // Header without valid region tables returns StorageFailure gracefully
        assert(res.is_err());
        assert(res.error().code() == ErrorCode::StorageFailure);
    }

    // 4. Invalid Image Rejection (random text / non-image format)
    {
        std::filesystem::path txt_file = test_dir / "notes.txt";
        {
            std::ofstream out(txt_file);
            out << "This is plain text and not a disk image.\n";
        }
        auto res = img_mgr->import_image(txt_file, ImageRole::OsImage);
        assert(res.is_err());
        assert(res.error().code() == ErrorCode::StorageFailure);

        std::filesystem::path garbage_vhd = test_dir / "garbage.vhd";
        {
            std::ofstream out(garbage_vhd, std::ios::binary);
            std::vector<uint8_t> garbage(1024, 0xAA);
            out.write(reinterpret_cast<const char*>(garbage.data()), garbage.size());
        }
        auto res2 = img_mgr->import_image(garbage_vhd, ImageRole::OsImage);
        assert(res2.is_err());
        assert(res2.error().code() == ErrorCode::StorageFailure);
    }

    // 5. Corrupted Image Rejection (Broken footer checksum)
    {
        std::filesystem::path corrupt_vhd = test_dir / "corrupted_checksum.vhd";
        constexpr uint64_t v_size = 1048576; // 1 MiB
        std::vector<uint8_t> disk_data(v_size, 0);

        std::vector<uint8_t> footer(512, 0);
        std::memcpy(footer.data(), "conectix", 8);
        write_be32(footer.data() + 8, 0x00000002);
        write_be32(footer.data() + 12, 0x00010000);
        write_be64(footer.data() + 16, 0xFFFFFFFFFFFFFFFFULL);
        write_be64(footer.data() + 48, v_size);
        write_be32(footer.data() + 60, 2); // Fixed

        // Corrupt checksum
        write_be32(footer.data() + 64, 0x12345678);

        {
            std::ofstream out(corrupt_vhd, std::ios::binary);
            out.write(reinterpret_cast<const char*>(disk_data.data()), static_cast<std::streamsize>(disk_data.size()));
            out.write(reinterpret_cast<const char*>(footer.data()), static_cast<std::streamsize>(footer.size()));
        }

        auto res = img_mgr->import_image(corrupt_vhd, ImageRole::OsImage);
        assert(res.is_err());
        assert(res.error().code() == ErrorCode::StorageFailure);
    }

    // 6. Windows Partition Inspection (GPT / UEFI detection from real disk image)
    {
        std::filesystem::path uefi_vhd = test_dir / "win_uefi.vhd";
        constexpr uint64_t v_size = 20 * 1024 * 1024; // 20 MiB
        std::vector<uint8_t> raw(v_size, 0);

        // LBA 0: Protective MBR
        raw[510] = 0x55; raw[511] = 0xAA;
        uint8_t* pmbr_p1 = raw.data() + 446;
        pmbr_p1[4] = 0xEE;
        write_le32(pmbr_p1 + 8, 1);
        write_le32(pmbr_p1 + 12, static_cast<uint32_t>((v_size / 512) - 1));

        // LBA 1: GPT Header
        uint8_t* gpt_hdr = raw.data() + 512;
        std::memcpy(gpt_hdr, "EFI PART", 8);
        write_le32(gpt_hdr + 8, 0x00010000);
        write_le32(gpt_hdr + 12, 92);
        write_le64(gpt_hdr + 24, 1);
        write_le64(gpt_hdr + 32, (v_size / 512) - 1);
        write_le64(gpt_hdr + 40, 34);
        write_le64(gpt_hdr + 48, (v_size / 512) - 34);
        write_le64(gpt_hdr + 72, 2);
        write_le32(gpt_hdr + 80, 128);
        write_le32(gpt_hdr + 84, 128);

        // LBA 2 Entry 0: ESP (EFI System Partition)
        // GUID: C12A7328-F81F-11D2-BA4B-00A0C93EC93B
        uint8_t* e0 = raw.data() + (2 * 512);
        write_le32(e0, 0xC12A7328);
        write_le16(e0 + 4, 0xF81F);
        write_le16(e0 + 6, 0x11D2);
        e0[8] = 0xBA; e0[9] = 0x4B; e0[10] = 0x00; e0[11] = 0xA0;
        e0[12] = 0xC9; e0[13] = 0x3E; e0[14] = 0xC9; e0[15] = 0x3B;
        write_le64(e0 + 32, 2048);
        write_le64(e0 + 40, 4095);

        // Write FAT32 signature & bootmgfw.efi in ESP
        std::memcpy(raw.data() + (2048 * 512) + 82, "FAT32   ", 8);
        std::memcpy(raw.data() + (2050 * 512), "\\EFI\\Microsoft\\Boot\\bootmgfw.efi", 32);

        // LBA 2 Entry 1: Basic Data Partition (Windows NTFS)
        // GUID: EBD0A0A2-B9E5-4433-87C0-68B6B72699C7
        uint8_t* e1 = e0 + 128;
        write_le32(e1, 0xEBD0A0A2);
        write_le16(e1 + 4, 0xB9E5);
        write_le16(e1 + 6, 0x4433);
        e1[8] = 0x87; e1[9] = 0xC0; e1[10] = 0x68; e1[11] = 0xB6;
        e1[12] = 0xB7; e1[13] = 0x26; e1[14] = 0x99; e1[15] = 0xC7;
        write_le64(e1 + 32, 4096);
        write_le64(e1 + 40, 30000);

        // Write NTFS signature & Windows kernel marker
        std::memcpy(raw.data() + (4096 * 512) + 3, "NTFS    ", 8);
        std::memcpy(raw.data() + (4100 * 512), "\\Windows\\System32\\ntoskrnl.exe", 30);

        // Conectix footer at EOF
        std::vector<uint8_t> footer(512, 0);
        std::memcpy(footer.data(), "conectix", 8);
        write_be32(footer.data() + 8, 0x00000002);
        write_be32(footer.data() + 12, 0x00010000);
        write_be64(footer.data() + 16, 0xFFFFFFFFFFFFFFFFULL);
        write_be64(footer.data() + 48, v_size);
        write_be32(footer.data() + 60, 2);

        uint32_t sum = 0;
        for (size_t i = 0; i < 512; ++i) sum += footer[i];
        write_be32(footer.data() + 64, ~sum);

        {
            std::ofstream out(uefi_vhd, std::ios::binary);
            out.write(reinterpret_cast<const char*>(raw.data()), static_cast<std::streamsize>(raw.size()));
            out.write(reinterpret_cast<const char*>(footer.data()), static_cast<std::streamsize>(footer.size()));
        }

        auto res = img_mgr->import_image(uefi_vhd, ImageRole::OsImage);
        assert(res.is_ok());
        const auto& info = res.value();
        assert(info.is_valid);
        assert(info.format == ImageFormat::VhdFixed);
        assert(info.partition_scheme == PartitionScheme::Gpt);
        assert(info.boot_mode == BootMode::Uefi);
        assert(info.virtual_size_bytes == v_size);
    }

    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_vhd_vhdx_import_suite\n";
}

int main() {
    std::cout << "=========================================================\n";
    std::cout << "CobDisklessCore Test Suite\n";
    std::cout << "=========================================================\n";

    // Phase 3 Tests
    test_common_types();
    test_errors_and_results();
    test_logging();
    test_configuration_validation();
    test_subsystem_deterministic_lifecycle();
    test_subsystem_failure_rollback();
    test_storage_block_device();

    // Phase 4 Tests
    test_mbr_detection();
    test_gpt_detection();
    test_boot_mode_recognition();
    test_filesystem_recognition();
    test_raw_image_backend();
    test_vhd_image_backend();
    test_golden_image_readonly_invariant();
    test_golden_image_registry();

    // Phase 5 Tests
    test_configuration_persistence_and_directories();
    test_storage_tester_health_and_benchmark();

    // Phase 6 Tests
    test_image_manager_lifecycle_and_safe_handling();

    // Phase 7 Tests
    test_cow_block_device_lifecycle();
    test_client_session_manager_isolation();

    // Phase 8 Tests
    test_dhcp_architecture_detection_and_pxe_provisioning();
    test_tftp_server_virtual_payloads_and_ipxe_script();

    // Phase 9 Tests
    test_iscsi_target_scsi_emulation_and_client_dispatch();

    // Phase 10 Tests
    test_block_cache_lru_and_read_ahead();

    // Phase 11 Tests
    test_production_hardening_and_recovery();

    // Phase 12 Tests
    test_end_to_end_diskless_boot_pipeline();

    // Phase 13 Reality Verification & Hardening Tests
    test_vhdx_rejection_and_vhd_handling();
    test_real_socket_networking();
    test_concurrency_and_stress();

    // Complete Diskless Management & Deep Virtual Disk Inspection Tests
    test_client_manager_lifecycle_and_persistence();
    test_storage_manager_drive_roles_and_validation();
    test_vhd_windows_deep_inspection();
    test_dhcp_client_auto_registration_pipeline();

    // End-to-End Block Data Path & Windows Client Boot Tests
    test_storage_roles_explicit_confirmation_requirement();
    test_iscsi_rfc3720_login_and_data_segment_drainage();
    test_iscsi_windows_boot_scsi_command_suite();
    test_iscsi_write10_and_sync_cache_persistence();
    test_iscsi_multi_lun_os_and_game_dispatch();

    // Real Hardware Recovery Tests
    test_real_hardware_recovery_dhcp_tftp_cache();
    test_vhd_vhdx_import_suite();

    std::cout << "=========================================================\n";
    std::cout << "ALL TESTS PASSED SUCCESSFULLY (40/40 suites)\n";
    std::cout << "=========================================================\n";
    return 0;
}
