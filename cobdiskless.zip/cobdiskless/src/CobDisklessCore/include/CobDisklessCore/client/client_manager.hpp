#pragma once

#include <string>
#include <vector>
#include <unordered_map>
#include <mutex>
#include <memory>
#include <filesystem>
#include <optional>
#include "CobDisklessCore/types/network_address.hpp"
#include "CobDisklessCore/errors/result.hpp"

namespace cobdiskless {

/**
 * @brief Complete persistent configuration and state record for a diskless client.
 */
struct ClientRecord {
    std::string pc_name;       // e.g. "PC01"
    std::string mac_address;   // Immutable persistent identity, e.g. "00:11:22:33:44:55"
    NetworkAddress ip_address; // Leased or reserved IP, e.g. 192.168.1.101
    bool enabled{true};
    std::string group{"Default"};
    std::string comment;
    NetworkAddress gateway{192, 168, 1, 1};
    NetworkAddress dns{192, 168, 1, 1};

    // Storage and image assignments
    std::string os_image_id{"default"};
    std::filesystem::path os_image_path;
    std::filesystem::path writeback_dir{"./writeback"};
    std::filesystem::path game_dir{"./games"};

    // Multi-tier cache configuration
    std::filesystem::path cache_dir{"./cache"};
    uint64_t cache_size_mb{512};
    uint64_t ram_cache_mb{512};
    uint64_t ssd_cache_mb{0};
    bool read_cache_enabled{true};
    bool write_cache_enabled{false};
    bool ram_cache_enabled{true};
    bool enable_write_cache{false};

    // Live state tracking
    std::string status{"Offline"}; // "Offline", "Booting", "Online"
    std::string first_seen;
    std::string last_seen;
    uint64_t first_seen_epoch{0};
    uint64_t last_seen_epoch{0};
};

/**
 * @brief Default profile applied to newly discovered clients.
 */
struct DefaultClientProfile {
    std::string os_image_id{"default"};
    std::string default_os_image_id{"default"};
    std::filesystem::path os_image_path;
    std::filesystem::path writeback_base_dir{"./writeback"};
    std::string default_writeback_dir{"./writeback"};
    std::filesystem::path games_dir{"./games"};
    std::string default_game_dir{"./games"};
    std::filesystem::path cache_base_dir{"./cache"};
    uint64_t cache_size_mb{512};
    uint64_t ram_cache_mb{512};
    uint64_t ssd_cache_mb{0};
    bool read_cache_enabled{true};
    bool write_cache_enabled{false};
    bool ram_cache_enabled{true};
    bool enable_write_cache{false};
    NetworkAddress default_gateway{192, 168, 1, 1};
    NetworkAddress default_dns{192, 168, 1, 1};
    std::string gateway{"192.168.1.1"};
    std::string dns_server{"1.1.1.1"};
    std::string name_prefix{"PC"};
    std::string pc_name_prefix{"PC"};
    uint32_t starting_number{1};
    uint32_t start_number{1};
};

/**
 * @brief Thread-safe manager for client configurations, profiles, and persistent records.
 */
class ClientManager {
public:
    explicit ClientManager(std::filesystem::path storage_file = "clients.conf");
    ~ClientManager() = default;

    // Profile Management
    [[nodiscard]] DefaultClientProfile default_profile() const;
    void set_default_profile(DefaultClientProfile profile);

    // Client CRUD Operations
    [[nodiscard]] std::optional<ClientRecord> find_by_mac(const std::string& mac) const;
    [[nodiscard]] std::optional<ClientRecord> find_by_name(const std::string& pc_name) const;
    [[nodiscard]] std::optional<ClientRecord> find_by_ip(const NetworkAddress& ip) const;

    [[nodiscard]] std::optional<ClientRecord> get_client_by_mac(const std::string& mac) const {
        return find_by_mac(mac);
    }
    [[nodiscard]] std::optional<ClientRecord> get_client_by_name(const std::string& pc_name) const {
        return find_by_name(pc_name);
    }
    [[nodiscard]] std::optional<ClientRecord> get_client_by_ip(const NetworkAddress& ip) const {
        return find_by_ip(ip);
    }
    [[nodiscard]] std::optional<ClientRecord> get_client_by_ip(const std::string& ip_str) const {
        return find_by_ip(NetworkAddress::parse(ip_str));
    }

    /**
     * @brief Retrieves existing client record or auto-registers a newly discovered MAC.
     * Assigns the next sequential PC name and allocates an unused IP from the pool.
     */
    Result<ClientRecord> get_or_register_client(
        const std::string& mac,
        const NetworkAddress& pool_start,
        const NetworkAddress& pool_end
    );

    Result<ClientRecord> get_or_register_client(const std::string& mac) {
        NetworkAddress p_start, p_end;
        {
            std::lock_guard<std::mutex> lock(mutex_);
            p_start = pool_start_;
            p_end = pool_end_;
        }
        return get_or_register_client(mac, p_start, p_end);
    }

    void set_dhcp_pool_range(const NetworkAddress& pool_start, const NetworkAddress& pool_end) {
        std::lock_guard<std::mutex> lock(mutex_);
        pool_start_ = pool_start;
        pool_end_ = pool_end;
    }

    /**
     * @brief Adds or updates a client record with strict duplicate MAC/IP/Name validation.
     */
    Result<void> save_client(const ClientRecord& record);
    Result<void> add_or_update_client(const ClientRecord& record) {
        return save_client(record);
    }

    /**
     * @brief Deletes a client record.
     */
    Result<void> delete_client(const std::string& mac);
    Result<void> remove_client(const std::string& mac) {
        return delete_client(mac);
    }

    /**
     * @brief Releases a client's leased IP, making it available for reuse.
     */
    Result<void> release_ip(const std::string& mac);

    /**
     * @brief Updates client status and last seen timestamp.
     */
    void update_status(const std::string& mac, const std::string& status);

    /**
     * @brief Returns a snapshot list of all registered clients.
     */
    [[nodiscard]] std::vector<ClientRecord> list_clients() const;

    /**
     * @brief Total number of registered clients.
     */
    [[nodiscard]] size_t client_count() const;

    // Persistence
    Result<void> save_to_file(const std::filesystem::path& file_path = {}) const;
    Result<void> load_from_file(const std::filesystem::path& file_path = {});

    [[nodiscard]] const std::filesystem::path& storage_file() const noexcept { return storage_file_; }

private:
    mutable std::mutex mutex_;
    std::filesystem::path storage_file_;
    DefaultClientProfile default_profile_;
    std::unordered_map<std::string, ClientRecord> clients_by_mac_;
    NetworkAddress pool_start_{192, 168, 1, 101};
    NetworkAddress pool_end_{192, 168, 1, 254};

    [[nodiscard]] std::string normalize_mac(std::string mac) const;
    [[nodiscard]] std::string get_next_available_pc_name_locked() const;
    [[nodiscard]] NetworkAddress allocate_unused_ip_locked(
        const NetworkAddress& pool_start,
        const NetworkAddress& pool_end
    ) const;
    [[nodiscard]] static std::string current_time_string();
};

} // namespace cobdiskless
