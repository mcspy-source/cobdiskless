#include "CobDisklessCore/client/client_session.hpp"
#include "CobDisklessCore/client/client_manager.hpp"
#include "CobDisklessCore/storage/storage_manager.hpp"
#include <algorithm>

namespace cobdiskless {

ClientSession::ClientSession(
    ClientId id,
    NetworkAddress ip,
    ImageId os_image_id,
    std::shared_ptr<CowBlockDevice> cow_device
) : id_(std::move(id)),
    ip_(ip),
    os_image_id_(std::move(os_image_id)),
    cow_device_(std::move(cow_device)) {}

Result<void> ClientSession::reset() noexcept {
    state_ = ClientState::Resetting;
    if (cow_device_) {
        auto res = cow_device_->reset();
        if (!res.is_ok()) {
            return res;
        }
    }
    state_ = ClientState::Booting;
    return {};
}

ClientSessionManager::ClientSessionManager(
    std::shared_ptr<ImageManager> image_manager,
    std::filesystem::path writeback_dir
) : image_manager_(std::move(image_manager)),
    writeback_dir_(std::move(writeback_dir)) {}

Result<std::shared_ptr<ClientSession>> ClientSessionManager::get_or_create_session(
    const ClientId& client_id,
    const NetworkAddress& client_ip,
    const ImageId& os_image_id
) {
    std::lock_guard<std::mutex> lock(mutex_);

    auto it = sessions_.find(client_id);
    if (it != sessions_.end()) {
        return it->second;
    }

    if (!image_manager_) {
        return Error(ErrorCode::InitializationFailure, "Image manager not configured");
    }

    ImageId effective_img_id = os_image_id;
    std::filesystem::path effective_wb_dir = writeback_dir_;

    if (client_manager_) {
        auto rec = client_manager_->get_client_by_mac(client_id.value());
        if (!rec) {
            rec = client_manager_->get_client_by_ip(client_ip.to_string());
        }
        if (rec) {
            if (!rec->os_image_id.empty()) {
                effective_img_id = ImageId(rec->os_image_id);
            }
            if (!rec->writeback_dir.empty()) {
                effective_wb_dir = std::filesystem::path(rec->writeback_dir);
                std::error_code ec;
                std::filesystem::create_directories(effective_wb_dir, ec);
            }
        }
    }

    if (storage_manager_ && effective_wb_dir == writeback_dir_) {
        if (!storage_manager_->is_role_assigned(StorageRole::Writeback)) {
            return Error(ErrorCode::InvalidConfiguration,
                "Writeback storage role is unassigned. Administrator must explicitly assign and confirm Writeback storage in Storage Roles.");
        }
        auto assigned_wb = storage_manager_->get_role_path(StorageRole::Writeback);
        if (!assigned_wb.empty()) {
            effective_wb_dir = assigned_wb;
            std::error_code ec;
            std::filesystem::create_directories(effective_wb_dir, ec);
        }
    }

    auto img_res = image_manager_->acquire_image(effective_img_id);
    if (!img_res.is_ok()) {
        return img_res.error();
    }

    auto golden_img = img_res.value();

    // Sanitize client id for filename (e.g. replace ':' with '_')
    std::string safe_name = client_id.value();
    std::replace(safe_name.begin(), safe_name.end(), ':', '_');
    std::replace(safe_name.begin(), safe_name.end(), '/', '_');
    std::replace(safe_name.begin(), safe_name.end(), '\\', '_');
    std::error_code ec_wb;
    std::filesystem::create_directories(effective_wb_dir, ec_wb);

    auto wb_path = effective_wb_dir / ("wb_" + safe_name + ".cow");

    auto cow_res = CowBlockDevice::create(golden_img->device(), wb_path);
    if (!cow_res.is_ok()) {
        // Crash / corruption recovery: quarantine corrupted file and retry with a clean one
        (void)CowBlockDevice::quarantine_corrupted_overlay(wb_path);
        cow_res = CowBlockDevice::create(golden_img->device(), wb_path);
        if (!cow_res.is_ok()) {
            (void)image_manager_->release_image(effective_img_id);
            return cow_res.error();
        }
    }

    auto session = std::make_shared<ClientSession>(
        client_id,
        client_ip,
        effective_img_id,
        cow_res.value()
    );

    // If game disk is configured in image_manager (by name 'games' or registered with GameDisk role)
    ImageId game_id("games");
    auto game_img_res = image_manager_->acquire_image(game_id);
    if (!game_img_res.is_ok()) {
        auto game_list = image_manager_->list_images(ImageRole::GameDisk);
        if (!game_list.empty()) {
            game_img_res = image_manager_->acquire_image(game_list[0].id);
        }
    }
    if (game_img_res.is_ok()) {
        session->set_game_device(game_img_res.value()->device());
    }

    sessions_[client_id] = session;
    return session;
}

std::shared_ptr<ClientSession> ClientSessionManager::find_session(const ClientId& client_id) const {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = sessions_.find(client_id);
    if (it != sessions_.end()) {
        return it->second;
    }
    return nullptr;
}

Result<void> ClientSessionManager::reset_client(const ClientId& client_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = sessions_.find(client_id);
    if (it == sessions_.end()) {
        return Error(ErrorCode::StorageFailure, "Client session not found: " + client_id.value());
    }
    return it->second->reset();
}

Result<void> ClientSessionManager::terminate_session(const ClientId& client_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = sessions_.find(client_id);
    if (it == sessions_.end()) {
        return Error(ErrorCode::StorageFailure, "Client session not found: " + client_id.value());
    }

    auto session = it->second;
    if (session->cow_device()) {
        session->cow_device()->close();
    }

    if (image_manager_) {
        (void)image_manager_->release_image(session->os_image_id());
    }

    sessions_.erase(it);
    return {};
}

std::vector<std::shared_ptr<ClientSession>> ClientSessionManager::list_sessions() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<std::shared_ptr<ClientSession>> result;
    result.reserve(sessions_.size());
    for (const auto& [_, session] : sessions_) {
        result.push_back(session);
    }
    return result;
}

size_t ClientSessionManager::active_clients_count() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return sessions_.size();
}

} // namespace cobdiskless
