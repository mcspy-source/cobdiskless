#include "CobDisklessCore/storage/storage_manager.hpp"
#include <fstream>
#include <sstream>
#include <iostream>

#if defined(_WIN32)
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif

namespace cobdiskless {

StorageManager::StorageManager(std::filesystem::path storage_file)
    : storage_file_(std::move(storage_file)) {
    // Note: Per design requirements, storage locations are never silently auto-assigned.
    // Roles remain unassigned (StorageRole::None) until explicitly confirmed and persisted.
    if (std::filesystem::exists(storage_file_)) {
        (void)load_from_file(storage_file_);
    }
}

std::vector<DriveInfo> StorageManager::scan_drives() {
    std::vector<DriveInfo> drives;

#if defined(_WIN32)
    wchar_t drive_strings[512] = {0};
    DWORD len = GetLogicalDriveStringsW(511, drive_strings);
    if (len > 0) {
        const wchar_t* p = drive_strings;
        while (*p) {
            DriveInfo info;
            info.root_path = std::filesystem::path(p);

            // Drive type
            UINT type = GetDriveTypeW(p);
            switch (type) {
                case DRIVE_FIXED:     info.drive_type = "Fixed"; break;
                case DRIVE_REMOVABLE: info.drive_type = "Removable"; break;
                case DRIVE_REMOTE:    info.drive_type = "Network"; break;
                case DRIVE_CDROM:     info.drive_type = "Optical"; break;
                case DRIVE_RAMDISK:   info.drive_type = "RAM Disk"; break;
                default:              info.drive_type = "Unknown"; break;
            }

            // Volume Info
            wchar_t volume_name[MAX_PATH + 1] = {0};
            wchar_t fs_name[MAX_PATH + 1] = {0};
            if (GetVolumeInformationW(p, volume_name, MAX_PATH, nullptr, nullptr, nullptr, fs_name, MAX_PATH)) {
                std::wstring w_vol(volume_name);
                info.volume_label = std::string(w_vol.begin(), w_vol.end());
                std::wstring w_fs(fs_name);
                info.filesystem = std::string(w_fs.begin(), w_fs.end());
            }

            // Disk Space
            ULARGE_INTEGER free_bytes_avail, total_bytes, total_free_bytes;
            if (GetDiskFreeSpaceExW(p, &free_bytes_avail, &total_bytes, &total_free_bytes)) {
                info.total_bytes = total_bytes.QuadPart;
                info.free_bytes = total_free_bytes.QuadPart;
            }

            // Determine if any role is currently mapped to this drive
            std::lock_guard<std::mutex> lock(mutex_);
            for (const auto& [role_val, role_path] : role_paths_) {
                std::string p_str = info.root_path.string();
                std::string r_str = role_path.string();
                if (r_str.starts_with(p_str) || (r_str.size() >= 2 && p_str.size() >= 2 &&
                    std::toupper(static_cast<unsigned char>(r_str[0])) == std::toupper(static_cast<unsigned char>(p_str[0])) &&
                    r_str[1] == ':' && p_str[1] == ':')) {
                    info.assigned_role = static_cast<StorageRole>(role_val);
                    auto it_c = role_cache_configs_.find(role_val);
                    if (it_c != role_cache_configs_.end()) {
                        info.cache_config = it_c->second;
                    } else {
                        TargetCacheConfig def;
                        if (info.assigned_role == StorageRole::Games) def.ram_cache_mb = 2048;
                        else if (info.assigned_role == StorageRole::Writeback) def.ram_cache_mb = 512;
                        else def.ram_cache_mb = 1024;
                        info.cache_config = def;
                    }
                }
            }

            if (info.assigned_role == StorageRole::None) {
                info.cache_config.ram_cache_enabled = false;
                info.cache_config.ssd_cache_enabled = false;
            }

            info.path = info.root_path.string();
            info.role = info.assigned_role;
            drives.push_back(info);
            p += wcslen(p) + 1;
        }
    }
#else
    // Fallback: report root / current filesystem
    DriveInfo info;
    info.root_path = std::filesystem::current_path().root_path();
    info.path = info.root_path.string();
    info.volume_label = "System";
    info.filesystem = "LocalFS";
    std::error_code ec;
    auto space = std::filesystem::space(info.root_path, ec);
    if (!ec) {
        info.total_bytes = space.capacity;
        info.free_bytes = space.available;
    }
    info.role = info.assigned_role;
    drives.push_back(info);
#endif

    return drives;
}

Result<void> StorageManager::assign_role(StorageRole role, const std::filesystem::path& path) {
    if (role == StorageRole::None) {
        return {};
    }

    auto val_res = validate_storage_path(path, true);
    if (!val_res.is_ok()) {
        return val_res;
    }

    {
        std::lock_guard<std::mutex> lock(mutex_);
        role_paths_[static_cast<int>(role)] = path;
    }

    return save_to_file();
}

std::filesystem::path StorageManager::get_role_path(StorageRole role) const {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = role_paths_.find(static_cast<int>(role));
    if (it != role_paths_.end()) {
        return it->second;
    }
    return {};
}

std::filesystem::path StorageManager::get_suggested_default(StorageRole role) noexcept {
    switch (role) {
        case StorageRole::OsImages: return "./images/os";
        case StorageRole::Writeback: return "./writeback";
        case StorageRole::Games:    return "./games";
        case StorageRole::Cache:    return "./cache";
        default:                    return {};
    }
}

Result<void> StorageManager::validate_storage_path(
    const std::filesystem::path& path,
    bool create_if_missing
) {
    if (path.empty()) {
        return Error(ErrorCode::InvalidConfiguration, "Storage path cannot be empty");
    }

    std::error_code ec;
    if (!std::filesystem::exists(path, ec)) {
        if (create_if_missing) {
            std::filesystem::create_directories(path, ec);
            if (ec) {
                return Error(ErrorCode::StorageFailure, "Failed to create directory: " + ec.message());
            }
        } else {
            return Error(ErrorCode::StorageFailure, "Directory does not exist: " + path.string());
        }
    }

    std::string s = path.string();
    bool is_root = (path == path.root_path() || path.parent_path() == path ||
                    s == "/" || s == "\\" ||
                    (s.size() <= 3 && s.find(':') != std::string::npos));
    if (is_root) {
        auto space = std::filesystem::space(path, ec);
        if (!ec && space.capacity > 0) {
            return {};
        }
    }

    // Verify write permissions by writing and deleting a temporary probe file
    auto probe_file = path / ".cobdiskless_write_probe";
    {
        std::ofstream probe(probe_file);
        if (!probe.is_open()) {
            if (is_root) {
                return {};
            }
            return Error(ErrorCode::StorageFailure, "Directory is not writable: " + path.string());
        }
        probe << "CobDiskless Storage Probe\n";
    }
    std::filesystem::remove(probe_file, ec);

    return {};
}

TargetCacheConfig StorageManager::get_cache_config(StorageRole role) const {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = role_cache_configs_.find(static_cast<int>(role));
    if (it != role_cache_configs_.end()) {
        return it->second;
    }
    TargetCacheConfig def;
    if (role == StorageRole::Games) {
        def.ram_cache_mb = 2048;
    } else if (role == StorageRole::Writeback) {
        def.ram_cache_mb = 512;
    } else {
        def.ram_cache_mb = 1024;
    }
    return def;
}

void StorageManager::set_cache_config(StorageRole role, TargetCacheConfig config) {
    std::lock_guard<std::mutex> lock(mutex_);
    role_cache_configs_[static_cast<int>(role)] = std::move(config);
}

Result<void> StorageManager::save_to_file(const std::filesystem::path& file_path) const {
    auto target = file_path.empty() ? storage_file_ : file_path;
    std::ofstream out(target, std::ios::trunc);
    if (!out.is_open()) {
        return Error(ErrorCode::StorageFailure, "Failed to open storage roles file for writing: " + target.string());
    }

    std::lock_guard<std::mutex> lock(mutex_);
    out << "[STORAGE_ROLES]\n";
    for (const auto& [role_val, role_path] : role_paths_) {
        std::string role_name = std::string(to_string(static_cast<StorageRole>(role_val)));
        out << role_name << "=" << role_path.string() << "\n";
    }

    out << "\n[STORAGE_CACHE]\n";
    for (const auto& [role_val, cfg] : role_cache_configs_) {
        std::string role_name = std::string(to_string(static_cast<StorageRole>(role_val)));
        out << role_name << "_RamEnabled=" << (cfg.ram_cache_enabled ? "1" : "0") << "\n";
        out << role_name << "_RamMb=" << cfg.ram_cache_mb << "\n";
        out << role_name << "_SsdEnabled=" << (cfg.ssd_cache_enabled ? "1" : "0") << "\n";
        out << role_name << "_SsdPath=" << cfg.ssd_cache_path.string() << "\n";
        out << role_name << "_SsdGb=" << cfg.ssd_cache_size_gb << "\n";
    }

    return {};
}

Result<void> StorageManager::load_from_file(const std::filesystem::path& file_path) {
    auto target = file_path.empty() ? storage_file_ : file_path;
    if (!std::filesystem::exists(target)) {
        return {};
    }

    std::ifstream in(target);
    if (!in.is_open()) {
        return Error(ErrorCode::StorageFailure, "Failed to open storage roles file for reading: " + target.string());
    }

    std::unordered_map<int, std::filesystem::path> loaded_roles;
    std::unordered_map<int, TargetCacheConfig> loaded_caches;
    std::string line;
    std::string current_section = "STORAGE_ROLES";

    while (std::getline(in, line)) {
        while (!line.empty() && std::isspace(static_cast<unsigned char>(line.front()))) line.erase(0, 1);
        while (!line.empty() && std::isspace(static_cast<unsigned char>(line.back()))) line.pop_back();

        if (line.empty() || line[0] == '#' || line[0] == ';') {
            continue;
        }

        if (line.front() == '[' && line.back() == ']') {
            current_section = line.substr(1, line.size() - 2);
            continue;
        }

        auto eq_pos = line.find('=');
        if (eq_pos == std::string::npos) {
            continue;
        }

        std::string key = line.substr(0, eq_pos);
        std::string val = line.substr(eq_pos + 1);

        if (current_section == "STORAGE_ROLES") {
            if (key == "OS Images") {
                loaded_roles[static_cast<int>(StorageRole::OsImages)] = val;
            } else if (key == "Writeback") {
                loaded_roles[static_cast<int>(StorageRole::Writeback)] = val;
            } else if (key == "Games") {
                loaded_roles[static_cast<int>(StorageRole::Games)] = val;
            } else if (key == "Cache") {
                loaded_roles[static_cast<int>(StorageRole::Cache)] = val;
            }
        } else if (current_section == "STORAGE_CACHE") {
            auto helper_cache = [&](StorageRole r, const std::string& prefix) {
                int ri = static_cast<int>(r);
                if (key == prefix + "_RamEnabled") {
                    loaded_caches[ri].ram_cache_enabled = (val == "1" || val == "true");
                } else if (key == prefix + "_RamMb") {
                    try { loaded_caches[ri].ram_cache_mb = std::stoul(val); } catch (...) {}
                } else if (key == prefix + "_SsdEnabled") {
                    loaded_caches[ri].ssd_cache_enabled = (val == "1" || val == "true");
                } else if (key == prefix + "_SsdPath") {
                    loaded_caches[ri].ssd_cache_path = val;
                } else if (key == prefix + "_SsdGb") {
                    try { loaded_caches[ri].ssd_cache_size_gb = std::stoul(val); } catch (...) {}
                }
            };
            helper_cache(StorageRole::OsImages, "OS Images");
            helper_cache(StorageRole::Writeback, "Writeback");
            helper_cache(StorageRole::Games, "Games");
            helper_cache(StorageRole::Cache, "Cache");
        }
    }

    {
        std::lock_guard<std::mutex> lock(mutex_);
        for (const auto& [k, v] : loaded_roles) {
            role_paths_[k] = v;
        }
        for (const auto& [k, v] : loaded_caches) {
            role_cache_configs_[k] = v;
        }
    }

    return {};
}

} // namespace cobdiskless
