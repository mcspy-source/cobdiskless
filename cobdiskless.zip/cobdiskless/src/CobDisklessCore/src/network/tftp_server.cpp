#include "CobDisklessCore/network/tftp_server.hpp"
#include "CobDisklessCore/logging/logger.hpp"
#include <fstream>
#include <cstring>
#include <sstream>
#include <algorithm>
#include <thread>
#include <optional>
#include <span>

#if defined(_WIN32)
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#endif

namespace cobdiskless {

TftpServer::TftpServer(
    NetworkAddress server_ip,
    std::filesystem::path root_dir,
    uint16_t port
) : server_ip_(server_ip),
    root_dir_(std::move(root_dir)),
    port_(port) {
    // Populate default dynamic iPXE script
    std::string default_script = generate_ipxe_script("iqn.2026-09.com.cobdiskless:storage");
    std::vector<uint8_t> script_data(default_script.begin(), default_script.end());
    register_virtual_file("boot.ipxe", std::move(script_data));

    // Note: undionly.kpxe and ipxe.efi are real bootloaders loaded from disk (e.g. tftp_boot/)
    // Never inject dummy strings here as they crash physical PXE bootloaders.
}

TftpServer::~TftpServer() {
    (void)shutdown();
}

std::string TftpServer::generate_ipxe_script(const std::string& target_iqn) const {
    std::ostringstream ss;
    ss << "#!ipxe\n";
    ss << "echo =========================================================\n";
    ss << "echo CobDiskless Network Boot Initializing...\n";
    ss << "echo =========================================================\n";
    ss << "set gateway " << server_ip_.ip_string() << "\n";
    ss << "echo Connecting to CobDiskless SAN Target at " << server_ip_.ip_string() << "...\n";
    ss << "sanboot iscsi:" << server_ip_.ip_string() << "::::" << target_iqn << "\n";
    return ss.str();
}

void TftpServer::register_virtual_file(std::string filename, std::vector<uint8_t> data) {
    std::lock_guard<std::mutex> lock(vfiles_mutex_);
    virtual_files_[std::move(filename)] = std::move(data);
}

Result<std::vector<uint8_t>> TftpServer::get_file_content(const std::string& filename) const {
    {
        std::lock_guard<std::mutex> lock(vfiles_mutex_);
        auto it = virtual_files_.find(filename);
        if (it != virtual_files_.end()) {
            return it->second;
        }
    }

    std::vector<std::filesystem::path> search_paths = {
        root_dir_ / filename,
        std::filesystem::path("./tftp_boot") / filename,
        std::filesystem::path("./tftp") / filename,
        std::filesystem::path("../tftp_boot") / filename,
        std::filesystem::current_path() / "tftp_boot" / filename,
        std::filesystem::current_path() / "tftp" / filename
    };

    std::error_code ec;
    for (const auto& path : search_paths) {
        if (std::filesystem::exists(path, ec) && std::filesystem::is_regular_file(path, ec)) {
            std::ifstream in(path, std::ios::binary);
            if (in.is_open()) {
                std::vector<uint8_t> content((std::istreambuf_iterator<char>(in)),
                                              std::istreambuf_iterator<char>());
                return content;
            }
        }
    }

    // Case-insensitive lookup in tftp_boot and root_dir_
    auto try_ci_lookup = [&](const std::filesystem::path& dir) -> std::optional<std::vector<uint8_t>> {
        if (!std::filesystem::exists(dir, ec) || !std::filesystem::is_directory(dir, ec)) {
            return std::nullopt;
        }
        std::string lower_fn = filename;
        for (auto& c : lower_fn) c = static_cast<char>(std::tolower(c));
        for (const auto& entry : std::filesystem::directory_iterator(dir, ec)) {
            if (entry.is_regular_file(ec)) {
                std::string ename = entry.path().filename().string();
                std::string lower_en = ename;
                for (auto& c : lower_en) c = static_cast<char>(std::tolower(c));
                if (lower_en == lower_fn) {
                    std::ifstream in(entry.path(), std::ios::binary);
                    if (in.is_open()) {
                        return std::vector<uint8_t>((std::istreambuf_iterator<char>(in)),
                                                    std::istreambuf_iterator<char>());
                    }
                }
            }
        }
        return std::nullopt;
    };

    if (auto c1 = try_ci_lookup(root_dir_)) return *c1;
    if (auto c2 = try_ci_lookup("./tftp_boot")) return *c2;
    if (auto c3 = try_ci_lookup(std::filesystem::current_path() / "tftp_boot")) return *c3;

    return Error(ErrorCode::StorageFailure, "File not found: " + filename);
}

std::vector<uint8_t> TftpServer::create_data_packet(
    uint16_t block_num,
    std::span<const uint8_t> block_payload
) {
    std::vector<uint8_t> packet;
    packet.resize(4 + block_payload.size());

    // Opcode 3 (DATA) in big-endian
    packet[0] = 0x00;
    packet[1] = 0x03;

    // Block number in big-endian
    packet[2] = static_cast<uint8_t>((block_num >> 8) & 0xFF);
    packet[3] = static_cast<uint8_t>(block_num & 0xFF);

    std::memcpy(packet.data() + 4, block_payload.data(), block_payload.size());
    return packet;
}

std::vector<uint8_t> TftpServer::create_ack_packet(uint16_t block_num) {
    std::vector<uint8_t> packet(4);
    // Opcode 4 (ACK)
    packet[0] = 0x00;
    packet[1] = 0x04;
    packet[2] = static_cast<uint8_t>((block_num >> 8) & 0xFF);
    packet[3] = static_cast<uint8_t>(block_num & 0xFF);
    return packet;
}

std::vector<uint8_t> TftpServer::create_error_packet(
    uint16_t error_code,
    std::string_view error_message
) {
    std::vector<uint8_t> packet;
    packet.resize(4 + error_message.size() + 1);

    // Opcode 5 (ERROR)
    packet[0] = 0x00;
    packet[1] = 0x05;
    packet[2] = static_cast<uint8_t>((error_code >> 8) & 0xFF);
    packet[3] = static_cast<uint8_t>(error_code & 0xFF);

    std::memcpy(packet.data() + 4, error_message.data(), error_message.size());
    packet[packet.size() - 1] = 0;
    return packet;
}

Result<std::string> TftpServer::parse_rrq_filename(std::span<const uint8_t> packet) {
    if (packet.size() < 4) {
        return Error(ErrorCode::NetworkFailure, "Packet too short for TFTP request");
    }

    uint16_t opcode = (static_cast<uint16_t>(packet[0]) << 8) | packet[1];
    if (opcode != 1) { // 1 = RRQ
        return Error(ErrorCode::NetworkFailure, "Expected RRQ opcode (1), got " + std::to_string(opcode));
    }

    const char* start = reinterpret_cast<const char*>(packet.data() + 2);
    const char* end = reinterpret_cast<const char*>(packet.data() + packet.size());
    auto null_it = std::find(start, end, '\0');
    if (null_it == end) {
        return Error(ErrorCode::NetworkFailure, "Malformed RRQ: missing null terminator");
    }

    std::string filename(start, null_it);
    if (filename.empty()) {
        return Error(ErrorCode::NetworkFailure, "Empty filename in RRQ");
    }

    // Traversal attack protection
    if (filename.find("..") != std::string::npos || filename.starts_with("/") || filename.starts_with("\\") ||
        (filename.size() >= 2 && filename[1] == ':')) {
        return Error(ErrorCode::NetworkFailure, "Directory traversal or absolute path rejected: " + filename);
    }

    return filename;
}

Result<void> TftpServer::initialize() {
    if (state_ == SubsystemState::Running) {
        return {};
    }

    running_ = true;
    state_ = SubsystemState::Running;

    worker_thread_ = std::make_unique<std::jthread>([this](std::stop_token st) {
        run_server_loop();
        (void)st;
    });

    return {};
}

void TftpServer::shutdown() noexcept {
    if (!running_) {
        state_ = SubsystemState::Stopped;
        return;
    }

    running_ = false;

#if defined(_WIN32)
    if (server_socket_ != ~static_cast<uintptr_t>(0)) {
        closesocket(static_cast<SOCKET>(server_socket_));
        server_socket_ = ~static_cast<uintptr_t>(0);
    }
#endif

    if (worker_thread_ && worker_thread_->joinable()) {
        worker_thread_->request_stop();
        worker_thread_->join();
        worker_thread_.reset();
    }

    state_ = SubsystemState::Stopped;
}

void TftpServer::run_server_loop() {
#if defined(_WIN32)
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        return;
    }

    SOCKET s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (s == INVALID_SOCKET) {
        WSACleanup();
        return;
    }

    server_socket_ = static_cast<uintptr_t>(s);

    BOOL reuse = TRUE;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (const char*)&reuse, sizeof(reuse));

    DWORD timeout_ms = 500;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char*)&timeout_ms, sizeof(timeout_ms));

    sockaddr_in bind_addr{};
    bind_addr.sin_family = AF_INET;
    bind_addr.sin_port = htons(port_);
    bind_addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(s, (sockaddr*)&bind_addr, sizeof(bind_addr)) != 0) {
        int err = WSAGetLastError();
        Logger::default_logger().error("TftpServer", "Failed to bind to UDP port " + std::to_string(port_) +
                      " (Winsock Error: " + std::to_string(err) + "). Administrative privileges may be required.");
        while (running_) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
        closesocket(s);
        WSACleanup();
        return;
    }

    Logger::default_logger().info("TftpServer", "Successfully listening on UDP port " + std::to_string(port_));

    std::vector<uint8_t> recv_buf(2048);
    sockaddr_in client_addr{};
    int client_addr_len = sizeof(client_addr);

    while (running_) {
        int bytes = recvfrom(s, reinterpret_cast<char*>(recv_buf.data()), recv_buf.size(), 0,
                             (sockaddr*)&client_addr, &client_addr_len);
        if (bytes >= 4) {
            auto span = std::span<const uint8_t>(recv_buf.data(), static_cast<size_t>(bytes));
            auto fn_res = parse_rrq_filename(span);
            if (fn_res.is_ok()) {
                const auto& filename = fn_res.value();
                char ip_buf[INET_ADDRSTRLEN] = {0};
                inet_ntop(AF_INET, &(client_addr.sin_addr), ip_buf, INET_ADDRSTRLEN);
                std::string client_ip = ip_buf;

                Logger::default_logger().info("BOOT", "[BOOT STAGE 6] TFTP request received: Client=" + client_ip + ":" + std::to_string(ntohs(client_addr.sin_port)) + " File='" + filename + "'");
                if (filename == "boot.ipxe") {
                    Logger::default_logger().info("BOOT", "[BOOT STAGE 9] boot.ipxe requested/executed: Client=" + client_ip + " requested dynamic SANBoot script");
                }

                auto content_res = get_file_content(filename);
                if (content_res.is_ok()) {
                    auto data = content_res.value();
                    // Spawn worker thread for RFC 1350 multi-block transfer
                    std::thread([client_addr, filename, data = std::move(data)]() mutable {
                        SOCKET ws = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
                        if (ws == INVALID_SOCKET) {
                            Logger::default_logger().error("TFTP", "Failed to allocate worker socket for transfer of " + filename);
                            return;
                        }

                        DWORD worker_timeout_ms = 2000;
                        setsockopt(ws, SOL_SOCKET, SO_RCVTIMEO, (const char*)&worker_timeout_ms, sizeof(worker_timeout_ms));

                        sockaddr_in worker_bind_addr{};
                        worker_bind_addr.sin_family = AF_INET;
                        worker_bind_addr.sin_port = 0; // OS assigns free ephemeral port
                        worker_bind_addr.sin_addr.s_addr = INADDR_ANY;
                        if (bind(ws, (sockaddr*)&worker_bind_addr, sizeof(worker_bind_addr)) != 0) {
                            closesocket(ws);
                            return;
                        }

                        char ip_str[INET_ADDRSTRLEN] = {0};
                        inet_ntop(AF_INET, &(client_addr.sin_addr), ip_str, INET_ADDRSTRLEN);
                        std::string client_ip_str = ip_str;

                        size_t total_size = data.size();
                        uint16_t block_num = 1;
                        size_t offset = 0;
                        bool transfer_complete = false;

                        while (!transfer_complete) {
                            size_t block_len = 0;
                            if (offset < total_size) {
                                block_len = std::min<size_t>(512, total_size - offset);
                            } else {
                                block_len = 0;
                            }

                            std::span<const uint8_t> payload(data.data() + offset, block_len);
                            auto data_pkt = TftpServer::create_data_packet(block_num, payload);

                            bool ack_received = false;
                            int retries = 0;

                            while (!ack_received && retries < 5) {
                                int sent = sendto(ws, reinterpret_cast<const char*>(data_pkt.data()), data_pkt.size(), 0,
                                                  (sockaddr*)&client_addr, sizeof(client_addr));
                                if (sent <= 0) {
                                    retries++;
                                    continue;
                                }

                                uint8_t ack_buf[64];
                                sockaddr_in from_addr{};
                                int from_len = sizeof(from_addr);

                                int r = recvfrom(ws, reinterpret_cast<char*>(ack_buf), sizeof(ack_buf), 0,
                                                 (sockaddr*)&from_addr, &from_len);
                                if (r >= 4) {
                                    uint16_t opcode = (static_cast<uint16_t>(ack_buf[0]) << 8) | ack_buf[1];
                                    uint16_t ack_blk = (static_cast<uint16_t>(ack_buf[2]) << 8) | ack_buf[3];

                                    if (opcode == 4 && ack_blk == block_num) {
                                        ack_received = true;
                                        client_addr = from_addr;
                                    } else if (opcode == 5) {
                                        Logger::default_logger().warn("TFTP", "Client sent error for " + filename);
                                        closesocket(ws);
                                        return;
                                    }
                                } else {
                                    retries++;
                                }
                            }

                            if (!ack_received) {
                                Logger::default_logger().warn("TFTP", "Timeout / max retries exceeded for " + filename + " block " + std::to_string(block_num));
                                closesocket(ws);
                                return;
                            }

                            offset += block_len;
                            if (block_len < 512) {
                                transfer_complete = true;
                            } else {
                                block_num++;
                            }
                        }

                        if (filename == "boot.ipxe") {
                            Logger::default_logger().info("BOOT", "[BOOT STAGE 10] SANBoot attempted: Client=" + client_ip_str + " completed retrieval of boot.ipxe. Client firmware will now attempt iSCSI SANBoot connection.");
                        } else {
                            Logger::default_logger().info("BOOT", "[BOOT STAGE 7] iPXE binary transferred: File='" + filename + "' (" + std::to_string(total_size) + " bytes, " + std::to_string(block_num) + " blocks) to " + client_ip_str);
                        }
                        closesocket(ws);
                    }).detach();
                } else {
                    Logger::default_logger().warn("TFTP", "File not found: '" + filename + "' requested by " + client_ip);
                    auto err_pkt = create_error_packet(1, "File not found: " + filename);
                    sendto(s, reinterpret_cast<const char*>(err_pkt.data()), err_pkt.size(), 0,
                           (sockaddr*)&client_addr, sizeof(client_addr));
                }
            } else {
                Logger::default_logger().warn("TFTP", "Malformed RRQ packet from " + std::string(inet_ntoa(client_addr.sin_addr)));
                auto err_pkt = create_error_packet(2, fn_res.error().message());
                sendto(s, reinterpret_cast<const char*>(err_pkt.data()), err_pkt.size(), 0,
                       (sockaddr*)&client_addr, sizeof(client_addr));
            }
        }
    }

    closesocket(s);
    WSACleanup();
#else
    while (running_) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
#endif
}

} // namespace cobdiskless
