#include "CobDisklessCore/network/iscsi_target.hpp"
#include "CobDisklessCore/client/client_manager.hpp"
#include "CobDisklessCore/logging/logger.hpp"
#include <cstring>
#include <vector>
#include <algorithm>
#include <sstream>
#include <iostream>
#include <unordered_set>
#include <iomanip>

#if defined(_WIN32) || defined(__CYGWIN__) || defined(__MSYS__)
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#endif

namespace cobdiskless {

namespace {

inline std::string to_hex_u8(uint8_t v) {
    char buf[8];
    snprintf(buf, sizeof(buf), "%02X", v);
    return std::string(buf);
}

inline std::string format_hex_u32(uint32_t val) {
    char buf[16];
    snprintf(buf, sizeof(buf), "%08X", val);
    return std::string(buf);
}

inline std::string scsi_op_name(uint8_t op) {
    switch (static_cast<ScsiOpcode>(op)) {
        case ScsiOpcode::TestUnitReady: return "TEST UNIT READY";
        case ScsiOpcode::RequestSense: return "REQUEST SENSE";
        case ScsiOpcode::Inquiry: return "INQUIRY";
        case ScsiOpcode::ModeSense6: return "MODE SENSE (6)";
        case ScsiOpcode::ModeSense10: return "MODE SENSE (10)";
        case ScsiOpcode::ReadCapacity10: return "READ CAPACITY (10)";
        case ScsiOpcode::Read10: return "READ (10)";
        case ScsiOpcode::Write10: return "WRITE (10)";
        case ScsiOpcode::SynchronizeCache10: return "SYNCHRONIZE CACHE (10)";
        case ScsiOpcode::ReportLUNs: return "REPORT LUNS";
        case ScsiOpcode::Read16: return "READ (16)";
        case ScsiOpcode::Write16: return "WRITE (16)";
        case ScsiOpcode::ServiceActionIn16: return "READ CAPACITY (16) / ServiceActionIn";
        default: return "Opcode";
    }
}

inline uint16_t read_be16(const uint8_t* p) noexcept {
    return static_cast<uint16_t>((p[0] << 8) | p[1]);
}

inline uint32_t read_be32(const uint8_t* p) noexcept {
    return (static_cast<uint32_t>(p[0]) << 24) |
           (static_cast<uint32_t>(p[1]) << 16) |
           (static_cast<uint32_t>(p[2]) << 8)  |
            static_cast<uint32_t>(p[3]);
}

inline uint64_t read_be64(const uint8_t* p) noexcept {
    return (static_cast<uint64_t>(read_be32(p)) << 32) | read_be32(p + 4);
}

inline void write_be16(uint8_t* p, uint16_t v) noexcept {
    p[0] = static_cast<uint8_t>((v >> 8) & 0xFF);
    p[1] = static_cast<uint8_t>(v & 0xFF);
}

inline void write_be32(uint8_t* p, uint32_t v) noexcept {
    p[0] = static_cast<uint8_t>((v >> 24) & 0xFF);
    p[1] = static_cast<uint8_t>((v >> 16) & 0xFF);
    p[2] = static_cast<uint8_t>((v >> 8) & 0xFF);
    p[3] = static_cast<uint8_t>(v & 0xFF);
}

inline void write_be64(uint8_t* p, uint64_t v) noexcept {
    write_be32(p, static_cast<uint32_t>(v >> 32));
    write_be32(p + 4, static_cast<uint32_t>(v & 0xFFFFFFFF));
}

#if defined(_WIN32) || defined(__CYGWIN__) || defined(__MSYS__)
static bool read_exact(SOCKET s, void* buf, size_t len) {
    char* p = static_cast<char*>(buf);
    size_t total = 0;
    while (total < len) {
        int r = recv(s, p + total, static_cast<int>(len - total), 0);
        if (r <= 0) {
            return false;
        }
        total += static_cast<size_t>(r);
    }
    return true;
}
#endif

} // namespace

IscsiTarget::IscsiTarget(
    IscsiTargetConfig config,
    std::shared_ptr<ClientSessionManager> session_mgr
) : config_(std::move(config)),
    session_mgr_(std::move(session_mgr)) {}

IscsiTarget::~IscsiTarget() {
    shutdown();
}

Result<void> IscsiTarget::initialize() {
    if (state_ == SubsystemState::Running) {
        return {};
    }

    running_ = true;
    state_ = SubsystemState::Running;

    accept_thread_ = std::make_unique<std::jthread>([this](std::stop_token st) {
        run_accept_loop();
        (void)st;
    });

    return {};
}

void IscsiTarget::shutdown() noexcept {
    if (!running_) {
        state_ = SubsystemState::Stopped;
        return;
    }

    running_ = false;

#if defined(_WIN32)
    if (listen_socket_ != ~static_cast<uintptr_t>(0)) {
        closesocket(static_cast<SOCKET>(listen_socket_));
        listen_socket_ = ~static_cast<uintptr_t>(0);
    }
#endif

    if (accept_thread_ && accept_thread_->joinable()) {
        accept_thread_->request_stop();
        accept_thread_->join();
        accept_thread_.reset();
    }

    state_ = SubsystemState::Stopped;
}

size_t IscsiTarget::connected_clients_count() const noexcept {
    return connected_clients_.load();
}

Result<std::vector<uint8_t>> IscsiTarget::handle_inquiry(const uint8_t* cdb, const std::string& serial) {
    bool evpd = (cdb[1] & 0x01) != 0;
    uint8_t page_code = cdb[2];
    uint16_t alloc_len = (static_cast<uint16_t>(cdb[3]) << 8) | cdb[4];
    if (alloc_len == 0) {
        alloc_len = 36;
    }

    std::vector<uint8_t> data;

    if (!evpd) {
        // Standard INQUIRY (36 bytes minimum per SPC-3)
        data.resize(36, 0);
        data[0] = 0x00; // Direct access block device
        data[1] = 0x00; // Not removable (RMB=0)
        data[2] = 0x05; // Version: SPC-3 compliant
        data[3] = 0x02; // Response Data Format: 2
        data[4] = 31;   // Additional Length (36 - 5)
        data[7] = 0x02; // Command Queueing (CMDQUE=1)

        // Vendor ID (8 bytes ASCII): "COB     "
        std::memcpy(data.data() + 8, "COB     ", 8);
        // Product ID (16 bytes ASCII): "CobDiskless SAN "
        std::memcpy(data.data() + 16, "CobDiskless SAN ", 16);
        // Product Revision (4 bytes ASCII): "1.0 "
        std::memcpy(data.data() + 32, "1.0 ", 4);
    } else {
        // Vital Product Data (VPD) Pages
        if (page_code == 0x00) {
            // Supported VPD Pages
            data.resize(7, 0);
            data[0] = 0x00;
            data[1] = 0x00;
            data[2] = 0x00;
            data[3] = 0x03; // 3 supported pages
            data[4] = 0x00; // Page 0x00
            data[5] = 0x80; // Page 0x80
            data[6] = 0x83; // Page 0x83
        } else if (page_code == 0x80) {
            // Unit Serial Number
            std::string sn = serial.empty() ? "COB-SAN-00000001" : serial;
            data.resize(4 + sn.size(), 0);
            data[0] = 0x00;
            data[1] = 0x80;
            data[2] = static_cast<uint8_t>((sn.size() >> 8) & 0xFF);
            data[3] = static_cast<uint8_t>(sn.size() & 0xFF);
            std::memcpy(data.data() + 4, sn.data(), sn.size());
        } else if (page_code == 0x83) {
            // Device Identification Page (Essential for Windows disk.sys)
            data.resize(4, 0);
            data[0] = 0x00;
            data[1] = 0x83;

            // Descriptor 1: T10 Vendor ID
            std::vector<uint8_t> d1(28, 0);
            d1[0] = 0x02; // ASCII
            d1[1] = 0x01; // T10 Vendor ID
            d1[2] = 0x00;
            d1[3] = 24;   // Length
            std::memcpy(d1.data() + 4, "COB     CobDiskless SAN ", 24);
            data.insert(data.end(), d1.begin(), d1.end());

            // Descriptor 2: NAA IEEE Registered Extended
            std::vector<uint8_t> d2(20, 0);
            d2[0] = 0x01; // Binary
            d2[1] = 0x03; // NAA
            d2[2] = 0x00;
            d2[3] = 16;   // 16 bytes
            d2[4] = 0x60; // NAA Type 6
            d2[5] = 0x01;
            d2[6] = 0x44;
            d2[7] = 0xF0;
            for (size_t i = 0; i < 12 && i < serial.size(); ++i) {
                d2[8 + i] = static_cast<uint8_t>(serial[i]);
            }
            data.insert(data.end(), d2.begin(), d2.end());

            uint16_t page_len = static_cast<uint16_t>(data.size() - 4);
            data[2] = static_cast<uint8_t>((page_len >> 8) & 0xFF);
            data[3] = static_cast<uint8_t>(page_len & 0xFF);
        } else {
            data.resize(4, 0);
            data[0] = 0x00;
            data[1] = page_code;
            data[2] = 0;
            data[3] = 0;
        }
    }

    if (data.size() > alloc_len) {
        data.resize(alloc_len);
    }
    return data;
}

Result<std::vector<uint8_t>> IscsiTarget::handle_read_capacity(uint64_t total_sectors, uint32_t sector_size) {
    std::vector<uint8_t> data(8, 0);
    uint32_t last_lba = (total_sectors > 0) ? (total_sectors > 0xFFFFFFFF ? 0xFFFFFFFF : static_cast<uint32_t>(total_sectors - 1)) : 0;

    write_be32(data.data(), last_lba);
    write_be32(data.data() + 4, sector_size);
    return data;
}

Result<std::vector<uint8_t>> IscsiTarget::handle_read_capacity16(uint64_t total_sectors, uint32_t sector_size) {
    std::vector<uint8_t> data(32, 0);
    uint64_t last_lba = (total_sectors > 0) ? (total_sectors - 1) : 0;

    write_be64(data.data(), last_lba);
    write_be32(data.data() + 8, sector_size);
    return data;
}

Result<std::vector<uint8_t>> IscsiTarget::handle_report_luns(const ClientSession* session, uint32_t alloc_len) {
    std::vector<uint64_t> luns = {0}; // LUN 0 is OS disk
    if (session && session->game_device()) {
        luns.push_back(1); // LUN 1 is Game disk
    }

    uint32_t lun_list_len = static_cast<uint32_t>(luns.size() * 8);
    std::vector<uint8_t> data(8 + lun_list_len, 0);

    write_be32(data.data(), lun_list_len);

    for (size_t i = 0; i < luns.size(); ++i) {
        uint64_t lun_num = luns[i];
        data[8 + (i * 8)] = static_cast<uint8_t>((lun_num >> 8) & 0xFF);
        data[8 + (i * 8) + 1] = static_cast<uint8_t>(lun_num & 0xFF);
    }

    if (alloc_len > 0 && data.size() > alloc_len) {
        data.resize(alloc_len);
    }
    return data;
}

Result<std::vector<uint8_t>> IscsiTarget::handle_mode_sense(const uint8_t* cdb) {
    bool is_mode10 = (cdb[0] == static_cast<uint8_t>(ScsiOpcode::ModeSense10));
    uint8_t page_code = cdb[2] & 0x3F;
    uint16_t alloc_len = is_mode10 ? ((static_cast<uint16_t>(cdb[7]) << 8) | cdb[8]) : cdb[4];
    if (alloc_len == 0) alloc_len = 64;

    std::vector<uint8_t> data;
    if (!is_mode10) {
        data.resize(4, 0);
        data[0] = 3;
        data[1] = 0x00;
        data[2] = 0x00;
        data[3] = 0x08; // Block descriptor length

        std::vector<uint8_t> bd(8, 0);
        write_be32(bd.data() + 4, 512);
        data.insert(data.end(), bd.begin(), bd.end());
    } else {
        data.resize(8, 0);
        data[0] = 0;
        data[1] = 7;
        data[2] = 0x00;
        data[3] = 0x00;
        data[4] = 0x00;
        data[5] = 0x00;
        data[6] = 0x00;
        data[7] = 0x08; // Block descriptor length

        std::vector<uint8_t> bd(8, 0);
        write_be32(bd.data() + 4, 512);
        data.insert(data.end(), bd.begin(), bd.end());
    }

    if (page_code == 0x08 || page_code == 0x3F) {
        // Caching Mode Page
        std::vector<uint8_t> cp(20, 0);
        cp[0] = 0x08; // Page code: Caching
        cp[1] = 0x12; // Length: 18 bytes
        cp[2] = 0x04; // WCE=1 (Write Cache Enable)
        data.insert(data.end(), cp.begin(), cp.end());
    }

    if (!is_mode10) {
        data[0] = static_cast<uint8_t>(data.size() - 1);
    } else {
        uint16_t m_len = static_cast<uint16_t>(data.size() - 2);
        data[0] = static_cast<uint8_t>((m_len >> 8) & 0xFF);
        data[1] = static_cast<uint8_t>(m_len & 0xFF);
    }

    if (data.size() > alloc_len) {
        data.resize(alloc_len);
    }
    return data;
}

Result<std::vector<uint8_t>> IscsiTarget::handle_request_sense() {
    std::vector<uint8_t> sense(18, 0);
    sense[0] = 0x70; // Current error
    sense[2] = 0x00; // NO SENSE
    sense[7] = 10;   // Additional length
    return sense;
}

std::unordered_map<std::string, std::string> IscsiTarget::parse_text_parameters(std::span<const uint8_t> data) {
    std::unordered_map<std::string, std::string> params;
    size_t start = 0;
    while (start < data.size()) {
        size_t end = start;
        while (end < data.size() && data[end] != 0 && data[end] != '\n' && data[end] != '\r') {
            end++;
        }
        if (end > start) {
            std::string line(reinterpret_cast<const char*>(data.data() + start), end - start);
            auto eq = line.find('=');
            if (eq != std::string::npos) {
                std::string k = line.substr(0, eq);
                std::string v = line.substr(eq + 1);
                params[k] = v;
            }
        }
        start = end + 1;
        while (start < data.size() && (data[start] == 0 || data[start] == '\n' || data[start] == '\r')) {
            start++;
        }
    }
    return params;
}

std::vector<uint8_t> IscsiTarget::build_login_response_parameters(const std::unordered_map<std::string, std::string>& req_params) {
    std::string text;
    auto it_target = req_params.find("TargetName");
    if (it_target != req_params.end()) {
        text += "TargetName=" + it_target->second;
    } else {
        text += "TargetName=iqn.2026-09.com.cobdiskless:storage";
    }
    text.push_back('\0');

    text += "TargetPortalGroupTag=1";
    text.push_back('\0');

    auto it_auth = req_params.find("AuthMethod");
    if (it_auth != req_params.end()) {
        text += "AuthMethod=None";
        text.push_back('\0');
    }

    text += "HeaderDigest=None";
    text.push_back('\0');
    text += "DataDigest=None";
    text.push_back('\0');
    text += "InitialR2T=Yes";
    text.push_back('\0');
    text += "ImmediateData=Yes";
    text.push_back('\0');
    text += "MaxRecvDataSegmentLength=65536";
    text.push_back('\0');
    text += "DefaultTime2Wait=0";
    text.push_back('\0');
    text += "DefaultTime2Retain=0";
    text.push_back('\0');
    text += "MaxOutstandingR2T=1";
    text.push_back('\0');
    text += "DataPDUInOrder=Yes";
    text.push_back('\0');
    text += "DataSequenceInOrder=Yes";
    text.push_back('\0');
    text += "ErrorRecoveryLevel=0";
    text.push_back('\0');

    return std::vector<uint8_t>(text.begin(), text.end());
}

Result<size_t> IscsiTarget::execute_read(
    ClientSession& session,
    uint64_t start_lba,
    uint32_t sector_count,
    std::span<std::byte> destination,
    uint64_t lun
) {
    auto dev = session.get_device_for_lun(lun);
    if (!dev) {
        return Error(ErrorCode::StorageFailure, "No block device attached to LUN " + std::to_string(lun));
    }

    uint64_t offset = start_lba * 512;
    size_t req_bytes = static_cast<size_t>(sector_count) * 512;

    if (offset + req_bytes > dev->size()) {
        return Error(ErrorCode::StorageFailure, "SCSI read exceeds device capacity");
    }

    if (destination.size() < req_bytes) {
        return Error(ErrorCode::StorageFailure, "Destination buffer smaller than requested sectors");
    }

    auto read_span = destination.subspan(0, req_bytes);
    auto res = dev->read(offset, read_span);
    if (res.is_ok()) {
        session.record_read(res.value());
    }
    return res;
}

Result<size_t> IscsiTarget::execute_write(
    ClientSession& session,
    uint64_t start_lba,
    uint32_t sector_count,
    std::span<const std::byte> source,
    uint64_t lun
) {
    if (lun != 0) {
        return Error(ErrorCode::UnsupportedOperation, "LUN " + std::to_string(lun) + " is read-only protected storage");
    }

    auto dev = session.cow_device();
    if (!dev) {
        return Error(ErrorCode::StorageFailure, "No block device attached to client session");
    }

    uint64_t offset = start_lba * 512;
    size_t req_bytes = static_cast<size_t>(sector_count) * 512;

    if (offset + req_bytes > dev->size()) {
        return Error(ErrorCode::StorageFailure, "SCSI write exceeds device capacity");
    }

    if (source.size() < req_bytes) {
        return Error(ErrorCode::StorageFailure, "Source buffer smaller than write sectors");
    }

    auto write_span = source.subspan(0, req_bytes);
    auto res = dev->write(offset, write_span);
    if (res.is_ok()) {
        session.record_write(res.value());
    }
    return res;
}

Result<void> IscsiTarget::execute_sync_cache(ClientSession& session, uint64_t lun) {
    if (lun == 0 && session.cow_device()) {
        return session.cow_device()->flush();
    }
    return {};
}

void IscsiTarget::run_accept_loop() {
#if defined(_WIN32) || defined(__CYGWIN__) || defined(__MSYS__)
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        return;
    }

    SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (s == INVALID_SOCKET) {
        WSACleanup();
        return;
    }

    listen_socket_ = static_cast<uintptr_t>(s);

    BOOL reuse = TRUE;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (const char*)&reuse, sizeof(reuse));

    // 1-second accept timeout so thread can react to stop
    DWORD timeout_ms = 1000;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char*)&timeout_ms, sizeof(timeout_ms));

    sockaddr_in bind_addr{};
    bind_addr.sin_family = AF_INET;
    bind_addr.sin_port = htons(config_.listen_address.port());
    bind_addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(s, (sockaddr*)&bind_addr, sizeof(bind_addr)) != 0 || listen(s, SOMAXCONN) != 0) {
        closesocket(s);
        WSACleanup();
        while (running_) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
        return;
    }

    while (running_) {
        sockaddr_in client_addr{};
        int addr_len = sizeof(client_addr);
        SOCKET cli_sock = accept(s, (sockaddr*)&client_addr, &addr_len);

        if (cli_sock != INVALID_SOCKET) {
            connected_clients_++;
            NetworkAddress client_ip(
                client_addr.sin_addr.s_addr & 0xFF,
                (client_addr.sin_addr.s_addr >> 8) & 0xFF,
                (client_addr.sin_addr.s_addr >> 16) & 0xFF,
                (client_addr.sin_addr.s_addr >> 24) & 0xFF,
                ntohs(client_addr.sin_port)
            );

            // Detach worker thread to service client concurrently
            std::thread([this, cli_sock, client_ip]() {
                handle_client_connection(static_cast<uintptr_t>(cli_sock), client_ip);
                connected_clients_--;
            }).detach();
        }
    }

    closesocket(s);
    WSACleanup();
#else
    while (running_) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
#endif
}

void IscsiTarget::handle_client_connection(uintptr_t client_sock, NetworkAddress client_ip) {
#if defined(_WIN32) || defined(__CYGWIN__) || defined(__MSYS__)
    SOCKET s = static_cast<SOCKET>(client_sock);

    Logger::default_logger().info("BOOT", "[BOOT STAGE 11] iSCSI TCP connection received: Client=" + client_ip.ip_string() + ":" + std::to_string(client_ip.port()));

    std::shared_ptr<ClientSession> session;
    std::string initiator_name;
    std::string client_mac;

    auto resolve_session = [&](const std::string& init_name) {
        if (session) return;
        ClientId cid;
        if (client_manager_) {
            auto rec = client_manager_->get_client_by_ip(client_ip.to_string());
            if (!rec && !init_name.empty()) {
                for (const auto& c : client_manager_->list_clients()) {
                    if (init_name.find(c.pc_name) != std::string::npos ||
                        init_name.find(c.mac_address) != std::string::npos) {
                        rec = c;
                        break;
                    }
                }
            }
            if (rec) {
                cid = ClientId(rec->mac_address);
                client_mac = rec->mac_address;
            }
        }
        if (cid.value().empty()) {
            cid = ClientId("ip_" + client_ip.ip_string());
        }

        if (session_mgr_) {
            auto sess_res = session_mgr_->get_or_create_session(cid, client_ip, config_.default_os_image_id);
            if (sess_res.is_ok()) {
                session = sess_res.value();
                session->set_state(ClientState::Online);
            } else {
                Logger::default_logger().error("iSCSI", "Failed to resolve/create session for client: " + sess_res.error().message());
            }
        }
    };

    resolve_session("");

    uint32_t stat_sn = 1;

    while (running_) {
        IscsiBhs bhs{};
        if (!read_exact(s, &bhs, sizeof(IscsiBhs))) {
            break;
        }

        uint8_t opcode = bhs.opcode & 0x3F;
        uint32_t data_seg_len = (static_cast<uint32_t>(bhs.data_seg_len[0]) << 16) |
                                (static_cast<uint32_t>(bhs.data_seg_len[1]) << 8)  |
                                static_cast<uint32_t>(bhs.data_seg_len[2]);

        uint32_t padded_len = (data_seg_len + 3) & ~3;
        std::vector<uint8_t> data_seg(padded_len, 0);
        if (padded_len > 0) {
            if (!read_exact(s, data_seg.data(), padded_len)) {
                break;
            }
            data_seg.resize(data_seg_len);
        }

        if (opcode == 0x03) { // Login Request
            auto params = parse_text_parameters(data_seg);
            auto it_init = params.find("InitiatorName");
            if (it_init != params.end()) {
                initiator_name = it_init->second;
                resolve_session(initiator_name);
            }

            IscsiBhs resp{};
            resp.opcode = 0x23; // Login Response
            resp.flags = 0x80;  // Transit to Full Feature phase
            resp.initiator_task_tag = bhs.initiator_task_tag;
            resp.cmd_sn = stat_sn++;
            resp.exp_stat_sn = bhs.cmd_sn + 1;

            Logger::default_logger().info("BOOT", "[BOOT STAGE 12] iSCSI login completed: Initiator='" + initiator_name +
                         "' Target='" + config_.target_iqn + "' ClientSession=" + (session ? session->id().value() : "unknown"));

            if (data_seg_len > 0) {
                auto resp_params = build_login_response_parameters(params);
                uint32_t r_len = static_cast<uint32_t>(resp_params.size());
                resp.data_seg_len[0] = static_cast<uint8_t>((r_len >> 16) & 0xFF);
                resp.data_seg_len[1] = static_cast<uint8_t>((r_len >> 8) & 0xFF);
                resp.data_seg_len[2] = static_cast<uint8_t>(r_len & 0xFF);

                send(s, reinterpret_cast<const char*>(&resp), sizeof(resp), 0);
                if (r_len > 0) {
                    send(s, reinterpret_cast<const char*>(resp_params.data()), resp_params.size(), 0);
                    uint32_t pad = (4 - (r_len % 4)) % 4;
                    if (pad > 0) {
                        const char pad_bytes[4] = {0};
                        send(s, pad_bytes, pad, 0);
                    }
                }
            } else {
                send(s, reinterpret_cast<const char*>(&resp), sizeof(resp), 0);
            }
        } else if (opcode == 0x06) { // Logout Request
            IscsiBhs resp{};
            resp.opcode = 0x26; // Logout Response
            resp.flags = 0x80;
            resp.initiator_task_tag = bhs.initiator_task_tag;
            resp.cmd_sn = stat_sn++;
            resp.exp_stat_sn = bhs.cmd_sn + 1;
            send(s, reinterpret_cast<const char*>(&resp), sizeof(resp), 0);
            break;
        } else if (opcode == 0x1C) { // NOP-Out (Ping)
            if (bhs.initiator_task_tag != 0xFFFFFFFF) {
                IscsiBhs resp{};
                resp.opcode = 0x20; // NOP-In
                resp.flags = 0x80;
                resp.initiator_task_tag = bhs.initiator_task_tag;
                resp.cmd_sn = stat_sn++;
                resp.exp_stat_sn = bhs.cmd_sn + 1;
                send(s, reinterpret_cast<const char*>(&resp), sizeof(resp), 0);
            }
        } else if (opcode == 0x01) { // SCSI Command
            uint8_t scsi_op = bhs.cdb[0];
            const uint8_t* lun_b = reinterpret_cast<const uint8_t*>(&bhs.lun);
            uint64_t req_lun = (static_cast<uint64_t>(lun_b[0] & 0x3F) << 8) | lun_b[1];
            if (req_lun == 0 && bhs.lun != 0) {
                req_lun = (bhs.lun & 0xFFFF);
            }

            Logger::default_logger().info("BOOT", "[BOOT STAGE 13] SCSI command received: " + scsi_op_name(scsi_op) +
                         " (0x" + to_hex_u8(scsi_op) + ") InitiatorTaskTag=0x" + format_hex_u32(bhs.initiator_task_tag) +
                         " LUN=" + std::to_string(req_lun));

            auto target_device = session ? session->get_device_for_lun(req_lun) : nullptr;

            if (req_lun == 0 && target_device) {
                static std::unordered_set<std::string> logged_lun0;
                if (session && !logged_lun0.contains(session->id().value())) {
                    logged_lun0.insert(session->id().value());
                    Logger::default_logger().info("BOOT", "[BOOT STAGE 14] LUN 0 selected: OS Virtual Disk mounted (" +
                                 std::to_string(target_device->size() / (1024 * 1024)) + " MB) with COW writeback overlay for " + session->id().value());
                }
            }

            if (scsi_op == static_cast<uint8_t>(ScsiOpcode::TestUnitReady)) {
                IscsiBhs resp{};
                resp.opcode = 0x21; // SCSI Response
                resp.flags = 0x80;
                resp.initiator_task_tag = bhs.initiator_task_tag;
                resp.cmd_sn = stat_sn++;
                resp.exp_stat_sn = bhs.cmd_sn + 1;
                send(s, reinterpret_cast<const char*>(&resp), sizeof(resp), 0);
            } else if (scsi_op == static_cast<uint8_t>(ScsiOpcode::Inquiry)) {
                std::string sn = client_mac.empty() ? "COB-SAN-00000001" : ("COB-SAN-" + client_mac);
                auto inq_data = handle_inquiry(bhs.cdb, sn).value();

                IscsiBhs in_bhs{};
                in_bhs.opcode = 0x25; // SCSI Data-In
                in_bhs.flags = 0x81;  // Final + Status
                in_bhs.initiator_task_tag = bhs.initiator_task_tag;
                in_bhs.cmd_sn = stat_sn++;
                in_bhs.exp_stat_sn = bhs.cmd_sn + 1;
                in_bhs.data_seg_len[0] = static_cast<uint8_t>((inq_data.size() >> 16) & 0xFF);
                in_bhs.data_seg_len[1] = static_cast<uint8_t>((inq_data.size() >> 8) & 0xFF);
                in_bhs.data_seg_len[2] = static_cast<uint8_t>(inq_data.size() & 0xFF);

                send(s, reinterpret_cast<const char*>(&in_bhs), sizeof(in_bhs), 0);
                send(s, reinterpret_cast<const char*>(inq_data.data()), inq_data.size(), 0);
                uint32_t pad = (4 - (inq_data.size() % 4)) % 4;
                if (pad > 0) {
                    const char pad_bytes[4] = {0};
                    send(s, pad_bytes, pad, 0);
                }
            } else if (scsi_op == static_cast<uint8_t>(ScsiOpcode::ReportLUNs)) {
                uint32_t alloc_len = read_be32(bhs.cdb + 6);
                auto luns_data = handle_report_luns(session.get(), alloc_len).value();

                IscsiBhs in_bhs{};
                in_bhs.opcode = 0x25;
                in_bhs.flags = 0x81;
                in_bhs.initiator_task_tag = bhs.initiator_task_tag;
                in_bhs.cmd_sn = stat_sn++;
                in_bhs.exp_stat_sn = bhs.cmd_sn + 1;
                in_bhs.data_seg_len[0] = static_cast<uint8_t>((luns_data.size() >> 16) & 0xFF);
                in_bhs.data_seg_len[1] = static_cast<uint8_t>((luns_data.size() >> 8) & 0xFF);
                in_bhs.data_seg_len[2] = static_cast<uint8_t>(luns_data.size() & 0xFF);

                send(s, reinterpret_cast<const char*>(&in_bhs), sizeof(in_bhs), 0);
                send(s, reinterpret_cast<const char*>(luns_data.data()), luns_data.size(), 0);
                uint32_t pad = (4 - (luns_data.size() % 4)) % 4;
                if (pad > 0) {
                    const char pad_bytes[4] = {0};
                    send(s, pad_bytes, pad, 0);
                }
            } else if (scsi_op == static_cast<uint8_t>(ScsiOpcode::ReadCapacity10)) {
                uint64_t total_sectors = target_device ? target_device->size() / 512 : 2097152;
                auto cap_data = handle_read_capacity(total_sectors, 512).value();

                IscsiBhs in_bhs{};
                in_bhs.opcode = 0x25;
                in_bhs.flags = 0x81;
                in_bhs.initiator_task_tag = bhs.initiator_task_tag;
                in_bhs.cmd_sn = stat_sn++;
                in_bhs.exp_stat_sn = bhs.cmd_sn + 1;
                in_bhs.data_seg_len[2] = static_cast<uint8_t>(cap_data.size());

                send(s, reinterpret_cast<const char*>(&in_bhs), sizeof(in_bhs), 0);
                send(s, reinterpret_cast<const char*>(cap_data.data()), cap_data.size(), 0);
            } else if (scsi_op == static_cast<uint8_t>(ScsiOpcode::ServiceActionIn16) && (bhs.cdb[1] & 0x1F) == 0x10) {
                uint64_t total_sectors = target_device ? target_device->size() / 512 : 2097152;
                auto cap_data = handle_read_capacity16(total_sectors, 512).value();

                IscsiBhs in_bhs{};
                in_bhs.opcode = 0x25;
                in_bhs.flags = 0x81;
                in_bhs.initiator_task_tag = bhs.initiator_task_tag;
                in_bhs.cmd_sn = stat_sn++;
                in_bhs.exp_stat_sn = bhs.cmd_sn + 1;
                in_bhs.data_seg_len[2] = static_cast<uint8_t>(cap_data.size());

                send(s, reinterpret_cast<const char*>(&in_bhs), sizeof(in_bhs), 0);
                send(s, reinterpret_cast<const char*>(cap_data.data()), cap_data.size(), 0);
            } else if (scsi_op == static_cast<uint8_t>(ScsiOpcode::ModeSense6) || scsi_op == static_cast<uint8_t>(ScsiOpcode::ModeSense10)) {
                auto mode_data = handle_mode_sense(bhs.cdb).value();

                IscsiBhs in_bhs{};
                in_bhs.opcode = 0x25;
                in_bhs.flags = 0x81;
                in_bhs.initiator_task_tag = bhs.initiator_task_tag;
                in_bhs.cmd_sn = stat_sn++;
                in_bhs.exp_stat_sn = bhs.cmd_sn + 1;
                in_bhs.data_seg_len[0] = static_cast<uint8_t>((mode_data.size() >> 16) & 0xFF);
                in_bhs.data_seg_len[1] = static_cast<uint8_t>((mode_data.size() >> 8) & 0xFF);
                in_bhs.data_seg_len[2] = static_cast<uint8_t>(mode_data.size() & 0xFF);

                send(s, reinterpret_cast<const char*>(&in_bhs), sizeof(in_bhs), 0);
                send(s, reinterpret_cast<const char*>(mode_data.data()), mode_data.size(), 0);
                uint32_t pad = (4 - (mode_data.size() % 4)) % 4;
                if (pad > 0) {
                    const char pad_bytes[4] = {0};
                    send(s, pad_bytes, pad, 0);
                }
            } else if (scsi_op == static_cast<uint8_t>(ScsiOpcode::Read10) || scsi_op == static_cast<uint8_t>(ScsiOpcode::Read16)) {
                uint64_t lba = (scsi_op == static_cast<uint8_t>(ScsiOpcode::Read10)) ? read_be32(bhs.cdb + 2) : read_be64(bhs.cdb + 2);
                uint32_t sectors = (scsi_op == static_cast<uint8_t>(ScsiOpcode::Read10)) ? read_be16(bhs.cdb + 7) : read_be32(bhs.cdb + 10);
                size_t byte_len = static_cast<size_t>(sectors) * 512;

                Logger::default_logger().info("BOOT", "[BOOT STAGE 15] SCSI READ request: LUN=" + std::to_string(req_lun) +
                             " LBA=" + std::to_string(lba) + " Sectors=" + std::to_string(sectors));

                if (req_lun == 0) {
                    static std::unordered_map<std::string, uint32_t> client_boot_stage;
                    std::string s_id = session ? session->id().value() : "unknown";
                    uint32_t& stage_mask = client_boot_stage[s_id];

                    if (lba == 0 && !(stage_mask & 1)) {
                        stage_mask |= 1;
                        Logger::default_logger().info("BOOT", "[BOOT STAGE 17] Windows boot progress: Reading MBR / Partition Table (LBA 0)");
                    } else if ((lba == 1 || lba == 2) && !(stage_mask & 2)) {
                        stage_mask |= 2;
                        Logger::default_logger().info("BOOT", "[BOOT STAGE 17] Windows boot progress: Reading GPT Header / Partition Entries (LBA " + std::to_string(lba) + ")");
                    } else if (lba >= 2048 && lba < 65536 && !(stage_mask & 4)) {
                        stage_mask |= 4;
                        Logger::default_logger().info("BOOT", "[BOOT STAGE 17] Windows boot progress: Reading System Boot Volume / VBR / bootmgr (LBA " + std::to_string(lba) + ")");
                    } else if (lba >= 65536 && !(stage_mask & 8)) {
                        stage_mask |= 8;
                        Logger::default_logger().info("BOOT", "[BOOT STAGE 17] Windows boot progress: Reading Windows OS Kernels / Drivers (LBA " + std::to_string(lba) + ")");
                    }
                }

                std::vector<std::byte> payload(byte_len, std::byte{0});
                if (session) {
                    (void)execute_read(*session, lba, sectors, payload, req_lun);
                }

                size_t max_burst = 65536;
                size_t sent_bytes = 0;
                while (sent_bytes < byte_len || byte_len == 0) {
                    size_t chunk = std::min(max_burst, byte_len - sent_bytes);
                    bool is_final = (sent_bytes + chunk >= byte_len);

                    IscsiBhs in_bhs{};
                    in_bhs.opcode = 0x25;
                    in_bhs.flags = is_final ? 0x81 : 0x00;
                    in_bhs.initiator_task_tag = bhs.initiator_task_tag;
                    in_bhs.data_transfer_tag = 0;
                    in_bhs.cmd_sn = stat_sn++;
                    in_bhs.exp_stat_sn = bhs.cmd_sn + 1;
                    in_bhs.data_seg_len[0] = static_cast<uint8_t>((chunk >> 16) & 0xFF);
                    in_bhs.data_seg_len[1] = static_cast<uint8_t>((chunk >> 8) & 0xFF);
                    in_bhs.data_seg_len[2] = static_cast<uint8_t>(chunk & 0xFF);

                    send(s, reinterpret_cast<const char*>(&in_bhs), sizeof(in_bhs), 0);
                    if (chunk > 0) {
                        send(s, reinterpret_cast<const char*>(payload.data() + sent_bytes), chunk, 0);
                        uint32_t pad = (4 - (chunk % 4)) % 4;
                        if (pad > 0) {
                            const char pad_bytes[4] = {0};
                            send(s, pad_bytes, pad, 0);
                        }
                    }
                    sent_bytes += chunk;
                    if (is_final) break;
                }
            } else if (scsi_op == static_cast<uint8_t>(ScsiOpcode::Write10) || scsi_op == static_cast<uint8_t>(ScsiOpcode::Write16)) {
                uint64_t lba = (scsi_op == static_cast<uint8_t>(ScsiOpcode::Write10)) ? read_be32(bhs.cdb + 2) : read_be64(bhs.cdb + 2);
                uint32_t sectors = (scsi_op == static_cast<uint8_t>(ScsiOpcode::Write10)) ? read_be16(bhs.cdb + 7) : read_be32(bhs.cdb + 10);
                size_t req_bytes = static_cast<size_t>(sectors) * 512;

                if (req_lun != 0) {
                    size_t drained = 0;
                    if (!data_seg.empty()) {
                        drained += std::min(data_seg.size(), req_bytes);
                    }
                    while (drained < req_bytes) {
                        IscsiBhs dout_bhs{};
                        if (!read_exact(s, &dout_bhs, sizeof(IscsiBhs))) {
                            break;
                        }
                        uint32_t d_len = (static_cast<uint32_t>(dout_bhs.data_seg_len[0]) << 16) |
                                         (static_cast<uint32_t>(dout_bhs.data_seg_len[1]) << 8)  |
                                         static_cast<uint32_t>(dout_bhs.data_seg_len[2]);
                        uint32_t p_len = (d_len + 3) & ~3;
                        if (p_len > 0) {
                            std::vector<uint8_t> discard(p_len);
                            if (!read_exact(s, discard.data(), p_len)) break;
                        }
                        drained += d_len;
                        if (dout_bhs.flags & 0x80) break;
                    }

                    IscsiBhs resp{};
                    resp.opcode = 0x21;
                    resp.flags = 0x80;
                    resp.rsvd1[1] = 0x02; // SCSI Status: Check Condition
                    resp.initiator_task_tag = bhs.initiator_task_tag;
                    resp.cmd_sn = stat_sn++;
                    resp.exp_stat_sn = bhs.cmd_sn + 1;
                    resp.cdb[0] = 0x02; // Check Condition (Data Protect)
                    send(s, reinterpret_cast<const char*>(&resp), sizeof(resp), 0);
                    continue;
                }

                std::vector<std::byte> write_buf;
                write_buf.reserve(req_bytes);

                if (!data_seg.empty()) {
                    size_t imm_len = std::min(data_seg.size(), req_bytes);
                    const auto* p = reinterpret_cast<const std::byte*>(data_seg.data());
                    write_buf.insert(write_buf.end(), p, p + imm_len);
                }

                while (write_buf.size() < req_bytes) {
                    IscsiBhs dout_bhs{};
                    if (!read_exact(s, &dout_bhs, sizeof(IscsiBhs))) {
                        break;
                    }
                    uint32_t d_len = (static_cast<uint32_t>(dout_bhs.data_seg_len[0]) << 16) |
                                     (static_cast<uint32_t>(dout_bhs.data_seg_len[1]) << 8)  |
                                     static_cast<uint32_t>(dout_bhs.data_seg_len[2]);
                    uint32_t p_len = (d_len + 3) & ~3;
                    std::vector<uint8_t> d_payload(p_len, 0);
                    if (p_len > 0) {
                        if (!read_exact(s, d_payload.data(), p_len)) {
                            break;
                        }
                    }
                    size_t needed = req_bytes - write_buf.size();
                    size_t to_copy = std::min(static_cast<size_t>(d_len), needed);
                    const auto* p = reinterpret_cast<const std::byte*>(d_payload.data());
                    write_buf.insert(write_buf.end(), p, p + to_copy);
                    if (dout_bhs.flags & 0x80) {
                        break;
                    }
                }

                if (session && write_buf.size() >= req_bytes) {
                    (void)execute_write(*session, lba, sectors, write_buf, req_lun);
                    Logger::default_logger().info("BOOT", "[BOOT STAGE 16] SCSI WRITE request: LUN=" + std::to_string(req_lun) +
                                 " LBA=" + std::to_string(lba) + " Sectors=" + std::to_string(sectors) + " committed to COW overlay");
                }

                IscsiBhs resp{};
                resp.opcode = 0x21;
                resp.flags = 0x80;
                resp.initiator_task_tag = bhs.initiator_task_tag;
                resp.cmd_sn = stat_sn++;
                resp.exp_stat_sn = bhs.cmd_sn + 1;
                send(s, reinterpret_cast<const char*>(&resp), sizeof(resp), 0);
            } else if (scsi_op == static_cast<uint8_t>(ScsiOpcode::SynchronizeCache10) || scsi_op == static_cast<uint8_t>(ScsiOpcode::SynchronizeCache16)) {
                if (session) {
                    (void)execute_sync_cache(*session, req_lun);
                }
                IscsiBhs resp{};
                resp.opcode = 0x21;
                resp.flags = 0x80;
                resp.initiator_task_tag = bhs.initiator_task_tag;
                resp.cmd_sn = stat_sn++;
                resp.exp_stat_sn = bhs.cmd_sn + 1;
                send(s, reinterpret_cast<const char*>(&resp), sizeof(resp), 0);
            } else if (scsi_op == static_cast<uint8_t>(ScsiOpcode::RequestSense)) {
                auto sense_data = handle_request_sense().value();
                IscsiBhs in_bhs{};
                in_bhs.opcode = 0x25;
                in_bhs.flags = 0x81;
                in_bhs.initiator_task_tag = bhs.initiator_task_tag;
                in_bhs.cmd_sn = stat_sn++;
                in_bhs.exp_stat_sn = bhs.cmd_sn + 1;
                in_bhs.data_seg_len[2] = static_cast<uint8_t>(sense_data.size());

                send(s, reinterpret_cast<const char*>(&in_bhs), sizeof(in_bhs), 0);
                send(s, reinterpret_cast<const char*>(sense_data.data()), sense_data.size(), 0);
            } else {
                IscsiBhs resp{};
                resp.opcode = 0x21;
                resp.flags = 0x80;
                resp.initiator_task_tag = bhs.initiator_task_tag;
                resp.cmd_sn = stat_sn++;
                resp.exp_stat_sn = bhs.cmd_sn + 1;
                send(s, reinterpret_cast<const char*>(&resp), sizeof(resp), 0);
            }
        }
    }

    if (session) {
        session->set_state(ClientState::Offline);
    }

    closesocket(s);
#else
    (void)client_sock;
    (void)client_ip;
#endif
}

} // namespace cobdiskless
