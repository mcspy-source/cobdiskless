#include "CobDisklessCore/network/dhcp_server.hpp"
#include "CobDisklessCore/client/client_manager.hpp"
#include "CobDisklessCore/logging/logger.hpp"
#include <cstring>
#include <sstream>
#include <iomanip>
#include <algorithm>

#if defined(_WIN32)
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#endif

namespace cobdiskless {

DhcpServer::DhcpServer(
    NetworkAddress server_ip,
    NetworkAddress subnet_mask,
    NetworkAddress ip_pool_start,
    NetworkAddress ip_pool_end,
    uint16_t port
) : server_ip_(server_ip),
    subnet_mask_(subnet_mask),
    ip_pool_start_(ip_pool_start),
    ip_pool_end_(ip_pool_end),
    port_(port) {}

DhcpServer::~DhcpServer() {
    (void)shutdown();
}

Result<void> DhcpServer::initialize() {
    if (state_ == SubsystemState::Running) {
        return {};
    }

    running_ = true;
    state_ = SubsystemState::Running;

    // Launch worker thread
    worker_thread_ = std::make_unique<std::jthread>([this](std::stop_token st) {
        run_packet_loop();
        (void)st;
    });

    return {};
}

void DhcpServer::shutdown() noexcept {
    if (!running_) {
        state_ = SubsystemState::Stopped;
        return;
    }

    running_ = false;

#if defined(_WIN32)
    if (server_socket_ != ~static_cast<uintptr_t>(0)) {
        closesocket(static_cast<SOCKET>(server_socket_));
        server_socket_ = ~static_cast<uintptr_t>(0);
    }
#endif

    if (worker_thread_ && worker_thread_->joinable()) {
        worker_thread_->request_stop();
        worker_thread_->join();
        worker_thread_.reset();
    }

    state_ = SubsystemState::Stopped;
}

Result<DhcpDiscoveredOptions> DhcpServer::parse_packet(
    std::span<const uint8_t> packet_data
) {
    if (packet_data.size() < sizeof(DhcpHeader)) {
        return Error(ErrorCode::NetworkFailure, "Packet smaller than DHCP header size");
    }

    const auto* header = reinterpret_cast<const DhcpHeader*>(packet_data.data());

    // Verify magic cookie: 99, 130, 83, 99
    if (header->magic_cookie[0] != 99 || header->magic_cookie[1] != 130 ||
        header->magic_cookie[2] != 83 || header->magic_cookie[3] != 99) {
        return Error(ErrorCode::NetworkFailure, "Invalid DHCP magic cookie");
    }

    DhcpDiscoveredOptions result;

    // Format MAC address
    std::ostringstream mac_ss;
    for (int i = 0; i < 6; ++i) {
        if (i > 0) mac_ss << ":";
        mac_ss << std::hex << std::uppercase << std::setw(2) << std::setfill('0')
               << static_cast<int>(header->chaddr[i]);
    }
    result.client_mac = mac_ss.str();

    // Parse options
    size_t offset = sizeof(DhcpHeader);
    while (offset < packet_data.size()) {
        uint8_t opt_code = packet_data[offset++];
        if (opt_code == 0) { // PAD
            continue;
        }
        if (opt_code == 255) { // END
            break;
        }

        if (offset >= packet_data.size()) {
            break;
        }
        uint8_t opt_len = packet_data[offset++];
        if (offset + opt_len > packet_data.size()) {
            break;
        }

        const uint8_t* opt_val = packet_data.data() + offset;

        if (opt_code == 53 && opt_len == 1) { // DHCP Message Type
            result.message_type = opt_val[0];
        } else if (opt_code == 50 && opt_len == 4) { // Requested IP
            result.requested_ip = NetworkAddress(opt_val[0], opt_val[1], opt_val[2], opt_val[3]);
        } else if (opt_code == 93 && opt_len >= 2) { // Client Architecture (RFC 4578)
            uint16_t arch_val = (static_cast<uint16_t>(opt_val[0]) << 8) | opt_val[1];
            switch (arch_val) {
                case 0:  result.client_arch = ClientArch::Bios_x86; break;
                case 6:  result.client_arch = ClientArch::Efi_x86; break;
                case 7:  result.client_arch = ClientArch::Efi_x64; break;
                case 9:  result.client_arch = ClientArch::Efi_Ebc; break;
                case 10: result.client_arch = ClientArch::Efi_Arm32; break;
                case 11: result.client_arch = ClientArch::Efi_Arm64; break;
                default: result.client_arch = ClientArch::Unknown; break;
            }
        } else if (opt_code == 60 && opt_len > 0) { // Vendor Class Identifier (RFC 2132)
            result.vendor_class = std::string(reinterpret_cast<const char*>(opt_val), opt_len);
            if (result.vendor_class.find("PXEClient") != std::string::npos) {
                result.is_pxe_client = true;
            }
        } else if (opt_code == 77 && opt_len > 0) { // User Class Identifier (RFC 3004)
            std::string user_class(reinterpret_cast<const char*>(opt_val), opt_len);
            if (user_class.find("iPXE") != std::string::npos) {
                result.is_ipxe_client = true;
            }
        } else if (opt_code == 54 && opt_len == 4) { // Server Identifier
            result.server_identifier = (static_cast<uint32_t>(opt_val[0]) << 24) |
                                       (static_cast<uint32_t>(opt_val[1]) << 16) |
                                       (static_cast<uint32_t>(opt_val[2]) << 8)  |
                                       opt_val[3];
        } else if (opt_code == 175) { // iPXE options
            result.is_ipxe_client = true;
        } else if (opt_code == 12 && opt_len > 0) { // Hostname
            result.hostname = std::string(reinterpret_cast<const char*>(opt_val), opt_len);
        }

        offset += opt_len;
    }

    return result;
}

Result<std::vector<uint8_t>> DhcpServer::build_reply(
    const DhcpHeader& request_header,
    const DhcpDiscoveredOptions& options,
    uint8_t reply_message_type,
    NetworkAddress assigned_ip
) {
    std::vector<uint8_t> packet;
    packet.resize(sizeof(DhcpHeader));

    auto* reply = reinterpret_cast<DhcpHeader*>(packet.data());
    reply->op = 2; // BOOTREPLY
    reply->htype = request_header.htype;
    reply->hlen = request_header.hlen;
    reply->hops = 0;
    reply->xid = request_header.xid;
    reply->secs = 0;
    // Force broadcast flag so physical PXE ROMs receive response before IP configuration
    reply->flags = request_header.flags | htons(0x8000);
    reply->ciaddr = 0;

    // DHCP Magic Cookie: RFC 2131 / RFC 1497 (0x63825363 = 99, 130, 83, 99)
    reply->magic_cookie[0] = 99;   // 0x63
    reply->magic_cookie[1] = 130;  // 0x82
    reply->magic_cookie[2] = 83;   // 0x53
    reply->magic_cookie[3] = 99;   // 0x63

    // Determine effective server IP (auto-detect physical interface if loopback or zero)
    NetworkAddress effective_server_ip = server_ip_;
    if (effective_server_ip.is_loopback() ||
        (effective_server_ip.octet(0) == 0 && effective_server_ip.octet(1) == 0 &&
         effective_server_ip.octet(2) == 0 && effective_server_ip.octet(3) == 0)) {
        effective_server_ip = NetworkAddress::detect_local_ip(67);
    }

    // Assigned Client IP (yiaddr)
    uint8_t yi_bytes[4] = {assigned_ip.octet(0), assigned_ip.octet(1), assigned_ip.octet(2), assigned_ip.octet(3)};
    std::memcpy(&reply->yiaddr, yi_bytes, 4);

    // Next Server IP (siaddr - TFTP Server IP for PXE stage 1)
    uint8_t si_bytes[4] = {effective_server_ip.octet(0), effective_server_ip.octet(1), effective_server_ip.octet(2), effective_server_ip.octet(3)};
    std::memcpy(&reply->siaddr, si_bytes, 4);
    reply->giaddr = request_header.giaddr;

    std::memcpy(reply->chaddr, request_header.chaddr, 16);

    // Bootfile Selection based on architecture and iPXE detection
    std::string bootfile;
    if (options.is_ipxe_client) {
        bootfile = "boot.ipxe";
    } else if (options.client_arch == ClientArch::Efi_x64 ||
               options.client_arch == ClientArch::Efi_Arm64 ||
               options.client_arch == ClientArch::Efi_Ebc) {
        bootfile = "ipxe.efi";
    } else {
        bootfile = "undionly.kpxe";
    }

    Logger::default_logger().info("BOOT", "[BOOT STAGE 5] PXE boot filename selected: '" + bootfile +
                 "' for client arch: " + std::string(to_string(options.client_arch)) +
                 (options.is_ipxe_client ? " (iPXE Stage-2)" : " (PXE ROM Stage-1)"));

    std::strncpy(reinterpret_cast<char*>(reply->file), bootfile.c_str(), sizeof(reply->file) - 1);
    std::strncpy(reinterpret_cast<char*>(reply->sname), "CobDiskless", sizeof(reply->sname) - 1);

    // Append Options
    auto append_option = [&](uint8_t code, std::span<const uint8_t> val) {
        packet.push_back(code);
        packet.push_back(static_cast<uint8_t>(val.size()));
        packet.insert(packet.end(), val.begin(), val.end());
    };

    // Option 53: Message Type (Offer = 2, Ack = 5)
    uint8_t msg_type = reply_message_type;
    append_option(53, {&msg_type, 1});

    // Option 54: Server Identifier
    append_option(54, {si_bytes, 4});

    // Option 51: Lease Time
    uint8_t lease_time[4] = {
        static_cast<uint8_t>((lease_duration_sec_ >> 24) & 0xFF),
        static_cast<uint8_t>((lease_duration_sec_ >> 16) & 0xFF),
        static_cast<uint8_t>((lease_duration_sec_ >> 8) & 0xFF),
        static_cast<uint8_t>(lease_duration_sec_ & 0xFF)
    };
    append_option(51, {lease_time, 4});

    // Option 1: Subnet Mask
    uint8_t mask[4] = {subnet_mask_.octet(0), subnet_mask_.octet(1), subnet_mask_.octet(2), subnet_mask_.octet(3)};
    append_option(1, {mask, 4});

    // Option 3: Router / Gateway
    NetworkAddress eff_gateway = gateway_;
    if (eff_gateway.octet(0) == 0 && eff_gateway.octet(3) == 0) {
        eff_gateway = effective_server_ip;
    }
    uint8_t gw[4] = {eff_gateway.octet(0), eff_gateway.octet(1), eff_gateway.octet(2), eff_gateway.octet(3)};
    append_option(3, {gw, 4});

    // Option 6: DNS
    NetworkAddress eff_dns = dns_;
    if (eff_dns.octet(0) == 0 && eff_dns.octet(3) == 0) {
        eff_dns = eff_gateway;
    }
    uint8_t dns_bytes[4] = {eff_dns.octet(0), eff_dns.octet(1), eff_dns.octet(2), eff_dns.octet(3)};
    append_option(6, {dns_bytes, 4});

    // Option 66: TFTP Server Name
    std::string srv_str = effective_server_ip.ip_string();
    append_option(66, std::span<const uint8_t>(reinterpret_cast<const uint8_t*>(srv_str.data()), srv_str.size()));

    // Option 67: Bootfile Name
    append_option(67, std::span<const uint8_t>(reinterpret_cast<const uint8_t*>(bootfile.data()), bootfile.size()));

    // Option 255: End
    packet.push_back(255);

    // RFC 2131: Standard DHCP minimum datagram options payload requires padding up to 548 bytes
    while (packet.size() < 548) {
        packet.push_back(0);
    }

    // Track lease for inspection and lease table display
    if (!options.client_mac.empty()) {
        std::lock_guard<std::mutex> lock(lease_mutex_);
        DhcpLease lease;
        lease.mac_address = options.client_mac;
        lease.ip_address = assigned_ip;
        lease.pc_name = options.hostname;
        if (client_manager_) {
            auto client_rec = client_manager_->get_client_by_mac(options.client_mac);
            if (client_rec.has_value()) {
                lease.pc_name = client_rec->pc_name;
            }
        }
        if (lease.pc_name.empty()) {
            lease.pc_name = "PC";
        }
        lease.lease_status = (reply_message_type == 2) ? "Offered" : "Active";

        auto now = std::chrono::system_clock::now();
        auto time_t_now = std::chrono::system_clock::to_time_t(now);
        std::tm tm_buf{};
#if defined(_MSC_VER) || (defined(_WIN32) && !defined(__CYGWIN__))
        localtime_s(&tm_buf, &time_t_now);
#else
        localtime_r(&time_t_now, &tm_buf);
#endif
        std::ostringstream ss;
        ss << std::put_time(&tm_buf, "%Y-%m-%d %H:%M:%S");
        lease.last_seen = ss.str();

        auto it_l = leases_by_mac_.find(options.client_mac);
        if (it_l == leases_by_mac_.end()) {
            lease.first_seen = lease.last_seen;
        } else {
            lease.first_seen = it_l->second.first_seen;
        }
        leases_by_mac_[options.client_mac] = lease;
        mac_to_ip_leases_[options.client_mac] = assigned_ip;
    }

    return packet;
}

std::vector<DhcpLease> DhcpServer::list_leases() const {
    std::lock_guard<std::mutex> lock(lease_mutex_);
    std::vector<DhcpLease> result;
    result.reserve(leases_by_mac_.size());
    for (const auto& [_, l] : leases_by_mac_) {
        result.push_back(l);
    }
    std::sort(result.begin(), result.end(), [](const DhcpLease& a, const DhcpLease& b) {
        return a.pc_name < b.pc_name;
    });
    return result;
}

size_t DhcpServer::active_leases_count() const noexcept {
    std::lock_guard<std::mutex> lock(lease_mutex_);
    return mac_to_ip_leases_.size();
}

void DhcpServer::run_packet_loop() {
#if defined(_WIN32)
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        return;
    }

    SOCKET s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (s == INVALID_SOCKET) {
        WSACleanup();
        return;
    }

    server_socket_ = static_cast<uintptr_t>(s);

    BOOL reuse = TRUE;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (const char*)&reuse, sizeof(reuse));

    BOOL bcast = TRUE;
    setsockopt(s, SOL_SOCKET, SO_BROADCAST, (const char*)&bcast, sizeof(bcast));

    // 500ms receive timeout
    DWORD timeout_ms = 500;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char*)&timeout_ms, sizeof(timeout_ms));

    sockaddr_in bind_addr{};
    bind_addr.sin_family = AF_INET;
    bind_addr.sin_port = htons(port_);
    bind_addr.sin_addr.s_addr = INADDR_ANY;

    // If bind fails, we stay in loop checking running_ to gracefully handle non-elevated runs.
    if (bind(s, (sockaddr*)&bind_addr, sizeof(bind_addr)) != 0) {
        int err = WSAGetLastError();
        Logger::default_logger().error("DhcpServer", "Failed to bind to UDP port " + std::to_string(port_) +
                      " (Winsock Error: " + std::to_string(err) + "). DHCP service requires Admin privileges.");
        while (running_) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
        closesocket(s);
        WSACleanup();
        return;
    }

    Logger::default_logger().info("DhcpServer", "Successfully listening on UDP port " + std::to_string(port_));

    std::vector<uint8_t> recv_buf(2048);
    sockaddr_in client_addr{};
    int client_addr_len = sizeof(client_addr);

    auto format_hex_u32 = [](uint32_t val) {
        std::ostringstream ss;
        ss << std::hex << std::uppercase << std::setfill('0') << std::setw(8) << val;
        return ss.str();
    };

    while (running_) {
        client_addr_len = sizeof(client_addr);
        int bytes = recvfrom(s, reinterpret_cast<char*>(recv_buf.data()), recv_buf.size(), 0,
                             (sockaddr*)&client_addr, &client_addr_len);
        if (bytes > 0) {
            auto parsed_res = parse_packet(std::span<const uint8_t>(recv_buf.data(), bytes));
            if (parsed_res.is_ok()) {
                const auto& opts = parsed_res.value();
                const auto* hdr = reinterpret_cast<const DhcpHeader*>(recv_buf.data());

                if (!enabled_) {
                    continue;
                }

                if (opts.message_type == 1) { // DHCPDISCOVER
                    Logger::default_logger().info("BOOT", "[BOOT STAGE 1] DHCP DISCOVER received: MAC=" + opts.client_mac +
                                 " XID=0x" + format_hex_u32(hdr->xid) +
                                 " ARCH=" + std::string(to_string(opts.client_arch)) +
                                 (opts.is_pxe_client ? " (PXEClient)" : "") +
                                 (opts.is_ipxe_client ? " (iPXE)" : ""));
                } else if (opts.message_type == 3) { // DHCPREQUEST
                    Logger::default_logger().info("BOOT", "[BOOT STAGE 3] DHCP REQUEST received: MAC=" + opts.client_mac +
                                 " XID=0x" + format_hex_u32(hdr->xid) +
                                 " REQ_IP=" + opts.requested_ip.ip_string() +
                                 (opts.is_ipxe_client ? " (iPXE Stage-2 Request)" : ""));
                    if (opts.is_ipxe_client) {
                        Logger::default_logger().info("BOOT", "[BOOT STAGE 8] iPXE executed: Client " + opts.client_mac +
                                     " running iPXE environment (Option 175 received). Requesting boot.ipxe.");
                    }
                }

                NetworkAddress lease_ip;
                std::string pc_name = "PC";
                bool have_ip = false;

                if (client_manager_) {
                    auto reg_res = client_manager_->get_or_register_client(opts.client_mac, ip_pool_start_, ip_pool_end_);
                    if (reg_res.is_ok()) {
                        const auto& rec = reg_res.value();
                        lease_ip = rec.ip_address;
                        pc_name = rec.pc_name;
                        have_ip = true;
                    }
                }

                if (!have_ip) {
                    std::lock_guard<std::mutex> lock(lease_mutex_);
                    auto it = mac_to_ip_leases_.find(opts.client_mac);
                    if (it != mac_to_ip_leases_.end()) {
                        lease_ip = it->second;
                        have_ip = true;
                    } else {
                        uint8_t start_oct = ip_pool_start_.octet(3);
                        uint8_t end_oct = ip_pool_end_.octet(3);
                        uint32_t range = (end_oct >= start_oct) ? (end_oct - start_oct + 1) : 100;
                        uint8_t last_octet = static_cast<uint8_t>(start_oct + (next_pool_offset_++ % range));
                        lease_ip = NetworkAddress(ip_pool_start_.octet(0),
                                                  ip_pool_start_.octet(1),
                                                  ip_pool_start_.octet(2),
                                                  last_octet);
                        mac_to_ip_leases_[opts.client_mac] = lease_ip;
                        have_ip = true;
                    }
                }

                if (!have_ip || (lease_ip.octet(0) == 0 && lease_ip.octet(3) == 0)) {
                    continue; // IP allocation failed or pool exhausted
                }

                // Record lease for GUI display
                {
                    std::lock_guard<std::mutex> lock(lease_mutex_);
                    DhcpLease lease;
                    lease.pc_name = pc_name;
                    lease.mac_address = opts.client_mac;
                    lease.ip_address = lease_ip;
                    lease.lease_status = "Active";

                    auto now = std::chrono::system_clock::now();
                    auto time_t_now = std::chrono::system_clock::to_time_t(now);
                    std::tm tm_buf{};
#if defined(_MSC_VER)
                    localtime_s(&tm_buf, &time_t_now);
#elif defined(_WIN32) && !defined(__CYGWIN__)
                    localtime_s(&tm_buf, &time_t_now);
#else
                    localtime_r(&time_t_now, &tm_buf);
#endif
                    std::ostringstream ss;
                    ss << std::put_time(&tm_buf, "%Y-%m-%d %H:%M:%S");
                    lease.last_seen = ss.str();

                    auto it_l = leases_by_mac_.find(opts.client_mac);
                    if (it_l == leases_by_mac_.end()) {
                        lease.first_seen = lease.last_seen;
                    } else {
                        lease.first_seen = it_l->second.first_seen;
                    }
                    leases_by_mac_[opts.client_mac] = lease;
                    mac_to_ip_leases_[opts.client_mac] = lease_ip;
                }

                uint8_t reply_type = (opts.message_type == 1) ? 2 : 5; // Offer or Ack
                auto reply_res = build_reply(*hdr, opts, reply_type, lease_ip);
                if (reply_res.is_ok()) {
                    const auto& reply_bytes = reply_res.value();

                    // Determine effective server IP
                    NetworkAddress effective_srv = server_ip_;
                    if (effective_srv.is_loopback() ||
                        (effective_srv.octet(0) == 0 && effective_srv.octet(3) == 0)) {
                        effective_srv = NetworkAddress::detect_local_ip(67);
                    }

                    // Print exact buffer hex dump of the outgoing OFFER before it is passed to sendto()
                    if (reply_type == 2) {
                        std::ostringstream hex_ss;
                        hex_ss << "\n=======================================================\n"
                               << " OUTGOING DHCP OFFER BUFFER HEX DUMP (" << reply_bytes.size() << " bytes)\n"
                               << " Dest IP: 255.255.255.255 & Subnet Broadcast | Dest Port: 68 (UDP)\n"
                               << " Client MAC: " << opts.client_mac << " | Offered IP: " << lease_ip.ip_string() << "\n"
                               << " NextServer (siaddr): " << effective_srv.ip_string() << "\n"
                               << " Magic Cookie (offset 236..239): "
                               << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(reply_bytes[236]) << " "
                               << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(reply_bytes[237]) << " "
                               << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(reply_bytes[238]) << " "
                               << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(reply_bytes[239]) << "\n"
                               << "=======================================================";
                        for (size_t i = 0; i < reply_bytes.size(); ++i) {
                            if (i % 16 == 0) {
                                hex_ss << "\n" << std::hex << std::setw(4) << std::setfill('0') << i << ": ";
                            }
                            hex_ss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(reply_bytes[i]) << " ";
                        }
                        hex_ss << "\n=======================================================\n";
                        Logger::default_logger().info("BOOT", hex_ss.str());
                    }

                    if (port_ != 67 && client_addr.sin_port != 0) {
                        // Loopback/unicast test socket
                        sendto(s, reinterpret_cast<const char*>(reply_bytes.data()), reply_bytes.size(), 0,
                               (sockaddr*)&client_addr, sizeof(client_addr));
                    } else {
                        // 1. Global Broadcast (255.255.255.255:68)
                        sockaddr_in send_addr{};
                        send_addr.sin_family = AF_INET;
                        send_addr.sin_port = htons(68);
                        send_addr.sin_addr.s_addr = INADDR_BROADCAST;
                        int sent_bcast = sendto(s, reinterpret_cast<const char*>(reply_bytes.data()), reply_bytes.size(), 0,
                                               (sockaddr*)&send_addr, sizeof(send_addr));
                        if (sent_bcast <= 0) {
                            int err = WSAGetLastError();
                            Logger::default_logger().error("DhcpServer", "sendto(255.255.255.255:68) failed (WSA: " + std::to_string(err) + ")");
                        }

                        // 2. Subnet Directed Broadcast (e.g. 192.168.1.255:68)
                        // Directly routes out the physical adapter matching the subnet,
                        // preventing drops on multi-adapter hosts (e.g. VirtualBox host-only NIC).
                        uint32_t srv_u32 = (effective_srv.octet(0) << 24) | (effective_srv.octet(1) << 16) |
                                           (effective_srv.octet(2) << 8) | effective_srv.octet(3);
                        uint32_t mask_u32 = (subnet_mask_.octet(0) << 24) | (subnet_mask_.octet(1) << 16) |
                                            (subnet_mask_.octet(2) << 8) | subnet_mask_.octet(3);
                        uint32_t subnet_bcast_u32 = (srv_u32 & mask_u32) | (~mask_u32);

                        sockaddr_in subnet_addr{};
                        subnet_addr.sin_family = AF_INET;
                        subnet_addr.sin_port = htons(68);
                        subnet_addr.sin_addr.s_addr = htonl(subnet_bcast_u32);
                        int sent_subnet = sendto(s, reinterpret_cast<const char*>(reply_bytes.data()), reply_bytes.size(), 0,
                                                (sockaddr*)&subnet_addr, sizeof(subnet_addr));
                        if (sent_subnet <= 0) {
                            int err = WSAGetLastError();
                            Logger::default_logger().error("DhcpServer", "sendto(subnet_bcast:68) failed (WSA: " + std::to_string(err) + ")");
                        }

                        // 3. Unicast to client lease IP on port 68 (for DHCPACK)
                        if (reply_type == 5) {
                            sockaddr_in unicast_addr{};
                            unicast_addr.sin_family = AF_INET;
                            unicast_addr.sin_port = htons(68);
                            uint32_t client_u32 = (lease_ip.octet(0) << 24) | (lease_ip.octet(1) << 16) |
                                                  (lease_ip.octet(2) << 8) | lease_ip.octet(3);
                            unicast_addr.sin_addr.s_addr = htonl(client_u32);
                            sendto(s, reinterpret_cast<const char*>(reply_bytes.data()), reply_bytes.size(), 0,
                                   (sockaddr*)&unicast_addr, sizeof(unicast_addr));
                        }
                    }

                    std::string bootfile_str(reinterpret_cast<const char*>(reply_bytes.data() + offsetof(DhcpHeader, file)));
                    if (reply_type == 2) {
                        Logger::default_logger().info("BOOT", "[BOOT STAGE 2] DHCP OFFER sent: MAC=" + opts.client_mac +
                                     " Offered-IP=" + lease_ip.ip_string() +
                                     " NextServer=" + effective_srv.ip_string() +
                                     " Bootfile=" + bootfile_str);
                    } else {
                        Logger::default_logger().info("BOOT", "[BOOT STAGE 4] DHCP ACK sent: MAC=" + opts.client_mac +
                                     " Leased-IP=" + lease_ip.ip_string() +
                                     " NextServer=" + effective_srv.ip_string() +
                                     " Bootfile=" + bootfile_str);
                    }
                }
            }
        }
    }

    closesocket(s);
    WSACleanup();
#else
    while (running_) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
#endif
}

} // namespace cobdiskless
