#pragma once

#include <string>
#include <vector>
#include <memory>
#include <filesystem>
#include <atomic>
#include "CobDisklessCore/core.hpp"
#include "CobDisklessCore/config/configuration.hpp"
#include "CobDisklessCore/image/image_registry.hpp"
#include "CobDisklessCore/storage/storage_tester.hpp"
#include "CobDisklessCore/client/client_manager.hpp"
#include "CobDisklessCore/storage/storage_manager.hpp"

namespace cobdiskless {

class AdminApp {
public:
    AdminApp();
    ~AdminApp();

    /**
     * @brief Parses command-line arguments and runs in CLI mode or launches GUI.
     */
    int run(int argc, char* argv[]);

    /**
     * @brief Launches the native Windows GUI application.
     */
    int run_gui();

    // CLI actions
    int cli_status();
    int cli_wizard();
    int cli_test_storage(const std::filesystem::path& target_dir);
    int cli_inspect_image(const std::filesystem::path& image_path);
    int cli_list_images();
    int cli_add_image(const std::filesystem::path& image_path, const std::string& image_id);
    int cli_list_clients();
    int cli_list_drives();
    int cli_start_server(bool run_in_background = false);

    // Server lifecycle controls
    Result<void> start_server_services();
    void stop_server_services();
    [[nodiscard]] bool is_server_running() const noexcept { return server_running_.load(); }

    [[nodiscard]] const Configuration& config() const noexcept { return config_; }
    void set_config(Configuration cfg) { config_ = std::move(cfg); }

    [[nodiscard]] std::shared_ptr<GoldenImageRegistry> registry() const noexcept { return registry_; }
    [[nodiscard]] std::shared_ptr<ClientManager> client_manager() const noexcept { return client_manager_; }
    [[nodiscard]] std::shared_ptr<StorageManager> storage_manager() const noexcept { return storage_manager_; }
    [[nodiscard]] const std::filesystem::path& config_file_path() const noexcept { return config_file_path_; }
    [[nodiscard]] const std::filesystem::path& clients_config_path() const noexcept { return clients_config_path_; }
    [[nodiscard]] const std::filesystem::path& storage_config_path() const noexcept { return storage_config_path_; }

private:
    Configuration config_;
    std::filesystem::path config_file_path_{"cobdiskless.conf"};
    std::filesystem::path clients_config_path_{"clients.conf"};
    std::filesystem::path storage_config_path_{"storage_roles.conf"};
    std::shared_ptr<GoldenImageRegistry> registry_;
    std::shared_ptr<ClientManager> client_manager_;
    std::shared_ptr<StorageManager> storage_manager_;
    std::shared_ptr<Logger> logger_;
    std::unique_ptr<Core> active_core_;
    std::atomic<bool> server_running_{false};
};

} // namespace cobdiskless
