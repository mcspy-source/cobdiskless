#ifndef _BITS_SMBIOS_H
#define _BITS_SMBIOS_H

/** @file
 *
 * x86-specific SMBIOS API implementations
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );
FILE_SECBOOT ( PERMITTED );

#include <ipxe/bios_smbios.h>

#endif /* _BITS_SMBIOS_H */
