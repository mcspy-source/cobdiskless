#if defined(_WIN32)
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#endif
#include <thread>
#include <atomic>
#include <iostream>
#include <vector>
#include <string>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <filesystem>
#include <fstream>
#include <memory>
#include <sstream>

#include "CobDisklessCore/core.hpp"
#include "CobDisklessCore/types/common_types.hpp"
#include "CobDisklessCore/types/network_address.hpp"
#include "CobDisklessCore/errors/result.hpp"
#include "CobDisklessCore/logging/logger.hpp"
#include "CobDisklessCore/config/configuration.hpp"
#include "CobDisklessCore/subsystem/subsystem.hpp"
#include "CobDisklessCore/storage/block_device.hpp"
#include "CobDisklessCore/storage/read_only_block_device.hpp"
#include "CobDisklessCore/storage/raw_image_backend.hpp"
#include "CobDisklessCore/storage/vhd_image_backend.hpp"
#include "CobDisklessCore/image/image_format.hpp"
#include "CobDisklessCore/image/partition_info.hpp"
#include "CobDisklessCore/image/image_inspector.hpp"
#include "CobDisklessCore/image/golden_image.hpp"
#include "CobDisklessCore/image/image_registry.hpp"
#include "CobDisklessCore/image/image_manager.hpp"
#include "CobDisklessCore/image/pnp_driver_armer.hpp"
#include "CobDisklessCore/storage/storage_tester.hpp"
#include "CobDisklessCore/storage/cow_block_device.hpp"
#include "CobDisklessCore/client/client_session.hpp"
#include "CobDisklessCore/client/client_manager.hpp"
#include "CobDisklessCore/storage/storage_manager.hpp"
#include "CobDisklessCore/network/dhcp_server.hpp"
#include "CobDisklessCore/network/tftp_server.hpp"
#include "CobDisklessCore/network/iscsi_target.hpp"
#include "CobDisklessCore/storage/block_cache.hpp"
#include "CobDisklessCore/network/host_network.hpp"
#include "CobDisklessCore/network/http_daemon.hpp"
#include "CobDisklessCore/network/ipxe_script.hpp"
#include "CobDisklessCore/network/cob_rename_script.hpp"
#include "CobDisklessCore/client/client_database.hpp"
#include "CobDisklessCore/config/simple_json.hpp"

using namespace cobdiskless;

// =============================================================================
// Helper Mock Subsystem for Lifecycle Testing
// =============================================================================
class MockSubsystem : public ISubsystem {
public:
    MockSubsystem(std::string name, bool should_succeed, std::vector<std::string>& event_log)
        : name_(std::move(name)), should_succeed_(should_succeed), event_log_(event_log) {}

    [[nodiscard]] std::string_view name() const noexcept override { return name_; }

    [[nodiscard]] Result<void> initialize() override {
        event_log_.push_back(name_ + ":init");
        if (!should_succeed_) {
            state_ = SubsystemState::Failed;
            return Error(ErrorCode::InitializationFailure, name_ + " simulated failure");
        }
        state_ = SubsystemState::Running;
        return {};
    }

    void shutdown() override {
        event_log_.push_back(name_ + ":shutdown");
        state_ = SubsystemState::Stopped;
    }

    [[nodiscard]] bool is_initialized() const noexcept override {
        return state_ == SubsystemState::Running;
    }

    [[nodiscard]] SubsystemState state() const noexcept override {
        return state_;
    }

private:
    std::string name_;
    bool should_succeed_{true};
    std::vector<std::string>& event_log_;
    SubsystemState state_{SubsystemState::Uninitialized};
};

// =============================================================================
// Helper In-Memory Block Device for Storage Interface Testing
// =============================================================================
class MemoryBlockDevice : public BlockDevice {
public:
    explicit MemoryBlockDevice(uint64_t size_bytes)
        : storage_(static_cast<size_t>(size_bytes), std::byte{0}) {}

    [[nodiscard]] Result<size_t> read(uint64_t offset, std::span<std::byte> destination) override {
        if (offset + destination.size() > storage_.size()) {
            return Error(ErrorCode::StorageFailure, "Out of bounds read request");
        }
        std::memcpy(destination.data(), storage_.data() + offset, destination.size());
        return destination.size();
    }

    [[nodiscard]] Result<size_t> write(uint64_t offset, std::span<const std::byte> source) override {
        if (offset + source.size() > storage_.size()) {
            return Error(ErrorCode::StorageFailure, "Out of bounds write request");
        }
        std::memcpy(storage_.data() + offset, source.data(), source.size());
        return source.size();
    }

    [[nodiscard]] Result<void> flush() override {
        flushed_ = true;
        return {};
    }

    [[nodiscard]] uint64_t size() const noexcept override {
        return storage_.size();
    }

    [[nodiscard]] bool was_flushed() const noexcept {
        return flushed_;
    }

    [[nodiscard]] std::span<std::byte> raw_data() noexcept {
        return storage_;
    }

private:
    std::vector<std::byte> storage_;
    bool flushed_{false};
};

// =============================================================================
// Synthesis Helpers for Disk Structures
// =============================================================================

inline void write_le16(uint8_t* p, uint16_t val) {
    p[0] = static_cast<uint8_t>(val & 0xFF);
    p[1] = static_cast<uint8_t>((val >> 8) & 0xFF);
}

inline void write_le32(uint8_t* p, uint32_t val) {
    p[0] = static_cast<uint8_t>(val & 0xFF);
    p[1] = static_cast<uint8_t>((val >> 8) & 0xFF);
    p[2] = static_cast<uint8_t>((val >> 16) & 0xFF);
    p[3] = static_cast<uint8_t>((val >> 24) & 0xFF);
}

inline void write_le64(uint8_t* p, uint64_t val) {
    write_le32(p, static_cast<uint32_t>(val & 0xFFFFFFFF));
    write_le32(p + 4, static_cast<uint32_t>((val >> 32) & 0xFFFFFFFF));
}

inline void write_be32(uint8_t* p, uint32_t val) {
    p[0] = static_cast<uint8_t>((val >> 24) & 0xFF);
    p[1] = static_cast<uint8_t>((val >> 16) & 0xFF);
    p[2] = static_cast<uint8_t>((val >> 8) & 0xFF);
    p[3] = static_cast<uint8_t>(val & 0xFF);
}

inline void write_be64(uint8_t* p, uint64_t val) {
    write_be32(p, static_cast<uint32_t>((val >> 32) & 0xFFFFFFFF));
    write_be32(p + 4, static_cast<uint32_t>(val & 0xFFFFFFFF));
}

// =============================================================================
// Phase 3 Architecture Test Cases
// =============================================================================

void test_common_types() {
    std::cout << "[RUN] test_common_types\n";

    constexpr ByteSize b1 = 512_KiB;
    constexpr ByteSize b2 = 10_MiB;
    constexpr ByteSize b3 = 2_GiB;

    assert(b1.bytes() == 512 * 1024);
    assert(b2.bytes() == 10 * 1024 * 1024);
    assert(b3.bytes() == 2ULL * 1024 * 1024 * 1024);
    assert(b1 < b2);
    assert(b2 < b3);

    ClientId c1{"client-001"};
    ClientId c2{"client-001"};
    ClientId c3{"client-002"};
    assert(c1 == c2);
    assert(c1 != c3);
    assert(c1.value() == "client-001");

    ImageId img{"win10-golden.vhd"};
    assert(img.value() == "win10-golden.vhd");

    NetworkAddress addr(192, 168, 1, 100, 3260);
    assert(addr.octet(0) == 192);
    assert(addr.octet(1) == 168);
    assert(addr.octet(2) == 1);
    assert(addr.octet(3) == 100);
    assert(addr.port() == 3260);
    assert(addr.to_string() == "192.168.1.100:3260");

    NetworkAddress parsed = NetworkAddress::parse("10.0.0.1:8080");
    assert(parsed.octet(0) == 10);
    assert(parsed.octet(3) == 1);
    assert(parsed.port() == 8080);

    std::cout << "  PASS: test_common_types\n";
}

void test_errors_and_results() {
    std::cout << "[RUN] test_errors_and_results\n";

    Error err(ErrorCode::NetworkFailure, "Failed to bind UDP socket on 67");
    assert(!err.is_success());
    assert(err.code() == ErrorCode::NetworkFailure);
    assert(err.message().find("UDP socket") != std::string_view::npos);

    Result<int> res_ok(42);
    assert(res_ok.is_ok());
    assert(!res_ok.is_err());
    assert(res_ok.has_value());
    assert(res_ok.value() == 42);

    Result<int> res_err(ErrorCode::StorageFailure, "Disk sector read error");
    assert(!res_ok.is_err());
    assert(res_err.is_err());
    assert(!res_err.has_value());
    assert(res_err.error().code() == ErrorCode::StorageFailure);

    Result<void> void_ok;
    assert(void_ok.is_ok());

    Result<void> void_err(ErrorCode::InvalidConfiguration, "Missing path");
    assert(void_err.is_err());
    assert(void_err.error().code() == ErrorCode::InvalidConfiguration);

    std::cout << "  PASS: test_errors_and_results\n";
}

void test_logging() {
    std::cout << "[RUN] test_logging\n";

    Logger logger(LogLevel::Debug);
    std::vector<std::string> captured_logs;

    logger.set_sink([&captured_logs](LogLevel /*level*/, std::string_view /*category*/,
                                     std::string_view /*message*/, std::string_view formatted) {
        captured_logs.emplace_back(formatted);
    });

    logger.trace("CORE", "Trace message - should be filtered");
    logger.debug("STORAGE", "Debug message - should be captured");
    logger.info("NETWORK", "Info message - should be captured");
    logger.warn("BOOT", "Warn message - should be captured");
    logger.error("CLIENT", "Error message - should be captured");

    assert(captured_logs.size() == 4);
    assert(captured_logs[0].find("[DEBUG] [STORAGE]") != std::string::npos);
    assert(captured_logs[1].find("[INFO] [NETWORK]") != std::string::npos);
    assert(captured_logs[2].find("[WARN] [BOOT]") != std::string::npos);
    assert(captured_logs[3].find("[ERROR] [CLIENT]") != std::string::npos);

    std::cout << "  PASS: test_logging\n";
}

void test_configuration_validation() {
    std::cout << "[RUN] test_configuration_validation\n";

    Configuration valid_cfg = Configuration::create_default();
    auto valid_res = valid_cfg.validate();
    assert(valid_res.is_ok());

    Configuration invalid_cfg = valid_cfg;
    invalid_cfg.set_storage_path("");
    auto invalid_res1 = invalid_cfg.validate();
    assert(invalid_res1.is_err());
    assert(invalid_res1.error().code() == ErrorCode::InvalidConfiguration);

    invalid_cfg = valid_cfg;
    invalid_cfg.set_max_clients(0);
    auto invalid_res2 = invalid_cfg.validate();
    assert(invalid_res2.is_err());
    assert(invalid_res2.error().code() == ErrorCode::InvalidConfiguration);

    invalid_cfg = valid_cfg;
    invalid_cfg.set_default_cache_size(ByteSize(0));
    auto invalid_res3 = invalid_cfg.validate();
    assert(invalid_res3.is_err());

    std::cout << "  PASS: test_configuration_validation\n";
}

void test_subsystem_deterministic_lifecycle() {
    std::cout << "[RUN] test_subsystem_deterministic_lifecycle\n";

    Core core;
    std::vector<std::string> events;

    auto sub1 = std::make_shared<MockSubsystem>("SubsystemA", true, events);
    auto sub2 = std::make_shared<MockSubsystem>("SubsystemB", true, events);
    auto sub3 = std::make_shared<MockSubsystem>("SubsystemC", true, events);

    assert(core.register_subsystem(sub1).is_ok());
    assert(core.register_subsystem(sub2).is_ok());
    assert(core.register_subsystem(sub3).is_ok());

    assert(core.subsystem_count() == 3);

    auto init_res = core.initialize();
    assert(init_res.is_ok());
    assert(core.is_initialized());

    assert(events.size() == 3);
    assert(events[0] == "SubsystemA:init");
    assert(events[1] == "SubsystemB:init");
    assert(events[2] == "SubsystemC:init");

    core.shutdown();
    assert(!core.is_initialized());

    assert(events.size() == 6);
    assert(events[3] == "SubsystemC:shutdown");
    assert(events[4] == "SubsystemB:shutdown");
    assert(events[5] == "SubsystemA:shutdown");

    std::cout << "  PASS: test_subsystem_deterministic_lifecycle\n";
}

void test_subsystem_failure_rollback() {
    std::cout << "[RUN] test_subsystem_failure_rollback\n";

    Core core;
    std::vector<std::string> events;

    auto sub1 = std::make_shared<MockSubsystem>("Subsystem1_OK", true, events);
    auto sub2 = std::make_shared<MockSubsystem>("Subsystem2_FAIL", false, events);
    auto sub3 = std::make_shared<MockSubsystem>("Subsystem3_SKIPPED", true, events);

    assert(core.register_subsystem(sub1).is_ok());
    assert(core.register_subsystem(sub2).is_ok());
    assert(core.register_subsystem(sub3).is_ok());

    auto init_res = core.initialize();
    assert(init_res.is_err());
    assert(init_res.error().code() == ErrorCode::InitializationFailure);
    assert(!core.is_initialized());

    assert(events.size() == 3);
    assert(events[0] == "Subsystem1_OK:init");
    assert(events[1] == "Subsystem2_FAIL:init");
    assert(events[2] == "Subsystem1_OK:shutdown");

    core.shutdown();
    assert(events.size() == 3);

    std::cout << "  PASS: test_subsystem_failure_rollback\n";
}

void test_storage_block_device() {
    std::cout << "[RUN] test_storage_block_device\n";

    constexpr uint64_t dev_size = 4096;
    MemoryBlockDevice device(dev_size);

    assert(device.size() == dev_size);
    assert(device.block_size() == 512);
    assert(!device.is_read_only());

    const char message[] = "CobDiskless Block Storage Test Data";
    const size_t msg_len = std::strlen(message);

    std::span<const std::byte> write_span(
        reinterpret_cast<const std::byte*>(message),
        msg_len
    );

    auto write_res = device.write(512, write_span);
    assert(write_res.is_ok());
    assert(write_res.value() == msg_len);

    std::vector<std::byte> read_buf(msg_len);
    auto read_res = device.read(512, std::span<std::byte>(read_buf.data(), read_buf.size()));
    assert(read_res.is_ok());
    assert(read_res.value() == msg_len);
    assert(std::memcmp(read_buf.data(), message, msg_len) == 0);

    // Out of bounds write
    auto oob_write = device.write(4080, write_span);
    assert(oob_write.is_err());
    assert(oob_write.error().code() == ErrorCode::StorageFailure);

    // Out of bounds read
    auto oob_read = device.read(4080, std::span<std::byte>(read_buf.data(), read_buf.size()));
    assert(oob_read.is_err());
    assert(oob_read.error().code() == ErrorCode::StorageFailure);

    // Flush
    assert(device.flush().is_ok());
    assert(device.was_flushed());

    std::cout << "  PASS: test_storage_block_device\n";
}

// =============================================================================
// Phase 4 Golden Image Engine Test Cases
// =============================================================================

void test_mbr_detection() {
    std::cout << "[RUN] test_mbr_detection\n";

    // 1. Valid MBR with 2 partitions
    auto dev = std::make_shared<MemoryBlockDevice>(100 * 1024 * 1024); // 100 MiB
    uint8_t* raw = reinterpret_cast<uint8_t*>(dev->raw_data().data());

    // Bootstrap code in bytes 0..445
    raw[0] = 0xFA; // cli
    raw[1] = 0x31; // xor eax, eax
    raw[2] = 0xC0;

    // Partition 1: Active, NTFS (0x07), start LBA 2048, size 100,000 sectors
    uint8_t* p1 = raw + 446;
    p1[0] = 0x80; // Bootable
    p1[4] = 0x07; // NTFS / exFAT
    write_le32(p1 + 8, 2048);
    write_le32(p1 + 12, 100000);

    // Write NTFS boot sector signature at LBA 2048 (offset 2048 * 512 = 1,048,576)
    uint8_t* vbr1 = raw + (2048 * 512);
    std::memcpy(vbr1 + 3, "NTFS    ", 8);
    vbr1[510] = 0x55;
    vbr1[511] = 0xAA;

    // Partition 2: Inactive, FAT32 (0x0B), start LBA 102048, size 50,000 sectors
    uint8_t* p2 = raw + 446 + 16;
    p2[0] = 0x00;
    p2[4] = 0x0B; // FAT32
    write_le32(p2 + 8, 102048);
    write_le32(p2 + 12, 50000);

    // Write FAT32 boot sector signature at LBA 102048
    uint8_t* vbr2 = raw + (102048 * 512);
    std::memcpy(vbr2 + 82, "FAT32   ", 8);
    vbr2[510] = 0x55;
    vbr2[511] = 0xAA;

    // MBR Signature
    raw[510] = 0x55;
    raw[511] = 0xAA;

    auto inspect_res = ImageInspector::inspect(dev, "test_mbr.img");
    assert(inspect_res.is_ok());
    const auto& report = inspect_res.value();

    assert(report.partition_scheme == PartitionScheme::Mbr);
    assert(report.boot_mode == BootMode::Bios);
    assert(report.has_active_boot_partition);
    assert(report.has_mbr_bootstrap_code);
    assert(!report.has_esp);
    assert(report.partitions.size() == 2);

    assert(report.partitions[0].index == 1);
    assert(report.partitions[0].is_bootable);
    assert(report.partitions[0].mbr_type == 0x07);
    assert(report.partitions[0].start_lba == 2048);
    assert(report.partitions[0].filesystem == FilesystemType::Ntfs);

    assert(report.partitions[1].index == 2);
    assert(!report.partitions[1].is_bootable);
    assert(report.partitions[1].mbr_type == 0x0B);
    assert(report.partitions[1].start_lba == 102048);
    assert(report.partitions[1].filesystem == FilesystemType::Fat32);

    // 2. Corrupted signature -> Unpartitioned
    raw[510] = 0x00;
    raw[511] = 0x00;
    auto corrupt_res = ImageInspector::inspect(dev, "corrupt.img");
    assert(corrupt_res.is_ok());
    assert(corrupt_res.value().partition_scheme == PartitionScheme::Unpartitioned);

    std::cout << "  PASS: test_mbr_detection\n";
}

void test_gpt_detection() {
    std::cout << "[RUN] test_gpt_detection\n";

    auto dev = std::make_shared<MemoryBlockDevice>(50 * 1024 * 1024); // 50 MiB
    uint8_t* raw = reinterpret_cast<uint8_t*>(dev->raw_data().data());

    // LBA 0: Protective MBR
    raw[510] = 0x55;
    raw[511] = 0xAA;
    uint8_t* pmbr_p1 = raw + 446;
    pmbr_p1[4] = 0xEE; // GPT Protective type
    write_le32(pmbr_p1 + 8, 1);
    write_le32(pmbr_p1 + 12, 102399);

    // LBA 1: GPT Header
    uint8_t* gpt_hdr = raw + 512;
    std::memcpy(gpt_hdr, "EFI PART", 8); // Signature
    write_le32(gpt_hdr + 8, 0x00010000);  // Revision
    write_le32(gpt_hdr + 12, 92);         // Header size
    write_le64(gpt_hdr + 24, 1);          // Current LBA
    write_le64(gpt_hdr + 32, 102399);     // Backup LBA
    write_le64(gpt_hdr + 40, 34);         // First usable LBA
    write_le64(gpt_hdr + 48, 102366);     // Last usable LBA
    write_le64(gpt_hdr + 72, 2);          // Partition entry LBA
    write_le32(gpt_hdr + 80, 128);        // Number of partition entries
    write_le32(gpt_hdr + 84, 128);        // Size of partition entry

    // LBA 2: Partition Entry 0 -> EFI System Partition (ESP)
    // GUID: C12A7328-F81F-11D2-BA4B-00A0C93EC93B
    // Bytes: 28 73 2A C1, 1F F8, D2 11, BA, 4B, 00, A0, C9, 3E, C9, 3B
    uint8_t* e0 = raw + (2 * 512);
    write_le32(e0, 0xC12A7328);
    write_le16(e0 + 4, 0xF81F);
    write_le16(e0 + 6, 0x11D2);
    e0[8] = 0xBA; e0[9] = 0x4B; e0[10] = 0x00; e0[11] = 0xA0;
    e0[12] = 0xC9; e0[13] = 0x3E; e0[14] = 0xC9; e0[15] = 0x3B;

    write_le64(e0 + 32, 2048); // Start LBA
    write_le64(e0 + 40, 4095); // End LBA (2048 sectors)

    // Partition Name in UTF-16LE: "EFI System"
    const char name1[] = "EFI System";
    for (size_t i = 0; i < std::strlen(name1); ++i) {
        e0[56 + (i * 2)] = static_cast<uint8_t>(name1[i]);
    }

    // Write FAT32 filesystem signature at LBA 2048
    uint8_t* esp_vbr = raw + (2048 * 512);
    std::memcpy(esp_vbr + 82, "FAT32   ", 8);

    // LBA 2 Entry 1 -> Microsoft Basic Data (NTFS)
    // GUID: EBD0A0A2-B9E5-4433-87C0-68B6B72699C7
    uint8_t* e1 = e0 + 128;
    write_le32(e1, 0xEBD0A0A2);
    write_le16(e1 + 4, 0xB9E5);
    write_le16(e1 + 6, 0x4433);
    e1[8] = 0x87; e1[9] = 0xC0; e1[10] = 0x68; e1[11] = 0xB6;
    e1[12] = 0xB7; e1[13] = 0x26; e1[14] = 0x99; e1[15] = 0xC7;

    write_le64(e1 + 32, 4096);
    write_le64(e1 + 40, 20479);

    const char name2[] = "Basic data partition";
    for (size_t i = 0; i < std::strlen(name2); ++i) {
        e1[56 + (i * 2)] = static_cast<uint8_t>(name2[i]);
    }

    // Write NTFS filesystem signature at LBA 4096
    uint8_t* ntfs_vbr = raw + (4096 * 512);
    std::memcpy(ntfs_vbr + 3, "NTFS    ", 8);

    auto inspect_res = ImageInspector::inspect(dev, "test_gpt.raw");
    assert(inspect_res.is_ok());
    const auto& report = inspect_res.value();

    assert(report.partition_scheme == PartitionScheme::Gpt);
    assert(report.boot_mode == BootMode::Uefi);
    assert(report.has_esp);
    assert(!report.has_active_boot_partition);
    assert(report.partitions.size() == 2);

    assert(report.partitions[0].name == "EFI System");
    assert(report.partitions[0].is_esp);
    assert(report.partitions[0].filesystem == FilesystemType::Fat32);
    assert(report.partitions[0].start_lba == 2048);
    assert(report.partitions[0].sector_count == 2048);

    assert(report.partitions[1].name == "Basic data partition");
    assert(!report.partitions[1].is_esp);
    assert(report.partitions[1].filesystem == FilesystemType::Ntfs);
    assert(report.partitions[1].start_lba == 4096);

    std::cout << "  PASS: test_gpt_detection\n";
}

void test_boot_mode_recognition() {
    std::cout << "[RUN] test_boot_mode_recognition\n";

    // 1. BIOS boot image: MBR bootstrap code + active partition
    {
        auto dev = std::make_shared<MemoryBlockDevice>(10 * 1024 * 1024);
        uint8_t* raw = reinterpret_cast<uint8_t*>(dev->raw_data().data());
        raw[0] = 0xEB; // JMP opcode
        raw[510] = 0x55; raw[511] = 0xAA;
        raw[446] = 0x80; // active boot flag
        raw[450] = 0x07; // NTFS
        write_le32(raw + 446 + 8, 2048);
        write_le32(raw + 446 + 12, 1000);

        auto rep = ImageInspector::inspect(dev).value();
        assert(rep.boot_mode == BootMode::Bios);
    }

    // 2. UEFI boot image: MBR with 0xEF partition (ESP)
    {
        auto dev = std::make_shared<MemoryBlockDevice>(10 * 1024 * 1024);
        uint8_t* raw = reinterpret_cast<uint8_t*>(dev->raw_data().data());
        raw[510] = 0x55; raw[511] = 0xAA;
        raw[446] = 0x00; // not active
        raw[450] = 0xEF; // EFI System Partition in MBR
        write_le32(raw + 446 + 8, 2048);
        write_le32(raw + 446 + 12, 1000);

        auto rep = ImageInspector::inspect(dev).value();
        assert(rep.boot_mode == BootMode::Uefi);
    }

    // 3. Dual / Hybrid image: Active BIOS partition + ESP partition
    {
        auto dev = std::make_shared<MemoryBlockDevice>(10 * 1024 * 1024);
        uint8_t* raw = reinterpret_cast<uint8_t*>(dev->raw_data().data());
        raw[0] = 0xFA; // bootstrap code
        raw[510] = 0x55; raw[511] = 0xAA;
        // Partition 1: Active BIOS NTFS
        raw[446] = 0x80;
        raw[450] = 0x07;
        write_le32(raw + 446 + 8, 2048);
        write_le32(raw + 446 + 12, 1000);
        // Partition 2: ESP
        raw[446 + 16] = 0x00;
        raw[446 + 16 + 4] = 0xEF;
        write_le32(raw + 446 + 16 + 8, 3048);
        write_le32(raw + 446 + 16 + 12, 1000);

        auto rep = ImageInspector::inspect(dev).value();
        assert(rep.boot_mode == BootMode::Dual);
    }

    std::cout << "  PASS: test_boot_mode_recognition\n";
}

void test_filesystem_recognition() {
    std::cout << "[RUN] test_filesystem_recognition\n";

    auto dev = std::make_shared<MemoryBlockDevice>(20 * 1024 * 1024);
    uint8_t* raw = reinterpret_cast<uint8_t*>(dev->raw_data().data());
    raw[510] = 0x55; raw[511] = 0xAA;

    // Partition 1: NTFS at sector 2048
    raw[446] = 0x80;
    raw[450] = 0x07;
    write_le32(raw + 446 + 8, 2048);
    write_le32(raw + 446 + 12, 2000);
    std::memcpy(raw + (2048 * 512) + 3, "NTFS    ", 8);

    // Partition 2: exFAT at sector 4096
    raw[446 + 16] = 0x00;
    raw[446 + 16 + 4] = 0x07;
    write_le32(raw + 446 + 16 + 8, 4096);
    write_le32(raw + 446 + 16 + 12, 2000);
    std::memcpy(raw + (4096 * 512) + 3, "EXFAT   ", 8);

    // Partition 3: FAT16 at sector 6144
    raw[446 + 32] = 0x00;
    raw[446 + 32 + 4] = 0x06;
    write_le32(raw + 446 + 32 + 8, 6144);
    write_le32(raw + 446 + 32 + 12, 2000);
    std::memcpy(raw + (6144 * 512) + 54, "FAT16   ", 8);

    auto rep = ImageInspector::inspect(dev).value();
    assert(rep.partitions.size() == 3);
    assert(rep.partitions[0].filesystem == FilesystemType::Ntfs);
    assert(rep.partitions[1].filesystem == FilesystemType::ExFat);
    assert(rep.partitions[2].filesystem == FilesystemType::Fat16);

    std::cout << "  PASS: test_filesystem_recognition\n";
}

void test_raw_image_backend() {
    std::cout << "[RUN] test_raw_image_backend\n";

    const std::filesystem::path temp_img = "test_raw_image.img";
    if (std::filesystem::exists(temp_img)) {
        std::filesystem::remove(temp_img);
    }

    // Create a 64 KiB test file
    {
        std::ofstream out(temp_img, std::ios_base::binary);
        std::vector<char> dummy(65536, 0x41); // 'A'
        out.write(dummy.data(), dummy.size());
    }

    auto raw_res = RawImageBackend::open(temp_img, true);
    assert(raw_res.is_ok());
    auto raw_dev = raw_res.value();

    assert(raw_dev->size() == 65536);
    assert(raw_dev->is_read_only());

    // Read payload
    std::vector<std::byte> buf(16);
    auto read_res = raw_dev->read(100, buf);
    assert(read_res.is_ok());
    assert(read_res.value() == 16);
    for (auto b : buf) {
        assert(static_cast<char>(b) == 'A');
    }

    // Out of bounds read
    auto oob = raw_dev->read(65530, buf);
    assert(oob.is_err());
    assert(oob.error().code() == ErrorCode::StorageFailure);

    // Reject write on read-only backend
    auto wr = raw_dev->write(0, buf);
    assert(wr.is_err());

    raw_dev.reset();
    std::filesystem::remove(temp_img);

    std::cout << "  PASS: test_raw_image_backend\n";
}

void test_vhd_image_backend() {
    std::cout << "[RUN] test_vhd_image_backend\n";

    const std::filesystem::path temp_vhd = "test_fixed.vhd";
    if (std::filesystem::exists(temp_vhd)) {
        std::filesystem::remove(temp_vhd);
    }

    constexpr uint64_t virtual_size = 1048576; // 1 MiB
    // Create Fixed VHD: 1 MiB payload + 512 byte footer
    {
        std::ofstream out(temp_vhd, std::ios_base::binary);
        std::vector<uint8_t> payload(virtual_size, 0x20); // space
        // Put MBR signature at byte 510
        payload[510] = 0x55;
        payload[511] = 0xAA;
        out.write(reinterpret_cast<const char*>(payload.data()), payload.size());

        // Craft 512-byte VHD footer
        uint8_t footer[512] = {0};
        std::memcpy(footer, "conectix", 8);
        write_be32(footer + 8, 0x00000002);          // Features
        write_be32(footer + 12, 0x00010000);         // Format version 1.0
        write_be64(footer + 16, 0xFFFFFFFFFFFFFFFF); // Data offset (fixed disk)
        write_be64(footer + 48, virtual_size);       // Current size
        write_be32(footer + 60, 2);                  // Disk type = 2 (Fixed)

        // Calculate ones-complement checksum
        uint32_t sum = 0;
        for (size_t i = 0; i < 512; ++i) {
            sum += footer[i];
        }
        write_be32(footer + 64, ~sum);

        out.write(reinterpret_cast<const char*>(footer), 512);
    }

    assert(VhdImageBackend::is_vhd(temp_vhd));

    auto vhd_res = VhdImageBackend::open(temp_vhd, true);
    assert(vhd_res.is_ok());
    auto vhd = vhd_res.value();

    assert(vhd->size() == virtual_size);
    assert(vhd->metadata().format == ImageFormat::VhdFixed);
    assert(vhd->metadata().checksum_valid);

    // Read virtual sector 0 through VHD translation
    uint8_t sector0[512];
    auto read_res = vhd->read(0, std::span<std::byte>(reinterpret_cast<std::byte*>(sector0), 512));
    assert(read_res.is_ok());
    assert(read_res.value() == 512);
    assert(sector0[510] == 0x55);
    assert(sector0[511] == 0xAA);

    vhd.reset();
    std::filesystem::remove(temp_vhd);

    std::cout << "  PASS: test_vhd_image_backend\n";
}

void test_golden_image_readonly_invariant() {
    std::cout << "[RUN] test_golden_image_readonly_invariant\n";

    const std::filesystem::path temp_path = "golden_win10.raw";
    if (std::filesystem::exists(temp_path)) {
        std::filesystem::remove(temp_path);
    }

    // Create 1 MiB image
    {
        std::ofstream out(temp_path, std::ios_base::binary);
        std::vector<char> data(1048576, 0x55);
        out.write(data.data(), data.size());
    }

    auto golden_res = GoldenImage::open(temp_path, ImageId("win10_pro_gold"));
    assert(golden_res.is_ok());
    auto golden = golden_res.value();

    assert(golden->id().value() == "win10_pro_gold");
    assert(golden->is_read_only());
    assert(golden->device()->is_read_only());
    assert(golden->virtual_size() == 1048576);

    // Attempting write MUST be rejected
    const char write_data[] = "Malicious or accidental write from client";
    std::span<const std::byte> bad_write(
        reinterpret_cast<const std::byte*>(write_data),
        std::strlen(write_data)
    );

    auto write_attempt = golden->device()->write(0, bad_write);
    assert(write_attempt.is_err());
    assert(write_attempt.error().code() == ErrorCode::StorageFailure);

    // Prove file remains untouched on disk
    golden.reset();
    {
        std::ifstream in(temp_path, std::ios_base::binary);
        char ch;
        in.read(&ch, 1);
        assert(ch == 0x55);
    }
    std::filesystem::remove(temp_path);

    std::cout << "  PASS: test_golden_image_readonly_invariant\n";
}

void test_golden_image_registry() {
    std::cout << "[RUN] test_golden_image_registry\n";

    const std::filesystem::path img1 = "reg_test1.raw";
    const std::filesystem::path img2 = "reg_test2.raw";

    {
        std::ofstream o1(img1, std::ios_base::binary);
        std::vector<char> d1(4096, 0x01);
        o1.write(d1.data(), d1.size());

        std::ofstream o2(img2, std::ios_base::binary);
        std::vector<char> d2(4096, 0x02);
        o2.write(d2.data(), d2.size());
    }

    GoldenImageRegistry registry;
    assert(registry.count() == 0);

    auto g1 = registry.register_image(img1, ImageId("img-01"));
    assert(g1.is_ok());
    assert(registry.count() == 1);
    assert(registry.has_image(ImageId("img-01")));

    auto g2 = registry.register_image(img2, ImageId("img-02"));
    assert(g2.is_ok());
    assert(registry.count() == 2);

    // Reject duplicate ID
    auto dup = registry.register_image(img1, ImageId("img-01"));
    assert(dup.is_err());
    assert(registry.count() == 2);

    // Lookup
    auto found = registry.find_image(ImageId("img-01"));
    assert(found != nullptr);
    assert(found->id().value() == "img-01");

    auto not_found = registry.find_image(ImageId("img-99"));
    assert(not_found == nullptr);

    // List IDs
    auto list = registry.list_images();
    assert(list.size() == 2);

    // Unregister
    assert(registry.unregister_image(ImageId("img-01")).is_ok());
    assert(registry.count() == 1);
    assert(!registry.has_image(ImageId("img-01")));

    registry.clear();
    assert(registry.count() == 0);

    std::filesystem::remove(img1);
    std::filesystem::remove(img2);

    std::cout << "  PASS: test_golden_image_registry\n";
}

// =============================================================================
// Phase 5 Setup Wizard, Persistence & Storage Benchmarking Tests
// =============================================================================

void test_configuration_persistence_and_directories() {
    std::cout << "[RUN] test_configuration_persistence_and_directories\n";

    const std::filesystem::path cfg_file = "test_persist.conf";
    const std::filesystem::path test_wb = "./test_persist_wb";
    const std::filesystem::path test_os = "./test_persist_os";
    const std::filesystem::path test_gm = "./test_persist_gm";
    const std::filesystem::path test_ch = "./test_persist_ch";

    if (std::filesystem::exists(cfg_file)) std::filesystem::remove(cfg_file);

    Configuration cfg;
    cfg.set_server_address(NetworkAddress(192, 168, 1, 100, 3260));
    cfg.set_network_interface("eth0");
    cfg.set_writeback_dir(test_wb);
    cfg.set_os_images_dir(test_os);
    cfg.set_games_dir(test_gm);
    cfg.set_cache_dir(test_ch);
    cfg.set_first_run_completed(true);
    cfg.set_max_clients(128);

    assert(cfg.validate().is_ok());

    // Ensure directories exist
    auto dir_res = cfg.ensure_directories_exist();
    assert(dir_res.is_ok());
    assert(std::filesystem::exists(test_wb));
    assert(std::filesystem::exists(test_os));
    assert(std::filesystem::exists(test_gm));
    assert(std::filesystem::exists(test_ch));

    // Save to file
    auto save_res = cfg.save_to_file(cfg_file);
    assert(save_res.is_ok());
    assert(std::filesystem::exists(cfg_file));

    // Load from file into new configuration
    Configuration loaded;
    auto load_res = loaded.load_from_file(cfg_file);
    assert(load_res.is_ok());

    assert(loaded.server_address().ip_string() == "192.168.1.100");
    assert(loaded.server_address().port() == 3260);
    assert(loaded.network_interface() == "eth0");
    assert(loaded.writeback_dir() == test_wb);
    assert(loaded.os_images_dir() == test_os);
    assert(loaded.games_dir() == test_gm);
    assert(loaded.cache_dir() == test_ch);
    assert(loaded.first_run_completed() == true);
    assert(loaded.max_clients() == 128);

    // Cleanup
    std::filesystem::remove(cfg_file);
    std::filesystem::remove_all(test_wb);
    std::filesystem::remove_all(test_os);
    std::filesystem::remove_all(test_gm);
    std::filesystem::remove_all(test_ch);

    std::cout << "  PASS: test_configuration_persistence_and_directories\n";
}

void test_storage_tester_health_and_benchmark() {
    std::cout << "[RUN] test_storage_tester_health_and_benchmark\n";

    const std::filesystem::path bench_dir = "./test_storage_bench";
    std::error_code ec;
    std::filesystem::remove_all(bench_dir, ec);

    // 1. Health check (creates dir if missing, checks free space, validates write probe)
    auto health_res = StorageTester::check_storage_health(bench_dir);
    assert(health_res.is_ok());
    const auto& health = health_res.value();
    assert(health.passed);
    assert(health.total_space_bytes > 0);
    assert(health.free_space_bytes > 0);

    // 2. Fast benchmark (1 MiB with 64 KiB blocks for fast test execution)
    auto bench_res = StorageTester::run_benchmark(bench_dir, 1024 * 1024, 64 * 1024);
    assert(bench_res.is_ok());
    const auto& bench = bench_res.value();
    assert(bench.passed);
    assert(bench.sequential_write_mbps > 0.0);
    assert(bench.sequential_read_mbps > 0.0);

    // Cleanup
    std::filesystem::remove_all(bench_dir, ec);

    std::cout << "  PASS: test_storage_tester_health_and_benchmark\n";
}

// =============================================================================
// Phase 6 Image Management, Validation & Safe Handling Tests
// =============================================================================

void test_image_manager_lifecycle_and_safe_handling() {
    std::cout << "[RUN] test_image_manager_lifecycle_and_safe_handling\n";

    const std::filesystem::path test_dir = "./test_img_mgr";
    const std::filesystem::path os_dir = test_dir / "os";
    const std::filesystem::path games_dir = test_dir / "games";
    const std::filesystem::path wb_dir = test_dir / "wb";
    const std::filesystem::path cache_dir = test_dir / "cache";

    std::error_code ec;
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(os_dir, ec);
    std::filesystem::create_directories(games_dir, ec);
    std::filesystem::create_directories(wb_dir, ec);
    std::filesystem::create_directories(cache_dir, ec);

    // Create a mock OS image
    const std::filesystem::path win11_path = os_dir / "win11_pro.raw";
    {
        std::ofstream out(win11_path, std::ios::binary);
        std::vector<char> dummy(1048576, 0x11);
        out.write(dummy.data(), dummy.size());
    }

    // Create a mock Game image
    const std::filesystem::path game_path = games_dir / "cyberpunk.raw";
    {
        std::ofstream out(game_path, std::ios::binary);
        std::vector<char> dummy(2097152, 0x22);
        out.write(dummy.data(), dummy.size());
    }

    Configuration cfg;
    cfg.set_os_images_dir(os_dir);
    cfg.set_games_dir(games_dir);
    cfg.set_writeback_dir(wb_dir);
    cfg.set_cache_dir(cache_dir);

    auto registry = std::make_shared<GoldenImageRegistry>();
    ImageManager manager(registry);
    manager.configure(cfg);

    // 1. Directory scan
    auto scan_res = manager.scan_directories();
    assert(scan_res.is_ok());
    assert(scan_res.value() == 2);

    assert(manager.list_all_images().size() == 2);
    assert(manager.list_images(ImageRole::OsImage).size() == 1);
    assert(manager.list_images(ImageRole::GameDisk).size() == 1);

    // 2. Storage usage report
    auto usage = manager.get_storage_usage();
    assert(usage.os_images_bytes == 1048576);
    assert(usage.game_images_bytes == 2097152);

    // 3. Image validation
    auto val_res = manager.validate_image(ImageId("win11_pro"));
    assert(val_res.is_ok());
    assert(val_res.value().health_status == ImageHealthStatus::Healthy);

    // 4. Safe image handling: Acquire reference
    auto acq_res = manager.acquire_image(ImageId("win11_pro"));
    assert(acq_res.is_ok());
    assert(acq_res.value() != nullptr);

    // Verify info shows active reference
    auto info_res = manager.get_image_info(ImageId("win11_pro"));
    assert(info_res.is_ok());
    assert(info_res.value().active_references == 1);

    // 5. Invariant: Attempting to remove an image with active client references MUST FAIL
    auto remove_fail = manager.remove_image(ImageId("win11_pro"), false);
    assert(remove_fail.is_err());
    assert(remove_fail.error().code() == ErrorCode::StorageFailure);

    // 6. Release reference and remove safely
    assert(manager.release_image(ImageId("win11_pro")).is_ok());
    auto remove_ok = manager.remove_image(ImageId("win11_pro"), true); // delete file on disk
    assert(remove_ok.is_ok());
    assert(!std::filesystem::exists(win11_path));
    assert(manager.list_images(ImageRole::OsImage).empty());

    // Cleanup
    std::filesystem::remove_all(test_dir, ec);

    std::cout << "  PASS: test_image_manager_lifecycle_and_safe_handling\n";
}

// =============================================================================
// Phase 7 Client Copy-On-Write (COW) & Writeback Tests
// =============================================================================

void test_cow_block_device_lifecycle() {
    std::cout << "[RUN] test_cow_block_device_lifecycle\n";

    const std::filesystem::path base_path = "golden_base.raw";
    const std::filesystem::path cow_path = "client_test.cow";

    std::error_code ec;
    std::filesystem::remove(base_path, ec);
    std::filesystem::remove(cow_path, ec);

    // 1. Create 1 MiB base image filled with 0x11
    {
        std::ofstream base_out(base_path, std::ios::binary);
        std::vector<uint8_t> base_data(1024 * 1024, 0x11);
        base_out.write(reinterpret_cast<const char*>(base_data.data()), base_data.size());
    }

    auto base_dev_res = RawImageBackend::open(base_path, true);
    assert(base_dev_res.is_ok());
    auto base_dev = base_dev_res.value();

    // 2. Create CowBlockDevice
    auto cow_res = CowBlockDevice::create(base_dev, cow_path, 4096);
    assert(cow_res.is_ok());
    auto cow = cow_res.value();

    assert(cow->is_open());
    assert(!cow->is_read_only());
    assert(cow->size_bytes() == 1024 * 1024);
    assert(cow->allocated_chunks() == 0);

    // 3. Read before write: should read through to base image (0x11)
    std::vector<std::byte> buf(4096, std::byte{0});
    auto r1 = cow->read(0, buf);
    assert(r1.is_ok());
    assert(r1.value() == 4096);
    assert(std::to_integer<int>(buf[0]) == 0x11);

    // 4. Write modified data to chunk 0
    std::vector<std::byte> write_data(4096, std::byte{0xAA});
    auto w1 = cow->write(0, write_data);
    assert(w1.is_ok());
    assert(w1.value() == 4096);
    assert(cow->allocated_chunks() == 1);
    assert(cow->dirty_bytes() == 4096);

    // 5. Read back modified chunk: should return 0xAA
    std::fill(buf.begin(), buf.end(), std::byte{0});
    auto r2 = cow->read(0, buf);
    assert(r2.is_ok());
    assert(std::to_integer<int>(buf[0]) == 0xAA);

    // 6. Read unmodified chunk 1: should still return 0x11 from base image
    std::fill(buf.begin(), buf.end(), std::byte{0});
    auto r3 = cow->read(4096, buf);
    assert(r3.is_ok());
    assert(std::to_integer<int>(buf[0]) == 0x11);

    // 7. Verify base image file is STRICTLY UNTOUCHED
    {
        std::ifstream verify_base(base_path, std::ios::binary);
        char ch;
        verify_base.read(&ch, 1);
        assert(static_cast<uint8_t>(ch) == 0x11);
    }

    // 8. Client Reset: wipe overlay and restore pristine state
    assert(cow->reset().is_ok());
    assert(cow->allocated_chunks() == 0);

    std::fill(buf.begin(), buf.end(), std::byte{0});
    auto r4 = cow->read(0, buf);
    assert(r4.is_ok());
    assert(std::to_integer<int>(buf[0]) == 0x11); // Restored!

    // Cleanup
    cow->close();
    base_dev.reset();
    std::filesystem::remove(base_path, ec);
    std::filesystem::remove(cow_path, ec);

    std::cout << "  PASS: test_cow_block_device_lifecycle\n";
}

void test_client_session_manager_isolation() {
    std::cout << "[RUN] test_client_session_manager_isolation\n";

    const std::filesystem::path test_dir = "./test_sessions";
    const std::filesystem::path os_dir = test_dir / "os";
    const std::filesystem::path wb_dir = test_dir / "wb";

    std::error_code ec;
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(os_dir, ec);
    std::filesystem::create_directories(wb_dir, ec);

    const std::filesystem::path win10_path = os_dir / "win10.raw";
    {
        std::ofstream out(win10_path, std::ios::binary);
        std::vector<uint8_t> base_data(512 * 1024, 0x55);
        out.write(reinterpret_cast<const char*>(base_data.data()), base_data.size());
    }

    Configuration cfg;
    cfg.set_os_images_dir(os_dir);
    cfg.set_writeback_dir(wb_dir);

    auto registry = std::make_shared<GoldenImageRegistry>();
    auto image_mgr = std::make_shared<ImageManager>(registry);
    image_mgr->configure(cfg);
    auto import_res = image_mgr->import_image(win10_path, ImageRole::OsImage, ImageId("win10"));
    assert(import_res.is_ok());

    ClientSessionManager session_mgr(image_mgr, wb_dir);

    // Client 1 (PC-01) connects
    ClientId c1("00:11:22:33:44:01");
    auto s1_res = session_mgr.get_or_create_session(c1, NetworkAddress(192, 168, 1, 101), ImageId("win10"));
    assert(s1_res.is_ok());
    auto s1 = s1_res.value();

    // Client 2 (PC-02) connects
    ClientId c2("00:11:22:33:44:02");
    auto s2_res = session_mgr.get_or_create_session(c2, NetworkAddress(192, 168, 1, 102), ImageId("win10"));
    assert(s2_res.is_ok());
    auto s2 = s2_res.value();

    assert(session_mgr.active_clients_count() == 2);

    // Client 1 writes 0xAA to block 0
    std::vector<std::byte> c1_write(512, std::byte{0xAA});
    assert(s1->cow_device()->write(0, c1_write).is_ok());

    // Client 2 writes 0xBB to block 0
    std::vector<std::byte> c2_write(512, std::byte{0xBB});
    assert(s2->cow_device()->write(0, c2_write).is_ok());

    // Verify isolation: Client 1 reads 0xAA, Client 2 reads 0xBB
    std::vector<std::byte> read_buf(512, std::byte{0});
    assert(s1->cow_device()->read(0, read_buf).is_ok());
    assert(std::to_integer<int>(read_buf[0]) == 0xAA);

    assert(s2->cow_device()->read(0, read_buf).is_ok());
    assert(std::to_integer<int>(read_buf[0]) == 0xBB);

    // Reset Client 1
    assert(session_mgr.reset_client(c1).is_ok());
    assert(s1->cow_device()->read(0, read_buf).is_ok());
    assert(std::to_integer<int>(read_buf[0]) == 0x55); // Restored to base image

    // Client 2 remains unaffected (still 0xBB)
    assert(s2->cow_device()->read(0, read_buf).is_ok());
    assert(std::to_integer<int>(read_buf[0]) == 0xBB);

    // Terminate both
    assert(session_mgr.terminate_session(c1).is_ok());
    assert(session_mgr.terminate_session(c2).is_ok());
    assert(session_mgr.active_clients_count() == 0);

    // Cleanup
    std::filesystem::remove_all(test_dir, ec);

    std::cout << "  PASS: test_client_session_manager_isolation\n";
}

// =============================================================================
// Phase 8 Network Boot (DHCP, PXE, TFTP & iPXE Architecture Detection) Tests
// =============================================================================

void test_dhcp_architecture_detection_and_pxe_provisioning() {
    std::cout << "[RUN] test_dhcp_architecture_detection_and_pxe_provisioning\n";

    DhcpServer server(NetworkAddress(192, 168, 1, 1));

    // 1. BIOS Client (Arch 0): DHCPDISCOVER with Option 93 = 0
    DhcpHeader bios_hdr{};
    bios_hdr.op = 1;
    bios_hdr.htype = 1;
    bios_hdr.hlen = 6;
    bios_hdr.xid = 0x12345678;
    bios_hdr.magic_cookie[0] = 99; bios_hdr.magic_cookie[1] = 130;
    bios_hdr.magic_cookie[2] = 83; bios_hdr.magic_cookie[3] = 99;
    bios_hdr.chaddr[0] = 0x00; bios_hdr.chaddr[1] = 0x11; bios_hdr.chaddr[2] = 0x22;
    bios_hdr.chaddr[3] = 0x33; bios_hdr.chaddr[4] = 0x44; bios_hdr.chaddr[5] = 0x55;

    std::vector<uint8_t> bios_packet(reinterpret_cast<const uint8_t*>(&bios_hdr),
                                      reinterpret_cast<const uint8_t*>(&bios_hdr) + sizeof(DhcpHeader));

    // Option 53 (Discover)
    bios_packet.push_back(53); bios_packet.push_back(1); bios_packet.push_back(1);
    // Option 93 (Client Arch: 0 = BIOS x86)
    bios_packet.push_back(93); bios_packet.push_back(2); bios_packet.push_back(0); bios_packet.push_back(0);
    bios_packet.push_back(255); // End

    auto bios_parse = DhcpServer::parse_packet(bios_packet);
    assert(bios_parse.is_ok());
    assert(bios_parse.value().client_arch == ClientArch::Bios_x86);
    assert(!bios_parse.value().is_ipxe_client);
    assert(bios_parse.value().client_mac == "00:11:22:33:44:55");

    auto bios_reply = server.build_reply(bios_hdr, bios_parse.value(), 2, NetworkAddress(192, 168, 1, 100));
    assert(bios_reply.is_ok());
    const auto* reply_hdr = reinterpret_cast<const DhcpHeader*>(bios_reply.value().data());
    assert(std::string(reinterpret_cast<const char*>(reply_hdr->file)) == "undionly.kpxe");

    // 2. UEFI Client (Arch 7): DHCPDISCOVER with Option 93 = 7
    DhcpHeader uefi_hdr{};
    uefi_hdr.op = 1;
    uefi_hdr.htype = 1;
    uefi_hdr.hlen = 6;
    uefi_hdr.xid = 0x87654321;
    uefi_hdr.magic_cookie[0] = 99; uefi_hdr.magic_cookie[1] = 130;
    uefi_hdr.magic_cookie[2] = 83; uefi_hdr.magic_cookie[3] = 99;
    uefi_hdr.chaddr[0] = 0xAA; uefi_hdr.chaddr[1] = 0xBB; uefi_hdr.chaddr[2] = 0xCC;
    uefi_hdr.chaddr[3] = 0xDD; uefi_hdr.chaddr[4] = 0xEE; uefi_hdr.chaddr[5] = 0xFF;

    std::vector<uint8_t> uefi_packet(reinterpret_cast<const uint8_t*>(&uefi_hdr),
                                      reinterpret_cast<const uint8_t*>(&uefi_hdr) + sizeof(DhcpHeader));

    uefi_packet.push_back(53); uefi_packet.push_back(1); uefi_packet.push_back(1);
    uefi_packet.push_back(93); uefi_packet.push_back(2); uefi_packet.push_back(0); uefi_packet.push_back(7); // Arch 7
    uefi_packet.push_back(255);

    auto uefi_parse = DhcpServer::parse_packet(uefi_packet);
    assert(uefi_parse.is_ok());
    assert(uefi_parse.value().client_arch == ClientArch::Efi_x64);

    auto uefi_reply = server.build_reply(uefi_hdr, uefi_parse.value(), 2, NetworkAddress(192, 168, 1, 101));
    assert(uefi_reply.is_ok());
    const auto* uefi_reply_hdr = reinterpret_cast<const DhcpHeader*>(uefi_reply.value().data());
    assert(std::string(reinterpret_cast<const char*>(uefi_reply_hdr->file)) == "ipxe.efi");

    // 3. iPXE Client Stage 2: DHCPREQUEST with Option 175
    DhcpHeader ipxe_hdr{};
    ipxe_hdr.op = 1;
    ipxe_hdr.htype = 1;
    ipxe_hdr.hlen = 6;
    ipxe_hdr.xid = 0x99999999;
    ipxe_hdr.magic_cookie[0] = 99; ipxe_hdr.magic_cookie[1] = 130;
    ipxe_hdr.magic_cookie[2] = 83; ipxe_hdr.magic_cookie[3] = 99;
    std::memcpy(ipxe_hdr.chaddr, uefi_hdr.chaddr, 16);

    std::vector<uint8_t> ipxe_packet(reinterpret_cast<const uint8_t*>(&ipxe_hdr),
                                      reinterpret_cast<const uint8_t*>(&ipxe_hdr) + sizeof(DhcpHeader));

    ipxe_packet.push_back(53); ipxe_packet.push_back(1); ipxe_packet.push_back(3); // Request
    ipxe_packet.push_back(175); ipxe_packet.push_back(1); ipxe_packet.push_back(1); // iPXE option
    ipxe_packet.push_back(255);

    auto ipxe_parse = DhcpServer::parse_packet(ipxe_packet);
    assert(ipxe_parse.is_ok());
    assert(ipxe_parse.value().is_ipxe_client);

    auto ipxe_reply = server.build_reply(ipxe_hdr, ipxe_parse.value(), 5, NetworkAddress(192, 168, 1, 101));
    assert(ipxe_reply.is_ok());
    const auto* ipxe_reply_hdr = reinterpret_cast<const DhcpHeader*>(ipxe_reply.value().data());
    assert(std::string(reinterpret_cast<const char*>(ipxe_reply_hdr->file)) == "boot.ipxe");

    // 4. IA32 UEFI Client (Arch 6): must receive ipxe.efi, NOT undionly.kpxe
    DhcpHeader uefi32_hdr = uefi_hdr;
    std::vector<uint8_t> uefi32_packet(reinterpret_cast<const uint8_t*>(&uefi32_hdr),
                                        reinterpret_cast<const uint8_t*>(&uefi32_hdr) + sizeof(DhcpHeader));
    uefi32_packet.push_back(53); uefi32_packet.push_back(1); uefi32_packet.push_back(1);
    uefi32_packet.push_back(93); uefi32_packet.push_back(2); uefi32_packet.push_back(0); uefi32_packet.push_back(6); // Arch 6
    uefi32_packet.push_back(255);

    auto uefi32_parse = DhcpServer::parse_packet(uefi32_packet);
    assert(uefi32_parse.is_ok());
    assert(uefi32_parse.value().client_arch == ClientArch::Efi_x86);
    auto uefi32_reply = server.build_reply(uefi32_hdr, uefi32_parse.value(), 2, NetworkAddress(192, 168, 1, 102));
    assert(uefi32_reply.is_ok());
    const auto* uefi32_reply_hdr = reinterpret_cast<const DhcpHeader*>(uefi32_reply.value().data());
    assert(std::string(reinterpret_cast<const char*>(uefi32_reply_hdr->file)) == "ipxe.efi");

    std::cout << "  PASS: test_dhcp_architecture_detection_and_pxe_provisioning\n";
}

void test_tftp_server_virtual_payloads_and_ipxe_script() {
    std::cout << "[RUN] test_tftp_server_virtual_payloads_and_ipxe_script\n";

    TftpServer server(NetworkAddress(192, 168, 1, 1));

    // 1. Dynamic iPXE script generation (single clean sanboot - no sanhook pair)
    std::string script = server.generate_ipxe_script("iqn.2026-09.com.cobdiskless:storage");
    assert(script.find("#!ipxe") != std::string::npos);
    assert(script.find("sanboot iscsi:192.168.1.1::::iqn.2026-09.com.cobdiskless:storage") != std::string::npos);
    assert(script.find("dhcp") != std::string::npos);
    assert(script.find("set keep-san 1") != std::string::npos);
    // Exactly ONE SAN attach: no 'sanhook' and no hardcoded '--drive 0x80'
    // (duplicate attaches produce iPXE error 0x03232019 / EADDRINUSE).
    assert(script.find("sanhook") == std::string::npos);
    assert(script.find("--drive 0x80") == std::string::npos);
    assert(script.find("iscsi:") == script.rfind("iscsi:")); // single iscsi reference

    // 2. Virtual file content checks
    auto ipxe_res = server.get_file_content("boot.ipxe");
    assert(ipxe_res.is_ok());
    assert(!ipxe_res.value().empty());

    auto bios_stage1 = server.get_file_content("undionly.kpxe");
    assert(bios_stage1.is_ok());
    assert(!bios_stage1.value().empty());

    auto uefi_stage1 = server.get_file_content("ipxe.efi");
    assert(uefi_stage1.is_ok());
    assert(!uefi_stage1.value().empty());

    // 3. TFTP Packet serialization
    std::vector<uint8_t> payload = {0x01, 0x02, 0x03, 0x04};
    auto data_pkt = TftpServer::create_data_packet(1, payload);
    assert(data_pkt.size() == 8);
    assert(data_pkt[1] == 0x03); // DATA opcode
    assert(data_pkt[3] == 0x01); // Block 1

    auto ack_pkt = TftpServer::create_ack_packet(1);
    assert(ack_pkt.size() == 4);
    assert(ack_pkt[1] == 0x04); // ACK opcode
    assert(ack_pkt[3] == 0x01); // Block 1

    auto err_pkt = TftpServer::create_error_packet(1, "File not found");
    assert(err_pkt.size() > 5);
    assert(err_pkt[1] == 0x05); // ERROR opcode

    std::cout << "  PASS: test_tftp_server_virtual_payloads_and_ipxe_script\n";
}

// =============================================================================
// Phase 9 Network Disk Service (iSCSI Target & Multi-Client Transport) Tests
// =============================================================================

void test_iscsi_target_scsi_emulation_and_client_dispatch() {
    std::cout << "[RUN] test_iscsi_target_scsi_emulation_and_client_dispatch\n";

    // 1. Test INQUIRY response
    uint8_t cdb_inquiry[16] = {0x12, 0, 0, 0, 36, 0};
    auto inq_res = IscsiTarget::handle_inquiry(cdb_inquiry);
    assert(inq_res.is_ok());
    const auto& inq = inq_res.value();
    assert(inq.size() == 36);
    assert(inq[0] == 0x00); // Direct access block device
    assert(std::string(reinterpret_cast<const char*>(inq.data() + 8), 8) == "COB     ");
    assert(std::string(reinterpret_cast<const char*>(inq.data() + 16), 16) == "CobDiskless SAN ");

    // 2. Test READ CAPACITY (10)
    // 1000 sectors, 512 bytes each
    auto cap_res = IscsiTarget::handle_read_capacity(1000, 512);
    assert(cap_res.is_ok());
    const auto& cap = cap_res.value();
    assert(cap.size() == 8);
    // Last LBA = 999 (0x000003E7)
    uint32_t last_lba = (cap[0] << 24) | (cap[1] << 16) | (cap[2] << 8) | cap[3];
    assert(last_lba == 999);
    // Block size = 512 (0x00000200)
    uint32_t blk_size = (cap[4] << 24) | (cap[5] << 16) | (cap[6] << 8) | cap[7];
    assert(blk_size == 512);

    // 3. Test SCSI Read/Write dispatch through ClientSession and COW overlay
    const std::filesystem::path test_dir = "./test_iscsi_dispatch";
    const std::filesystem::path base_path = test_dir / "golden_os.raw";
    const std::filesystem::path wb_dir = test_dir / "wb";

    std::error_code ec;
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);
    std::filesystem::create_directories(wb_dir, ec);

    // Create 1 MiB base image filled with 0x33
    {
        std::ofstream base_out(base_path, std::ios::binary);
        std::vector<uint8_t> data(1024 * 1024, 0x33);
        base_out.write(reinterpret_cast<const char*>(data.data()), data.size());
    }

    Configuration cfg;
    cfg.set_os_images_dir(test_dir);
    cfg.set_writeback_dir(wb_dir);

    auto registry = std::make_shared<GoldenImageRegistry>();
    auto img_mgr = std::make_shared<ImageManager>(registry);
    img_mgr->configure(cfg);
    assert(img_mgr->import_image(base_path, ImageRole::OsImage, ImageId("os_image")).is_ok());

    auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, wb_dir);

    IscsiTargetConfig target_cfg;
    target_cfg.default_os_image_id = ImageId("os_image");
    IscsiTarget target(target_cfg, sess_mgr);

    ClientId client_id("00:50:56:C0:00:08");
    auto session_res = sess_mgr->get_or_create_session(client_id, NetworkAddress(192, 168, 1, 150), ImageId("os_image"));
    assert(session_res.is_ok());
    auto session = session_res.value();

    // Read Sector 10 before write -> should return base image byte 0x33
    std::vector<std::byte> read_buf(512, std::byte{0});
    auto r1 = IscsiTarget::execute_read(*session, 10, 1, read_buf);
    assert(r1.is_ok());
    assert(r1.value() == 512);
    assert(std::to_integer<int>(read_buf[0]) == 0x33);
    assert(session->bytes_read() == 512);

    // Write Sector 10 with 0x77
    std::vector<std::byte> write_buf(512, std::byte{0x77});
    auto w1 = IscsiTarget::execute_write(*session, 10, 1, write_buf);
    assert(w1.is_ok());
    assert(w1.value() == 512);
    assert(session->bytes_written() == 512);

    // Read Sector 10 after write -> should return modified byte 0x77 from COW overlay
    std::fill(read_buf.begin(), read_buf.end(), std::byte{0});
    auto r2 = IscsiTarget::execute_read(*session, 10, 1, read_buf);
    assert(r2.is_ok());
    assert(std::to_integer<int>(read_buf[0]) == 0x77);

    // Read Sector 11 -> untouched, still 0x33
    std::fill(read_buf.begin(), read_buf.end(), std::byte{0});
    auto r3 = IscsiTarget::execute_read(*session, 11, 1, read_buf);
    assert(r3.is_ok());
    assert(std::to_integer<int>(read_buf[0]) == 0x33);

    // Terminate session and cleanup
    assert(sess_mgr->terminate_session(client_id).is_ok());
    std::filesystem::remove_all(test_dir, ec);

    std::cout << "  PASS: test_iscsi_target_scsi_emulation_and_client_dispatch\n";
}

static void test_block_cache_lru_and_read_ahead() {
    std::cout << "Running test_block_cache_lru_and_read_ahead...\n";
    std::error_code ec;
    auto test_dir = std::filesystem::current_path() / "test_scratch_cache";
    std::filesystem::create_directories(test_dir, ec);
    auto raw_path = test_dir / "cache_backing.raw";

    // 16 KiB backing file
    const size_t total_size = 16 * 1024;
    {
        std::ofstream ofs(raw_path, std::ios::binary);
        std::vector<uint8_t> init_data(total_size);
        for (size_t i = 0; i < total_size; ++i) {
            init_data[i] = static_cast<uint8_t>(i % 251);
        }
        ofs.write(reinterpret_cast<const char*>(init_data.data()), init_data.size());
    }

    auto raw_backend = RawImageBackend::open(raw_path.string(), false).value();

    // Cache: 4 pages total (1024 bytes / 256 bytes per page), read-ahead window of 2 pages
    const size_t max_cache_bytes = 1024;
    const size_t page_size = 256;
    const size_t read_ahead_pages = 2;

    auto cached_dev = CachedBlockDevice::create(raw_backend, max_cache_bytes, page_size, read_ahead_pages).value();
    assert(cached_dev != nullptr);
    assert(cached_dev->size() == total_size);

    CacheStats s = cached_dev->stats();
    assert(s.hits == 0);
    assert(s.misses == 0);
    assert(s.active_pages == 0);
    assert(s.max_pages == 4);

    // 1. Read first page (256 bytes) -> Miss
    std::vector<std::byte> buf(page_size);
    auto r1 = cached_dev->read(0, buf);
    assert(r1.is_ok() && r1.value() == page_size);
    assert(static_cast<uint8_t>(buf[0]) == 0);
    assert(static_cast<uint8_t>(buf[10]) == 10);

    s = cached_dev->stats();
    assert(s.misses == 1);
    assert(s.hits == 0);
    assert(s.active_pages == 1);

    // 2. Read first page again -> Hit
    auto r2 = cached_dev->read(0, buf);
    assert(r2.is_ok() && r2.value() == page_size);
    s = cached_dev->stats();
    assert(s.misses == 1);
    assert(s.hits == 1);
    assert(s.hit_ratio() == 50.0);

    // 3. Read page 1 sequentially (offset 256) -> Triggers read-ahead for page 2 and page 3!
    auto r3 = cached_dev->read(256, buf);
    assert(r3.is_ok() && r3.value() == page_size);
    s = cached_dev->stats();
    assert(s.misses == 2);
    assert(s.read_ahead_prefetches >= 1);
    // Page 0, 1, 2, 3 should now be cached (active_pages == 4, maxed out)
    assert(s.active_pages == 4);

    // 4. Reading page 2 (offset 512) and page 3 (offset 768) should be hits because of read-ahead!
    auto r4 = cached_dev->read(512, buf);
    assert(r4.is_ok());
    auto r5 = cached_dev->read(768, buf);
    assert(r5.is_ok());
    s = cached_dev->stats();
    assert(s.hits >= 3);

    // 5. Read page 4 (offset 1024) -> Must evict oldest page from LRU
    auto r6 = cached_dev->read(1024, buf);
    assert(r6.is_ok());
    s = cached_dev->stats();
    assert(s.evictions >= 1);
    assert(s.active_pages <= 4);

    // 6. Test write-through and cache invalidation
    std::vector<std::byte> write_data(64, std::byte{0x7F});
    auto w1 = cached_dev->write(1024, write_data);
    assert(w1.is_ok() && w1.value() == 64);

    // Read back modified area
    std::vector<std::byte> read_back(64);
    auto r7 = cached_dev->read(1024, read_back);
    assert(r7.is_ok());
    assert(read_back[0] == std::byte{0x7F});
    assert(read_back[63] == std::byte{0x7F});

    // 7. Clear cache
    cached_dev->clear_cache();
    s = cached_dev->stats();
    assert(s.active_pages == 0);

    raw_backend.reset();
    cached_dev.reset();
    std::filesystem::remove_all(test_dir, ec);

    std::cout << "  PASS: test_block_cache_lru_and_read_ahead\n";
}

static void test_production_hardening_and_recovery() {
    std::cout << "Running test_production_hardening_and_recovery...\n";
    std::error_code ec;
    auto test_dir = std::filesystem::current_path() / "test_scratch_hardening";
    std::filesystem::create_directories(test_dir, ec);

    // 1. Create a dummy base raw image (64 KiB)
    auto base_path = test_dir / "base_img.raw";
    {
        std::ofstream ofs(base_path, std::ios::binary);
        std::vector<uint8_t> zeros(64 * 1024, 0xAA);
        ofs.write(reinterpret_cast<const char*>(zeros.data()), zeros.size());
    }
    auto base_dev = RawImageBackend::open(base_path.string(), false).value();

    // 2. Corrupt COW file test (bad magic)
    auto corrupt_cow_path = test_dir / "bad_magic.cow";
    {
        std::ofstream ofs(corrupt_cow_path, std::ios::binary);
        ofs.write("BAD!CORRUPT_DATA", 16);
    }
    // Attempting to open bad_magic.cow directly fails
    auto dev_fail = CowBlockDevice::create(base_dev, corrupt_cow_path);
    assert(!dev_fail.is_ok());

    // 3. Quarantine corrupted overlay test
    assert(CowBlockDevice::quarantine_corrupted_overlay(corrupt_cow_path).is_ok());
    assert(!std::filesystem::exists(corrupt_cow_path));
    auto quarantined_path = std::filesystem::path(corrupt_cow_path.string() + ".corrupted");
    assert(std::filesystem::exists(quarantined_path));

    // 4. Truncated COW file auto-recovery test (power failure simulation)
    // Create header specifying 5 allocated chunks, but only write 2 chunk slots to disk
    auto trunc_cow_path = test_dir / "truncated.cow";
    const uint32_t chunk_size = 4096;
    {
        std::ofstream ofs(trunc_cow_path, std::ios::binary);
        // Direct write of CowHeader layout
        struct RawHdr {
            char magic[4];
            uint32_t version;
            uint32_t chunk_size;
            uint32_t reserved;
            uint64_t virtual_capacity;
            uint64_t allocated_chunks;
            uint64_t checksum;
            uint8_t pad[472];
        } hdr{};
        std::memcpy(hdr.magic, "COWB", 4);
        hdr.version = 1;
        hdr.chunk_size = chunk_size;
        hdr.virtual_capacity = base_dev->size();
        hdr.allocated_chunks = 5; // Claims 5 slots exist
        ofs.write(reinterpret_cast<const char*>(&hdr), sizeof(hdr));

        // Write only 2 valid slots:
        // Slot 0: virtual chunk 1
        uint64_t v0 = 1;
        ofs.write(reinterpret_cast<const char*>(&v0), sizeof(v0));
        std::vector<uint8_t> payload0(chunk_size, 0x11);
        ofs.write(reinterpret_cast<const char*>(payload0.data()), payload0.size());

        // Slot 1: virtual chunk 3
        uint64_t v1 = 3;
        ofs.write(reinterpret_cast<const char*>(&v1), sizeof(v1));
        std::vector<uint8_t> payload1(chunk_size, 0x33);
        ofs.write(reinterpret_cast<const char*>(payload1.data()), payload1.size());
        // Abrupt termination here! File truncated before slots 2, 3, 4!
    }

    // Opening truncated.cow should auto-repair and clamp allocated chunks to 2
    auto recovered_cow = CowBlockDevice::create(base_dev, trunc_cow_path, chunk_size);
    assert(recovered_cow.is_ok());
    auto r_dev = recovered_cow.value();
    assert(r_dev->allocated_chunks() == 2);

    // Verify chunk 1 data was preserved
    std::vector<std::byte> read_buf(chunk_size);
    auto read_res = r_dev->read(1 * chunk_size, read_buf);
    assert(read_res.is_ok());
    assert(read_buf[0] == std::byte{0x11});

    // Verify unwritten chunk reads from base device (0xAA)
    read_res = r_dev->read(0, read_buf);
    assert(read_res.is_ok());
    assert(read_buf[0] == std::byte{0xAA});

    r_dev->close();
    r_dev.reset();

    // 5. ClientSessionManager auto-quarantine test
    Configuration cfg;
    cfg.set_os_images_dir(test_dir);
    cfg.set_writeback_dir(test_dir / "writeback");
    auto registry = std::make_shared<GoldenImageRegistry>();
    auto img_mgr = std::make_shared<ImageManager>(registry);
    img_mgr->configure(cfg);
    auto import_res = img_mgr->import_image(base_path, ImageRole::OsImage, ImageId("base_img"));
    assert(import_res.is_ok());
    auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, test_dir / "writeback");

    // Pre-create a corrupt writeback file for client "faulty_pc"
    auto client_wb = test_dir / "writeback" / "wb_faulty_pc.cow";
    std::filesystem::create_directories(client_wb.parent_path(), ec);
    {
        std::ofstream ofs(client_wb, std::ios::binary);
        ofs.write("CORRUPT_HEADER_GARBAGE", 22);
    }
    assert(std::filesystem::exists(client_wb));

    // ClientSessionManager must auto-quarantine faulty_pc.cow and succeed in creating session!
    ClientId cid("faulty_pc");
    NetworkAddress client_ip(192, 168, 1, 99);
    ImageId os_id("base_img");
    auto sess_res = sess_mgr->get_or_create_session(cid, client_ip, os_id);
    assert(sess_res.is_ok());
    assert(std::filesystem::exists(test_dir / "writeback" / "wb_faulty_pc.cow.corrupted"));
    assert(std::filesystem::exists(client_wb));
    assert(sess_res.value()->cow_device()->allocated_chunks() == 0);
    assert(sess_mgr->terminate_session(cid).is_ok());

    // 6. TFTP RRQ safety checks
    // Malformed: no null terminator
    std::vector<uint8_t> malformed_rrq = {0x00, 0x01, 'b', 'o', 'o', 't'};
    auto fn_res = TftpServer::parse_rrq_filename(malformed_rrq);
    assert(!fn_res.is_ok());

    // Traversal attack rejected
    std::vector<uint8_t> traversal_rrq = {0x00, 0x01, '.', '.', '/', 'e', 't', 'c', '/', 'p', 'a', 's', 's', 'w', 'd', 0x00, 'o', 'c', 't', 'e', 't', 0x00};
    fn_res = TftpServer::parse_rrq_filename(traversal_rrq);
    assert(!fn_res.is_ok());

    // Valid RRQ accepted
    std::vector<uint8_t> valid_rrq = {0x00, 0x01, 'b', 'o', 'o', 't', '.', 'i', 'p', 'x', 'e', 0x00, 'o', 'c', 't', 'e', 't', 0x00};
    fn_res = TftpServer::parse_rrq_filename(valid_rrq);
    assert(fn_res.is_ok());
    assert(fn_res.value() == "boot.ipxe");

    // 7. iSCSI Target bounds validation
    IscsiTargetConfig iscsi_cfg;
    iscsi_cfg.default_os_image_id = os_id;
    auto target = std::make_shared<IscsiTarget>(iscsi_cfg, sess_mgr);
    auto sess_ok = sess_mgr->get_or_create_session(cid, client_ip, os_id).value();

    // Out of bounds read: base image is 64 KiB = 128 sectors. Try reading at LBA 130!
    std::vector<std::byte> oob_buf(512);
    auto oob_read = target->execute_read(*sess_ok, 130, 1, oob_buf);
    assert(!oob_read.is_ok());

    auto oob_write = target->execute_write(*sess_ok, 130, 1, oob_buf);
    assert(!oob_write.is_ok());

    assert(sess_mgr->terminate_session(cid).is_ok());
    base_dev.reset();
    std::filesystem::remove_all(test_dir, ec);

    std::cout << "  PASS: test_production_hardening_and_recovery\n";
}

static void test_end_to_end_diskless_boot_pipeline() {
    std::cout << "Running test_end_to_end_diskless_boot_pipeline...\n";
    std::error_code ec;
    auto test_dir = std::filesystem::current_path() / "test_scratch_e2e";
    std::filesystem::create_directories(test_dir / "os_images", ec);
    std::filesystem::create_directories(test_dir / "games", ec);
    std::filesystem::create_directories(test_dir / "writeback", ec);
    std::filesystem::create_directories(test_dir / "cache", ec);

    // 1. Create a pristine golden OS image (256 KiB)
    auto os_image_path = test_dir / "os_images" / "win11_pro.raw";
    const size_t img_size = 256 * 1024;
    {
        std::ofstream ofs(os_image_path, std::ios::binary);
        std::vector<uint8_t> base_data(img_size, 0xEE);
        // Put boot signature at sector 0
        base_data[510] = 0x55;
        base_data[511] = 0xAA;
        ofs.write(reinterpret_cast<const char*>(base_data.data()), base_data.size());
    }

    // 2. Configure system
    Configuration config;
    config.set_server_address(NetworkAddress(192, 168, 1, 10));
    config.set_os_images_dir(test_dir / "os_images");
    config.set_games_dir(test_dir / "games");
    config.set_writeback_dir(test_dir / "writeback");
    config.set_cache_dir(test_dir / "cache");

    // 3. Image Registry & Management
    auto registry = std::make_shared<GoldenImageRegistry>();
    auto img_mgr = std::make_shared<ImageManager>(registry);
    img_mgr->configure(config);
    auto import_res = img_mgr->import_image(os_image_path, ImageRole::OsImage, ImageId("win11_pro"));
    assert(import_res.is_ok());
    assert(registry->count() == 1);

    // 4. Client Session Manager (Multi-tenant COW)
    auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, config.writeback_dir());

    // 5. Build Subsystems
    auto dhcp = std::make_shared<DhcpServer>(
        config.server_address(),
        NetworkAddress(255, 255, 255, 0),
        NetworkAddress(192, 168, 1, 100),
        NetworkAddress(192, 168, 1, 200)
    );

    auto tftp = std::make_shared<TftpServer>(
        config.server_address(),
        config.os_images_dir(),
        10069
    );

    IscsiTargetConfig iscsi_cfg;
    iscsi_cfg.listen_address = NetworkAddress(127, 0, 0, 1, 13260);
    iscsi_cfg.target_iqn = "iqn.2026-09.com.cobdiskless:storage";
    iscsi_cfg.default_os_image_id = ImageId("win11_pro");
    auto iscsi = std::make_shared<IscsiTarget>(iscsi_cfg, sess_mgr);

    // 6. Host in Core and initialize
    Core core(config);
    assert(core.register_subsystem(dhcp).is_ok());
    assert(core.register_subsystem(tftp).is_ok());
    assert(core.register_subsystem(iscsi).is_ok());
    assert(core.initialize().is_ok());
    assert(core.is_initialized());
    assert(dhcp->is_initialized());
    assert(tftp->is_initialized());
    assert(iscsi->is_initialized());

    // =========================================================================
    // PIPELINE STEP 1: DHCP Architecture Detection (UEFI vs BIOS)
    // =========================================================================
    // Client boots with UEFI x64 firmware: DHCPDISCOVER with Option 93 = 7
    DhcpHeader uefi_hdr{};
    uefi_hdr.op = 1;
    uefi_hdr.htype = 1;
    uefi_hdr.hlen = 6;
    uefi_hdr.xid = 0xCAFEBABE;
    uefi_hdr.magic_cookie[0] = 99; uefi_hdr.magic_cookie[1] = 130;
    uefi_hdr.magic_cookie[2] = 83; uefi_hdr.magic_cookie[3] = 99;
    uefi_hdr.chaddr[0] = 0xAA; uefi_hdr.chaddr[1] = 0xBB; uefi_hdr.chaddr[2] = 0xCC;
    uefi_hdr.chaddr[3] = 0x11; uefi_hdr.chaddr[4] = 0x22; uefi_hdr.chaddr[5] = 0x33;

    std::vector<uint8_t> uefi_packet(reinterpret_cast<const uint8_t*>(&uefi_hdr),
                                     reinterpret_cast<const uint8_t*>(&uefi_hdr) + sizeof(uefi_hdr));
    // Option 53: DHCPDISCOVER
    uefi_packet.push_back(53); uefi_packet.push_back(1); uefi_packet.push_back(1);
    // Option 93: UEFI x64
    uefi_packet.push_back(93); uefi_packet.push_back(2); uefi_packet.push_back(0); uefi_packet.push_back(7);
    uefi_packet.push_back(255); // END

    auto uefi_opts = dhcp->parse_packet(uefi_packet);
    assert(uefi_opts.is_ok());
    assert(uefi_opts.value().client_arch == ClientArch::Efi_x64);
    assert(!uefi_opts.value().is_ipxe_client);

    // DHCP Offer responds with ipxe.efi stage-1 loader
    auto uefi_offer = dhcp->build_reply(uefi_hdr, uefi_opts.value(), 2, NetworkAddress(192, 168, 1, 150));
    assert(uefi_offer.is_ok());
    const auto* uefi_reply = reinterpret_cast<const DhcpHeader*>(uefi_offer.value().data());
    assert(std::string(reinterpret_cast<const char*>(uefi_reply->file)) == "ipxe.efi");

    // =========================================================================
    // PIPELINE STEP 2: iPXE Client Identification
    // =========================================================================
    // Client boots ipxe.efi, which sends second DHCPDISCOVER with Option 175
    std::vector<uint8_t> ipxe_packet(reinterpret_cast<const uint8_t*>(&uefi_hdr),
                                     reinterpret_cast<const uint8_t*>(&uefi_hdr) + sizeof(uefi_hdr));
    ipxe_packet.push_back(53); ipxe_packet.push_back(1); ipxe_packet.push_back(1);
    ipxe_packet.push_back(175); ipxe_packet.push_back(1); ipxe_packet.push_back(1);
    ipxe_packet.push_back(255);

    auto ipxe_opts = dhcp->parse_packet(ipxe_packet);
    assert(ipxe_opts.is_ok());
    assert(ipxe_opts.value().is_ipxe_client);

    auto ipxe_offer = dhcp->build_reply(uefi_hdr, ipxe_opts.value(), 2, NetworkAddress(192, 168, 1, 150));
    assert(ipxe_offer.is_ok());
    const auto* ipxe_reply = reinterpret_cast<const DhcpHeader*>(ipxe_offer.value().data());
    assert(std::string(reinterpret_cast<const char*>(ipxe_reply->file)) == "boot.ipxe");

    // =========================================================================
    // PIPELINE STEP 2b: Stage-2 bootfile points at the embedded HTTP daemon
    // =========================================================================
    // Once the HTTP daemon is registered the stage-2 bootfile becomes an
    // absolute URL so /boot.ipxe can answer per client MAC (enrollment prompt
    // for unknown machines, SANBoot for enrolled ones). DHCP cannot expand
    // iPXE variables, hence the bare URL - /boot.ipxe re-chains itself with
    // ${net0/mac} attached. Both the BOOTP `file` field and Option 67 carry it.
    dhcp->set_boot_script_url("http://192.168.1.100:18080/boot.ipxe");
    auto http_boot_offer = dhcp->build_reply(uefi_hdr, ipxe_opts.value(), 2,
                                             NetworkAddress(192, 168, 1, 150));
    assert(http_boot_offer.is_ok());
    const auto* http_boot_reply =
        reinterpret_cast<const DhcpHeader*>(http_boot_offer.value().data());
    assert(std::string(reinterpret_cast<const char*>(http_boot_reply->file)) ==
           "http://192.168.1.100:18080/boot.ipxe");

    bool http_boot_opt67 = false;
    for (size_t i = 240; i + 1 < http_boot_offer.value().size();) {
        const uint8_t code = http_boot_offer.value()[i];
        if (code == 255) {
            break;
        }
        if (code == 0) {
            ++i;
            continue;
        }
        const uint8_t len = http_boot_offer.value()[i + 1];
        if (code == 67) {
            const std::string value(
                reinterpret_cast<const char*>(http_boot_offer.value().data() + i + 2), len);
            http_boot_opt67 = (value == "http://192.168.1.100:18080/boot.ipxe");
        }
        i += static_cast<size_t>(len) + 2;
    }
    assert(http_boot_opt67);

    // Clearing it restores the legacy TFTP "boot.ipxe" virtual file.
    dhcp->set_boot_script_url("");
    auto legacy_boot_offer = dhcp->build_reply(uefi_hdr, ipxe_opts.value(), 2,
                                               NetworkAddress(192, 168, 1, 150));
    assert(legacy_boot_offer.is_ok());
    const auto* legacy_boot_reply =
        reinterpret_cast<const DhcpHeader*>(legacy_boot_offer.value().data());
    assert(std::string(reinterpret_cast<const char*>(legacy_boot_reply->file)) == "boot.ipxe");

    // =========================================================================
    // PIPELINE STEP 3: TFTP Boot Script Retrieval
    // =========================================================================
    auto script_res = tftp->get_file_content("boot.ipxe");
    assert(script_res.is_ok());
    std::string script_str(script_res.value().begin(), script_res.value().end());
    assert(script_str.find("sanboot iscsi:") != std::string::npos);
    assert(script_str.find("set keep-san 1") != std::string::npos);

    // =========================================================================
    // PIPELINE STEP 4: iSCSI Multi-client Session & Cache Verification
    // =========================================================================
    ClientId client_a("AA:BB:CC:11:22:33");
    NetworkAddress client_a_ip(192, 168, 1, 150);
    auto sess_a_res = sess_mgr->get_or_create_session(client_a, client_a_ip, ImageId("win11_pro"));
    assert(sess_a_res.is_ok());
    auto sess_a = sess_a_res.value();
    sess_a->set_state(ClientState::Online);

    ClientId client_b("AA:BB:CC:99:88:77");
    NetworkAddress client_b_ip(192, 168, 1, 151);
    auto sess_b_res = sess_mgr->get_or_create_session(client_b, client_b_ip, ImageId("win11_pro"));
    assert(sess_b_res.is_ok());
    auto sess_b = sess_b_res.value();
    sess_b->set_state(ClientState::Online);

    assert(sess_mgr->active_clients_count() == 2);

    // Wrap Client A device with CachedBlockDevice
    auto cached_dev_a = CachedBlockDevice::create(sess_a->cow_device(), 32768, 4096, 2).value();

    // Client A: Read sector 0 (MBR)
    std::vector<std::byte> sector_buf(512);
    auto r_a = cached_dev_a->read(0, sector_buf);
    assert(r_a.is_ok() && r_a.value() == 512);
    assert(static_cast<uint8_t>(sector_buf[510]) == 0x55);
    assert(static_cast<uint8_t>(sector_buf[511]) == 0xAA);

    // Cache hit on second read
    assert(cached_dev_a->read(0, sector_buf).is_ok());
    assert(cached_dev_a->stats().hits >= 1);

    // Client A writes 0x42 to sector 10
    std::vector<std::byte> write_buf(512, std::byte{0x42});
    auto w_a = iscsi->execute_write(*sess_a, 10, 1, write_buf);
    assert(w_a.is_ok());

    // Client B reads sector 10 -> MUST get pristine 0xEE from golden image!
    std::vector<std::byte> read_b(512);
    auto r_b = iscsi->execute_read(*sess_b, 10, 1, read_b);
    assert(r_b.is_ok());
    assert(read_b[0] == std::byte{0xEE}); // Completely isolated!

    // Client A reads sector 10 -> MUST get 0x42
    std::vector<std::byte> read_a(512);
    auto r_a2 = iscsi->execute_read(*sess_a, 10, 1, read_a);
    assert(r_a2.is_ok());
    assert(read_a[0] == std::byte{0x42});

    // =========================================================================
    // PIPELINE STEP 5: Instant Zero-Cost Reset
    // =========================================================================
    assert(sess_mgr->reset_client(client_a).is_ok());
    auto r_a_reset = iscsi->execute_read(*sess_a, 10, 1, read_a);
    assert(r_a_reset.is_ok());
    assert(read_a[0] == std::byte{0xEE}); // Restored!

    // =========================================================================
    // PIPELINE STEP 6: Deterministic Core Shutdown
    // =========================================================================
    cached_dev_a.reset();
    assert(sess_mgr->terminate_session(client_a).is_ok());
    assert(sess_mgr->terminate_session(client_b).is_ok());
    core.shutdown();
    assert(!core.is_initialized());

    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_end_to_end_diskless_boot_pipeline\n";
}

// =============================================================================
// PHASE 13: Reality Verification & Hardening Tests
// =============================================================================

void test_vhdx_rejection_and_vhd_handling() {
    std::cout << "[RUN] test_vhdx_rejection_and_vhd_handling\n";
    std::error_code ec;
    std::filesystem::path test_dir = "test_vhdx_env";
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);

    // 1. Synthesize a mock VHDX file with "vhdxfile" header
    std::filesystem::path vhdx_file = test_dir / "test_image.vhdx";
    {
        std::ofstream out(vhdx_file, std::ios::binary);
        std::vector<uint8_t> header(1024 * 1024, 0); // 1 MB
        const char* magic = "vhdxfile";
        std::memcpy(header.data(), magic, 8);
        out.write(reinterpret_cast<const char*>(header.data()), static_cast<std::streamsize>(header.size()));
    }

    // Verify format detection explicitly identifies ImageFormat::Vhdx
    auto format = ImageInspector::detect_format(vhdx_file);
    assert(format == ImageFormat::Vhdx);

    // Verify GoldenImage::open attempts VHDX parsing and rejects corrupted headers with StorageFailure
    auto open_res = GoldenImage::open(vhdx_file, ImageId("vhdx_test"));
    assert(!open_res.is_ok());
    assert(open_res.error().code() == ErrorCode::StorageFailure);

    // 2. Synthesize a valid Fixed VHD with "conectix" footer
    std::filesystem::path vhd_file = test_dir / "test_image.vhd";
    {
        std::ofstream out(vhd_file, std::ios::binary);
        std::vector<uint8_t> disk_data(65536, 0x5A); // 64 KB data
        out.write(reinterpret_cast<const char*>(disk_data.data()), static_cast<std::streamsize>(disk_data.size()));

        // 512-byte conectix footer
        std::vector<uint8_t> footer(512, 0);
        std::memcpy(footer.data(), "conectix", 8);
        // disk_type = 2 (Fixed) at offset 0x3C (big-endian)
        footer[0x3C] = 0x00; footer[0x3D] = 0x00; footer[0x3E] = 0x00; footer[0x3F] = 0x02;
        // current_size at offset 0x30
        uint64_t v_size = 65536;
        for (int i = 0; i < 8; ++i) {
            footer[0x30 + i] = static_cast<uint8_t>((v_size >> ((7 - i) * 8)) & 0xFF);
        }
        uint32_t sum = 0;
        for (size_t i = 0; i < 512; ++i) {
            sum += footer[i];
        }
        uint32_t csum = ~sum;
        footer[64] = static_cast<uint8_t>((csum >> 24) & 0xFF);
        footer[65] = static_cast<uint8_t>((csum >> 16) & 0xFF);
        footer[66] = static_cast<uint8_t>((csum >> 8) & 0xFF);
        footer[67] = static_cast<uint8_t>(csum & 0xFF);
        out.write(reinterpret_cast<const char*>(footer.data()), static_cast<std::streamsize>(footer.size()));
    }

    auto vhd_format = ImageInspector::detect_format(vhd_file);
    assert(vhd_format == ImageFormat::VhdFixed);

    auto vhd_open = GoldenImage::open(vhd_file, ImageId("vhd_fixed_test"));
    assert(vhd_open.is_ok());
    assert(vhd_open.value()->virtual_size() == 65536);

    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_vhdx_rejection_and_vhd_handling\n";
}

void test_real_socket_networking() {
    std::cout << "[RUN] test_real_socket_networking\n";

#if defined(_WIN32)
    WSADATA wsa;
    int wsa_res = WSAStartup(MAKEWORD(2, 2), &wsa);
    assert(wsa_res == 0);
#endif

    std::error_code ec;
    std::filesystem::path test_dir = "test_socket_env";
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);

    // =========================================================================
    // 1. TFTP Server Real UDP Socket Test
    // =========================================================================
    {
        uint16_t tftp_port = 10069;
        TftpServer tftp(NetworkAddress(127, 0, 0, 1), test_dir, tftp_port);
        assert(tftp.initialize().is_ok());
        std::this_thread::sleep_for(std::chrono::milliseconds(50));

        // Create client UDP socket
        SOCKET s_tftp = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        assert(s_tftp != INVALID_SOCKET);

        DWORD tv_ms = 3000;
        setsockopt(s_tftp, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv_ms), sizeof(tv_ms));

        sockaddr_in tftp_srv_addr{};
        tftp_srv_addr.sin_family = AF_INET;
        tftp_srv_addr.sin_port = htons(tftp_port);
        tftp_srv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

        // Send TFTP RRQ for "boot.ipxe" (opcode 1, "boot.ipxe\0octet\0")
        std::vector<uint8_t> rrq = {0x00, 0x01, 'b', 'o', 'o', 't', '.', 'i', 'p', 'x', 'e', 0x00, 'o', 'c', 't', 'e', 't', 0x00};
        int sent = sendto(s_tftp, reinterpret_cast<const char*>(rrq.data()), static_cast<int>(rrq.size()), 0,
                          reinterpret_cast<const sockaddr*>(&tftp_srv_addr), sizeof(tftp_srv_addr));
        assert(sent == static_cast<int>(rrq.size()));

        // Receive real DATA packet
        std::vector<uint8_t> recv_buf(2048);
        sockaddr_in from_addr{};
        int from_len = sizeof(from_addr);
        int recvd = recvfrom(s_tftp, reinterpret_cast<char*>(recv_buf.data()), static_cast<int>(recv_buf.size()), 0,
                             reinterpret_cast<sockaddr*>(&from_addr), &from_len);
        assert(recvd >= 4);
        assert(recv_buf[0] == 0x00 && recv_buf[1] == 0x03); // Opcode 3 (DATA)
        assert(recv_buf[2] == 0x00 && recv_buf[3] == 0x01); // Block 1
        std::string payload(recv_buf.begin() + 4, recv_buf.begin() + recvd);
        assert(payload.find("#!ipxe") != std::string::npos);

        // Test path traversal security rejection
        std::vector<uint8_t> bad_rrq = {0x00, 0x01, '.', '.', '/', 'e', 't', 'c', 0x00, 'o', 'c', 't', 'e', 't', 0x00};
        sent = sendto(s_tftp, reinterpret_cast<const char*>(bad_rrq.data()), static_cast<int>(bad_rrq.size()), 0,
                      reinterpret_cast<const sockaddr*>(&tftp_srv_addr), sizeof(tftp_srv_addr));
        assert(sent == static_cast<int>(bad_rrq.size()));

        recvd = recvfrom(s_tftp, reinterpret_cast<char*>(recv_buf.data()), static_cast<int>(recv_buf.size()), 0,
                         reinterpret_cast<sockaddr*>(&from_addr), &from_len);
        assert(recvd >= 4);
        assert(recv_buf[0] == 0x00 && recv_buf[1] == 0x05); // Opcode 5 (ERROR)

        closesocket(s_tftp);
        tftp.shutdown();
    }

    // =========================================================================
    // 2. DHCP Server Real UDP Socket Test
    // =========================================================================
    {
        uint16_t dhcp_port = 16767;
        DhcpServer dhcp(
            NetworkAddress(127, 0, 0, 1),
            NetworkAddress(255, 255, 255, 0),
            NetworkAddress(192, 168, 1, 100),
            NetworkAddress(192, 168, 1, 200),
            dhcp_port
        );
        assert(dhcp.initialize().is_ok());
        std::this_thread::sleep_for(std::chrono::milliseconds(50));

        SOCKET s_dhcp = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        assert(s_dhcp != INVALID_SOCKET);

        DWORD tv_ms = 3000;
        setsockopt(s_dhcp, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv_ms), sizeof(tv_ms));

        sockaddr_in dhcp_srv_addr{};
        dhcp_srv_addr.sin_family = AF_INET;
        dhcp_srv_addr.sin_port = htons(dhcp_port);
        dhcp_srv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

        // Send real DHCPDISCOVER with Option 93 = 7 (UEFI x64)
        std::vector<uint8_t> d_pkt(sizeof(DhcpHeader) + 64, 0);
        auto* hdr = reinterpret_cast<DhcpHeader*>(d_pkt.data());
        hdr->op = 1; // BOOTREQUEST
        hdr->htype = 1;
        hdr->hlen = 6;
        hdr->xid = htonl(0x11223344);
        hdr->flags = htons(0x8000);
        hdr->chaddr[0] = 0xAA; hdr->chaddr[1] = 0xBB; hdr->chaddr[2] = 0xCC;
        hdr->chaddr[3] = 0xDD; hdr->chaddr[4] = 0xEE; hdr->chaddr[5] = 0xFF;
        hdr->magic_cookie[0] = 99; hdr->magic_cookie[1] = 130; hdr->magic_cookie[2] = 83; hdr->magic_cookie[3] = 99;

        size_t opt_pos = sizeof(DhcpHeader);
        d_pkt[opt_pos++] = 53; d_pkt[opt_pos++] = 1; d_pkt[opt_pos++] = 1; // DHCPDISCOVER
        d_pkt[opt_pos++] = 93; d_pkt[opt_pos++] = 2; d_pkt[opt_pos++] = 0; d_pkt[opt_pos++] = 7; // UEFI x64
        d_pkt[opt_pos++] = 255; // END
        d_pkt.resize(opt_pos);

        int sent = sendto(s_dhcp, reinterpret_cast<const char*>(d_pkt.data()), static_cast<int>(d_pkt.size()), 0,
                          reinterpret_cast<const sockaddr*>(&dhcp_srv_addr), sizeof(dhcp_srv_addr));
        assert(sent == static_cast<int>(d_pkt.size()));

        std::vector<uint8_t> offer_buf(2048);
        sockaddr_in from_addr{};
        int from_len = sizeof(from_addr);
        int recvd = recvfrom(s_dhcp, reinterpret_cast<char*>(offer_buf.data()), static_cast<int>(offer_buf.size()), 0,
                             reinterpret_cast<sockaddr*>(&from_addr), &from_len);
        assert(recvd >= static_cast<int>(sizeof(DhcpHeader)));
        const auto* reply_hdr = reinterpret_cast<const DhcpHeader*>(offer_buf.data());
        assert(reply_hdr->op == 2); // BOOTREPLY
        assert(reply_hdr->xid == htonl(0x11223344));
        assert(std::string(reinterpret_cast<const char*>(reply_hdr->file)) == "ipxe.efi");

        // Test truncated/malformed DHCP packet (must not crash server)
        std::vector<uint8_t> short_pkt = {0x01, 0x01, 0x06, 0x00};
        sendto(s_dhcp, reinterpret_cast<const char*>(short_pkt.data()), static_cast<int>(short_pkt.size()), 0,
               reinterpret_cast<const sockaddr*>(&dhcp_srv_addr), sizeof(dhcp_srv_addr));

        closesocket(s_dhcp);
        dhcp.shutdown();
    }

    // =========================================================================
    // 3. iSCSI Target Real TCP Socket Test
    // =========================================================================
    {
        uint16_t iscsi_port = 13260;
        auto reg = std::make_shared<GoldenImageRegistry>();
        auto img_mgr = std::make_shared<ImageManager>(reg);
        auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, test_dir);

        IscsiTargetConfig cfg;
        cfg.listen_address = NetworkAddress(127, 0, 0, 1, iscsi_port);
        cfg.target_iqn = "iqn.2026-09.com.cobdiskless:storage";
        IscsiTarget target(cfg, sess_mgr);
        assert(target.initialize().is_ok());
        std::this_thread::sleep_for(std::chrono::milliseconds(50));

        SOCKET s_iscsi = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        assert(s_iscsi != INVALID_SOCKET);

        DWORD tv_ms = 3000;
        setsockopt(s_iscsi, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv_ms), sizeof(tv_ms));

        sockaddr_in iscsi_srv_addr{};
        iscsi_srv_addr.sin_family = AF_INET;
        iscsi_srv_addr.sin_port = htons(iscsi_port);
        iscsi_srv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

        int conn = connect(s_iscsi, reinterpret_cast<const sockaddr*>(&iscsi_srv_addr), sizeof(iscsi_srv_addr));
        assert(conn == 0);

        // Send iSCSI Login Request
        IscsiBhs login_req{};
        login_req.opcode = 0x03; // Login Request
        login_req.flags = 0x80;  // Transit bit
        login_req.initiator_task_tag = 0x44332211;
        int sent = send(s_iscsi, reinterpret_cast<const char*>(&login_req), sizeof(login_req), 0);
        assert(sent == sizeof(login_req));

        IscsiBhs login_resp{};
        int recvd = recv(s_iscsi, reinterpret_cast<char*>(&login_resp), sizeof(login_resp), 0);
        assert(recvd == sizeof(login_resp));
        assert((login_resp.opcode & 0x3F) == 0x23); // Login Response
        assert(login_resp.initiator_task_tag == 0x44332211);

        // Send SCSI INQUIRY
        IscsiBhs inq_req{};
        inq_req.opcode = 0x01; // SCSI Command
        inq_req.flags = 0x40;  // Read
        inq_req.initiator_task_tag = 0x55667788;
        inq_req.cdb[0] = 0x12; // INQUIRY
        inq_req.cdb[4] = 36;
        sent = send(s_iscsi, reinterpret_cast<const char*>(&inq_req), sizeof(inq_req), 0);
        assert(sent == sizeof(inq_req));

        IscsiBhs data_in_bhs{};
        recvd = recv(s_iscsi, reinterpret_cast<char*>(&data_in_bhs), sizeof(data_in_bhs), 0);
        assert(recvd == sizeof(data_in_bhs));
        assert((data_in_bhs.opcode & 0x3F) == 0x25); // SCSI Data-In
        assert(data_in_bhs.initiator_task_tag == 0x55667788);

        std::vector<uint8_t> inq_payload(36);
        recvd = recv(s_iscsi, reinterpret_cast<char*>(inq_payload.data()), static_cast<int>(inq_payload.size()), 0);
        assert(recvd == 36);
        std::string vendor(reinterpret_cast<char*>(inq_payload.data() + 8), 8);
        assert(vendor == "COB     ");

        // Send iSCSI Logout Request
        IscsiBhs logout_req{};
        logout_req.opcode = 0x06;
        logout_req.flags = 0x80;
        logout_req.initiator_task_tag = 0x9999;
        send(s_iscsi, reinterpret_cast<const char*>(&logout_req), sizeof(logout_req), 0);

        IscsiBhs logout_resp{};
        recvd = recv(s_iscsi, reinterpret_cast<char*>(&logout_resp), sizeof(logout_resp), 0);
        assert(recvd == sizeof(logout_resp));
        assert((logout_resp.opcode & 0x3F) == 0x26);

        closesocket(s_iscsi);
        target.shutdown();
    }

    std::filesystem::remove_all(test_dir, ec);

#if defined(_WIN32)
    WSACleanup();
#endif

    std::cout << "  PASS: test_real_socket_networking\n";
}

void test_concurrency_and_stress() {
    std::cout << "[RUN] test_concurrency_and_stress\n";
    std::error_code ec;
    std::filesystem::path test_dir = "test_concurrency_env";
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);

    // Create 1 MB base image filled with 0xAA
    auto base_mem = std::make_shared<MemoryBlockDevice>(1024 * 1024);
    std::vector<std::byte> init_fill(1024 * 1024, std::byte{0xAA});
    (void)base_mem->write(0, init_fill);

    auto base_ro = std::make_shared<ReadOnlyBlockDevice>(base_mem);
    auto cow_file = test_dir / "cow_stress.bin";
    auto cow_dev = CowBlockDevice::create(base_ro, cow_file, 4096).value();

    auto cached_dev = CachedBlockDevice::create(cow_dev, 65536, 4096, 2).value();

    constexpr size_t num_threads = 8;
    std::vector<std::thread> workers;
    workers.reserve(num_threads);

    std::atomic<bool> start_gate{false};
    std::atomic<bool> failure{false};

    // 4 reader threads
    for (size_t t = 0; t < 4; ++t) {
        workers.emplace_back([&, t]() {
            while (!start_gate.load()) {
                std::this_thread::yield();
            }
            std::vector<std::byte> buf(4096);
            for (size_t iter = 0; iter < 100; ++iter) {
                uint64_t offset = ((t * 10 + iter) % 200) * 4096;
                auto read_res = cached_dev->read(offset, buf);
                if (!read_res.is_ok() || read_res.value() != 4096) {
                    failure.store(true);
                    break;
                }
            }
        });
    }

    // 4 writer threads, each writing unique byte patterns to independent non-overlapping ranges
    for (size_t t = 0; t < 4; ++t) {
        workers.emplace_back([&, t]() {
            while (!start_gate.load()) {
                std::this_thread::yield();
            }
            uint8_t pattern = static_cast<uint8_t>(0x10 + t);
            std::vector<std::byte> buf(4096, std::byte{pattern});
            for (size_t iter = 0; iter < 20; ++iter) {
                uint64_t offset = (t * 20 + iter) * 4096;
                auto write_res = cached_dev->write(offset, buf);
                if (!write_res.is_ok() || write_res.value() != 4096) {
                    failure.store(true);
                    break;
                }
            }
        });
    }

    start_gate.store(true);
    for (auto& w : workers) {
        w.join();
    }

    assert(!failure.load());

    // Flush and verify all written patterns
    assert(cached_dev->flush().is_ok());

    for (size_t t = 0; t < 4; ++t) {
        uint8_t expected_pattern = static_cast<uint8_t>(0x10 + t);
        std::vector<std::byte> verify_buf(4096);
        for (size_t iter = 0; iter < 20; ++iter) {
            uint64_t offset = (t * 20 + iter) * 4096;
            auto read_res = cached_dev->read(offset, verify_buf);
            assert(read_res.is_ok());
            for (auto b : verify_buf) {
                assert(b == std::byte{expected_pattern});
            }
        }
    }

    // Verify untouched area retains original 0xAA
    std::vector<std::byte> untouched_buf(4096);
    auto untouched_res = cached_dev->read(150 * 4096, untouched_buf);
    assert(untouched_res.is_ok());
    for (auto b : untouched_buf) {
        assert(b == std::byte{0xAA});
    }

    // Verify cache hits occurred
    assert(cached_dev->stats().hits > 0);

    cached_dev.reset();
    cow_dev.reset();
    base_ro.reset();
    base_mem.reset();

    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_concurrency_and_stress\n";
}

// =============================================================================
// Complete Diskless Management & Deep Virtual Disk Inspection Tests
// =============================================================================

void test_client_manager_lifecycle_and_persistence() {
    std::cout << "[RUN] test_client_manager_lifecycle_and_persistence\n";

    const std::filesystem::path test_conf = "test_clients.conf";
    std::error_code ec;
    std::filesystem::remove(test_conf, ec);

    ClientManager mgr(test_conf);
    mgr.set_dhcp_pool_range(NetworkAddress(192, 168, 1, 101), NetworkAddress(192, 168, 1, 105));

    // Auto-register first client from unknown MAC
    auto r1 = mgr.get_or_register_client("00:11:22:33:44:01");
    assert(r1.is_ok());
    assert(r1.value().pc_name == "PC01");
    assert(r1.value().ip_address == NetworkAddress(192, 168, 1, 101));
    assert(r1.value().mac_address == "00:11:22:33:44:01");
    assert(mgr.client_count() == 1);

    // Auto-register second client
    auto r2 = mgr.get_or_register_client("00:11:22:33:44:02");
    assert(r2.is_ok());
    assert(r2.value().pc_name == "PC02");
    assert(r2.value().ip_address == NetworkAddress(192, 168, 1, 102));
    assert(mgr.client_count() == 2);

    // Calling get_or_register_client for existing MAC returns same record
    auto r1_again = mgr.get_or_register_client("00:11:22:33:44:01");
    assert(r1_again.is_ok());
    assert(r1_again.value().pc_name == "PC01");
    assert(r1_again.value().ip_address == NetworkAddress(192, 168, 1, 101));
    assert(mgr.client_count() == 2);

    // Duplicate collision rejection: attempting to add a client with duplicate PC name
    ClientRecord bad_name;
    bad_name.mac_address = "00:11:22:33:44:99";
    bad_name.pc_name = "PC01"; // Already used
    bad_name.ip_address = NetworkAddress(192, 168, 1, 103);
    auto rej1 = mgr.add_or_update_client(bad_name);
    assert(rej1.is_err());
    assert(rej1.error().code() == ErrorCode::InvalidConfiguration);

    // Duplicate collision rejection: attempting to add a client with duplicate IP
    ClientRecord bad_ip;
    bad_ip.mac_address = "00:11:22:33:44:99";
    bad_ip.pc_name = "PC99";
    bad_ip.ip_address = NetworkAddress(192, 168, 1, 101); // Already used
    auto rej2 = mgr.add_or_update_client(bad_ip);
    assert(rej2.is_err());
    assert(rej2.error().code() == ErrorCode::InvalidConfiguration);

    // Update client 1 properties
    auto c1_rec = *mgr.get_client_by_mac("00:11:22:33:44:01");
    c1_rec.os_image_id = "win10-pro-vhd";
    c1_rec.writeback_dir = "D:/CustomWriteback";
    c1_rec.game_dir = "E:/Games";
    c1_rec.ram_cache_mb = 2048;
    c1_rec.ssd_cache_mb = 32768;
    c1_rec.enable_write_cache = true;
    assert(mgr.add_or_update_client(c1_rec).is_ok());

    // Save to file
    assert(mgr.save_to_file(test_conf).is_ok());
    assert(std::filesystem::exists(test_conf));

    // Load in fresh manager
    ClientManager loaded_mgr;
    assert(loaded_mgr.load_from_file(test_conf).is_ok());
    assert(loaded_mgr.client_count() == 2);

    auto loaded_c1 = loaded_mgr.get_client_by_mac("00:11:22:33:44:01");
    assert(loaded_c1.has_value());
    assert(loaded_c1->pc_name == "PC01");
    assert(loaded_c1->ip_address == NetworkAddress(192, 168, 1, 101));
    assert(loaded_c1->os_image_id == "win10-pro-vhd");
    assert(loaded_c1->writeback_dir == "D:/CustomWriteback");
    assert(loaded_c1->game_dir == "E:/Games");
    assert(loaded_c1->ram_cache_mb == 2048);
    assert(loaded_c1->ssd_cache_mb == 32768);
    assert(loaded_c1->enable_write_cache == true);

    auto loaded_c2 = loaded_mgr.get_client_by_mac("00:11:22:33:44:02");
    assert(loaded_c2.has_value());
    assert(loaded_c2->pc_name == "PC02");
    assert(loaded_c2->ip_address == NetworkAddress(192, 168, 1, 102));

    std::filesystem::remove(test_conf, ec);
    std::cout << "  PASS: test_client_manager_lifecycle_and_persistence\n";
}

void test_storage_manager_drive_roles_and_validation() {
    std::cout << "[RUN] test_storage_manager_drive_roles_and_validation\n";

    const std::filesystem::path test_roles_conf = "test_roles.conf";
    std::error_code ec;
    std::filesystem::remove(test_roles_conf, ec);

    StorageManager sm(test_roles_conf);
    auto drives = sm.scan_drives();

    // HOST SAFETY GUARD: the host system volume must never be offered by the picker
    std::string sys_root = StorageManager::host_system_drive_root().string();
    std::string win_dir = StorageManager::host_windows_directory().string();
    assert(!sys_root.empty());
    assert(!win_dir.empty());
    for (const auto& d : drives) {
        assert(!StorageManager::is_host_system_drive(d.root_path));
        assert(!StorageManager::is_host_system_root(d.root_path));
    }

    if (!drives.empty()) {
        const auto& d0 = drives[0];
        assert(!d0.path.empty());
        assert(d0.total_bytes > 0);
        assert(!StorageManager::is_host_system_drive(d0.root_path));

        // Assign roles (must succeed: d0 is guaranteed NOT to be the system drive)
        assert(sm.set_drive_role(d0.path, StorageRole::Writeback).is_ok());
        assert(sm.get_drive_role(d0.path) == StorageRole::Writeback);
    } else {
        // Degenerate host with a single system volume: fall back to a dedicated sub-directory
        std::filesystem::path fallback = std::filesystem::path(sys_root) / "cobdiskless_wb_fallback";
        assert(sm.set_drive_role(fallback, StorageRole::Writeback).is_ok());
    }

    // HOST SAFETY GUARD: refusing the system drive root and Windows directory
    assert(StorageManager::validate_storage_path(sys_root, false).is_err());
    assert(StorageManager::validate_storage_path(std::filesystem::path(sys_root) / "Windows", false).is_err());
    assert(StorageManager::validate_storage_path(win_dir, false).is_err());
    assert(StorageManager::is_host_system_root(std::filesystem::path(sys_root)));
    assert(StorageManager::is_host_system_drive(std::filesystem::path(sys_root)));
    assert(StorageManager::is_protected_host_path(std::filesystem::path(win_dir) / "Temp"));
    assert(!StorageManager::is_host_system_drive("D:\\"));
    assert(!StorageManager::is_protected_host_path("D:\\Data"));

    // Write probe validation on valid directory
    const std::filesystem::path probe_dir = "test_probe_dir";
    std::filesystem::create_directories(probe_dir, ec);
    auto val_ok = sm.validate_storage_path(probe_dir);
    assert(val_ok.is_ok());

    // Invalid path validation
    auto val_err = sm.validate_storage_path("Z:\\NonExistent_Invalid_Path_12345");
    assert(val_err.is_err());

    // Persistence test
    assert(sm.save_to_file(test_roles_conf).is_ok());
    assert(std::filesystem::exists(test_roles_conf));

    StorageManager loaded_sm(test_roles_conf);
    assert(loaded_sm.load_from_file(test_roles_conf).is_ok());
    assert(loaded_sm.get_role_path(StorageRole::Writeback) ==
           sm.get_role_path(StorageRole::Writeback));

    std::filesystem::remove_all(probe_dir, ec);
    std::filesystem::remove(test_roles_conf, ec);
    std::cout << "  PASS: test_storage_manager_drive_roles_and_validation\n";
}

void test_vhd_windows_deep_inspection() {
    std::cout << "[RUN] test_vhd_windows_deep_inspection\n";

    // Synthetic Fixed VHD with GPT + ESP (FAT32) + bootmgfw.efi + NTFS Windows markers
    constexpr uint64_t virtual_size = 20 * 1024 * 1024;
    auto dev = std::make_shared<MemoryBlockDevice>(virtual_size);
    uint8_t* raw = reinterpret_cast<uint8_t*>(dev->raw_data().data());

    // LBA 0: Protective MBR
    raw[510] = 0x55; raw[511] = 0xAA;
    uint8_t* pmbr_p1 = raw + 446;
    pmbr_p1[4] = 0xEE; // GPT Protective type
    write_le32(pmbr_p1 + 8, 1);
    write_le32(pmbr_p1 + 12, static_cast<uint32_t>((virtual_size / 512) - 1));

    // LBA 1: GPT Header
    uint8_t* gpt_hdr = raw + 512;
    std::memcpy(gpt_hdr, "EFI PART", 8);
    write_le32(gpt_hdr + 8, 0x00010000);
    write_le32(gpt_hdr + 12, 92);
    write_le64(gpt_hdr + 24, 1);
    write_le64(gpt_hdr + 32, (virtual_size / 512) - 1);
    write_le64(gpt_hdr + 40, 34);
    write_le64(gpt_hdr + 48, (virtual_size / 512) - 34);
    write_le64(gpt_hdr + 72, 2); // Entries at LBA 2
    write_le32(gpt_hdr + 80, 128);
    write_le32(gpt_hdr + 84, 128);

    // LBA 2 Entry 0: ESP (EFI System Partition)
    // GUID: C12A7328-F81F-11D2-BA4B-00A0C93EC93B
    uint8_t* e0 = raw + (2 * 512);
    write_le32(e0, 0xC12A7328);
    write_le16(e0 + 4, 0xF81F);
    write_le16(e0 + 6, 0x11D2);
    e0[8] = 0xBA; e0[9] = 0x4B; e0[10] = 0x00; e0[11] = 0xA0;
    e0[12] = 0xC9; e0[13] = 0x3E; e0[14] = 0xC9; e0[15] = 0x3B;
    write_le64(e0 + 32, 2048); // Start LBA 2048 (1 MiB)
    write_le64(e0 + 40, 4095); // End LBA 4095 (2048 sectors = 1 MiB ESP)

    // Write FAT32 filesystem signature in ESP VBR (LBA 2048)
    uint8_t* esp_vbr = raw + (2048 * 512);
    std::memcpy(esp_vbr + 82, "FAT32   ", 8);

    // Write bootmgfw.efi and bootx64.efi file markers in ESP clusters
    uint8_t* esp_data = raw + (2050 * 512);
    std::memcpy(esp_data, "\\EFI\\Microsoft\\Boot\\bootmgfw.efi", 32);
    std::memcpy(esp_data + 128, "bootx64.efi", 11);

    // LBA 2 Entry 1: Basic Data Partition (Windows NTFS)
    // GUID: EBD0A0A2-B9E5-4433-87C0-68B6B72699C7
    uint8_t* e1 = e0 + 128;
    write_le32(e1, 0xEBD0A0A2);
    write_le16(e1 + 4, 0xB9E5);
    write_le16(e1 + 6, 0x4433);
    e1[8] = 0x87; e1[9] = 0xC0; e1[10] = 0x68; e1[11] = 0xB6;
    e1[12] = 0xB7; e1[13] = 0x26; e1[14] = 0x99; e1[15] = 0xC7;
    write_le64(e1 + 32, 4096);
    write_le64(e1 + 40, 30000);

    // Write NTFS filesystem signature in NTFS VBR (LBA 4096)
    uint8_t* ntfs_vbr = raw + (4096 * 512);
    std::memcpy(ntfs_vbr + 3, "NTFS    ", 8);

    // Write Windows directory markers in NTFS data sectors
    uint8_t* ntfs_data = raw + (4100 * 512);
    std::memcpy(ntfs_data, "\\Windows\\System32\\ntoskrnl.exe", 30);

    auto rep_res = ImageInspector::inspect(dev, "win10_production.vhd");
    assert(rep_res.is_ok());
    const auto& rep = rep_res.value();

    assert(rep.format == ImageFormat::VhdFixed);
    assert(rep.partition_scheme == PartitionScheme::Gpt);
    assert(rep.has_esp == true);
    assert(rep.has_efi_boot_files == true);
    assert(rep.has_windows_dir == true);
    assert(rep.has_windows_partition == true);
    assert(rep.boot_mode == BootMode::Uefi); // Confirmed by EFI boot files

    std::string summary = rep.detailed_inspection_summary();
    assert(summary.find("ESP FAT32: YES") != std::string::npos);
    assert(summary.find("EFI Bootloader: YES") != std::string::npos);
    assert(summary.find("Windows Directory Marker: YES") != std::string::npos);
    assert(summary.find("Determined Boot Mode: UEFI") != std::string::npos);

    std::cout << "  PASS: test_vhd_windows_deep_inspection\n";
}

void test_dhcp_client_auto_registration_pipeline() {
    std::cout << "[RUN] test_dhcp_client_auto_registration_pipeline\n";

    const std::filesystem::path test_dhcp_conf = "test_dhcp_clients.conf";
    std::error_code ec;
    std::filesystem::remove(test_dhcp_conf, ec);

    auto client_mgr = std::make_shared<ClientManager>(test_dhcp_conf);
    client_mgr->set_dhcp_pool_range(NetworkAddress(192, 168, 1, 150), NetworkAddress(192, 168, 1, 160));

    DhcpServer server(NetworkAddress(192, 168, 1, 1));
    server.set_client_manager(client_mgr);
    server.set_pool_range(NetworkAddress(192, 168, 1, 150), NetworkAddress(192, 168, 1, 160));
    server.set_gateway(NetworkAddress(192, 168, 1, 1));
    server.set_dns_server(NetworkAddress(1, 1, 1, 1));
    server.set_lease_duration_seconds(86400);

    // Verify initially no clients
    assert(client_mgr->client_count() == 0);

    // Simulate unknown client broadcasting DHCPDISCOVER
    DhcpHeader disc_hdr{};
    disc_hdr.op = 1;
    disc_hdr.htype = 1;
    disc_hdr.hlen = 6;
    disc_hdr.xid = 0x55AA1122;
    disc_hdr.magic_cookie[0] = 99; disc_hdr.magic_cookie[1] = 130;
    disc_hdr.magic_cookie[2] = 83; disc_hdr.magic_cookie[3] = 99;
    disc_hdr.chaddr[0] = 0x00; disc_hdr.chaddr[1] = 0x50; disc_hdr.chaddr[2] = 0x56;
    disc_hdr.chaddr[3] = 0xC0; disc_hdr.chaddr[4] = 0x00; disc_hdr.chaddr[5] = 0x08;

    std::vector<uint8_t> disc_packet(reinterpret_cast<const uint8_t*>(&disc_hdr),
                                      reinterpret_cast<const uint8_t*>(&disc_hdr) + sizeof(DhcpHeader));
    // Option 53 = 1 (Discover)
    disc_packet.push_back(53); disc_packet.push_back(1); disc_packet.push_back(1);
    // Option 93 = 7 (UEFI x64)
    disc_packet.push_back(93); disc_packet.push_back(2); disc_packet.push_back(0); disc_packet.push_back(7);
    disc_packet.push_back(255);

    auto parsed_opt = DhcpServer::parse_packet(disc_packet);
    assert(parsed_opt.is_ok());
    const auto& parsed = parsed_opt.value();
    assert(parsed.client_mac == "00:50:56:C0:00:08");

    // Process reply (DHCPOFFER) - Server auto-registers client into ClientManager
    auto reg_res = client_mgr->get_or_register_client(parsed.client_mac);
    assert(reg_res.is_ok());
    assert(reg_res.value().pc_name == "PC01");
    assert(reg_res.value().ip_address == NetworkAddress(192, 168, 1, 150));
    assert(client_mgr->client_count() == 1);

    auto assigned_ip = reg_res.value().ip_address;
    auto offer_res = server.build_reply(disc_hdr, parsed, 2, assigned_ip);
    assert(offer_res.is_ok());
    const auto* offer_hdr = reinterpret_cast<const DhcpHeader*>(offer_res.value().data());
    const auto* yiaddr_bytes = reinterpret_cast<const uint8_t*>(&offer_hdr->yiaddr);
    assert(yiaddr_bytes[0] == assigned_ip.octet(0));
    assert(yiaddr_bytes[1] == assigned_ip.octet(1));
    assert(yiaddr_bytes[2] == assigned_ip.octet(2));
    assert(yiaddr_bytes[3] == assigned_ip.octet(3));
    assert(std::string(reinterpret_cast<const char*>(offer_hdr->file)) == "ipxe.efi");

    // Verify lease table records
    auto leases = server.list_leases();
    assert(leases.size() >= 1);
    assert(leases[0].pc_name == "PC01");
    assert(leases[0].ip_address == NetworkAddress(192, 168, 1, 150));
    assert(leases[0].mac_address == "00:50:56:C0:00:08");

    std::filesystem::remove(test_dhcp_conf, ec);
    std::cout << "  PASS: test_dhcp_client_auto_registration_pipeline\n";
}

// Helpers for end-to-end iSCSI and storage tests
static bool send_all_bytes(SOCKET s, const void* data, size_t len) {
    const char* ptr = reinterpret_cast<const char*>(data);
    while (len > 0) {
        int res = send(s, ptr, static_cast<int>(len), 0);
        if (res <= 0) return false;
        ptr += res;
        len -= static_cast<size_t>(res);
    }
    return true;
}

static bool recv_all_bytes(SOCKET s, void* data, size_t len) {
    char* ptr = reinterpret_cast<char*>(data);
    while (len > 0) {
        int res = recv(s, ptr, static_cast<int>(len), 0);
        if (res <= 0) return false;
        ptr += res;
        len -= static_cast<size_t>(res);
    }
    return true;
}

static void test_write_be32(uint8_t* p, uint32_t val) {
    p[0] = static_cast<uint8_t>((val >> 24) & 0xFF);
    p[1] = static_cast<uint8_t>((val >> 16) & 0xFF);
    p[2] = static_cast<uint8_t>((val >> 8) & 0xFF);
    p[3] = static_cast<uint8_t>(val & 0xFF);
}

static void test_write_be16(uint8_t* p, uint16_t val) {
    p[0] = static_cast<uint8_t>((val >> 8) & 0xFF);
    p[1] = static_cast<uint8_t>(val & 0xFF);
}

static std::vector<uint8_t> recv_scsi_data_in(SOCKET s, IscsiBhs& out_bhs) {
    bool ok = recv_all_bytes(s, &out_bhs, sizeof(out_bhs));
    assert(ok);
    assert((out_bhs.opcode & 0x3F) == 0x25); // SCSI Data-In
    uint32_t dlen = (static_cast<uint32_t>(out_bhs.data_seg_len[0]) << 16) |
                    (static_cast<uint32_t>(out_bhs.data_seg_len[1]) << 8) |
                    static_cast<uint32_t>(out_bhs.data_seg_len[2]);
    std::vector<uint8_t> data(dlen, 0);
    if (dlen > 0) {
        ok = recv_all_bytes(s, data.data(), dlen);
        assert(ok);
        uint32_t pad = (4 - (dlen % 4)) % 4;
        if (pad > 0) {
            uint8_t pad_buf[4];
            ok = recv_all_bytes(s, pad_buf, pad);
            assert(ok);
        }
    }
    return data;
}

static IscsiBhs recv_scsi_response(SOCKET s) {
    IscsiBhs resp{};
    bool ok = recv_all_bytes(s, &resp, sizeof(resp));
    assert(ok);
    assert((resp.opcode & 0x3F) == 0x21); // SCSI Response
    return resp;
}

static void perform_test_login(SOCKET s, const std::string& initiator_name, uint32_t task_tag = 0x1000) {
    std::string text;
    text += "InitiatorName=" + initiator_name;
    text.push_back('\0');
    text += "SessionType=Normal";
    text.push_back('\0');
    text += "AuthMethod=None";
    text.push_back('\0');

    IscsiBhs bhs{};
    bhs.opcode = 0x03;
    bhs.flags = 0x87;
    bhs.initiator_task_tag = task_tag;
    uint32_t d_len = static_cast<uint32_t>(text.size());
    bhs.data_seg_len[0] = static_cast<uint8_t>((d_len >> 16) & 0xFF);
    bhs.data_seg_len[1] = static_cast<uint8_t>((d_len >> 8) & 0xFF);
    bhs.data_seg_len[2] = static_cast<uint8_t>(d_len & 0xFF);

    assert(send_all_bytes(s, &bhs, sizeof(bhs)));
    assert(send_all_bytes(s, text.data(), text.size()));
    uint32_t pad = (4 - (text.size() % 4)) % 4;
    if (pad > 0) {
        char pad_buf[4] = {0};
        assert(send_all_bytes(s, pad_buf, pad));
    }

    IscsiBhs resp{};
    assert(recv_all_bytes(s, &resp, sizeof(resp)));
    assert((resp.opcode & 0x3F) == 0x23);

    uint32_t resp_dlen = (static_cast<uint32_t>(resp.data_seg_len[0]) << 16) |
                         (static_cast<uint32_t>(resp.data_seg_len[1]) << 8) |
                         static_cast<uint32_t>(resp.data_seg_len[2]);
    uint32_t resp_padded = (resp_dlen + 3) & ~3;
    if (resp_padded > 0) {
        std::vector<char> discard(resp_padded);
        assert(recv_all_bytes(s, discard.data(), resp_padded));
    }
}

void test_storage_roles_explicit_confirmation_requirement() {
    std::cout << "[RUN] test_storage_roles_explicit_confirmation_requirement\n";
    std::error_code ec;
    std::filesystem::path scratch = "test_scratch_storage_roles";
    std::filesystem::remove_all(scratch, ec);
    std::filesystem::create_directories(scratch, ec);

    std::filesystem::path config_file = scratch / "cobdiskless.json";
    StorageManager sm(config_file);

    // Invariant 1: Fresh StorageManager MUST NOT auto-assign paths
    assert(sm.get_role_path(StorageRole::OsImages).empty());
    assert(sm.get_role_path(StorageRole::Writeback).empty());
    assert(sm.get_role_path(StorageRole::Games).empty());
    assert(sm.get_role_path(StorageRole::Cache).empty());

    // Invariant 2: Suggested defaults must be non-empty paths for UI/CLI presentation
    auto def_os = StorageManager::get_suggested_default(StorageRole::OsImages);
    auto def_wb = StorageManager::get_suggested_default(StorageRole::Writeback);
    auto def_game = StorageManager::get_suggested_default(StorageRole::Games);
    auto def_cache = StorageManager::get_suggested_default(StorageRole::Cache);
    assert(!def_os.empty());
    assert(!def_wb.empty());
    assert(!def_game.empty());
    assert(!def_cache.empty());

    // Invariant 3: Explicit assignment and validation
    std::filesystem::path os_dir = scratch / "os_images";
    std::filesystem::create_directories(os_dir, ec);

    // Assigning to non-existent directory fails validation
    std::filesystem::path non_existent = scratch / "does_not_exist";
    assert(StorageManager::validate_storage_path(non_existent, false).is_err());

    // Assigning to valid created directory succeeds validation
    assert(sm.assign_role(StorageRole::OsImages, os_dir).is_ok());
    assert(StorageManager::validate_storage_path(sm.get_role_path(StorageRole::OsImages)).is_ok());

    // Persist and reload: only explicitly assigned roles are persisted
    assert(sm.save_to_file().is_ok());

    StorageManager sm2(config_file);
    assert(sm2.load_from_file().is_ok());
    assert(sm2.get_role_path(StorageRole::OsImages) == os_dir);
    assert(sm2.get_role_path(StorageRole::Writeback).empty());

    std::filesystem::remove_all(scratch, ec);
    std::cout << "  PASS: test_storage_roles_explicit_confirmation_requirement\n";
}

void test_iscsi_rfc3720_login_and_data_segment_drainage() {
    std::cout << "[RUN] test_iscsi_rfc3720_login_and_data_segment_drainage\n";
#if defined(_WIN32)
    WSADATA wsa;
    assert(WSAStartup(MAKEWORD(2, 2), &wsa) == 0);
#endif
    std::error_code ec;
    std::filesystem::path test_dir = "test_scratch_iscsi_login";
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);

    std::filesystem::path os_path = test_dir / "golden.raw";
    {
        std::ofstream ofs(os_path, std::ios::binary);
        std::vector<uint8_t> dummy(64 * 1024, 0x11);
        ofs.write(reinterpret_cast<const char*>(dummy.data()), dummy.size());
    }

    auto registry = std::make_shared<GoldenImageRegistry>();
    auto img_mgr = std::make_shared<ImageManager>(registry);
    Configuration cfg;
    cfg.set_os_images_dir(test_dir);
    cfg.set_writeback_dir(test_dir);
    img_mgr->configure(cfg);
    assert(img_mgr->import_image(os_path, ImageRole::OsImage, ImageId("os_image")).is_ok());

    auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, test_dir);

    uint16_t port = 13261;
    IscsiTargetConfig tcfg;
    tcfg.listen_address = NetworkAddress(127, 0, 0, 1, port);
    tcfg.default_os_image_id = ImageId("os_image");
    tcfg.target_iqn = "iqn.2026-09.com.cobdiskless:storage";
    IscsiTarget target(tcfg, sess_mgr);
    assert(target.initialize().is_ok());
    std::this_thread::sleep_for(std::chrono::milliseconds(50));

    SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    assert(s != INVALID_SOCKET);
    DWORD tv = 3000;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv), sizeof(tv));

    sockaddr_in srv{};
    srv.sin_family = AF_INET;
    srv.sin_port = htons(port);
    srv.sin_addr.s_addr = inet_addr("127.0.0.1");
    assert(connect(s, reinterpret_cast<const sockaddr*>(&srv), sizeof(srv)) == 0);

    // RFC 3720 Login Request with text data segment
    std::string text_params;
    text_params += "InitiatorName=iqn.1991-05.com.microsoft:client-pc01";
    text_params.push_back('\0');
    text_params += "SessionType=Normal";
    text_params.push_back('\0');
    text_params += "AuthMethod=None";
    text_params.push_back('\0');
    text_params += "HeaderDigest=None";
    text_params.push_back('\0');
    text_params += "DataDigest=None";
    text_params.push_back('\0');
    text_params += "MaxRecvDataSegmentLength=65536";
    text_params.push_back('\0');

    IscsiBhs login_bhs{};
    login_bhs.opcode = 0x03; // Login Request
    login_bhs.flags = 0x87;  // Transit=1, CSG=0, NSG=3
    login_bhs.initiator_task_tag = 0x778899AA;
    uint32_t d_len = static_cast<uint32_t>(text_params.size());
    login_bhs.data_seg_len[0] = static_cast<uint8_t>((d_len >> 16) & 0xFF);
    login_bhs.data_seg_len[1] = static_cast<uint8_t>((d_len >> 8) & 0xFF);
    login_bhs.data_seg_len[2] = static_cast<uint8_t>(d_len & 0xFF);

    assert(send_all_bytes(s, &login_bhs, sizeof(login_bhs)));
    assert(send_all_bytes(s, text_params.data(), text_params.size()));
    uint32_t pad = (4 - (text_params.size() % 4)) % 4;
    if (pad > 0) {
        char pad_buf[4] = {0};
        assert(send_all_bytes(s, pad_buf, pad));
    }

    IscsiBhs resp_bhs{};
    assert(recv_all_bytes(s, &resp_bhs, sizeof(resp_bhs)));
    assert((resp_bhs.opcode & 0x3F) == 0x23); // Login Response
    assert(resp_bhs.initiator_task_tag == 0x778899AA);
    assert(resp_bhs.cdb[0] == 0); // Status-Class: Success

    uint32_t resp_dlen = (static_cast<uint32_t>(resp_bhs.data_seg_len[0]) << 16) |
                         (static_cast<uint32_t>(resp_bhs.data_seg_len[1]) << 8) |
                         static_cast<uint32_t>(resp_bhs.data_seg_len[2]);
    assert(resp_dlen > 0);
    uint32_t resp_padded = (resp_dlen + 3) & ~3;
    std::vector<char> resp_payload(resp_padded, 0);
    assert(recv_all_bytes(s, resp_payload.data(), resp_padded));

    std::string resp_text(resp_payload.data(), resp_dlen);
    assert(resp_text.find("TargetName=") != std::string::npos);
    assert(resp_text.find("AuthMethod=None") != std::string::npos);
    assert(resp_text.find("InitialR2T=Yes") != std::string::npos);

    IscsiBhs logout_req{};
    logout_req.opcode = 0x06;
    logout_req.flags = 0x80;
    logout_req.initiator_task_tag = 0x112233;
    assert(send_all_bytes(s, &logout_req, sizeof(logout_req)));

    IscsiBhs logout_resp{};
    assert(recv_all_bytes(s, &logout_resp, sizeof(logout_resp)));
    assert((logout_resp.opcode & 0x3F) == 0x26);

    closesocket(s);
    target.shutdown();
    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_iscsi_rfc3720_login_and_data_segment_drainage\n";
}

void test_iscsi_windows_boot_scsi_command_suite() {
    std::cout << "[RUN] test_iscsi_windows_boot_scsi_command_suite\n";
#if defined(_WIN32)
    WSADATA wsa;
    assert(WSAStartup(MAKEWORD(2, 2), &wsa) == 0);
#endif
    std::error_code ec;
    std::filesystem::path test_dir = "test_scratch_win_boot_scsi";
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);

    std::filesystem::path os_path = test_dir / "golden_win.raw";
    {
        std::ofstream ofs(os_path, std::ios::binary);
        std::vector<uint8_t> dummy(64 * 1024, 0x00);
        ofs.write(reinterpret_cast<const char*>(dummy.data()), dummy.size());
    }

    auto registry = std::make_shared<GoldenImageRegistry>();
    auto img_mgr = std::make_shared<ImageManager>(registry);
    Configuration cfg;
    cfg.set_os_images_dir(test_dir);
    cfg.set_writeback_dir(test_dir);
    img_mgr->configure(cfg);
    assert(img_mgr->import_image(os_path, ImageRole::OsImage, ImageId("win_os")).is_ok());

    auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, test_dir);

    uint16_t port = 13262;
    IscsiTargetConfig tcfg;
    tcfg.listen_address = NetworkAddress(127, 0, 0, 1, port);
    tcfg.default_os_image_id = ImageId("win_os");
    IscsiTarget target(tcfg, sess_mgr);
    assert(target.initialize().is_ok());
    std::this_thread::sleep_for(std::chrono::milliseconds(50));

    SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    assert(s != INVALID_SOCKET);
    DWORD tv = 3000;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv), sizeof(tv));

    sockaddr_in srv{};
    srv.sin_family = AF_INET;
    srv.sin_port = htons(port);
    srv.sin_addr.s_addr = inet_addr("127.0.0.1");
    assert(connect(s, reinterpret_cast<const sockaddr*>(&srv), sizeof(srv)) == 0);

    perform_test_login(s, "iqn.1991-05.com.microsoft:win-boot-client", 0x2001);

    // 1. Standard INQUIRY
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40; // Read
        cmd.initiator_task_tag = 0x3001;
        cmd.cdb[0] = 0x12; // INQUIRY
        cmd.cdb[4] = 36;
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() == 36);
        assert(data[0] == 0x00); // Direct-access block device
        assert(std::string(reinterpret_cast<const char*>(data.data() + 8), 8) == "COB     ");
        assert(std::string(reinterpret_cast<const char*>(data.data() + 16), 16) == "CobDiskless SAN ");
    }

    // 2. INQUIRY VPD Page 0x00 (Supported VPD Pages)
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x3002;
        cmd.cdb[0] = 0x12;
        cmd.cdb[1] = 0x01; // EVPD
        cmd.cdb[2] = 0x00; // Supported Pages
        cmd.cdb[4] = 64;
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() >= 4);
        assert(data[1] == 0x00);
        bool has_80 = false, has_83 = false;
        for (size_t i = 4; i < data.size(); ++i) {
            if (data[i] == 0x80) has_80 = true;
            if (data[i] == 0x83) has_83 = true;
        }
        assert(has_80 && has_83);
    }

    // 3. INQUIRY VPD Page 0x80 (Unit Serial Number)
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x3003;
        cmd.cdb[0] = 0x12;
        cmd.cdb[1] = 0x01;
        cmd.cdb[2] = 0x80;
        cmd.cdb[4] = 64;
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() >= 4);
        assert(data[1] == 0x80);
        std::string sn(reinterpret_cast<const char*>(data.data() + 4), data[3]);
        assert(sn.rfind("COB-SAN-", 0) == 0);
    }

    // 4. INQUIRY VPD Page 0x83 (Device Identification for Windows disk.sys)
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x3004;
        cmd.cdb[0] = 0x12;
        cmd.cdb[1] = 0x01;
        cmd.cdb[2] = 0x83;
        cmd.cdb[4] = 64;
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() >= 4);
        assert(data[1] == 0x83);
        assert(data.size() >= 44);
    }

    // 5. REPORT LUNS (Opcode 0xA0)
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x3005;
        cmd.cdb[0] = 0xA0; // REPORT LUNS
        test_write_be32(cmd.cdb + 6, 64);
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() >= 16);
        uint32_t list_len = (static_cast<uint32_t>(data[0]) << 24) |
                            (static_cast<uint32_t>(data[1]) << 16) |
                            (static_cast<uint32_t>(data[2]) << 8)  |
                            static_cast<uint32_t>(data[3]);
        assert(list_len >= 8); // At least LUN 0
    }

    // 6. READ CAPACITY (10)
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x3006;
        cmd.cdb[0] = 0x25; // READ CAPACITY (10)
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() == 8);
        uint32_t blk_size = (static_cast<uint32_t>(data[4]) << 24) |
                            (static_cast<uint32_t>(data[5]) << 16) |
                            (static_cast<uint32_t>(data[6]) << 8)  |
                            static_cast<uint32_t>(data[7]);
        assert(blk_size == 512);
    }

    // 7. SERVICE ACTION IN 16 (READ CAPACITY 16)
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x3007;
        cmd.cdb[0] = 0x9E; // SERVICE ACTION IN 16
        cmd.cdb[1] = 0x10; // READ CAPACITY (16)
        test_write_be32(cmd.cdb + 10, 32);
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() == 32);
        uint32_t blk_size = (static_cast<uint32_t>(data[8]) << 24) |
                            (static_cast<uint32_t>(data[9]) << 16) |
                            (static_cast<uint32_t>(data[10]) << 8) |
                            static_cast<uint32_t>(data[11]);
        assert(blk_size == 512);
    }

    // 8. MODE SENSE (6) and (10)
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x3008;
        cmd.cdb[0] = 0x1A; // MODE SENSE (6)
        cmd.cdb[2] = 0x08; // Caching page
        cmd.cdb[4] = 64;
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() >= 12);

        // MODE SENSE (10)
        IscsiBhs cmd10{};
        cmd10.opcode = 0x01;
        cmd10.flags = 0x40;
        cmd10.initiator_task_tag = 0x3009;
        cmd10.cdb[0] = 0x5A; // MODE SENSE (10)
        cmd10.cdb[2] = 0x08;
        test_write_be16(cmd10.cdb + 7, 64);
        assert(send_all_bytes(s, &cmd10, sizeof(cmd10)));

        IscsiBhs in_bhs10{};
        auto data10 = recv_scsi_data_in(s, in_bhs10);
        assert(data10.size() >= 16);
    }

    // 9. TEST UNIT READY
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.initiator_task_tag = 0x300A;
        cmd.cdb[0] = 0x00; // TEST UNIT READY
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        auto resp = recv_scsi_response(s);
        assert(resp.initiator_task_tag == 0x300A);
        assert(resp.cdb[0] == 0x00); // SCSI Status: Good
    }

    closesocket(s);
    target.shutdown();
    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_iscsi_windows_boot_scsi_command_suite\n";
}

void test_iscsi_write10_and_sync_cache_persistence() {
    std::cout << "[RUN] test_iscsi_write10_and_sync_cache_persistence\n";
#if defined(_WIN32)
    WSADATA wsa;
    assert(WSAStartup(MAKEWORD(2, 2), &wsa) == 0);
#endif
    std::error_code ec;
    std::filesystem::path test_dir = "test_scratch_iscsi_write";
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);

    std::filesystem::path os_path = test_dir / "golden_base.raw";
    {
        std::ofstream ofs(os_path, std::ios::binary);
        std::vector<uint8_t> base_data(64 * 1024, 0x33);
        ofs.write(reinterpret_cast<const char*>(base_data.data()), base_data.size());
    }

    auto registry = std::make_shared<GoldenImageRegistry>();
    auto img_mgr = std::make_shared<ImageManager>(registry);
    Configuration cfg;
    cfg.set_os_images_dir(test_dir);
    cfg.set_writeback_dir(test_dir);
    img_mgr->configure(cfg);
    assert(img_mgr->import_image(os_path, ImageRole::OsImage, ImageId("os_base")).is_ok());

    auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, test_dir);

    uint16_t port = 13263;
    IscsiTargetConfig tcfg;
    tcfg.listen_address = NetworkAddress(127, 0, 0, 1, port);
    tcfg.default_os_image_id = ImageId("os_base");
    IscsiTarget target(tcfg, sess_mgr);
    assert(target.initialize().is_ok());
    std::this_thread::sleep_for(std::chrono::milliseconds(50));

    SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    assert(s != INVALID_SOCKET);
    DWORD tv = 3000;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv), sizeof(tv));

    sockaddr_in srv{};
    srv.sin_family = AF_INET;
    srv.sin_port = htons(port);
    srv.sin_addr.s_addr = inet_addr("127.0.0.1");
    assert(connect(s, reinterpret_cast<const sockaddr*>(&srv), sizeof(srv)) == 0);

    perform_test_login(s, "iqn.1991-05.com.microsoft:write-client", 0x4001);

    // 1. Send WRITE 10 with 2 sectors (1024 bytes) of distinct pattern 0x77
    {
        uint32_t write_len = 1024;
        std::vector<uint8_t> write_data(write_len, 0x77);

        IscsiBhs cmd{};
        cmd.opcode = 0x01; // SCSI Command
        cmd.flags = 0x20 | 0x80; // Write bit | Final
        cmd.initiator_task_tag = 0x4002;
        cmd.data_seg_len[0] = static_cast<uint8_t>((write_len >> 16) & 0xFF);
        cmd.data_seg_len[1] = static_cast<uint8_t>((write_len >> 8) & 0xFF);
        cmd.data_seg_len[2] = static_cast<uint8_t>(write_len & 0xFF);

        cmd.cdb[0] = 0x2A; // WRITE 10
        test_write_be32(cmd.cdb + 2, 20); // LBA = 20
        test_write_be16(cmd.cdb + 7, 2);  // Sectors = 2

        assert(send_all_bytes(s, &cmd, sizeof(cmd)));
        assert(send_all_bytes(s, write_data.data(), write_data.size()));

        auto resp = recv_scsi_response(s);
        assert(resp.initiator_task_tag == 0x4002);
        assert(resp.cdb[0] == 0x00); // SCSI Status Good
    }

    // 2. Send SYNCHRONIZE CACHE 10
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.initiator_task_tag = 0x4003;
        cmd.cdb[0] = 0x35; // SYNCHRONIZE CACHE 10
        test_write_be32(cmd.cdb + 2, 20);
        test_write_be16(cmd.cdb + 7, 2);

        assert(send_all_bytes(s, &cmd, sizeof(cmd)));
        auto resp = recv_scsi_response(s);
        assert(resp.initiator_task_tag == 0x4003);
        assert(resp.cdb[0] == 0x00);
    }

    // 3. Send READ 10 for the written sectors (LBA 20, 2 sectors) -> must return 0x77
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40; // Read
        cmd.initiator_task_tag = 0x4004;
        cmd.cdb[0] = 0x28; // READ 10
        test_write_be32(cmd.cdb + 2, 20);
        test_write_be16(cmd.cdb + 7, 2);

        assert(send_all_bytes(s, &cmd, sizeof(cmd)));
        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() == 1024);
        for (size_t i = 0; i < data.size(); ++i) {
            assert(data[i] == 0x77);
        }
    }

    // 4. Send READ 10 for an untouched sector (LBA 0, 1 sector) -> must return 0x33 from base image
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x4005;
        cmd.cdb[0] = 0x28;
        test_write_be32(cmd.cdb + 2, 0);
        test_write_be16(cmd.cdb + 7, 1);

        assert(send_all_bytes(s, &cmd, sizeof(cmd)));
        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() == 512);
        for (size_t i = 0; i < data.size(); ++i) {
            assert(data[i] == 0x33);
        }
    }

    // 5. Send WRITE 10 WITHOUT immediate data -> verify R2T flow (Opcode 0x31) and Data-Out (Opcode 0x05)
    {
        uint32_t write_len = 512;
        std::vector<uint8_t> r2t_data(write_len, 0x88);

        IscsiBhs cmd{};
        cmd.opcode = 0x01; // SCSI Command
        cmd.flags = 0x20 | 0x80; // Write bit | Final
        cmd.initiator_task_tag = 0x4006;
        // No immediate data (data_seg_len == 0)
        cmd.data_seg_len[0] = 0;
        cmd.data_seg_len[1] = 0;
        cmd.data_seg_len[2] = 0;

        cmd.cdb[0] = 0x2A; // WRITE 10
        test_write_be32(cmd.cdb + 2, 30); // LBA = 30
        test_write_be16(cmd.cdb + 7, 1);  // Sectors = 1

        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        // Expect R2T PDU (Opcode 0x31)
        IscsiBhs r2t{};
        assert(recv_all_bytes(s, &r2t, sizeof(r2t)));
        assert((r2t.opcode & 0x3F) == 0x31); // R2T
        assert(r2t.initiator_task_tag == 0x4006);

        // Send SCSI Data-Out PDU (Opcode 0x05) in response to R2T
        IscsiBhs dout{};
        dout.opcode = 0x05; // SCSI Data-Out
        dout.flags = 0x80;  // Final
        dout.initiator_task_tag = 0x4006;
        dout.data_transfer_tag = r2t.data_transfer_tag;
        dout.data_seg_len[0] = static_cast<uint8_t>((write_len >> 16) & 0xFF);
        dout.data_seg_len[1] = static_cast<uint8_t>((write_len >> 8) & 0xFF);
        dout.data_seg_len[2] = static_cast<uint8_t>(write_len & 0xFF);

        assert(send_all_bytes(s, &dout, sizeof(dout)));
        assert(send_all_bytes(s, r2t_data.data(), r2t_data.size()));

        // Receive SCSI Response
        auto resp = recv_scsi_response(s);
        assert(resp.initiator_task_tag == 0x4006);
        assert(resp.cdb[0] == 0x00); // SCSI Status Good

        // Read back LBA 30 to confirm data written to COW overlay
        IscsiBhs read_cmd{};
        read_cmd.opcode = 0x01;
        read_cmd.flags = 0x40;
        read_cmd.initiator_task_tag = 0x4007;
        read_cmd.cdb[0] = 0x28; // READ 10
        test_write_be32(read_cmd.cdb + 2, 30);
        test_write_be16(read_cmd.cdb + 7, 1);

        assert(send_all_bytes(s, &read_cmd, sizeof(read_cmd)));
        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() == 512);
        for (size_t i = 0; i < data.size(); ++i) {
            assert(data[i] == 0x88);
        }
    }

    // 6. Test RFC 3720 NOP-Out (Ping, Opcode 0x00) -> Target must respond with NOP-In (Opcode 0x20)
    {
        IscsiBhs nop{};
        nop.opcode = 0x00; // NOP-Out
        nop.flags = 0x80;
        nop.initiator_task_tag = 0x4008;

        assert(send_all_bytes(s, &nop, sizeof(nop)));
        IscsiBhs nopin{};
        assert(recv_all_bytes(s, &nopin, sizeof(nopin)));
        assert((nopin.opcode & 0x3F) == 0x20); // NOP-In
        assert(nopin.initiator_task_tag == 0x4008);
    }

    closesocket(s);
    target.shutdown();
    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_iscsi_write10_and_sync_cache_persistence\n";
}

void test_iscsi_multi_lun_os_and_game_dispatch() {
    std::cout << "[RUN] test_iscsi_multi_lun_os_and_game_dispatch\n";
#if defined(_WIN32)
    WSADATA wsa;
    assert(WSAStartup(MAKEWORD(2, 2), &wsa) == 0);
#endif
    std::error_code ec;
    std::filesystem::path test_dir = "test_scratch_multi_lun";
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);

    std::filesystem::path os_path = test_dir / "os.raw";
    {
        std::ofstream ofs(os_path, std::ios::binary);
        std::vector<uint8_t> os_data(64 * 1024, 0x11);
        ofs.write(reinterpret_cast<const char*>(os_data.data()), os_data.size());
    }

    std::filesystem::path game_path = test_dir / "game.raw";
    {
        std::ofstream ofs(game_path, std::ios::binary);
        std::vector<uint8_t> game_data(64 * 1024, 0x47); // 'G'
        ofs.write(reinterpret_cast<const char*>(game_data.data()), game_data.size());
    }

    auto registry = std::make_shared<GoldenImageRegistry>();
    auto img_mgr = std::make_shared<ImageManager>(registry);
    Configuration cfg;
    cfg.set_os_images_dir(test_dir);
    cfg.set_writeback_dir(test_dir);
    img_mgr->configure(cfg);
    assert(img_mgr->import_image(os_path, ImageRole::OsImage, ImageId("os_image")).is_ok());
    assert(img_mgr->import_image(game_path, ImageRole::GameDisk, ImageId("game_image")).is_ok());

    auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, test_dir);

    uint16_t port = 13264;
    IscsiTargetConfig tcfg;
    tcfg.listen_address = NetworkAddress(127, 0, 0, 1, port);
    tcfg.default_os_image_id = ImageId("os_image");
    IscsiTarget target(tcfg, sess_mgr);
    assert(target.initialize().is_ok());
    std::this_thread::sleep_for(std::chrono::milliseconds(50));

    SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    assert(s != INVALID_SOCKET);
    DWORD tv = 3000;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv), sizeof(tv));

    sockaddr_in srv{};
    srv.sin_family = AF_INET;
    srv.sin_port = htons(port);
    srv.sin_addr.s_addr = inet_addr("127.0.0.1");
    assert(connect(s, reinterpret_cast<const sockaddr*>(&srv), sizeof(srv)) == 0);

    perform_test_login(s, "iqn.1991-05.com.microsoft:multi-lun-client", 0x5001);

    // 1. REPORT LUNS -> Should report at least LUN 0 and LUN 1
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x5002;
        cmd.cdb[0] = 0xA0; // REPORT LUNS
        test_write_be32(cmd.cdb + 6, 64);
        assert(send_all_bytes(s, &cmd, sizeof(cmd)));

        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() >= 24); // 8-byte header + 2 * 8-byte LUN descriptors
        uint32_t list_len = (static_cast<uint32_t>(data[0]) << 24) |
                            (static_cast<uint32_t>(data[1]) << 16) |
                            (static_cast<uint32_t>(data[2]) << 8)  |
                            static_cast<uint32_t>(data[3]);
        assert(list_len >= 16);
    }

    // 2. READ 10 from LUN 1 -> Should return 0x47 ('G')
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x5003;
        reinterpret_cast<uint8_t*>(&cmd.lun)[1] = 1; // LUN 1 in network byte order
        cmd.cdb[0] = 0x28; // READ 10
        test_write_be32(cmd.cdb + 2, 0);
        test_write_be16(cmd.cdb + 7, 1);

        assert(send_all_bytes(s, &cmd, sizeof(cmd)));
        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() == 512);
        for (size_t i = 0; i < data.size(); ++i) {
            assert(data[i] == 0x47);
        }
    }

    // 3. WRITE 10 to LUN 1 -> Must be rejected with Check Condition (Write Protected)
    {
        uint32_t write_len = 512;
        std::vector<uint8_t> write_data(write_len, 0xFF);

        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x20 | 0x80;
        cmd.initiator_task_tag = 0x5004;
        reinterpret_cast<uint8_t*>(&cmd.lun)[1] = 1; // LUN 1
        cmd.data_seg_len[0] = static_cast<uint8_t>((write_len >> 16) & 0xFF);
        cmd.data_seg_len[1] = static_cast<uint8_t>((write_len >> 8) & 0xFF);
        cmd.data_seg_len[2] = static_cast<uint8_t>(write_len & 0xFF);
        cmd.cdb[0] = 0x2A; // WRITE 10
        test_write_be32(cmd.cdb + 2, 0);
        test_write_be16(cmd.cdb + 7, 1);

        assert(send_all_bytes(s, &cmd, sizeof(cmd)));
        assert(send_all_bytes(s, write_data.data(), write_data.size()));

        auto resp = recv_scsi_response(s);
        assert(resp.initiator_task_tag == 0x5004);
        assert(resp.rsvd1[1] == 0x02 || resp.cdb[0] == 0x02); // Check Condition (Data Protect)
    }

    // 4. READ 10 from LUN 1 again -> Data must be intact (still 0x47)
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x5005;
        reinterpret_cast<uint8_t*>(&cmd.lun)[1] = 1;
        cmd.cdb[0] = 0x28;
        test_write_be32(cmd.cdb + 2, 0);
        test_write_be16(cmd.cdb + 7, 1);

        assert(send_all_bytes(s, &cmd, sizeof(cmd)));
        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() == 512);
        for (size_t i = 0; i < data.size(); ++i) {
            assert(data[i] == 0x47);
        }
    }

    // 5. READ 10 from LUN 0 -> Should return 0x11 (OS image) and confirms socket stream is synced
    {
        IscsiBhs cmd{};
        cmd.opcode = 0x01;
        cmd.flags = 0x40;
        cmd.initiator_task_tag = 0x5006;
        cmd.lun = 0; // LUN 0
        cmd.cdb[0] = 0x28;
        test_write_be32(cmd.cdb + 2, 0);
        test_write_be16(cmd.cdb + 7, 1);

        assert(send_all_bytes(s, &cmd, sizeof(cmd)));
        IscsiBhs in_bhs{};
        auto data = recv_scsi_data_in(s, in_bhs);
        assert(data.size() == 512);
        for (size_t i = 0; i < data.size(); ++i) {
            assert(data[i] == 0x11);
        }
    }

    closesocket(s);
    target.shutdown();
    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_iscsi_multi_lun_os_and_game_dispatch\n";
}

void test_real_hardware_recovery_dhcp_tftp_cache() {
    std::cout << "[RUN] test_real_hardware_recovery_dhcp_tftp_cache\n";

    // 1. DHCP Option 60 ("PXEClient"), Broadcast Flag 0x8000, and Boot Server Info
    {
        DhcpServer server(NetworkAddress(192, 168, 1, 100));

        DhcpHeader pxe_req_hdr{};
        pxe_req_hdr.op = 1;
        pxe_req_hdr.htype = 1;
        pxe_req_hdr.hlen = 6;
        pxe_req_hdr.xid = 0x55AA1122;
        pxe_req_hdr.magic_cookie[0] = 99; pxe_req_hdr.magic_cookie[1] = 130;
        pxe_req_hdr.magic_cookie[2] = 83; pxe_req_hdr.magic_cookie[3] = 99;
        pxe_req_hdr.chaddr[0] = 0x52; pxe_req_hdr.chaddr[1] = 0x54; pxe_req_hdr.chaddr[2] = 0x00;
        pxe_req_hdr.chaddr[3] = 0x12; pxe_req_hdr.chaddr[4] = 0x34; pxe_req_hdr.chaddr[5] = 0x56;

        std::vector<uint8_t> pxe_discover(reinterpret_cast<const uint8_t*>(&pxe_req_hdr),
                                          reinterpret_cast<const uint8_t*>(&pxe_req_hdr) + sizeof(DhcpHeader));

        // Option 53: Discover
        pxe_discover.push_back(53); pxe_discover.push_back(1); pxe_discover.push_back(1);
        // Option 60: "PXEClient:Arch:00000:UNDI:002001"
        std::string pxe_vendor = "PXEClient:Arch:00000:UNDI:002001";
        pxe_discover.push_back(60); pxe_discover.push_back(static_cast<uint8_t>(pxe_vendor.size()));
        pxe_discover.insert(pxe_discover.end(), pxe_vendor.begin(), pxe_vendor.end());
        // Option 93: 0 (BIOS x86)
        pxe_discover.push_back(93); pxe_discover.push_back(2); pxe_discover.push_back(0); pxe_discover.push_back(0);
        pxe_discover.push_back(255); // End

        auto parsed = DhcpServer::parse_packet(pxe_discover);
        assert(parsed.is_ok());
        assert(parsed.value().is_pxe_client);
        assert(parsed.value().vendor_class.find("PXEClient") != std::string::npos);

        auto offer_res = server.build_reply(pxe_req_hdr, parsed.value(), 2, NetworkAddress(192, 168, 1, 150));
        assert(offer_res.is_ok());
        const auto& offer = offer_res.value();
        assert(offer.size() > sizeof(DhcpHeader));

        const auto* reply_hdr = reinterpret_cast<const DhcpHeader*>(offer.data());
        // Verify broadcast flag is set (crucial for physical PXE ROMs)
        assert((ntohs(reply_hdr->flags) & 0x8000) != 0);
        // Verify next-server (siaddr) is set to server IP (192.168.1.100)
        assert(reply_hdr->siaddr != 0);
        // Verify your-IP (yiaddr) is set to 192.168.1.150
        uint8_t yiaddr_octets[4];
        std::memcpy(yiaddr_octets, &reply_hdr->yiaddr, 4);
        assert(yiaddr_octets[0] == 192 && yiaddr_octets[1] == 168 && yiaddr_octets[2] == 1 && yiaddr_octets[3] == 150);

        // Verify Magic Cookie at offset 236..239 (0x63825363 = 99, 130, 83, 99)
        assert(reply_hdr->magic_cookie[0] == 99);
        assert(reply_hdr->magic_cookie[1] == 130);
        assert(reply_hdr->magic_cookie[2] == 83);
        assert(reply_hdr->magic_cookie[3] == 99);

        // Verify options payload contains:
        // Option 53 (Message Type = 2 / Offer)
        // Option 54 (Server Identifier = server_ip_)
        // Option 1 (Subnet Mask = 255.255.255.0)
        // Option 60 (Vendor Class Identifier = "PXEClient")
        // Option 43 (PXE Discovery Control = 8)
        // Option 66 (TFTP Server)
        // Option 67 (Bootfile Name)
        bool found_opt53 = false;
        bool found_opt54 = false;
        bool found_opt1 = false;
        bool found_opt43 = false;
        bool found_opt60 = false;
        bool found_opt66 = false;
        bool found_opt67 = false;
        bool found_opt17 = false; // Root-Path: must NEVER be sent (double-attach -> 0x03232019)
        size_t opt_idx = sizeof(DhcpHeader);
        while (opt_idx < offer.size()) {
            uint8_t code = offer[opt_idx++];
            if (code == 255) break;
            if (code == 0) continue;
            if (opt_idx >= offer.size()) break;
            uint8_t len = offer[opt_idx++];
            if (opt_idx + len > offer.size()) break;

            if (code == 53 && len == 1) {
                assert(offer[opt_idx] == 2); // Offer
                found_opt53 = true;
            } else if (code == 54 && len == 4) {
                assert(offer[opt_idx] == 192 && offer[opt_idx + 1] == 168 && offer[opt_idx + 2] == 1 && offer[opt_idx + 3] == 100);
                found_opt54 = true;
            } else if (code == 1 && len == 4) {
                assert(offer[opt_idx] == 255 && offer[opt_idx + 1] == 255 && offer[opt_idx + 2] == 255 && offer[opt_idx + 3] == 0);
                found_opt1 = true;
            } else if (code == 43) {
                // Verify Sub-option 6 (PXE Discovery Control) = 8
                if (len >= 3 && offer[opt_idx] == 6 && offer[opt_idx + 1] == 1 && offer[opt_idx + 2] == 8) {
                    found_opt43 = true;
                }
            } else if (code == 60) {
                std::string v(reinterpret_cast<const char*>(offer.data() + opt_idx), len);
                if (v == "PXEClient") {
                    found_opt60 = true;
                }
            } else if (code == 66) {
                found_opt66 = true;
            } else if (code == 67) {
                found_opt67 = true;
            } else if (code == 17) {
                // Option 17 (Root-Path) would make iPXE auto-attach the SAN during
                // 'dhcp', causing a second attach in boot.ipxe -> EADDRINUSE
                // "could not open san device error 0x03232019" on drive 0x80.
                found_opt17 = true;
            }
            opt_idx += len;
        }
        assert(found_opt53);
        assert(found_opt54);
        assert(found_opt1);
        assert(found_opt43);
        assert(found_opt60);
        assert(found_opt66);
        assert(found_opt67);
        assert(!found_opt17);
        // Verify minimum BOOTP size padding (>= 300 bytes)
        assert(offer.size() >= 300);
    }

    // 2. Real TFTP Bootloader Payloads and Multi-Block Delivery
    {
        TftpServer tftp_srv(NetworkAddress(192, 168, 1, 100), "tftp_boot");

        auto ipxe_efi = tftp_srv.get_file_content("ipxe.efi");
        assert(ipxe_efi.is_ok());
        // Verify real binary size (must be > 500 KB, not a 13-byte stub)
        assert(ipxe_efi.value().size() > 500000);

        auto undi = tftp_srv.get_file_content("undionly.kpxe");
        assert(undi.is_ok());
        assert(undi.value().size() > 50000);

        auto snp = tftp_srv.get_file_content("snponly.efi");
        assert(snp.is_ok());
        assert(snp.value().size() > 100000);

        auto boot_ipxe = tftp_srv.get_file_content("boot.ipxe");
        assert(boot_ipxe.is_ok());
        std::string ipxe_script(reinterpret_cast<const char*>(boot_ipxe.value().data()), boot_ipxe.value().size());
        assert(ipxe_script.find("#!ipxe") != std::string::npos);
        assert(ipxe_script.find("sanboot iscsi:") != std::string::npos);
        assert(ipxe_script.find("set keep-san 1") != std::string::npos);
    }

    // 3. StorageManager Attached Cache Configuration & Persistence
    {
        std::error_code ec;
        std::filesystem::path cfg_path = "test_hardware_recovery_storage_roles.conf";
        std::filesystem::remove(cfg_path, ec);

        StorageManager sm1(cfg_path);
        (void)sm1.scan_drives();

        TargetCacheConfig os_cache{};
        os_cache.ram_cache_enabled = true;
        os_cache.ram_cache_mb = 2048;
        os_cache.ssd_cache_enabled = true;
        os_cache.ssd_cache_path = "D:\\ssd_cache";
        os_cache.ssd_cache_size_gb = 64;
        sm1.set_cache_config(StorageRole::OsImages, os_cache);

        TargetCacheConfig games_cache{};
        games_cache.ram_cache_enabled = true;
        games_cache.ram_cache_mb = 8192;
        games_cache.ssd_cache_enabled = false;
        sm1.set_cache_config(StorageRole::Games, games_cache);

        auto save_res = sm1.save_to_file(cfg_path);
        assert(save_res.is_ok());

        // Load back into separate StorageManager instance
        StorageManager sm2(cfg_path);
        auto load_res = sm2.load_from_file(cfg_path);
        assert(load_res.is_ok());

        auto loaded_os = sm2.get_cache_config(StorageRole::OsImages);
        assert(loaded_os.ram_cache_enabled);
        assert(loaded_os.ram_cache_mb == 2048);
        assert(loaded_os.ssd_cache_enabled);
        assert(loaded_os.ssd_cache_path == "D:\\ssd_cache");
        assert(loaded_os.ssd_cache_size_gb == 64);

        auto loaded_games = sm2.get_cache_config(StorageRole::Games);
        assert(loaded_games.ram_cache_enabled);
        assert(loaded_games.ram_cache_mb == 8192);
        assert(!loaded_games.ssd_cache_enabled);

        std::filesystem::remove(cfg_path, ec);
    }

    // 4. GoldenImage Attached Cache Verification
    {
        std::error_code ec;
        std::filesystem::path img_file = "test_recovery_golden.raw";
        std::filesystem::remove(img_file, ec);

        // Create a 4 MB raw image file with test pattern
        {
            std::ofstream out(img_file, std::ios::binary);
            std::vector<uint8_t> block(4096, 0x77);
            for (size_t i = 0; i < 1024; ++i) {
                out.write(reinterpret_cast<const char*>(block.data()), block.size());
            }
        }

        // Open with 2 MB RAM cache
        auto img_res = GoldenImage::open(img_file, ImageId("rec_img"), 2 * 1024 * 1024);
        assert(img_res.is_ok());
        auto img = img_res.value();
        assert(img->has_cache());
        assert(img->cache_size_bytes() == 2 * 1024 * 1024);

        // Read through cached device
        std::vector<std::byte> read_buf(4096);
        auto read_res = img->device()->read(0, read_buf);
        assert(read_res.is_ok());
        assert(read_res.value() == 4096);
        assert(static_cast<uint8_t>(read_buf[0]) == 0x77);

        std::filesystem::remove(img_file, ec);
    }

    std::cout << "  PASS: test_real_hardware_recovery_dhcp_tftp_cache\n";
}

void test_vhd_vhdx_import_suite() {
    std::cout << "[RUN] test_vhd_vhdx_import_suite\n";

    std::error_code ec;
    std::filesystem::path test_dir = "test_vhd_import_env";
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);

    auto reg = std::make_shared<GoldenImageRegistry>();
    auto img_mgr = std::make_shared<ImageManager>(reg);

    // 1. Fixed VHD Import (Valid MBR/NTFS sector, valid conectix footer)
    {
        std::filesystem::path fixed_vhd = test_dir / "valid_fixed.vhd";
        constexpr uint64_t v_size = 2 * 1024 * 1024; // 2 MiB
        std::vector<uint8_t> disk_data(v_size, 0);

        // MBR at Sector 0
        disk_data[510] = 0x55; disk_data[511] = 0xAA;
        disk_data[0] = 0xEB; // Bootstrap jump
        uint8_t* p1 = disk_data.data() + 446;
        p1[0] = 0x80; // Bootable
        p1[4] = 0x07; // NTFS
        write_le32(p1 + 8, 2048); // Start LBA 2048
        write_le32(p1 + 12, 2048); // 2048 sectors (1 MiB)

        // NTFS VBR at Sector 2048
        std::memcpy(disk_data.data() + (2048 * 512) + 3, "NTFS    ", 8);

        // Windows directory marker at Sector 2050
        std::memcpy(disk_data.data() + (2050 * 512), "\\Windows\\System32\\ntoskrnl.exe", 30);

        // Conectix footer at EOF (512 bytes)
        std::vector<uint8_t> footer(512, 0);
        std::memcpy(footer.data(), "conectix", 8);
        write_be32(footer.data() + 8, 0x00000002);
        write_be32(footer.data() + 12, 0x00010000);
        write_be64(footer.data() + 16, 0xFFFFFFFFFFFFFFFFULL);
        write_be64(footer.data() + 48, v_size);
        write_be32(footer.data() + 60, 2); // Fixed

        uint32_t sum = 0;
        for (size_t i = 0; i < 512; ++i) {
            sum += footer[i];
        }
        write_be32(footer.data() + 64, ~sum);

        {
            std::ofstream out(fixed_vhd, std::ios::binary);
            out.write(reinterpret_cast<const char*>(disk_data.data()), static_cast<std::streamsize>(disk_data.size()));
            out.write(reinterpret_cast<const char*>(footer.data()), static_cast<std::streamsize>(footer.size()));
        }

        auto res = img_mgr->import_image(fixed_vhd, ImageRole::OsImage);
        assert(res.is_ok());
        const auto& info = res.value();
        assert(info.is_valid);
        assert(info.format == ImageFormat::VhdFixed);
        assert(info.partition_scheme == PartitionScheme::Mbr);
        assert(info.boot_mode == BootMode::Bios);
        assert(info.virtual_size_bytes == v_size);

        // Mount on ClientSession and verify LUN 0 block read
        auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, test_dir / "wb");
        auto sess_res = sess_mgr->get_or_create_session(ClientId("PC01"), NetworkAddress(192, 168, 1, 101), info.id);
        assert(sess_res.is_ok());
        auto session = sess_res.value();
        auto lun0_dev = session->get_device_for_lun(0);
        assert(lun0_dev != nullptr);

        std::vector<std::byte> read_mbr(512);
        auto r_res = lun0_dev->read(0, read_mbr);
        assert(r_res.is_ok());
        assert(static_cast<uint8_t>(read_mbr[510]) == 0x55 && static_cast<uint8_t>(read_mbr[511]) == 0xAA);

        (void)img_mgr->release_image(info.id);
    }

    // 2. Dynamic VHD Import (Valid dynamic header + BAT)
    {
        std::filesystem::path dyn_vhd = test_dir / "valid_dynamic.vhd";
        constexpr uint64_t v_size = 2097152; // 2 MiB
        constexpr uint32_t blk_size = 2097152; // 2 MiB block size

        // 1. Footer at start (512 bytes)
        std::vector<uint8_t> footer(512, 0);
        std::memcpy(footer.data(), "conectix", 8);
        write_be32(footer.data() + 8, 0x00000002);
        write_be32(footer.data() + 12, 0x00010000);
        write_be64(footer.data() + 16, 512); // Dynamic header at 512
        write_be64(footer.data() + 48, v_size);
        write_be32(footer.data() + 60, 3); // Dynamic

        uint32_t sum = 0;
        for (size_t i = 0; i < 512; ++i) sum += footer[i];
        write_be32(footer.data() + 64, ~sum);

        // 2. Dynamic header (1024 bytes)
        std::vector<uint8_t> dyn_hdr(1024, 0);
        std::memcpy(dyn_hdr.data(), "cxsparse", 8);
        write_be64(dyn_hdr.data() + 16, 1536); // BAT offset at 1536
        write_be32(dyn_hdr.data() + 28, 1);    // 1 block
        write_be32(dyn_hdr.data() + 32, blk_size);

        // 3. BAT table (padded to 512 bytes)
        std::vector<uint8_t> bat(512, 0xFF); // 0xFFFFFFFF = unallocated block

        {
            std::ofstream out(dyn_vhd, std::ios::binary);
            out.write(reinterpret_cast<const char*>(footer.data()), 512);
            out.write(reinterpret_cast<const char*>(dyn_hdr.data()), 1024);
            out.write(reinterpret_cast<const char*>(bat.data()), 512);
            // Copy of footer at EOF
            out.write(reinterpret_cast<const char*>(footer.data()), 512);
        }

        auto res = img_mgr->import_image(dyn_vhd, ImageRole::OsImage);
        assert(res.is_ok());
        const auto& info = res.value();
        assert(info.is_valid);
        assert(info.format == ImageFormat::VhdDynamic);
        assert(info.virtual_size_bytes == v_size);

        auto acq = img_mgr->acquire_image(info.id);
        assert(acq.is_ok());
        std::vector<std::byte> buf(512);
        auto r_res = acq.value()->device()->read(0, buf);
        assert(r_res.is_ok());
        // Unallocated block returns zeros
        for (auto b : buf) {
            assert(static_cast<uint8_t>(b) == 0);
        }
        (void)img_mgr->release_image(info.id);
    }

    // 3. VHDX Image Import & Validation
    {
        std::filesystem::path vhdx_file = test_dir / "test_import.vhdx";
        {
            std::ofstream out(vhdx_file, std::ios::binary);
            std::vector<uint8_t> header(1024 * 1024, 0);
            std::memcpy(header.data(), "vhdxfile", 8);
            out.write(reinterpret_cast<const char*>(header.data()), static_cast<std::streamsize>(header.size()));
        }

        auto res = img_mgr->import_image(vhdx_file, ImageRole::OsImage);
        // Header without valid region tables returns StorageFailure gracefully
        assert(res.is_err());
        assert(res.error().code() == ErrorCode::StorageFailure);
    }

    // 4. Invalid Image Rejection (random text / non-image format)
    {
        std::filesystem::path txt_file = test_dir / "notes.txt";
        {
            std::ofstream out(txt_file);
            out << "This is plain text and not a disk image.\n";
        }
        auto res = img_mgr->import_image(txt_file, ImageRole::OsImage);
        assert(res.is_err());
        assert(res.error().code() == ErrorCode::StorageFailure);

        std::filesystem::path garbage_vhd = test_dir / "garbage.vhd";
        {
            std::ofstream out(garbage_vhd, std::ios::binary);
            std::vector<uint8_t> garbage(1024, 0xAA);
            out.write(reinterpret_cast<const char*>(garbage.data()), garbage.size());
        }
        auto res2 = img_mgr->import_image(garbage_vhd, ImageRole::OsImage);
        assert(res2.is_err());
        assert(res2.error().code() == ErrorCode::StorageFailure);
    }

    // 5. Corrupted Image Rejection (Broken footer checksum)
    {
        std::filesystem::path corrupt_vhd = test_dir / "corrupted_checksum.vhd";
        constexpr uint64_t v_size = 1048576; // 1 MiB
        std::vector<uint8_t> disk_data(v_size, 0);

        std::vector<uint8_t> footer(512, 0);
        std::memcpy(footer.data(), "conectix", 8);
        write_be32(footer.data() + 8, 0x00000002);
        write_be32(footer.data() + 12, 0x00010000);
        write_be64(footer.data() + 16, 0xFFFFFFFFFFFFFFFFULL);
        write_be64(footer.data() + 48, v_size);
        write_be32(footer.data() + 60, 2); // Fixed

        // Corrupt checksum
        write_be32(footer.data() + 64, 0x12345678);

        {
            std::ofstream out(corrupt_vhd, std::ios::binary);
            out.write(reinterpret_cast<const char*>(disk_data.data()), static_cast<std::streamsize>(disk_data.size()));
            out.write(reinterpret_cast<const char*>(footer.data()), static_cast<std::streamsize>(footer.size()));
        }

        auto res = img_mgr->import_image(corrupt_vhd, ImageRole::OsImage);
        assert(res.is_err());
        assert(res.error().code() == ErrorCode::StorageFailure);
    }

    // 6. Windows Partition Inspection (GPT / UEFI detection from real disk image)
    {
        std::filesystem::path uefi_vhd = test_dir / "win_uefi.vhd";
        constexpr uint64_t v_size = 20 * 1024 * 1024; // 20 MiB
        std::vector<uint8_t> raw(v_size, 0);

        // LBA 0: Protective MBR
        raw[510] = 0x55; raw[511] = 0xAA;
        uint8_t* pmbr_p1 = raw.data() + 446;
        pmbr_p1[4] = 0xEE;
        write_le32(pmbr_p1 + 8, 1);
        write_le32(pmbr_p1 + 12, static_cast<uint32_t>((v_size / 512) - 1));

        // LBA 1: GPT Header
        uint8_t* gpt_hdr = raw.data() + 512;
        std::memcpy(gpt_hdr, "EFI PART", 8);
        write_le32(gpt_hdr + 8, 0x00010000);
        write_le32(gpt_hdr + 12, 92);
        write_le64(gpt_hdr + 24, 1);
        write_le64(gpt_hdr + 32, (v_size / 512) - 1);
        write_le64(gpt_hdr + 40, 34);
        write_le64(gpt_hdr + 48, (v_size / 512) - 34);
        write_le64(gpt_hdr + 72, 2);
        write_le32(gpt_hdr + 80, 128);
        write_le32(gpt_hdr + 84, 128);

        // LBA 2 Entry 0: ESP (EFI System Partition)
        // GUID: C12A7328-F81F-11D2-BA4B-00A0C93EC93B
        uint8_t* e0 = raw.data() + (2 * 512);
        write_le32(e0, 0xC12A7328);
        write_le16(e0 + 4, 0xF81F);
        write_le16(e0 + 6, 0x11D2);
        e0[8] = 0xBA; e0[9] = 0x4B; e0[10] = 0x00; e0[11] = 0xA0;
        e0[12] = 0xC9; e0[13] = 0x3E; e0[14] = 0xC9; e0[15] = 0x3B;
        write_le64(e0 + 32, 2048);
        write_le64(e0 + 40, 4095);

        // Write FAT32 signature & bootmgfw.efi in ESP
        std::memcpy(raw.data() + (2048 * 512) + 82, "FAT32   ", 8);
        std::memcpy(raw.data() + (2050 * 512), "\\EFI\\Microsoft\\Boot\\bootmgfw.efi", 32);

        // LBA 2 Entry 1: Basic Data Partition (Windows NTFS)
        // GUID: EBD0A0A2-B9E5-4433-87C0-68B6B72699C7
        uint8_t* e1 = e0 + 128;
        write_le32(e1, 0xEBD0A0A2);
        write_le16(e1 + 4, 0xB9E5);
        write_le16(e1 + 6, 0x4433);
        e1[8] = 0x87; e1[9] = 0xC0; e1[10] = 0x68; e1[11] = 0xB6;
        e1[12] = 0xB7; e1[13] = 0x26; e1[14] = 0x99; e1[15] = 0xC7;
        write_le64(e1 + 32, 4096);
        write_le64(e1 + 40, 30000);

        // Write NTFS signature & Windows kernel marker
        std::memcpy(raw.data() + (4096 * 512) + 3, "NTFS    ", 8);
        std::memcpy(raw.data() + (4100 * 512), "\\Windows\\System32\\ntoskrnl.exe", 30);

        // Conectix footer at EOF
        std::vector<uint8_t> footer(512, 0);
        std::memcpy(footer.data(), "conectix", 8);
        write_be32(footer.data() + 8, 0x00000002);
        write_be32(footer.data() + 12, 0x00010000);
        write_be64(footer.data() + 16, 0xFFFFFFFFFFFFFFFFULL);
        write_be64(footer.data() + 48, v_size);
        write_be32(footer.data() + 60, 2);

        uint32_t sum = 0;
        for (size_t i = 0; i < 512; ++i) sum += footer[i];
        write_be32(footer.data() + 64, ~sum);

        {
            std::ofstream out(uefi_vhd, std::ios::binary);
            out.write(reinterpret_cast<const char*>(raw.data()), static_cast<std::streamsize>(raw.size()));
            out.write(reinterpret_cast<const char*>(footer.data()), static_cast<std::streamsize>(footer.size()));
        }

        auto res = img_mgr->import_image(uefi_vhd, ImageRole::OsImage);
        assert(res.is_ok());
        const auto& info = res.value();
        assert(info.is_valid);
        assert(info.format == ImageFormat::VhdFixed);
        assert(info.partition_scheme == PartitionScheme::Gpt);
        assert(info.boot_mode == BootMode::Uefi);
        assert(info.virtual_size_bytes == v_size);
    }

    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_vhd_vhdx_import_suite\n";
}

void test_super_client_image_update_pipeline() {
    std::cout << "[RUN] test_super_client_image_update_pipeline\n";
    std::error_code ec;
    std::filesystem::path test_dir = "test_super_client_env";
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);

    // 1. Synthesize a Fixed VHD base image (128 KB)
    std::filesystem::path vhd_file = test_dir / "master_os.vhd";
    uint64_t v_size = 128 * 1024;
    {
        std::ofstream out(vhd_file, std::ios::binary);
        std::vector<uint8_t> data(v_size, 0x11);
        out.write(reinterpret_cast<const char*>(data.data()), static_cast<std::streamsize>(data.size()));

        std::vector<uint8_t> footer(512, 0);
        std::memcpy(footer.data(), "conectix", 8);
        footer[0x3C] = 0; footer[0x3D] = 0; footer[0x3E] = 0; footer[0x3F] = 2; // Fixed
        for (int i = 0; i < 8; ++i) {
            footer[0x30 + i] = static_cast<uint8_t>((v_size >> ((7 - i) * 8)) & 0xFF);
        }
        uint32_t sum = 0;
        for (size_t i = 0; i < 512; ++i) sum += footer[i];
        uint32_t csum = ~sum;
        footer[64] = static_cast<uint8_t>((csum >> 24) & 0xFF);
        footer[65] = static_cast<uint8_t>((csum >> 16) & 0xFF);
        footer[66] = static_cast<uint8_t>((csum >> 8) & 0xFF);
        footer[67] = static_cast<uint8_t>(csum & 0xFF);
        out.write(reinterpret_cast<const char*>(footer.data()), 512);
    }

    // 2. Setup GoldenImageRegistry and ImageManager
    auto reg = std::make_shared<GoldenImageRegistry>();
    auto img_mgr = std::make_shared<ImageManager>(reg);
    Configuration cfg;
    cfg.set_os_images_dir(test_dir);
    img_mgr->configure(cfg);
    auto import_res = img_mgr->import_image(vhd_file, ImageRole::OsImage, ImageId("master_os"));
    assert(import_res.is_ok());

    // Test Fuzzy Resolution Fallbacks:
    // a. Exact match
    auto res_exact = img_mgr->acquire_image("master_os");
    assert(res_exact.is_ok());
    (void)img_mgr->release_image(ImageId("master_os"));

    // b. Extension fallback (.vhd)
    auto res_ext = img_mgr->acquire_image("master_os.vhd");
    assert(res_ext.is_ok());
    (void)img_mgr->release_image(ImageId("master_os"));

    // c. Case-insensitive stem fallback
    auto res_stem = img_mgr->acquire_image("MASTER_OS");
    assert(res_stem.is_ok());
    (void)img_mgr->release_image(ImageId("master_os"));

    // d. Single registered image fallback
    auto res_fallback = img_mgr->acquire_image("non_existent_image_id");
    assert(res_fallback.is_ok());
    assert(res_fallback.value()->id().value() == "master_os");
    (void)img_mgr->release_image(ImageId("master_os"));

    // 3. Client Manager: Super Client toggle and persistence
    auto cli_mgr = std::make_shared<ClientManager>();
    ClientRecord cl1;
    cl1.pc_name = "SuperPC";
    cl1.mac_address = "AA:BB:CC:11:22:33";
    cl1.ip_address = NetworkAddress(192, 168, 1, 50);
    cl1.os_image_id = "master_os";
    cl1.is_super_client = true;
    assert(cli_mgr->add_or_update_client(cl1).is_ok());

    // Test saving and loading is_super_client
    std::filesystem::path cl_json = test_dir / "clients.json";
    assert(cli_mgr->save_to_file(cl_json).is_ok());

    auto cli_mgr2 = std::make_shared<ClientManager>();
    assert(cli_mgr2->load_from_file(cl_json).is_ok());
    auto cl_loaded = cli_mgr2->get_client_by_mac("AA:BB:CC:11:22:33");
    assert(cl_loaded.has_value());
    assert(cl_loaded->is_super_client == true);

    // 4. Session Manager and Super Client COW Merge Pipeline
    std::filesystem::path wb_dir = test_dir / "writeback";
    std::filesystem::create_directories(wb_dir, ec);
    auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, wb_dir);
    sess_mgr->set_client_manager(cli_mgr);

    auto sess_res = sess_mgr->get_or_create_session(ClientId(cl1.mac_address), cl1.ip_address, ImageId(cl1.os_image_id));
    assert(sess_res.is_ok());
    auto session = sess_res.value();
    assert(session->is_super_client());

    auto cow_dev = session->cow_device();
    assert(cow_dev != nullptr);

    // Initial read from sector 5: verify it has 0x11 from base image
    std::vector<std::byte> read_buf(512);
    assert(cow_dev->read(5, read_buf).is_ok());
    assert(read_buf[0] == std::byte{0x11});

    // Super client writes updates to sector 5: 0x99
    std::vector<std::byte> write_buf(512, std::byte{0x99});
    assert(cow_dev->write(5, write_buf).is_ok());
    assert(cow_dev->flush().is_ok());

    // Read back through COW overlay: sees 0x99
    assert(cow_dev->read(5, read_buf).is_ok());
    assert(read_buf[0] == std::byte{0x99});

    // 5. Commit image changes back to master golden image
    auto commit_res = sess_mgr->commit_super_client(session->id());
    assert(commit_res.is_ok());

    // COW overlay should have been reset / cleared
    assert(cow_dev->allocated_chunks() == 0);

    // Reading through COW overlay still returns 0x99 because base image was updated
    std::vector<std::byte> read_post_commit(512);
    assert(cow_dev->read(5, read_post_commit).is_ok());
    assert(read_post_commit[0] == std::byte{0x99});

    // Terminate session
    assert(sess_mgr->terminate_session(session->id()).is_ok());

    // 6. Direct physical disk verification:
    // Open the base VHD directly with GoldenImage and verify sector 5 has 0x99 permanently written
    auto verified_img_res = GoldenImage::open(vhd_file, ImageId("verify_img"));
    assert(verified_img_res.is_ok());
    auto verified_dev = verified_img_res.value()->device();
    std::vector<std::byte> phys_read(512);
    assert(verified_dev->read(5, phys_read).is_ok());
    assert(phys_read[0] == std::byte{0x99});

    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_super_client_image_update_pipeline\n";
}

void test_image_persistence_and_autoload_pipeline() {
    std::cout << "[RUN] test_image_persistence_and_autoload_pipeline\n";
    std::error_code ec;
    std::filesystem::path scratch = "test_scratch_image_persistence";
    std::filesystem::remove_all(scratch, ec);
    std::filesystem::create_directories(scratch, ec);
    std::filesystem::create_directories(scratch / "images", ec);

    // Create test image files (sector-aligned)
    std::filesystem::path raw_os = scratch / "images" / "master_win10.raw";
    {
        std::ofstream f(raw_os, std::ios::binary);
        std::vector<char> zero(1024 * 1024, 0);
        f.write(zero.data(), zero.size());
    }

    std::filesystem::path raw_game = scratch / "images" / "cyberpunk.img";
    {
        std::ofstream f(raw_game, std::ios::binary);
        std::vector<char> zero(512 * 1024, 0);
        f.write(zero.data(), zero.size());
    }

    std::filesystem::path config_json = scratch / "config.json";

    // 1. Persistence on import
    auto reg1 = std::make_shared<GoldenImageRegistry>();
    ImageManager mgr1(reg1);
    mgr1.set_config_path(config_json);
    Configuration cfg1;
    cfg1.set_os_images_dir(scratch / "images");
    cfg1.set_games_dir(scratch / "images");
    mgr1.configure(cfg1);

    auto import_res = mgr1.import_image(raw_os, ImageRole::OsImage, ImageId("master_win10"));
    assert(import_res.is_ok());

    // Verify that the stored ManagedImageInfo object's file_path MUST remain the full canonical path with extension
    auto info_res = mgr1.get_image_info(ImageId("master_win10"));
    assert(info_res.is_ok());
    assert(info_res.value().file_path.has_extension());
    assert(info_res.value().file_path.extension() == ".raw");
    assert(std::filesystem::exists(info_res.value().file_path));

    // Verify StorageManager::verify_file_openable
    assert(StorageManager::verify_file_openable(raw_os).is_ok());
    assert(!StorageManager::verify_file_openable("non_existent_path_probe.vhd").is_ok());

    // Explicitly test save_images_to_config
    assert(mgr1.save_images_to_config(config_json).is_ok());
    assert(std::filesystem::exists(config_json));

    // Verify config.json content contains images array
    {
        std::ifstream in(config_json);
        std::string content((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
        assert(content.find("\"images\":") != std::string::npos);
        assert(content.find("master_win10") != std::string::npos);
    }

    // 2. Auto-load from config.json in a fresh ImageManager
    auto reg2 = std::make_shared<GoldenImageRegistry>();
    ImageManager mgr2(reg2);
    assert(mgr2.load_images_from_config(config_json).is_ok());
    assert(mgr2.list_all_images().size() == 1);
    assert(mgr2.get_image_info(ImageId("master_win10")).is_ok());
    assert(mgr2.get_image_info(ImageId("master_win10")).value().file_path.extension() == ".raw");

    // 3. Multi-alias acquire and diagnostic logging on unknown lookup
    // Verify lookup by ID
    auto acq_id = mgr2.acquire_image("master_win10");
    assert(acq_id.is_ok());
    assert(acq_id.value()->path().has_extension());
    assert(std::filesystem::exists(acq_id.value()->path()));

    // Verify lookup by filename
    assert(mgr2.acquire_image("master_win10.raw").is_ok());
    // Verify lookup by stem
    assert(mgr2.acquire_image("master_win10").is_ok());

    // Diagnostic logging on lookup failure with fallback
    // When looking up an unknown key "non_existent_image", it fails resolution, logs diagnostic list of currently loaded images, and falls back to first registered image
    auto acq_res = mgr2.acquire_image("non_existent_image");
    assert(acq_res.is_ok()); // Fallback succeeds because images_.size() > 0
    assert(acq_res.value()->path().has_extension());
    assert(std::filesystem::exists(acq_res.value()->path()));

    // In an empty manager, lookup failure logs diagnostic and returns Error
    auto reg3 = std::make_shared<GoldenImageRegistry>();
    ImageManager mgr3(reg3);
    auto empty_acq = mgr3.acquire_image("missing_image");
    assert(!empty_acq.is_ok());

    // 4. Test initialize() auto-scan and auto-load
    auto reg4 = std::make_shared<GoldenImageRegistry>();
    ImageManager mgr4(reg4);
    Configuration cfg4;
    cfg4.set_os_images_dir(scratch / "images");
    cfg4.set_games_dir(scratch / "images");
    mgr4.configure(cfg4);

    assert(mgr4.initialize(config_json).is_ok());
    // Both master_win10 and cyberpunk should be discovered/loaded
    assert(mgr4.list_all_images().size() >= 2);

    for (const auto& img_info : mgr4.list_all_images()) {
        assert(img_info.file_path.has_extension());
        assert(std::filesystem::exists(img_info.file_path));
    }

    std::filesystem::remove_all(scratch, ec);
    std::cout << "  PASS: test_image_persistence_and_autoload_pipeline\n";
}

// =============================================================================
// Multi-Client Copy-on-Write Writeback: isolation, lifecycle, quota & Super
// Client direct-bypass Tests
// =============================================================================

void test_multi_client_writeback_isolation_and_lifecycle() {
    std::cout << "[RUN] test_multi_client_writeback_isolation_and_lifecycle\n";

    const std::filesystem::path test_dir = "./test_multi_client_writeback";
    const std::filesystem::path os_dir = test_dir / "os";
    const std::filesystem::path wb_dir = test_dir / "wb";
    std::error_code ec;
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(os_dir, ec);
    std::filesystem::create_directories(wb_dir, ec);

    // One shared golden base: 1 MiB of 0x5A, opened read-only by every session.
    const std::filesystem::path base_path = os_dir / "shared_base.raw";
    {
        std::ofstream out(base_path, std::ios::binary);
        std::vector<uint8_t> base_data(1024 * 1024, 0x5A);
        out.write(reinterpret_cast<const char*>(base_data.data()),
                  static_cast<std::streamsize>(base_data.size()));
    }

    auto base_byte = [&](uint64_t offset) -> int {
        std::ifstream in(base_path, std::ios::binary);
        assert(in.good());
        in.seekg(static_cast<std::streamoff>(offset));
        char c = 0;
        in.read(&c, 1);
        assert(in.good());
        return static_cast<unsigned char>(c);
    };

    Configuration cfg;
    cfg.set_os_images_dir(os_dir);
    cfg.set_writeback_dir(wb_dir);

    auto registry = std::make_shared<GoldenImageRegistry>();
    auto image_mgr = std::make_shared<ImageManager>(registry);
    image_mgr->configure(cfg);
    assert(image_mgr->import_image(base_path, ImageRole::OsImage, ImageId("shared_base")).is_ok());

    auto sess_mgr = std::make_shared<ClientSessionManager>(image_mgr, wb_dir);
    // 64 KiB == sixteen 4 KiB clusters of dirty state per client.
    sess_mgr->set_writeback_quota_bytes(64 * 1024);

    const std::string iqn_a = "iqn.2026-09.cobdiskless:client-a";
    const std::string iqn_b = "iqn.2026-09.cobdiskless:client-b";

    // --- 1. Two initiators boot concurrently from the same base image ---
    auto a_res = sess_mgr->get_or_create_session(
        ClientId("00:11:22:33:44:AA"), NetworkAddress(192, 168, 1, 101),
        ImageId("shared_base"), iqn_a);
    assert(a_res.is_ok());
    auto sess_a = a_res.value();

    auto b_res = sess_mgr->get_or_create_session(
        ClientId("00:11:22:33:44:BB"), NetworkAddress(192, 168, 1, 102),
        ImageId("shared_base"), iqn_b);
    assert(b_res.is_ok());
    auto sess_b = b_res.value();

    assert(sess_mgr->active_clients_count() == 2);
    assert(sess_a->initiator_iqn() == iqn_a);
    assert(sess_b->initiator_iqn() == iqn_b);
    assert(sess_mgr->find_session_by_iqn(iqn_a).get() == sess_a.get());
    assert(sess_mgr->find_session_by_iqn(iqn_b).get() == sess_b.get());
    assert(sess_mgr->find_session_by_iqn("iqn.2026-09.cobdiskless:nobody") == nullptr);

    // The same initiator reconnecting from a different MAC/IP reuses its overlay.
    auto a_again = sess_mgr->get_or_create_session(
        ClientId("00:11:22:33:44:FE"), NetworkAddress(192, 168, 1, 201),
        ImageId("shared_base"), iqn_a);
    assert(a_again.is_ok());
    assert(a_again.value().get() == sess_a.get());
    assert(sess_mgr->active_clients_count() == 2);

    // --- 2. Writes are isolated per client; the shared base stays pristine ---
    const std::vector<std::byte> a_write(4096, std::byte{0xAA});
    const std::vector<std::byte> b_write(4096, std::byte{0xBB});
    assert(sess_a->cow_device()->write(4096, a_write).is_ok());
    assert(sess_b->cow_device()->write(4096, b_write).is_ok());

    std::vector<std::byte> buf(4096);
    assert(sess_a->cow_device()->read(4096, buf).is_ok());
    assert(std::to_integer<int>(buf[0]) == 0xAA);
    assert(sess_b->cow_device()->read(4096, buf).is_ok());
    assert(std::to_integer<int>(buf[0]) == 0xBB);

    assert(base_byte(0) == 0x5A);
    assert(base_byte(4096) == 0x5A);   // neither client's write reached the base

    // --- 3. Concurrent composite reads across sessions never collide ---
    std::atomic<int> failures{0};
    std::vector<std::thread> readers;
    readers.reserve(8);
    for (int t = 0; t < 8; ++t) {
        readers.emplace_back([&, t]() {
            const bool side_a = (t % 2) == 0;
            const int expected = side_a ? 0xAA : 0xBB;
            const auto target = side_a ? sess_a : sess_b;
            std::vector<std::byte> local(8192);
            for (int i = 0; i < 64; ++i) {
                // Dirty cluster served from this client's overlay...
                if (!target->cow_device()->read(4096, local).is_ok() ||
                    std::to_integer<int>(local[0]) != expected) {
                    ++failures;
                }
                // ...clean range still coalesces into a shared base read.
                if (!target->cow_device()->read(0, local).is_ok() ||
                    std::to_integer<int>(local[0]) != 0x5A) {
                    ++failures;
                }
            }
        });
    }
    for (auto& th : readers) {
        th.join();
    }
    assert(failures.load() == 0);
    assert(base_byte(4096) == 0x5A);

    // --- 4. Writeback quota stops a runaway client from filling the disk ---
    auto c_res = sess_mgr->get_or_create_session(
        ClientId("00:11:22:33:44:CC"), NetworkAddress(192, 168, 1, 103),
        ImageId("shared_base"), "iqn.2026-09.cobdiskless:client-c");
    assert(c_res.is_ok());
    auto sess_c = c_res.value();
    assert(sess_c->cow_device()->writeback_quota() == 64 * 1024);

    const std::vector<std::byte> block(4096, std::byte{0x77});
    for (uint64_t i = 0; i < 16; ++i) {
        assert(sess_c->cow_device()->write(i * 4096, block).is_ok());
    }
    // The seventeenth distinct cluster would exceed the 64 KiB allowance.
    assert(!sess_c->cow_device()->write(16ull * 4096, block).is_ok());
    assert(sess_c->cow_device()->dirty_bytes() == 64 * 1024);
    assert(base_byte(0) == 0x5A);      // quota pressure never leaks into the base
    assert(sess_mgr->terminate_session(sess_c->id()).is_ok());
    assert(sess_mgr->active_clients_count() == 2);

    // --- 5. Session teardown purges the overlay for a clean baseline ---
    const std::filesystem::path a_overlay = wb_dir / "wb_00_11_22_33_44_AA.cow";
    const std::filesystem::path b_overlay = wb_dir / "wb_00_11_22_33_44_BB.cow";
    assert(std::filesystem::exists(a_overlay));
    assert(std::filesystem::exists(b_overlay));

    assert(sess_mgr->terminate_session(sess_a->id()).is_ok());
    assert(!std::filesystem::exists(a_overlay));
    assert(sess_mgr->find_session_by_iqn(iqn_a) == nullptr);
    assert(sess_mgr->active_clients_count() == 1);

    // Session B is completely unaffected by A's teardown.
    assert(std::filesystem::exists(b_overlay));
    assert(sess_b->cow_device()->read(4096, buf).is_ok());
    assert(std::to_integer<int>(buf[0]) == 0xBB);

    // Re-login rebuilds a pristine overlay on top of the untouched base.
    auto a_fresh = sess_mgr->get_or_create_session(
        ClientId("00:11:22:33:44:AA"), NetworkAddress(192, 168, 1, 101),
        ImageId("shared_base"), iqn_a);
    assert(a_fresh.is_ok());
    assert(a_fresh.value().get() != sess_a.get());
    assert(std::filesystem::exists(a_overlay));
    assert(a_fresh.value()->cow_device()->allocated_chunks() == 0);
    assert(a_fresh.value()->cow_device()->read(4096, buf).is_ok());
    assert(std::to_integer<int>(buf[0]) == 0x5A);
    assert(base_byte(4096) == 0x5A);

    // --- 6. Super Client direct-bypass on an exclusively owned image ---
    assert(sess_mgr->terminate_session(a_fresh.value()->id()).is_ok());
    assert(sess_mgr->terminate_session(sess_b->id()).is_ok());
    assert(sess_mgr->active_clients_count() == 0);

    sess_mgr->set_super_client_identities({"iqn.2026-09.cobdiskless:maintenance"});
    auto sup_res = sess_mgr->get_or_create_session(
        ClientId("00:11:22:33:44:99"), NetworkAddress(192, 168, 1, 150),
        ImageId("shared_base"), "iqn.2026-09.cobdiskless:maintenance");
    assert(sup_res.is_ok());
    auto sup = sup_res.value();
    assert(sup->is_super_client());
    // Nobody else holds the image, so the exclusive bypass was granted.
    assert(sup->cow_device()->direct_base_writes());

    const std::vector<std::byte> sup_write(4096, std::byte{0xC3});
    assert(sup->cow_device()->write(8192, sup_write).is_ok());
    assert(sup->cow_device()->flush().is_ok());
    assert(sup->cow_device()->dirty_bytes() == 0);   // nothing staged in an overlay
    assert(sup->cow_device()->read(8192, buf).is_ok());
    assert(std::to_integer<int>(buf[0]) == 0xC3);

    assert(sess_mgr->terminate_session(sup->id()).is_ok());
    assert(sess_mgr->active_clients_count() == 0);
    assert(!std::filesystem::exists(wb_dir / "wb_00_11_22_33_44_99.cow"));

    // --- 7. The base only ever received the Super Client's maintenance write ---
    assert(base_byte(8192) == 0xC3);   // committed directly into the base
    assert(base_byte(4096) == 0x5A);   // client A/B writes were never committed
    assert(base_byte(0) == 0x5A);

    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_multi_client_writeback_isolation_and_lifecycle\n";
}

// =============================================================================
// Client Enrollment: host auto-detection, dynamic IP pool, persistent registry
// =============================================================================

void test_host_network_pool_and_client_registry() {
    std::cout << "[RUN] test_host_network_pool_and_client_registry\n";

    // --- 1. IPv4 conversion helpers round-trip -------------------------------
    const NetworkAddress addr(192, 168, 10, 7);
    assert(ipv4_to_u32(addr) == 0xC0A80A07u);
    assert(u32_to_ipv4(0xC0A80A07u) == addr);

    assert(prefix_to_netmask(24) == NetworkAddress(255, 255, 255, 0));
    assert(prefix_to_netmask(8) == NetworkAddress(255, 0, 0, 0));
    assert(prefix_to_netmask(32) == NetworkAddress(255, 255, 255, 255));
    assert(netmask_to_prefix(NetworkAddress(255, 255, 255, 0)) == 24);
    assert(netmask_to_prefix(NetworkAddress(255, 255, 252, 0)) == 22);
    assert(netmask_to_prefix(prefix_to_netmask(20)) == 20);

    // --- 2. Host auto-detection never throws and never reports loopback -----
    const HostNetworkInfo detected = detect_host_network();
    if (detected.detected) {
        assert(!detected.ip.is_any());
        assert(!detected.ip.is_loopback());
        assert(detected.netmask != NetworkAddress(0, 0, 0, 0));
        assert(detected.prefix_length() >= 1 && detected.prefix_length() <= 32);
        std::cout << "  [info] adapter '" << detected.interface_name << "' = "
                  << detected.ip.ip_string() << "/" << (int)detected.prefix_length()
                  << " gw=" << detected.gateway.ip_string() << "\n";
    }

    // --- 3. Default pool derivation on a conventional /24 --------------------
    HostNetworkInfo subnet;
    subnet.ip = NetworkAddress(192, 168, 10, 7);
    subnet.netmask = NetworkAddress(255, 255, 255, 0);
    subnet.gateway = NetworkAddress(192, 168, 10, 1);
    subnet.interface_name = "test-nic";
    subnet.detected = true;

    const IpPool pool = derive_default_pool(subnet);
    assert(pool.valid());
    assert(pool.start == NetworkAddress(192, 168, 10, 101));
    assert(pool.end == NetworkAddress(192, 168, 10, 254));
    // The network and broadcast addresses stay outside the range.
    assert(pool.start != NetworkAddress(192, 168, 10, 0));
    assert(pool.end != NetworkAddress(192, 168, 10, 255));

    // Verify start steps over host IP if host IP is .101
    HostNetworkInfo colliding_host = subnet;
    colliding_host.ip = NetworkAddress(192, 168, 10, 101);
    const IpPool stepped_pool = derive_default_pool(colliding_host);
    assert(stepped_pool.valid());
    assert(stepped_pool.start == NetworkAddress(192, 168, 10, 102));

    // A subnet too small for .100-.254 still offers its usable range...
    HostNetworkInfo small = subnet;
    small.netmask = NetworkAddress(255, 255, 255, 192); // /26 -> .0 - .63
    const IpPool small_pool = derive_default_pool(small);
    assert(small_pool.valid());
    assert(small_pool.start == NetworkAddress(192, 168, 10, 1));
    assert(small_pool.end == NetworkAddress(192, 168, 10, 62));

    // ...while a one-address subnet cannot offer anything at all.
    HostNetworkInfo tiny = subnet;
    tiny.netmask = NetworkAddress(255, 255, 255, 255);
    assert(!derive_default_pool(tiny).valid());

    // A never-detected adapter derives no pool (config must fall back).
    assert(!derive_default_pool(HostNetworkInfo{}).valid());

    // --- 4. MAC normalization / validation ----------------------------------
    assert(ClientDatabase::normalize_mac("aa-bb-cc-dd-ee-ff") == "AA:BB:CC:DD:EE:FF");
    assert(ClientDatabase::normalize_mac("aabb.ccdd.eeff") == "AA:BB:CC:DD:EE:FF");
    assert(ClientDatabase::normalize_mac("AA:BB:CC:DD:EE:FF") == "AA:BB:CC:DD:EE:FF");
    assert(ClientDatabase::is_valid_mac("aa:bb:cc:dd:ee:ff"));
    assert(ClientDatabase::is_valid_mac("aa-bb-cc-dd-ee-ff"));
    assert(!ClientDatabase::is_valid_mac("aa:bb:cc"));
    assert(!ClientDatabase::is_valid_mac("zz:zz:zz:zz:zz:zz"));
    assert(!ClientDatabase::is_valid_mac(""));

    // --- 5. Hostname sanitization -------------------------------------------
    assert(ClientDatabase::sanitize_hostname("  pc-01  ").is_ok());
    assert(ClientDatabase::sanitize_hostname("  pc-01  ").value() == "PC-01");
    assert(ClientDatabase::sanitize_hostname("gaming-rig-1").value() == "GAMING-RIG-1");
    assert(!ClientDatabase::sanitize_hostname("").is_ok());
    assert(!ClientDatabase::sanitize_hostname("   ").is_ok());
    assert(!ClientDatabase::sanitize_hostname("THISNAMEISWAYTOOLONG").is_ok()); // >15
    assert(!ClientDatabase::sanitize_hostname("-LEADING").is_ok());             // bad 1st char
    assert(!ClientDatabase::sanitize_hostname("BAD NAME").is_ok());             // space
    assert(!ClientDatabase::sanitize_hostname("PC;RM").is_ok());                // punctuation
    assert(!ClientDatabase::sanitize_hostname("con").is_ok());                  // DOS device
    assert(!ClientDatabase::sanitize_hostname("LPT1").is_ok());                 // DOS device
    assert(ClientDatabase::sanitize_hostname("CONSOLE").is_ok());               // not reserved

    // --- 6. Pool allocation never collides with server / gateway -------------
    const std::filesystem::path db_path = "test_clients_enrollment.json";
    std::filesystem::remove(db_path);

    auto db = std::make_shared<ClientDatabase>(db_path);
    // 5 addresses total; .102 belongs to the server and is taken out of play.
    db->configure_pool(NetworkAddress(192, 168, 10, 100),
                       NetworkAddress(192, 168, 10, 104));
    db->set_reserved_addresses({NetworkAddress(192, 168, 10, 102),
                                NetworkAddress(192, 168, 10, 1)}); // gateway, out of pool
    db->set_default_base_image("win10_base.vhd");

    const auto c1 = db->enroll_client("aa:bb:cc:00:00:01", "pc-01");
    assert(c1.is_ok());
    assert(c1.value().mac_address == "AA:BB:CC:00:00:01");
    assert(c1.value().hostname == "PC-01");
    assert(c1.value().ip_address == NetworkAddress(192, 168, 10, 100));
    assert(c1.value().base_image == "win10_base.vhd");
    assert(!c1.value().super_client);

    const auto c2 = db->enroll_client("aa:bb:cc:00:00:02", "pc-02");
    assert(c2.is_ok());
    assert(c2.value().ip_address == NetworkAddress(192, 168, 10, 101));

    // .102 is reserved for the server and must be skipped entirely.
    const auto c3 = db->enroll_client("aa:bb:cc:00:00:03", "pc-03");
    assert(c3.is_ok());
    assert(c3.value().ip_address == NetworkAddress(192, 168, 10, 103));

    const auto c4 = db->enroll_client("aa:bb:cc:00:00:04", "pc-04");
    assert(c4.is_ok());
    assert(c4.value().ip_address == NetworkAddress(192, 168, 10, 104));
    assert(db->client_count() == 4);

    // Pool exhausted: 5 addresses, 1 reserved for the server, 4 handed out.
    const auto c5 = db->enroll_client("aa:bb:cc:00:00:05", "pc-05");
    assert(!c5.is_ok());
    assert(c5.error().code() == ErrorCode::NetworkFailure);
    assert(db->client_count() == 4);

    // --- 7. Invalid and duplicate requests are rejected ----------------------
    assert(!db->enroll_client("aa:bb:cc:00:00:06", "pc-01").is_ok());   // duplicate name
    assert(!db->enroll_client("not-a-mac", "pc-06").is_ok());            // malformed MAC
    assert(!db->enroll_client("aa:bb:cc:00:00:06", "bad name!").is_ok()); // bad hostname
    assert(db->client_count() == 4);
    assert(db->is_hostname_taken("pc-01"));
    assert(!db->is_hostname_taken("pc-99"));

    // --- 8. Re-enrolling a known MAC is idempotent (keeps its lease) ---------
    const auto again = db->enroll_client("aa:bb:cc:00:00:01", "pc-01");
    assert(again.is_ok());
    assert(again.value().ip_address == NetworkAddress(192, 168, 10, 100));
    assert(db->client_count() == 4);

    // --- 9. Lookups normalize their keys -------------------------------------
    assert(db->find_client_by_mac("aa-bb-cc-00-00-02").has_value());
    assert(db->find_client_by_mac("aa-bb-cc-00-00-02")->hostname == "PC-02");
    assert(!db->find_client_by_mac("aa:bb:cc:00:00:ff").has_value());
    assert(db->find_client_by_hostname(" pc-03 ").has_value());

    // --- 10. Super Client flag and removal persist ---------------------------
    assert(db->set_super_client("aa:bb:cc:00:00:01", true).is_ok());
    assert(!db->set_super_client("aa:bb:cc:00:00:ff", true).is_ok());
    assert(db->remove_client("aa:bb:cc:00:00:04").is_ok());
    assert(!db->remove_client("aa:bb:cc:00:00:04").is_ok()); // already gone
    assert(db->client_count() == 3);

    // --- 11. clients.json survives a full reload -----------------------------
    auto reloaded = std::make_shared<ClientDatabase>(db_path);
    assert(reloaded->client_count() == 3);
    assert(reloaded->pool_start() == NetworkAddress(192, 168, 10, 100));
    assert(reloaded->pool_end() == NetworkAddress(192, 168, 10, 104));
    assert(reloaded->default_base_image() == "win10_base.vhd");
    assert(reloaded->reserved_addresses().size() == 2);

    const auto back = reloaded->find_client_by_mac("aa:bb:cc:00:00:01");
    assert(back.has_value());
    assert(back->hostname == "PC-01");
    assert(back->ip_address == NetworkAddress(192, 168, 10, 100));
    assert(back->base_image == "win10_base.vhd");
    assert(back->super_client);              // flag survived the reload
    assert(!reloaded->find_client_by_mac("aa:bb:cc:00:00:04").has_value());

    // The reloaded registry can keep allocating without reusing a taken lease.
    const auto post_reload = reloaded->enroll_client("aa:bb:cc:00:00:07", "pc-07");
    assert(post_reload.is_ok());
    assert(post_reload.value().ip_address == NetworkAddress(192, 168, 10, 104));

    std::filesystem::remove(db_path);

    // --- 12. The new enrollment configuration keys round-trip ---------------
    const std::filesystem::path cfg_path = "test_enroll_config.conf";
    std::filesystem::remove(cfg_path);

    Configuration cfg;
    cfg.set_http_port(9090);
    cfg.set_network_auto_detect(false);
    cfg.set_subnet_mask(NetworkAddress(255, 255, 240, 0));
    cfg.set_gateway(NetworkAddress(192, 168, 15, 254));
    cfg.set_client_pool_start(NetworkAddress(192, 168, 15, 50));
    cfg.set_client_pool_end(NetworkAddress(192, 168, 15, 90));
    assert(cfg.save_to_file(cfg_path).is_ok());

    Configuration reloaded_cfg;
    assert(reloaded_cfg.load_from_file(cfg_path).is_ok());
    assert(reloaded_cfg.http_port() == 9090);
    assert(reloaded_cfg.network_auto_detect() == false);
    assert(reloaded_cfg.subnet_mask() == NetworkAddress(255, 255, 240, 0));
    assert(reloaded_cfg.gateway() == NetworkAddress(192, 168, 15, 254));
    assert(reloaded_cfg.client_pool_start() == NetworkAddress(192, 168, 15, 50));
    assert(reloaded_cfg.client_pool_end() == NetworkAddress(192, 168, 15, 90));

    std::filesystem::remove(cfg_path);

    std::cout << "  PASS: test_host_network_pool_and_client_registry\n";
}

// =============================================================================
// Dynamic Network Sniffing: HTTP daemon routes and generated iPXE scripts
// =============================================================================

void test_http_enrollment_and_ipxe_scripts() {
    std::cout << "[RUN] test_http_enrollment_and_ipxe_scripts\n";

    // --- 1. Request parsing helpers -----------------------------------------
    {
        const auto [path, query] = HttpDaemon::split_target("/boot.ipxe?mac=aa:bb&x=1#frag");
        assert(path == "/boot.ipxe");
        assert(query == "mac=aa:bb&x=1");

        const auto [bare_path, bare_query] = HttpDaemon::split_target("/boot.ipxe");
        assert(bare_path == "/boot.ipxe");
        assert(bare_query.empty());

        const auto params = HttpDaemon::parse_query("mac=aa%3Abb%3Acc&name=PC-01&flag");
        assert(params.at("mac") == "aa:bb:cc");
        assert(params.at("name") == "PC-01");
        assert(params.at("flag").empty());

        assert(HttpDaemon::url_decode("a%20b") == "a b");
        assert(HttpDaemon::url_decode("plain") == "plain");
        assert(HttpDaemon::url_decode("bad%zz") == "bad%zz"); // tolerated
    }

    const std::filesystem::path db_path = "test_clients_http.json";
    std::filesystem::remove(db_path);

    auto db = std::make_shared<ClientDatabase>(db_path);
    db->configure_pool(NetworkAddress(192, 168, 10, 100),
                       NetworkAddress(192, 168, 10, 110));
    db->set_default_base_image("win10_base.vhd");

    HttpDaemon daemon;
    daemon.set_client_database(db);
    daemon.set_server_ip(NetworkAddress(192, 168, 10, 7));
    daemon.set_gateway(NetworkAddress(192, 168, 10, 1));
    daemon.set_target_iqn("iqn.2026-09.com.cobdiskless:storage");
    daemon.set_initiator_prefix("iqn.2026-09.cobdiskless:");
    daemon.set_http_port(8080);

    // --- 2. Bare /boot.ipxe returns clean SANBoot script --------------------
    const HttpResponse bootstrap = daemon.handle_request("GET", "/boot.ipxe");
    assert(bootstrap.status == 200);
    assert(bootstrap.body.rfind("#!ipxe", 0) == 0);
    assert(bootstrap.body.find("set keep-san 1") != std::string::npos);
    assert(bootstrap.body.find("sanboot iscsi:192.168.10.7::::iqn.2026-09.com.cobdiskless:storage") != std::string::npos);
    assert(bootstrap.body.find("${server_ip}") == std::string::npos);
    assert(bootstrap.body.find("sanhook") == std::string::npos);

    // --- 3. Unregistered MAC -> interactive enrollment prompt ----------------
    HttpResponse unknown = daemon.handle_request("GET", "/boot.ipxe?mac=aa:bb:cc:00:00:01");
    assert(unknown.status == 200);
    assert(unknown.body.rfind("#!ipxe", 0) == 0);
    assert(unknown.body.find("Unregistered PC Detected") != std::string::npos);
    assert(unknown.body.find("read pc_name") != std::string::npos);
    assert(unknown.body.find(":enroll_failed") != std::string::npos);
    assert(unknown.body.find(
               "chain http://192.168.10.7:8080/api/enroll?mac=${net0/mac}&name=${pc_name}")
            != std::string::npos);
    assert(unknown.body.find("sanhook") == std::string::npos);
    assert(unknown.body.find("sanboot") == std::string::npos);

    // --- 4. Enrollment over the API answers with a SANBoot script ------------
    HttpResponse enrolled = daemon.handle_request(
        "GET", "/api/enroll?mac=aa:bb:cc:00:00:01&name=pc-01");
    assert(enrolled.status == 200);
    assert(enrolled.body.rfind("#!ipxe", 0) == 0);
    assert(enrolled.body.find("set keep-san 1") != std::string::npos);
    assert(enrolled.body.find("sanboot iscsi:192.168.10.7::::iqn.2026-09.com.cobdiskless:storage") != std::string::npos);
    assert(enrolled.body.find("${server_ip}") == std::string::npos);
    assert(enrolled.body.find("sanhook") == std::string::npos);
    assert(db->client_count() == 1);
    assert(db->find_client_by_mac("aa:bb:cc:00:00:01")->hostname == "PC-01");
    assert(db->find_client_by_mac("aa:bb:cc:00:00:01")->ip_address ==
           NetworkAddress(192, 168, 10, 100));
    assert(db->find_client_by_mac("aa:bb:cc:00:00:01")->base_image == "win10_base.vhd");

    // --- 5. Registered MAC now boots straight to the SAN ---------------------
    HttpResponse known = daemon.handle_request("GET", "/boot.ipxe?mac=aa:bb:cc:00:00:01");
    assert(known.status == 200);
    assert(known.body.find("sanboot iscsi:192.168.10.7::::iqn.2026-09.com.cobdiskless:storage") != std::string::npos);
    assert(known.body.find("${server_ip}") == std::string::npos);
    assert(known.body.find("set keep-san 1") != std::string::npos);
    assert(known.body.find("sanhook") == std::string::npos);
    assert(known.body.find("read pc_name") == std::string::npos);
    assert(known.body.find("Unregistered PC Detected") == std::string::npos);

    // --- 6. Idempotent re-enrollment -----------------------------------------
    const HttpResponse replay = daemon.handle_request(
        "GET", "/api/enroll?mac=AA:BB:CC:00:00:01&name=PC-01");
    assert(replay.status == 200);
    assert(replay.body.find("sanboot iscsi:192.168.10.7::::iqn.2026-09.com.cobdiskless:storage") != std::string::npos);
    assert(replay.body.find("${server_ip}") == std::string::npos);
    assert(replay.body.find("set keep-san 1") != std::string::npos);
    assert(replay.body.find("sanhook") == std::string::npos);
    assert(db->client_count() == 1);

    // Same MAC under a different name -> conflict, not a silent rename.
    assert(daemon.handle_request("GET",
                                 "/api/enroll?mac=aa:bb:cc:00:00:01&name=PC-77").status == 409);

    // --- 7. Enrollment input validation ---------------------------------------
    assert(daemon.handle_request("GET", "/api/enroll").status == 400);
    assert(daemon.handle_request("GET", "/api/enroll?mac=aa:bb:cc:00:00:02").status == 400);
    assert(daemon.handle_request("GET",
                                 "/api/enroll?mac=zz&name=PC-02").status == 400);
    assert(daemon.handle_request("GET",
                                 "/api/enroll?mac=aa:bb:cc:00:00:02&name=BAD%20NAME").status == 400);
    assert(daemon.handle_request("GET",
                                 "/api/enroll?mac=aa:bb:cc:00:00:02&name=THISNAMEISTOOLONG1").status
           == 400);
    assert(db->client_count() == 1); // rejected requests mutate nothing

    // A second machine enrolling under a taken name loses the conflict.
    assert(daemon.handle_request("GET",
                                 "/api/enroll?mac=aa:bb:cc:00:00:02&name=pc-01").status == 409);
    assert(db->client_count() == 1);

    // A genuinely new client enrolls normally.
    assert(daemon.handle_request("GET",
                                 "/api/enroll?mac=aa:bb:cc:00:00:02&name=pc-02").status == 200);
    assert(db->client_count() == 2);
    assert(db->find_client_by_mac("aa:bb:cc:00:00:02")->ip_address ==
           NetworkAddress(192, 168, 10, 101));

    // --- 8. /api/whoami feeds cob_rename.cmd ---------------------------------
    const HttpResponse whoami =
        daemon.handle_request("GET", "/api/whoami?mac=aa:bb:cc:00:00:01");
    assert(whoami.status == 200);
    assert(whoami.content_type.rfind("application/json", 0) == 0);
    auto parsed = JsonValue::parse(whoami.body);
    assert(parsed.has_value());
    assert(parsed->is_object());
    assert(parsed->find("hostname") != nullptr);
    assert(parsed->find("hostname")->as_string() == "PC-01");
    assert(parsed->find("ip")->as_string() == "192.168.10.100");
    assert(parsed->find("gateway")->as_string() == "192.168.10.1");
    assert(parsed->find("mac")->as_string() == "AA:BB:CC:00:00:01");
    assert(parsed->find("base_image")->as_string() == "win10_base.vhd");
    assert(parsed->find("super_client")->as_bool() == false);

    assert(daemon.handle_request("GET", "/api/whoami").status == 400);
    assert(daemon.handle_request("GET", "/api/whoami?mac=aa:bb:cc:00:00:ff").status == 404);

    // --- 9. The Windows hostname helper is served with the endpoint baked in -
    const HttpResponse helper = daemon.handle_request("GET", "/cob_rename.cmd");
    assert(helper.status == 200);
    assert(helper.body.rfind("@echo off", 0) == 0);
    assert(helper.body.find(ipxe::kServerIpPlaceholder) == std::string::npos);
    assert(helper.body.find(ipxe::kHttpPortPlaceholder) == std::string::npos);
    assert(helper.body.find("set \"SERVER=192.168.10.7\"") != std::string::npos);
    assert(helper.body.find("set \"PORT=8080\"") != std::string::npos);
    assert(helper.body.find("/api/whoami?mac=%MAC%") != std::string::npos);
    assert(helper.body.find("ActiveComputerName") != std::string::npos);
    assert(helper.body.find("NV Hostname") != std::string::npos);
    assert(helper.body.find("Rename-Computer") != std::string::npos);

    // --- 10. Routing errors ---------------------------------------------------
    assert(daemon.handle_request("GET", "/does-not-exist").status == 404);
    assert(daemon.handle_request("POST", "/api/enroll?mac=aa:bb:cc:00:00:03&name=pc-03").status
           == 405);
    assert(daemon.handle_request("PUT", "/boot.ipxe").status == 405);
    // HEAD is allowed and shares the GET representation.
    assert(daemon.handle_request("HEAD", "/boot.ipxe?mac=aa:bb:cc:00:00:01").status == 200);

    // --- 11. Wire serialization ------------------------------------------------
    const std::string wire = HttpResponse::ok("hello", "text/plain").serialize();
    assert(wire.rfind("HTTP/1.1 200 OK\r\n", 0) == 0);
    assert(wire.find("Content-Length: 5\r\n") != std::string::npos);
    assert(wire.find("Connection: close\r\n") != std::string::npos);
    assert(wire.substr(wire.size() - 5) == "hello");
    assert(HttpResponse::fail(409, "nope").serialize().find("HTTP/1.1 409 Conflict\r\n")
           != std::string::npos);

    // --- 12. Enrollment actually hit the disk ----------------------------------
    {
        std::ifstream in(db_path, std::ios::binary);
        assert(in.is_open());
        std::ostringstream buffer;
        buffer << in.rdbuf();
        auto on_disk = JsonValue::parse(buffer.str());
        assert(on_disk.has_value());
        assert(on_disk->is_object());
        assert(on_disk->find("clients") != nullptr);
        assert(on_disk->find("clients")->is_array());
        assert(on_disk->find("clients")->as_array().size() == 2);
    }

    std::filesystem::remove(db_path);
    std::cout << "  PASS: test_http_enrollment_and_ipxe_scripts\n";
}

// =============================================================================
// Live socket round-trip through the embedded HTTP daemon
// =============================================================================

void test_http_daemon_live_socket() {
    std::cout << "[RUN] test_http_daemon_live_socket\n";

#if defined(_WIN32)
    WSADATA wsa{};
    assert(WSAStartup(MAKEWORD(2, 2), &wsa) == 0);
#endif

    const std::filesystem::path db_path = "test_clients_http_live.json";
    std::filesystem::remove(db_path);

    auto db = std::make_shared<ClientDatabase>(db_path);
    db->configure_pool(NetworkAddress(192, 168, 10, 100),
                       NetworkAddress(192, 168, 10, 110));
    db->set_default_base_image("win10_base.vhd");
    assert(db->enroll_client("aa:bb:cc:00:00:01", "live-01").is_ok());

    HttpDaemon daemon(NetworkAddress(127, 0, 0, 1, 0)); // ephemeral port
    daemon.set_client_database(db);
    daemon.set_server_ip(NetworkAddress(192, 168, 10, 7));
    daemon.set_gateway(NetworkAddress(192, 168, 10, 1));
    daemon.set_target_iqn("iqn.2026-09.com.cobdiskless:storage");
    daemon.set_initiator_prefix("iqn.2026-09.cobdiskless:");

    const auto started = daemon.initialize();
    assert(started.is_ok());
    assert(daemon.is_initialized());
    assert(daemon.is_listening());
    assert(daemon.state() == SubsystemState::Running);
    assert(daemon.protocol() == NetworkProtocol::Tcp);
    assert(daemon.name() == "HttpDaemon");

    const uint16_t port = daemon.bound_port();
    assert(port != 0);
    assert(daemon.bound_address().port() == port);
    assert(daemon.bound_address().octet(0) == 127);

    // --- GET /api/whoami over a real TCP connection ---------------------------
    SOCKET sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    assert(sock != INVALID_SOCKET);

    sockaddr_in target{};
    target.sin_family = AF_INET;
    target.sin_port = htons(port);
    target.sin_addr.s_addr = htonl(0x7F000001u); // 127.0.0.1
    assert(connect(sock, reinterpret_cast<sockaddr*>(&target), sizeof(target)) == 0);

    const std::string request =
        "GET /api/whoami?mac=aa:bb:cc:00:00:01 HTTP/1.1\r\n"
        "Host: 127.0.0.1\r\n"
        "\r\n";
    assert(send(sock, request.c_str(), static_cast<int>(request.size()), 0) ==
           static_cast<int>(request.size()));

    std::string reply;
    char buffer[4096];
    for (;;) {
        const int n = recv(sock, buffer, sizeof(buffer), 0);
        if (n <= 0) {
            break;
        }
        reply.append(buffer, static_cast<size_t>(n));
    }
    closesocket(sock);

    assert(reply.rfind("HTTP/1.1 200 OK\r\n", 0) == 0);
    assert(reply.find("Content-Type: application/json") != std::string::npos);
    assert(reply.find("\"LIVE-01\"") != std::string::npos);
    assert(reply.find("\"192.168.10.100\"") != std::string::npos);

    // --- GET /boot.ipxe over a real TCP connection ----------------------------
    {
        SOCKET boot_sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        assert(boot_sock != INVALID_SOCKET);
        assert(connect(boot_sock, reinterpret_cast<sockaddr*>(&target), sizeof(target)) == 0);

        const std::string boot_request =
            "GET /boot.ipxe?mac=aa:bb:cc:00:00:01 HTTP/1.1\r\n"
            "Host: 127.0.0.1\r\n"
            "\r\n";
        assert(send(boot_sock, boot_request.c_str(), static_cast<int>(boot_request.size()), 0) ==
               static_cast<int>(boot_request.size()));

        std::string boot_reply;
        for (;;) {
            const int n = recv(boot_sock, buffer, sizeof(buffer), 0);
            if (n <= 0) {
                break;
            }
            boot_reply.append(buffer, static_cast<size_t>(n));
        }
        closesocket(boot_sock);

        assert(boot_reply.rfind("HTTP/1.1 200 OK\r\n", 0) == 0);
        assert(boot_reply.find("#!ipxe") != std::string::npos);
        assert(boot_reply.find("sanboot iscsi:192.168.10.7::::iqn.2026-09.com.cobdiskless:storage") != std::string::npos);
        assert(boot_reply.find("${server_ip}") == std::string::npos);
        assert(boot_reply.find("set keep-san 1") != std::string::npos);
        assert(boot_reply.find("sanhook") == std::string::npos);
    }

    // --- 404 over the wire -----------------------------------------------------
    {
        SOCKET missing = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        assert(missing != INVALID_SOCKET);
        assert(connect(missing, reinterpret_cast<sockaddr*>(&target), sizeof(target)) == 0);

        const std::string missing_request =
            "GET /nope HTTP/1.1\r\nHost: 127.0.0.1\r\n\r\n";
        assert(send(missing, missing_request.c_str(), static_cast<int>(missing_request.size()), 0) ==
               static_cast<int>(missing_request.size()));

        std::string missing_reply;
        for (;;) {
            const int n = recv(missing, buffer, sizeof(buffer), 0);
            if (n <= 0) {
                break;
            }
            missing_reply.append(buffer, static_cast<size_t>(n));
        }
        closesocket(missing);

        assert(missing_reply.rfind("HTTP/1.1 404 Not Found\r\n", 0) == 0);
    }

    // Re-initializing an already-running daemon is a harmless no-op.
    assert(daemon.initialize().is_ok());
    assert(daemon.is_initialized());

    daemon.shutdown();
    assert(!daemon.is_initialized());
    assert(!daemon.is_listening());
    assert(daemon.state() == SubsystemState::Stopped);

    // Calling shutdown twice must be harmless (destructor does it too).
    daemon.shutdown();

#if defined(_WIN32)
    WSACleanup();
#endif

    std::filesystem::remove(db_path);
    std::cout << "  PASS: test_http_daemon_live_socket\n";
}

// =============================================================================
// Config File Resolution and HTTP Port Fallback Tests
// =============================================================================

void test_config_file_resolution_and_default_port() {
    std::cout << "[RUN] test_config_file_resolution_and_default_port\n";

    // 1. Default HTTP port fallback check: 18080
    Configuration default_cfg;
    assert(default_cfg.http_port() == 18080);

    HttpDaemon default_daemon;
    assert(default_daemon.bound_address().port() == 18080);

    // 2. Candidate paths ordering check
    const std::filesystem::path mock_work = "C:/mock/project";
    const std::filesystem::path mock_exe = "C:/mock/project/build";
    auto candidates = Configuration::candidate_config_paths("cobdiskless.conf", mock_work, mock_exe);
    assert(candidates.size() == 3);
    assert(candidates[0] == mock_work / "cobdiskless.conf");
    assert(candidates[1] == mock_exe / "cobdiskless.conf");
    assert(candidates[2] == mock_exe / ".." / "cobdiskless.conf");

    // 3. Test filesystem resolution across relative/parent paths
    const std::filesystem::path base_test_dir = "test_scratch_config_res";
    std::error_code ec;
    std::filesystem::remove_all(base_test_dir, ec);

    const std::filesystem::path dir_root = base_test_dir / "app";
    const std::filesystem::path dir_build = dir_root / "build";
    const std::filesystem::path dir_work = dir_root / "other_work";

    std::filesystem::create_directories(dir_build, ec);
    std::filesystem::create_directories(dir_work, ec);

    // Case A: File only exists in parent directory of executable (dir_root)
    const std::filesystem::path parent_conf = dir_root / "cobdiskless.conf";
    {
        std::ofstream ofs(parent_conf);
        ofs << "# CobDiskless Configuration\n";
        ofs << "http_port=18080\n";
        ofs << "max_clients=42\n";
    }

    auto resolved_parent = Configuration::resolve_config_path("cobdiskless.conf", dir_work, dir_build);
    assert(resolved_parent == dir_build / ".." / "cobdiskless.conf");
    assert(std::filesystem::exists(resolved_parent));

    Configuration loaded_from_parent;
    assert(loaded_from_parent.load_from_file(resolved_parent).is_ok());
    assert(loaded_from_parent.http_port() == 18080);
    assert(loaded_from_parent.max_clients() == 42);

    // Case B: File also exists in executable directory (dir_build) -> takes precedence over parent
    const std::filesystem::path exe_conf = dir_build / "cobdiskless.conf";
    {
        std::ofstream ofs(exe_conf);
        ofs << "# CobDiskless Configuration\n";
        ofs << "http_port=18082\n";
        ofs << "max_clients=55\n";
    }

    auto resolved_exe = Configuration::resolve_config_path("cobdiskless.conf", dir_work, dir_build);
    assert(resolved_exe == dir_build / "cobdiskless.conf");
    assert(std::filesystem::exists(resolved_exe));

    Configuration loaded_from_exe;
    assert(loaded_from_exe.load_from_file(resolved_exe).is_ok());
    assert(loaded_from_exe.http_port() == 18082);
    assert(loaded_from_exe.max_clients() == 55);

    // Case C: File also exists in working directory (dir_work) -> highest precedence
    const std::filesystem::path work_conf = dir_work / "cobdiskless.conf";
    {
        std::ofstream ofs(work_conf);
        ofs << "# CobDiskless Configuration\n";
        ofs << "http_port=18084\n";
        ofs << "max_clients=77\n";
    }

    auto resolved_work = Configuration::resolve_config_path("cobdiskless.conf", dir_work, dir_build);
    assert(resolved_work == dir_work / "cobdiskless.conf");
    assert(std::filesystem::exists(resolved_work));

    Configuration loaded_from_work;
    assert(loaded_from_work.load_from_file(resolved_work).is_ok());
    assert(loaded_from_work.http_port() == 18084);
    assert(loaded_from_work.max_clients() == 77);

    // Case D: When none exist, fallback to candidate 1
    std::filesystem::remove_all(base_test_dir, ec);
    auto resolved_none = Configuration::resolve_config_path("cobdiskless.conf", dir_work, dir_build);
    assert(resolved_none == dir_work / "cobdiskless.conf");

    std::filesystem::remove_all(base_test_dir, ec);
    std::cout << "  PASS: test_config_file_resolution_and_default_port\n";
}

// =============================================================================
// Dynamic Port Propagation on Collision Tests
// =============================================================================

void test_dynamic_port_propagation_on_collision() {
    std::cout << "[RUN] test_dynamic_port_propagation_on_collision\n";

#if defined(_WIN32)
    WSADATA wsa{};
    assert(WSAStartup(MAKEWORD(2, 2), &wsa) == 0);
#endif

    const uint16_t occupied_base_port = 28080;

    // 1. Artificially occupy port 28080 with a raw TCP socket
    SOCKET s_occupy = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    assert(s_occupy != INVALID_SOCKET);

#if defined(_WIN32)
    int exclusive = 1;
    (void)setsockopt(s_occupy, SOL_SOCKET, SO_EXCLUSIVEADDRUSE,
                     reinterpret_cast<const char*>(&exclusive), sizeof(exclusive));
#else
    int reuse = 0;
    (void)setsockopt(s_occupy, SOL_SOCKET, SO_REUSEADDR,
                     reinterpret_cast<const char*>(&reuse), sizeof(reuse));
#endif

    sockaddr_in bind_addr{};
    bind_addr.sin_family = AF_INET;
    bind_addr.sin_addr.s_addr = htonl(0x7F000001u); // 127.0.0.1
    bind_addr.sin_port = htons(occupied_base_port);

    assert(bind(s_occupy, reinterpret_cast<sockaddr*>(&bind_addr), sizeof(bind_addr)) == 0);
    assert(listen(s_occupy, 5) == 0);

    // 2. Initialize HttpDaemon configured with the occupied port
    HttpDaemon daemon(NetworkAddress(127, 0, 0, 1, occupied_base_port));
    daemon.set_server_ip(NetworkAddress(192, 168, 1, 100));
    daemon.set_gateway(NetworkAddress(192, 168, 1, 1));
    daemon.set_target_iqn("iqn.2026-09.com.cobdiskless:storage");
    daemon.set_initiator_prefix("iqn.2026-09.cobdiskless:");

    // Initialization should succeed through auto-probe fallback to occupied_base_port + 1 (28081)
    auto init_res = daemon.initialize();
    assert(init_res.is_ok());
    assert(daemon.is_initialized());
    assert(daemon.is_listening());

    const uint16_t bound = daemon.bound_port();
    assert(bound == occupied_base_port + 1);
    assert(daemon.bound_address().port() == bound);

    // 3. Verify DhcpServer receives and uses the actual bound port
    DhcpServer dhcp(
        NetworkAddress(192, 168, 1, 100),
        NetworkAddress(255, 255, 255, 0),
        NetworkAddress(192, 168, 1, 150),
        NetworkAddress(192, 168, 1, 200)
    );
    dhcp.set_boot_script_url("http://192.168.1.100:" + std::to_string(daemon.bound_port()) + "/boot.ipxe");
    assert(dhcp.boot_script_url() == "http://192.168.1.100:28081/boot.ipxe");

    // Verify Option 67 and BOOTP header in DHCP response
    DhcpHeader req_hdr{};
    req_hdr.op = 1;
    req_hdr.htype = 1;
    req_hdr.hlen = 6;
    req_hdr.xid = htonl(0x12345678);
    req_hdr.chaddr[0] = 0xAA;
    req_hdr.chaddr[1] = 0xBB;
    req_hdr.chaddr[2] = 0xCC;
    req_hdr.chaddr[3] = 0xDD;
    req_hdr.chaddr[4] = 0xEE;
    req_hdr.chaddr[5] = 0xFF;

    DhcpDiscoveredOptions opts{};
    opts.is_ipxe_client = true;
    opts.client_arch = ClientArch::Efi_x64;
    opts.client_mac = "aa:bb:cc:dd:ee:ff";

    auto reply_res = dhcp.build_reply(req_hdr, opts, 2, NetworkAddress(192, 168, 1, 150));
    assert(reply_res.is_ok());
    const auto* reply_hdr = reinterpret_cast<const DhcpHeader*>(reply_res.value().data());
    assert(std::string(reinterpret_cast<const char*>(reply_hdr->file)) ==
           "http://192.168.1.100:28081/boot.ipxe");

    bool found_opt67 = false;
    for (size_t i = 240; i + 1 < reply_res.value().size();) {
        uint8_t code = reply_res.value()[i];
        if (code == 255) break;
        if (code == 0) { ++i; continue; }
        uint8_t len = reply_res.value()[i + 1];
        if (code == 67) {
            std::string val(reinterpret_cast<const char*>(reply_res.value().data() + i + 2), len);
            assert(val == "http://192.168.1.100:28081/boot.ipxe");
            found_opt67 = true;
        }
        i += static_cast<size_t>(len) + 2;
    }
    assert(found_opt67);

    // 4. Verify all iPXE script templates contain correct configuration
    // 4a. Clean SANBoot script (bare /boot.ipxe)
    auto boot_script = daemon.handle_request("GET", "/boot.ipxe");
    assert(boot_script.status == 200);
    assert(boot_script.body.rfind("#!ipxe", 0) == 0);
    assert(boot_script.body.find("set keep-san 1") != std::string::npos);
    assert(boot_script.body.find("sanboot iscsi:192.168.1.100::::iqn.2026-09.com.cobdiskless:storage") != std::string::npos);
    assert(boot_script.body.find("${server_ip}") == std::string::npos);

    // 4b. Interactive enrollment script (unregistered client contains bound port 28081)
    auto enroll_script = daemon.handle_request("GET", "/boot.ipxe?mac=11:22:33:44:55:66");
    assert(enroll_script.status == 200);
    assert(enroll_script.body.find("chain http://192.168.1.100:28081/api/enroll?mac=${net0/mac}&name=${pc_name}") != std::string::npos);

    // 4c. Windows hostname helper script contains bound port 28081
    auto rename_script = daemon.handle_request("GET", "/cob_rename.cmd");
    assert(rename_script.status == 200);
    assert(rename_script.body.find("set \"PORT=28081\"") != std::string::npos);

    // 5. Connect to the fallback port over real TCP socket and verify response
    {
        SOCKET client_sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        assert(client_sock != INVALID_SOCKET);

        sockaddr_in srv{};
        srv.sin_family = AF_INET;
        srv.sin_port = htons(bound);
        srv.sin_addr.s_addr = htonl(0x7F000001u); // 127.0.0.1
        assert(connect(client_sock, reinterpret_cast<sockaddr*>(&srv), sizeof(srv)) == 0);

        std::string req = "GET /boot.ipxe HTTP/1.1\r\nHost: 127.0.0.1\r\n\r\n";
        assert(send(client_sock, req.c_str(), static_cast<int>(req.size()), 0) == static_cast<int>(req.size()));

        std::string resp;
        char buf[2048];
        for (;;) {
            int n = recv(client_sock, buf, sizeof(buf), 0);
            if (n <= 0) break;
            resp.append(buf, static_cast<size_t>(n));
        }
        closesocket(client_sock);

        assert(resp.rfind("HTTP/1.1 200 OK\r\n", 0) == 0);
        assert(resp.find("#!ipxe") != std::string::npos);
        assert(resp.find("set keep-san 1") != std::string::npos);
        assert(resp.find("sanboot iscsi:192.168.1.100::::iqn.2026-09.com.cobdiskless:storage") != std::string::npos);
        assert(resp.find("${server_ip}") == std::string::npos);
    }

    daemon.shutdown();
    closesocket(s_occupy);

    // 6. Multi-port skip: occupy port 28090 AND 28091 simultaneously
    SOCKET s_occ1 = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    SOCKET s_occ2 = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    assert(s_occ1 != INVALID_SOCKET && s_occ2 != INVALID_SOCKET);

#if defined(_WIN32)
    (void)setsockopt(s_occ1, SOL_SOCKET, SO_EXCLUSIVEADDRUSE, reinterpret_cast<const char*>(&exclusive), sizeof(exclusive));
    (void)setsockopt(s_occ2, SOL_SOCKET, SO_EXCLUSIVEADDRUSE, reinterpret_cast<const char*>(&exclusive), sizeof(exclusive));
#endif

    sockaddr_in a1{};
    a1.sin_family = AF_INET;
    a1.sin_addr.s_addr = htonl(0x7F000001u);
    a1.sin_port = htons(28090);
    assert(bind(s_occ1, reinterpret_cast<sockaddr*>(&a1), sizeof(a1)) == 0);
    assert(listen(s_occ1, 5) == 0);

    sockaddr_in a2{};
    a2.sin_family = AF_INET;
    a2.sin_addr.s_addr = htonl(0x7F000001u);
    a2.sin_port = htons(28091);
    assert(bind(s_occ2, reinterpret_cast<sockaddr*>(&a2), sizeof(a2)) == 0);
    assert(listen(s_occ2, 5) == 0);

    HttpDaemon daemon_multi(NetworkAddress(127, 0, 0, 1, 28090));
    assert(daemon_multi.initialize().is_ok());
    assert(daemon_multi.bound_port() == 28092); // Skips 28090 and 28091, lands on 28092!
    daemon_multi.shutdown();

    closesocket(s_occ1);
    closesocket(s_occ2);

    // 7. Exhaustion check: occupy 28100 through 28110 (11 ports)
    std::vector<SOCKET> occupied_sockets;
    for (uint16_t p = 28100; p <= 28110; ++p) {
        SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        assert(s != INVALID_SOCKET);
#if defined(_WIN32)
        (void)setsockopt(s, SOL_SOCKET, SO_EXCLUSIVEADDRUSE, reinterpret_cast<const char*>(&exclusive), sizeof(exclusive));
#endif
        sockaddr_in a{};
        a.sin_family = AF_INET;
        a.sin_addr.s_addr = htonl(0x7F000001u);
        a.sin_port = htons(p);
        assert(bind(s, reinterpret_cast<sockaddr*>(&a), sizeof(a)) == 0);
        assert(listen(s, 5) == 0);
        occupied_sockets.push_back(s);
    }

    HttpDaemon daemon_exhaust(NetworkAddress(127, 0, 0, 1, 28100));
    auto exhaust_res = daemon_exhaust.initialize();
    assert(exhaust_res.is_err());
    assert(exhaust_res.error().code() == ErrorCode::InitializationFailure);

    for (SOCKET s : occupied_sockets) {
        closesocket(s);
    }

#if defined(_WIN32)
    WSACleanup();
#endif

    std::cout << "  PASS: test_dynamic_port_propagation_on_collision\n";
}

// =============================================================================
// Minimal read-only regf hive walker (used to verify offline hive injections)
// =============================================================================
namespace {

uint16_t hive_rd16(const uint8_t* p) noexcept {
    return static_cast<uint16_t>(p[0] | (static_cast<uint16_t>(p[1]) << 8));
}

uint32_t hive_rd32(const uint8_t* p) noexcept {
    return static_cast<uint32_t>(p[0]) |
           (static_cast<uint32_t>(p[1]) << 8) |
           (static_cast<uint32_t>(p[2]) << 16) |
           (static_cast<uint32_t>(p[3]) << 24);
}

bool hive_name_iequal(const std::string& a, const std::string& b) {
    if (a.size() != b.size()) return false;
    for (size_t i = 0; i < a.size(); ++i) {
        if (std::tolower(static_cast<unsigned char>(a[i])) !=
            std::tolower(static_cast<unsigned char>(b[i]))) {
            return false;
        }
    }
    return true;
}

struct HiveCell {
    const uint8_t* data{nullptr};
    size_t len{0};
    [[nodiscard]] bool valid() const noexcept { return data != nullptr; }
};

// Resolve a hive cell offset (relative to 0x1000) to its payload and payload length
HiveCell hive_cell(const std::vector<uint8_t>& hive, uint32_t cell_off) {
    HiveCell cell;
    size_t base = 0x1000 + static_cast<size_t>(cell_off);
    if (cell_off == 0 || cell_off == 0xFFFFFFFF) return cell;
    if (base + 4 > hive.size()) return cell;
    int32_t csize = static_cast<int32_t>(hive_rd32(&hive[base]));
    if (csize >= 0) return cell; // free cell
    size_t payload_len = static_cast<size_t>(-static_cast<int64_t>(csize));
    if (payload_len < 4) return cell;
    payload_len -= 4;
    if (base + 4 + payload_len > hive.size()) return cell;
    cell.data = &hive[base + 4];
    cell.len = payload_len;
    return cell;
}

// Locate a direct child subkey of an nk cell (returns 0xFFFFFFFF when absent)
uint32_t hive_find_subkey(const std::vector<uint8_t>& hive, uint32_t parent_off, const std::string& name) {
    HiveCell nk = hive_cell(hive, parent_off);
    if (!nk.valid() || nk.len < 0x20 || hive_rd16(nk.data) != 0x6B6E) return 0xFFFFFFFF;

    uint32_t subkey_count = hive_rd32(nk.data + 0x14);
    uint32_t list_off = hive_rd32(nk.data + 0x1C);
    if (subkey_count == 0 || list_off == 0 || list_off == 0xFFFFFFFF) return 0xFFFFFFFF;

    std::vector<uint32_t> pending = {list_off};
    for (size_t i = 0; i < pending.size(); ++i) {
        HiveCell sl = hive_cell(hive, pending[i]);
        if (!sl.valid() || sl.len < 4) continue;
        uint16_t sig = hive_rd16(sl.data);
        uint16_t count = hive_rd16(sl.data + 0x02);

        if (sig == 0x6972) { // "ri" root index
            for (uint16_t k = 0; k < count; ++k) {
                if (0x04 + static_cast<size_t>(k + 1) * 4 > sl.len) break;
                pending.push_back(hive_rd32(sl.data + 0x04 + k * 4));
            }
        } else if (sig == 0x666C || sig == 0x686C) { // "lf" / "lh"
            for (uint16_t k = 0; k < count; ++k) {
                if (0x04 + static_cast<size_t>(k + 1) * 8 > sl.len) break;
                uint32_t child = hive_rd32(sl.data + 0x04 + k * 8);
                HiveCell cnk = hive_cell(hive, child);
                if (!cnk.valid() || cnk.len < 0x4C || hive_rd16(cnk.data) != 0x6B6E) continue;
                uint16_t nlen = hive_rd16(cnk.data + 0x48);
                if (0x4C + static_cast<size_t>(nlen) > cnk.len) continue;
                std::string child_name(reinterpret_cast<const char*>(cnk.data + 0x4C), nlen);
                if (hive_name_iequal(child_name, name)) return child;
            }
        } else if (sig == 0x696C) { // "li"
            for (uint16_t k = 0; k < count; ++k) {
                if (0x04 + static_cast<size_t>(k + 1) * 4 > sl.len) break;
                uint32_t child = hive_rd32(sl.data + 0x04 + k * 4);
                HiveCell cnk = hive_cell(hive, child);
                if (!cnk.valid() || cnk.len < 0x4C || hive_rd16(cnk.data) != 0x6B6E) continue;
                uint16_t nlen = hive_rd16(cnk.data + 0x48);
                if (0x4C + static_cast<size_t>(nlen) > cnk.len) continue;
                std::string child_name(reinterpret_cast<const char*>(cnk.data + 0x4C), nlen);
                if (hive_name_iequal(child_name, name)) return child;
            }
        }
    }
    return 0xFFFFFFFF;
}

// Resolve a backslash separated path from the hive root (0xFFFFFFFF when absent)
uint32_t hive_open_path(const std::vector<uint8_t>& hive, const std::string& path) {
    if (hive.size() < 0x1000 + 0x28) return 0xFFFFFFFF;
    uint32_t current = hive_rd32(&hive[0x24]); // root nk cell offset

    size_t start = 0;
    while (start <= path.size() && current != 0xFFFFFFFF) {
        size_t sep = path.find('\\', start);
        std::string part = (sep == std::string::npos) ? path.substr(start) : path.substr(start, sep - start);
        if (!part.empty()) {
            current = hive_find_subkey(hive, current, part);
        }
        if (sep == std::string::npos) break;
        start = sep + 1;
    }
    return current;
}

// Read a REG_SZ / REG_EXPAND_SZ value from an nk cell as ASCII ("" when absent)
std::string hive_get_string(const std::vector<uint8_t>& hive, uint32_t nk_off, const std::string& value_name) {
    HiveCell nk = hive_cell(hive, nk_off);
    if (!nk.valid() || nk.len < 0x2C || hive_rd16(nk.data) != 0x6B6E) return "";

    uint32_t val_count = hive_rd32(nk.data + 0x24);
    uint32_t vl_off = hive_rd32(nk.data + 0x28);
    if (val_count == 0 || vl_off == 0 || vl_off == 0xFFFFFFFF) return "";

    HiveCell vl = hive_cell(hive, vl_off);
    if (!vl.valid()) return "";

    for (uint32_t i = 0; i < val_count; ++i) {
        if (static_cast<size_t>(i + 1) * 4 > vl.len) break; // value list cell is a bare offset array
        uint32_t vk_off = hive_rd32(vl.data + i * 4);
        HiveCell vk = hive_cell(hive, vk_off);
        if (!vk.valid() || vk.len < 0x14 || hive_rd16(vk.data) != 0x6B76) continue;

        uint16_t nlen = hive_rd16(vk.data + 0x02);
        if (0x14 + static_cast<size_t>(nlen) > vk.len) continue;
        std::string vname(reinterpret_cast<const char*>(vk.data + 0x14), nlen);
        if (!hive_name_iequal(vname, value_name)) continue;

        uint32_t dlen = hive_rd32(vk.data + 0x04);
        uint32_t raw_len = dlen & 0x7FFFFFFF;
        const uint8_t* dptr = nullptr;
        size_t dcap = 0;
        if (dlen & 0x80000000u) {
            if (vk.len < 0x0C) return "";
            dptr = vk.data + 0x08;
            dcap = vk.len - 0x08;
        } else {
            uint32_t doff = hive_rd32(vk.data + 0x08);
            HiveCell dc = hive_cell(hive, doff);
            if (!dc.valid()) return "";
            dptr = dc.data;
            dcap = dc.len;
        }
        if (!dptr || raw_len == 0) return "";
        if (raw_len > dcap) raw_len = static_cast<uint32_t>(dcap);

        std::string out;
        if (raw_len >= 2 && dptr[1] == 0) { // UTF-16LE
            for (uint32_t c = 0; c + 1 < raw_len; c += 2) {
                char ch = static_cast<char>(dptr[c]);
                if (ch == 0) break;
                out.push_back(ch);
            }
        } else {
            for (uint32_t c = 0; c < raw_len; ++c) {
                char ch = static_cast<char>(dptr[c]);
                if (ch == 0) break;
                out.push_back(ch);
            }
        }
        return out;
    }
    return "";
}

// Read a REG_DWORD value from an nk cell (false when absent or not a DWORD)
bool hive_get_dword(const std::vector<uint8_t>& hive, uint32_t nk_off, const std::string& value_name, uint32_t* out) {
    HiveCell nk = hive_cell(hive, nk_off);
    if (!nk.valid() || nk.len < 0x2C || hive_rd16(nk.data) != 0x6B6E) return false;

    uint32_t val_count = hive_rd32(nk.data + 0x24);
    uint32_t vl_off = hive_rd32(nk.data + 0x28);
    if (val_count == 0 || vl_off == 0 || vl_off == 0xFFFFFFFF) return false;

    HiveCell vl = hive_cell(hive, vl_off);
    if (!vl.valid()) return false;

    for (uint32_t i = 0; i < val_count; ++i) {
        if (static_cast<size_t>(i + 1) * 4 > vl.len) break; // value list cell is a bare offset array
        uint32_t vk_off = hive_rd32(vl.data + i * 4);
        HiveCell vk = hive_cell(hive, vk_off);
        if (!vk.valid() || vk.len < 0x14 || hive_rd16(vk.data) != 0x6B76) continue;

        uint16_t nlen = hive_rd16(vk.data + 0x02);
        if (0x14 + static_cast<size_t>(nlen) > vk.len) continue;
        std::string vname(reinterpret_cast<const char*>(vk.data + 0x14), nlen);
        if (!hive_name_iequal(vname, value_name)) continue;

        uint32_t reg_type = hive_rd32(vk.data + 0x0C);
        if (reg_type != 4) return false; // not REG_DWORD

        uint32_t dlen = hive_rd32(vk.data + 0x04);
        uint32_t raw_len = dlen & 0x7FFFFFFF;
        const uint8_t* dptr = nullptr;
        if (dlen & 0x80000000u) {
            if (vk.len < 0x0C || raw_len < 4) return false;
            dptr = vk.data + 0x08;
        } else {
            HiveCell dc = hive_cell(hive, hive_rd32(vk.data + 0x08));
            if (!dc.valid() || dc.len < 4) return false;
            dptr = dc.data;
        }
        if (out) *out = hive_rd32(dptr);
        return true;
    }
    return false;
}

// ---------------------------------------------------------------------------
// Small write helpers. The Stage 15 test deliberately re-corrupts already-armed
// values (dump stack on, paging file present, task offload on, VBoxNetLwf at
// boot-start) and re-arms, which proves the armer *corrects* existing values
// instead of only creating the ones that are missing.
// ---------------------------------------------------------------------------

void hive_wr32(uint8_t* p, uint32_t v) noexcept {
    p[0] = static_cast<uint8_t>(v & 0xFF);
    p[1] = static_cast<uint8_t>((v >> 8) & 0xFF);
    p[2] = static_cast<uint8_t>((v >> 16) & 0xFF);
    p[3] = static_cast<uint8_t>((v >> 24) & 0xFF);
}

// REG_* type of a value (0xFFFFFFFF when the value does not exist)
uint32_t hive_value_type(const std::vector<uint8_t>& hive, uint32_t nk_off, const std::string& value_name) {
    HiveCell nk = hive_cell(hive, nk_off);
    if (!nk.valid() || nk.len < 0x2C || hive_rd16(nk.data) != 0x6B6E) return 0xFFFFFFFF;

    uint32_t val_count = hive_rd32(nk.data + 0x24);
    uint32_t vl_off = hive_rd32(nk.data + 0x28);
    if (val_count == 0 || vl_off == 0 || vl_off == 0xFFFFFFFF) return 0xFFFFFFFF;

    HiveCell vl = hive_cell(hive, vl_off);
    if (!vl.valid()) return 0xFFFFFFFF;

    for (uint32_t i = 0; i < val_count; ++i) {
        if (static_cast<size_t>(i + 1) * 4 > vl.len) break;
        uint32_t vk_off = hive_rd32(vl.data + i * 4);
        HiveCell vk = hive_cell(hive, vk_off);
        if (!vk.valid() || vk.len < 0x14 || hive_rd16(vk.data) != 0x6B76) continue;
        uint16_t nlen = hive_rd16(vk.data + 0x02);
        if (0x14 + static_cast<size_t>(nlen) > vk.len) continue;
        std::string vname(reinterpret_cast<const char*>(vk.data + 0x14), nlen);
        if (!hive_name_iequal(vname, value_name)) continue;
        return hive_rd32(vk.data + 0x0C);
    }
    return 0xFFFFFFFF;
}

// Mutable pointer to a value's vk payload inside an nk cell (nullptr when absent)
uint8_t* hive_vk_ptr(std::vector<uint8_t>& hive, uint32_t nk_off, const std::string& value_name) {
    HiveCell nk = hive_cell(hive, nk_off);
    if (!nk.valid() || nk.len < 0x2C || hive_rd16(nk.data) != 0x6B6E) return nullptr;

    uint32_t val_count = hive_rd32(nk.data + 0x24);
    uint32_t vl_off = hive_rd32(nk.data + 0x28);
    if (val_count == 0 || vl_off == 0 || vl_off == 0xFFFFFFFF) return nullptr;

    HiveCell vl = hive_cell(hive, vl_off);
    if (!vl.valid()) return nullptr;

    for (uint32_t i = 0; i < val_count; ++i) {
        if (static_cast<size_t>(i + 1) * 4 > vl.len) break;
        uint32_t vk_off = hive_rd32(vl.data + i * 4);
        HiveCell vk = hive_cell(hive, vk_off);
        if (!vk.valid() || vk.len < 0x14 || hive_rd16(vk.data) != 0x6B76) continue;
        uint16_t nlen = hive_rd16(vk.data + 0x02);
        if (0x14 + static_cast<size_t>(nlen) > vk.len) continue;
        std::string vname(reinterpret_cast<const char*>(vk.data + 0x14), nlen);
        if (!hive_name_iequal(vname, value_name)) continue;
        return const_cast<uint8_t*>(vk.data);
    }
    return nullptr;
}

// Overwrite a REG_DWORD in place (inline data or heap cell)
bool hive_poke_dword(std::vector<uint8_t>& hive, uint32_t nk_off, const std::string& value_name, uint32_t value) {
    uint8_t* vk = hive_vk_ptr(hive, nk_off, value_name);
    if (!vk) return false;
    if (hive_rd32(vk + 0x04) & 0x80000000u) {
        hive_wr32(vk + 0x08, value);
        return true;
    }
    HiveCell dc = hive_cell(hive, hive_rd32(vk + 0x08));
    if (!dc.valid() || dc.len < 4) return false;
    hive_wr32(const_cast<uint8_t*>(dc.data), value);
    return true;
}

// Overwrite the raw UTF-16 payload of a REG_SZ / REG_MULTI_SZ value in place
// (only when the replacement fits the existing data cell -- no hive allocation).
bool hive_poke_string_data(std::vector<uint8_t>& hive, uint32_t nk_off, const std::string& value_name,
                           const std::vector<uint8_t>& bytes) {
    uint8_t* vk = hive_vk_ptr(hive, nk_off, value_name);
    if (!vk) return false;
    uint32_t dlen = hive_rd32(vk + 0x04);
    if (dlen & 0x80000000u) {
        if (bytes.size() > (dlen & 0x7FFFFFFFu)) return false;
        std::memcpy(vk + 0x08, bytes.data(), bytes.size());
        hive_wr32(vk + 0x04, 0x80000000u | static_cast<uint32_t>(bytes.size()));
        return true;
    }
    HiveCell dc = hive_cell(hive, hive_rd32(vk + 0x08));
    if (!dc.valid() || dc.len < bytes.size()) return false;
    std::memcpy(const_cast<uint8_t*>(dc.data), bytes.data(), bytes.size());
    hive_wr32(vk + 0x04, static_cast<uint32_t>(bytes.size()));
    return true;
}

} // namespace

namespace {
// Advanced properties a "capable" NDIS miniport declares under
// <Index>\Ndi\params\<ParamName>: every anti-flap parameter PnpDriverArmer injects except
// PnPCapabilities, which is a device-instance capability mask PnP reads straight off the
// instance key and is therefore never schema-gated. A synthetic adapter carrying this list
// models a driver whose hardware supports all of them; a partial one models older PHY
// silicon (an RTL8111E Rev 06 does not advertise *EEE).
const std::vector<std::string>& full_anti_flap_ndi_schema() {
    static const std::vector<std::string> params = {
        "EEE", "EnableGreenEthernet", "*PowerSavingMode", "LinkDownPowerSaving",
        "FlowControl", "*FlowControl", "*InterruptModeration",
        "*LsoV2IPv4", "*LsoV2IPv6", "*IPChecksumOffloadIPv4", "*TCPChecksumOffloadIPv4",
        "*UDPChecksumOffloadIPv4", "*TCPChecksumOffloadIPv6", "*UDPChecksumOffloadIPv6",
        "*EEE", "AdvancedEEE", "PowerSavingMode", "ReduceSpeedOnPowerDown",
        "AutoDisableGigabit", "GigaLite", "*WaitAutoNegComplete", "*GreenEthernet",
        "*GigaLite", "*WakeOnMagicPacket", "AutoDisablePhy",
    };
    return params;
}

// The same schema with the listed advanced properties withheld: the miniport does not
// implement them, so PnpDriverArmer must refuse to write them.
std::vector<std::string> ndi_schema_without(std::initializer_list<const char*> excluded) {
    std::vector<std::string> params;
    for (const std::string& name : full_anti_flap_ndi_schema()) {
        bool drop = false;
        for (const char* hidden : excluded) {
            if (name == hidden) {
                drop = true;
                break;
            }
        }
        if (!drop) params.push_back(name);
    }
    return params;
}
} // namespace

void test_pnp_driver_arming_and_offline_registry_injection() {
    std::cout << "[RUN] test_pnp_driver_arming_and_offline_registry_injection\n";

    const std::filesystem::path scratch_dir = "test_scratch_pnp_arming";
    std::error_code ec;
    std::filesystem::remove_all(scratch_dir, ec);
    std::filesystem::create_directories(scratch_dir, ec);

    // 1. Validate critical_boot_services list contains all required storage/network drivers
    const auto& critical_svcs = PnpDriverArmer::critical_boot_services();
    for (const char* expected_driver : {
        "msiscsi", "Tcpip", "NDIS",
        "e1d68x64", "e1r68x64", "e1i68x64", "e2f68", "e1c",
        "rt640x64", "rtump64x64", "rtux64w10",
        "b57nd64a", "k1116x64"
    }) {
        auto it = std::find(critical_svcs.begin(), critical_svcs.end(), expected_driver);
        assert(it != critical_svcs.end());
    }

    // 2. In-memory synthetic hive: ControlSet001 with msiscsi (Start=3), rt640x64 (Start=3), e1d68x64 (Start=2)
    // Note: e2f68, b57nd64a, k1116x64 are absent to test graceful ignoring.
    std::vector<std::pair<std::string, uint32_t>> initial_services = {
        {"msiscsi", 3},
        {"Tcpip", 1},
        {"NDIS", 1},
        {"rt640x64", 3},
        {"e1d68x64", 2}
    };

    auto hive_buf = PnpDriverArmer::create_synthetic_system_hive(1, initial_services);
    assert(hive_buf.size() >= 8192);
    assert(std::memcmp(hive_buf.data(), "regf", 4) == 0);

    // Initial checksum must be valid
    uint32_t initial_csum = PnpDriverArmer::calculate_regf_header_checksum(hive_buf.data());
    uint32_t stored_csum = static_cast<uint32_t>(hive_buf[0x1FC]) |
                           (static_cast<uint32_t>(hive_buf[0x1FD]) << 8) |
                           (static_cast<uint32_t>(hive_buf[0x1FE]) << 16) |
                           (static_cast<uint32_t>(hive_buf[0x1FF]) << 24);
    assert(initial_csum == stored_csum);

    // Arm the in-memory buffer
    auto arm_buf_res = PnpDriverArmer::arm_hive_buffer(hive_buf);
    assert(arm_buf_res.is_ok());
    const auto& report1 = arm_buf_res.value();
    assert(report1.success);
    assert(report1.control_set == "ControlSet001");

    // Verify armed services
    assert(std::find(report1.armed_services.begin(), report1.armed_services.end(), "msiscsi") != report1.armed_services.end());
    assert(std::find(report1.armed_services.begin(), report1.armed_services.end(), "rt640x64") != report1.armed_services.end());
    assert(std::find(report1.armed_services.begin(), report1.armed_services.end(), "e1d68x64") != report1.armed_services.end());
    assert(std::find(report1.armed_services.begin(), report1.armed_services.end(), "Tcpip") != report1.armed_services.end());
    assert(std::find(report1.armed_services.begin(), report1.armed_services.end(), "NDIS") != report1.armed_services.end());

    // Verify modified services telemetry
    assert(std::find(report1.modified_services.begin(), report1.modified_services.end(), "msiscsi") != report1.modified_services.end());
    assert(std::find(report1.modified_services.begin(), report1.modified_services.end(), "rt640x64") != report1.modified_services.end());
    assert(std::find(report1.modified_services.begin(), report1.modified_services.end(), "e1d68x64") != report1.modified_services.end());
    assert(std::find(report1.modified_services.begin(), report1.modified_services.end(), "Tcpip") != report1.modified_services.end());
    assert(std::find(report1.modified_services.begin(), report1.modified_services.end(), "NDIS") != report1.modified_services.end());

    // Verify missing critical services are injected from scratch into the hive
    assert(std::find(report1.injected_services.begin(), report1.injected_services.end(), "e2f68") != report1.injected_services.end());
    assert(std::find(report1.injected_services.begin(), report1.injected_services.end(), "b57nd64a") != report1.injected_services.end());
    assert(std::find(report1.injected_services.begin(), report1.injected_services.end(), "iscsiprt") != report1.injected_services.end());

    // Windows 10/11 boot-critical promotion telemetry (BootFlags + iSCSI stack)
    assert(report1.boot_flags_armed);
    assert(report1.iscsi_stack_armed);

    // Verify safe unmount & transaction hygiene: sequence numbers synchronized and checksum recomputed
    uint32_t pseq = static_cast<uint32_t>(hive_buf[0x04]) | (static_cast<uint32_t>(hive_buf[0x05]) << 8);
    uint32_t sseq = static_cast<uint32_t>(hive_buf[0x08]) | (static_cast<uint32_t>(hive_buf[0x09]) << 8);
    assert(pseq == sseq); // Clean unmount, no dirty log state
    uint32_t new_csum = PnpDriverArmer::calculate_regf_header_checksum(hive_buf.data());
    uint32_t new_stored_csum = static_cast<uint32_t>(hive_buf[0x1FC]) |
                               (static_cast<uint32_t>(hive_buf[0x1FD]) << 8) |
                               (static_cast<uint32_t>(hive_buf[0x1FE]) << 16) |
                               (static_cast<uint32_t>(hive_buf[0x1FF]) << 24);
    assert(new_csum == new_stored_csum);

    // Helper to find UTF-16LE string values within raw hive buffer
    auto find_u16 = [](const std::string& haystack, const std::string& needle) -> bool {
        std::string u16;
        for (char c : needle) {
            u16.push_back(c);
            u16.push_back(0);
        }
        return haystack.find(u16) != std::string::npos;
    };

    // Verify Realtek NIC link-flap prevention parameters were injected into rt640x64\Parameters
    std::string hive_str(reinterpret_cast<const char*>(hive_buf.data()), hive_buf.size());
    assert(hive_str.find("Parameters") != std::string::npos);
    assert(hive_str.find("*EEE") != std::string::npos);
    assert(hive_str.find("*GreenEthernet") != std::string::npos);
    assert(hive_str.find("*GigaLite") != std::string::npos);
    assert(hive_str.find("*WakeOnMagicPacket") != std::string::npos);
    assert(hive_str.find("PowerSavingMode") != std::string::npos);
    assert(hive_str.find("AutoDisablePhy") != std::string::npos);
    assert(find_u16(hive_str, "Boot Bus Extender"));

    // 2b. Test injection of rt640x64 when absent from hive
    {
        auto no_rt_hive = PnpDriverArmer::create_synthetic_system_hive(1, {{"msiscsi", 3}});
        auto no_rt_res = PnpDriverArmer::arm_hive_buffer(no_rt_hive);
        assert(no_rt_res.is_ok());
        const auto& no_rt_rep = no_rt_res.value();
        assert(std::find(no_rt_rep.injected_services.begin(), no_rt_rep.injected_services.end(), "rt640x64") != no_rt_rep.injected_services.end());
        assert(std::find(no_rt_rep.modified_services.begin(), no_rt_rep.modified_services.end(), "msiscsi") != no_rt_rep.modified_services.end());

        // Verify injected parameters for rt640x64 in hive buffer
        std::string s_hive(reinterpret_cast<const char*>(no_rt_hive.data()), no_rt_hive.size());
        assert(s_hive.find("DisplayName") != std::string::npos);
        assert(s_hive.find("ImagePath") != std::string::npos);
        assert(s_hive.find("Group") != std::string::npos);
        assert(find_u16(s_hive, "Realtek RT640 Gigabit Ethernet NIC Driver"));
        assert(find_u16(s_hive, "rt640x64.sys"));
        assert(find_u16(s_hive, "NDIS"));
    }

    // 2c. CriticalDeviceDatabase (CDDB) hardware-ID bindings.
    //     Start = 0 alone does not make pci.sys bind PCI\VEN_xxxx&DEV_xxxx to the NIC driver
    //     during Phase 0 -- the PnP manager needs an explicit device-to-driver association
    //     under Control\<ControlSet>\Control\CriticalDeviceDatabase before the boot volume
    //     comes online, otherwise the boot fails with 0x7B INACCESSIBLE_BOOT_DEVICE.
    const std::string expected_net_guid = "{4d36e972-e325-11ce-bfc1-08002be10318}";
    const std::vector<std::pair<std::string, std::string>> expected_cddb_bindings = {
        {"pci#ven_10ec&dev_8168", "rt640x64"},   // Realtek RTL8168/8111
        {"pci#ven_10ec&cc_0200", "rt640x64"},    // Realtek Ethernet class-code fallback
        {"pci#ven_10ec*", "rt640x64"},           // Realtek generic vendor wildcard fallback
        {"pci#ven_10ec&dev_8169", "rt640x64"},   // Realtek subsystem variant (Acer)
        {"pci#ven_8086&dev_15b8", "e1d68x64"},   // Intel I219/I218
    };
    {
        auto cddb_hive = PnpDriverArmer::create_synthetic_system_hive(1, {{"rt640x64", 3}, {"e1d68x64", 2}});
        auto cddb_res = PnpDriverArmer::arm_hive_buffer(cddb_hive);
        assert(cddb_res.is_ok());
        const auto& cddb_rep = cddb_res.value();
        assert(cddb_rep.success);
        assert(cddb_rep.control_set == "ControlSet001");

        // Telemetry: every injected binding is reported as "<hwid> -> <service>"
        assert(cddb_rep.cddb_bindings.size() == expected_cddb_bindings.size());
        for (const auto& binding : expected_cddb_bindings) {
            std::string desc = binding.first + " -> " + binding.second;
            assert(std::count(cddb_rep.cddb_bindings.begin(), cddb_rep.cddb_bindings.end(), desc) == 1);
        }

        // Structural verification of ControlSet001\Control\CriticalDeviceDatabase
        uint32_t cddb_root = hive_open_path(cddb_hive, "ControlSet001\\Control\\CriticalDeviceDatabase");
        assert(cddb_root != 0xFFFFFFFF);

        for (const auto& binding : expected_cddb_bindings) {
            uint32_t hwid_off = hive_find_subkey(cddb_hive, cddb_root, binding.first);
            assert(hwid_off != 0xFFFFFFFF);
            assert(hive_get_string(cddb_hive, hwid_off, "Service") == binding.second);
            assert(hive_get_string(cddb_hive, hwid_off, "ClassGUID") == expected_net_guid);
        }

        // Negative control: no stray hardware ID bindings were created
        assert(hive_find_subkey(cddb_hive, cddb_root, "pci#ven_10ec&dev_9999") == 0xFFFFFFFF);

        // The whole CriticalDeviceDatabase path must resolve from the hive root
        for (const auto& binding : expected_cddb_bindings) {
            assert(hive_open_path(cddb_hive,
                                  "ControlSet001\\Control\\CriticalDeviceDatabase\\" + binding.first) != 0xFFFFFFFF);
        }

        // Values must be persisted as UTF-16LE REG_SZ data in the raw hive
        std::string cddb_raw(reinterpret_cast<const char*>(cddb_hive.data()), cddb_hive.size());
        assert(find_u16(cddb_raw, expected_net_guid));
        assert(find_u16(cddb_raw, "rt640x64"));

        // Key names are stored as plain ASCII in the hive, with Windows' exact casing
        assert(cddb_raw.find("CriticalDeviceDatabase") != std::string::npos);
        for (const auto& binding : expected_cddb_bindings) {
            assert(cddb_raw.find(binding.first) != std::string::npos);
        }

        // Hive must still be cleanly unmounted after the extra writes
        uint32_t cddb_pseq = static_cast<uint32_t>(cddb_hive[0x04]) | (static_cast<uint32_t>(cddb_hive[0x05]) << 8);
        uint32_t cddb_sseq = static_cast<uint32_t>(cddb_hive[0x08]) | (static_cast<uint32_t>(cddb_hive[0x09]) << 8);
        assert(cddb_pseq == cddb_sseq);
        uint32_t cddb_csum = PnpDriverArmer::calculate_regf_header_checksum(cddb_hive.data());
        uint32_t cddb_stored = static_cast<uint32_t>(cddb_hive[0x1FC]) |
                               (static_cast<uint32_t>(cddb_hive[0x1FD]) << 8) |
                               (static_cast<uint32_t>(cddb_hive[0x1FE]) << 16) |
                               (static_cast<uint32_t>(cddb_hive[0x1FF]) << 24);
        assert(cddb_csum == cddb_stored);
    }

    // 2d. Test driver file staging
    {
        auto test_drivers_dir = scratch_dir / "Windows" / "System32" / "drivers";
        auto test_filerepo_dir = scratch_dir / "Windows" / "System32" / "DriverStore" / "FileRepository" / "rt640x64.inf_amd64_test";
        std::filesystem::create_directories(test_drivers_dir, ec);
        std::filesystem::create_directories(test_filerepo_dir, ec);

        std::ofstream mock_drv(test_filerepo_dir / "rt640x64.sys", std::ios::binary);
        mock_drv << "MOCK_RT640X64_DRIVER_PAYLOAD";
        mock_drv.close();

        std::vector<std::string> stage_warns;
        bool staged = PnpDriverArmer::verify_or_stage_driver_file(test_drivers_dir, "rt640x64.sys", stage_warns);
        assert(staged);
        assert(std::filesystem::exists(test_drivers_dir / "rt640x64.sys", ec));
    }

    // 2e. Windows 10/11 boot-critical promotion: BootFlags (CM_SERVICE_NETWORK_BOOT_LOAD),
    //     the core iSCSI boot stack, and Realtek PHY power-saving suppression.
    //     The CriticalDeviceDatabase is deprecated since Windows 8, so these values are what
    //     prevent 0x7B INACCESSIBLE_BOOT_DEVICE on modern images (CDDB stays as NT5/6 fallback).
    {
        // Seed services with *wrong* boot values to prove they get promoted
        auto flags_hive = PnpDriverArmer::create_synthetic_system_hive(1, {
            {"msiscsi", 3}, {"Tcpip", 3}, {"NDIS", 3}, {"rt640x64", 3}, {"e1d68x64", 2}
        });
        auto flags_res = PnpDriverArmer::arm_hive_buffer(flags_hive);
        assert(flags_res.is_ok());
        const auto& flags_rep = flags_res.value();
        assert(flags_rep.success);

        // Report telemetry requested by the modern iSCSI boot workflow
        assert(flags_rep.boot_flags_armed);
        assert(flags_rep.iscsi_stack_armed);

        // CDDB injection is retained as a legacy NT5/6 fallback
        assert(flags_rep.cddb_bindings.size() == expected_cddb_bindings.size());

        auto dword_at = [&](const std::string& path, const char* value_name) -> uint32_t {
            uint32_t nk = hive_open_path(flags_hive, path);
            assert(nk != 0xFFFFFFFF);
            uint32_t value = 0;
            assert(hive_get_dword(flags_hive, nk, value_name, &value));
            return value;
        };
        auto string_at = [&](const std::string& path, const char* value_name) -> std::string {
            uint32_t nk = hive_open_path(flags_hive, path);
            assert(nk != 0xFFFFFFFF);
            return hive_get_string(flags_hive, nk, value_name);
        };
        auto type_at = [&](const std::string& path, const char* value_name) -> uint32_t {
            uint32_t nk = hive_open_path(flags_hive, path);
            assert(nk != 0xFFFFFFFF);
            return hive_value_type(flags_hive, nk, value_name);
        };

        // 1. BootFlags = 0x1 (REG_DWORD) on every armed network service + the iSCSI stack
        for (const char* svc : {"rt640x64", "e1d68x64", "msiscsi", "Tcpip", "NDIS"}) {
            const std::string base = std::string("ControlSet001\\Services\\") + svc;
            assert(dword_at(base, "BootFlags") == 0x1); // CM_SERVICE_NETWORK_BOOT_LOAD
            assert(dword_at(base, "Start") == 0x0);     // SERVICE_BOOT_START
            assert(dword_at(base, "Type") == 0x1);      // SERVICE_KERNEL_DRIVER
            assert(dword_at(base, "ErrorControl") == 0x1);
        }

        // 2. Core iSCSI boot stack: msiscsi / Tcpip / ndis are boot-start
        assert(dword_at("ControlSet001\\Services\\msiscsi", "Start") == 0x0);
        assert(dword_at("ControlSet001\\Services\\msiscsi", "BootFlags") == 0x1);
        assert(dword_at("ControlSet001\\Services\\Tcpip", "Start") == 0x0);
        assert(dword_at("ControlSet001\\Services\\NDIS", "Start") == 0x0);

        // 3. Load groups: NIC drivers + NDIS sit in NDIS, msiscsi keeps Boot Bus Extender
        assert(string_at("ControlSet001\\Services\\rt640x64", "Group") == "NDIS");
        assert(string_at("ControlSet001\\Services\\e1d68x64", "Group") == "NDIS");
        assert(string_at("ControlSet001\\Services\\msiscsi", "Group") == "Boot Bus Extender");
        assert(string_at("ControlSet001\\Services\\Tcpip", "Group") == "PNP_TDI");

        // 4. Realtek PHY power-saving / link reset disabled.
        //    Every NDIS standardized "*" keyword is written as REG_SZ "0" -- never as a
        //    REG_DWORD -- because NDIS parses it through the miniport's advanced-property
        //    string descriptor at DISPATCH_LEVEL.
        //
        //    The flat key that carries them is the *Intel* service's. The Realtek miniport
        //    parses its hardware configuration from
        //    Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}\<Index> only, so
        //    Services\rt640x64\Parameters is purged (never written) and the mirror that has
        //    to survive for miniports which DO read the driver-level key lands on
        //    e1d68x64 instead.
        assert(hive_open_path(flags_hive, "ControlSet001\\Services\\rt640x64\\Parameters") == 0xFFFFFFFF);
        const std::string rt_params = "ControlSet001\\Services\\e1d68x64\\Parameters";
        assert(hive_open_path(flags_hive, rt_params) != 0xFFFFFFFF);
        for (const char* star_key : {"*EEE", "*FlowControl", "*WaitAutoNegComplete", "*GreenEthernet"}) {
            assert(type_at(rt_params, star_key) == 1 /* REG_SZ */);
            assert(string_at(rt_params, star_key) == "0");
        }
        assert(dword_at(rt_params, "AdvancedEEE") == 0);
        assert(dword_at(rt_params, "PowerSavingMode") == 0);
        assert(dword_at(rt_params, "ReduceSpeedOnPowerDown") == 0);
        assert(dword_at(rt_params, "AutoDisableGigabit") == 0);
        assert(dword_at(rt_params, "GigaLite") == 0);
        assert(dword_at(rt_params, "AutoDisablePhy") == 0);
        assert(dword_at(rt_params, "PnPCapabilities") == 0x00000018);
        assert(string_at(rt_params, "EEE") == "0");
        assert(string_at(rt_params, "LinkDownPowerSaving") == "0");

        // 5. Hive integrity after all of the writes: synchronized sequence numbers + checksum
        uint32_t flags_pseq = static_cast<uint32_t>(flags_hive[0x04]) | (static_cast<uint32_t>(flags_hive[0x05]) << 8);
        uint32_t flags_sseq = static_cast<uint32_t>(flags_hive[0x08]) | (static_cast<uint32_t>(flags_hive[0x09]) << 8);
        assert(flags_pseq == flags_sseq);
        uint32_t flags_csum = PnpDriverArmer::calculate_regf_header_checksum(flags_hive.data());
        uint32_t flags_stored = static_cast<uint32_t>(flags_hive[0x1FC]) |
                                (static_cast<uint32_t>(flags_hive[0x1FD]) << 8) |
                                (static_cast<uint32_t>(flags_hive[0x1FE]) << 16) |
                                (static_cast<uint32_t>(flags_hive[0x1FF]) << 24);
        assert(flags_csum == flags_stored);

        // 6. Round-trip through the on-disk hive path used for real images
        const std::filesystem::path flags_file = scratch_dir / "SYSTEM_BOOTFLAGS";
        {
            std::ofstream ofs(flags_file, std::ios::binary);
            ofs.write(reinterpret_cast<const char*>(flags_hive.data()), flags_hive.size());
        }
        auto flags_file_res = PnpDriverArmer::arm_offline_system_hive(flags_file);
        assert(flags_file_res.is_ok());
        assert(flags_file_res.value().boot_flags_armed);
        assert(flags_file_res.value().iscsi_stack_armed);
        {
            std::ifstream ifs(flags_file, std::ios::binary);
            std::vector<uint8_t> read_back((std::istreambuf_iterator<char>(ifs)), std::istreambuf_iterator<char>());
            uint32_t rt_off = hive_open_path(read_back, "ControlSet001\\Services\\rt640x64");
            assert(rt_off != 0xFFFFFFFF);
            uint32_t boot_flags = 0;
            assert(hive_get_dword(read_back, rt_off, "BootFlags", &boot_flags));
            assert(boot_flags == 0x1);
            uint32_t msi_off = hive_open_path(read_back, "ControlSet001\\Services\\msiscsi");
            assert(msi_off != 0xFFFFFFFF);
            uint32_t msi_flags = 0;
            assert(hive_get_dword(read_back, msi_off, "BootFlags", &msi_flags));
            assert(msi_flags == 0x1);
        }
    }

    // 2f. Realtek Anti-Flap Parameter Injection & CDDB Hardware Binding Test:
    //     Under ControlSet001\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318},
    //     enumerates all adapter subkeys (0000, 0001, 0002, 0003).
    //     Checks DriverDesc ("Realtek", "RTL") and MatchingDeviceId ("VEN_10EC").
    //     Verifies 11 REG_SZ anti-flap + offload-disable parameters injected as "0",
    //     PnPCapabilities=0x18 and *WaitAutoNegComplete=0 (never wait for the PHY).
    //     Verifies Intel adapter is untouched.
    //     Verifies CDDB binding Control\CriticalDeviceDatabase\pci#ven_10ec&dev_8168.
    //     Verifies header sequence numbers and XOR checksum remain valid.
    {
        // Every anti-flap parameter except PnPCapabilities (not an NDIS advanced property)
        // is declared by a "capable" miniport under <Index>\Ndi\params -- that schema is what
        // PnpDriverArmer consults before writing anything into the instance key.
        std::vector<PnpDriverArmer::SyntheticNetAdapter> adapters = {
            {
                "0000",
                "Realtek PCIe GbE Family Controller",
                "PCI\\VEN_10EC&DEV_8168&SUBSYS_123410EC",
                "pci\\ven_10ec&dev_8168",
                full_anti_flap_ndi_schema()
            },
            {
                "0001",
                "RTL8168 Gigabit Ethernet Controller",
                "PCI\\VEN_10EC&DEV_8168",
                "pci\\ven_10ec&dev_8168",
                full_anti_flap_ndi_schema()
            },
            {
                "0002",
                "Ethernet Adapter",
                "PCI\\VEN_10EC&DEV_8169",
                "pci\\ven_10ec&dev_8169",
                full_anti_flap_ndi_schema()
            },
            {
                "0003",
                "Intel(R) Ethernet Connection I219-LM",
                "PCI\\VEN_8086&DEV_15B8",
                "pci\\ven_8086&dev_15b8",
                {}
            }
        };

        auto anti_flap_hive = PnpDriverArmer::create_synthetic_system_hive(
            1,
            {{"msiscsi", 3}, {"rt640x64", 3}, {"Tcpip", 1}, {"NDIS", 1}},
            adapters
        );
        assert(anti_flap_hive.size() >= 8192);

        // Verify initial checksum
        uint32_t init_csum = PnpDriverArmer::calculate_regf_header_checksum(anti_flap_hive.data());
        uint32_t init_stored = hive_rd32(&anti_flap_hive[0x1FC]);
        assert(init_csum == init_stored);

        // Arm the in-memory hive buffer
        auto arm_res = PnpDriverArmer::arm_hive_buffer(anti_flap_hive);
        assert(arm_res.is_ok());
        const auto& rep = arm_res.value();
        assert(rep.success);
        assert(rep.control_set == "ControlSet001");

        // Verify anti-flap parameters (both REG_DWORD and REG_SZ) on matching instances (0000, 0001, 0002)
        // Every NDIS standardized "*" keyword is REG_SZ "0"; only plain vendor keywords and
        // PnPCapabilities stay REG_DWORD.
        const std::vector<std::string> anti_flap_string_keys = {
            "EEE", "EnableGreenEthernet",
            "*PowerSavingMode", "LinkDownPowerSaving",
            "FlowControl", "*InterruptModeration",
            // DMA / TSO / checksum offload disables (ndis.sys 0xD1 during Phase 0)
            "*LsoV2IPv4", "*LsoV2IPv6",
            "*IPChecksumOffloadIPv4", "*TCPChecksumOffloadIPv4", "*UDPChecksumOffloadIPv4",
            // NDIS standardized anti-flap keywords, forced to REG_SZ
            "*EEE", "*FlowControl", "*WaitAutoNegComplete", "*GreenEthernet",
            "*GigaLite", "*WakeOnMagicPacket"
        };
        const std::vector<std::pair<std::string, uint32_t>> anti_flap_dword_keys = {
            {"AdvancedEEE", 0},
            {"PowerSavingMode", 0},
            {"ReduceSpeedOnPowerDown", 0},
            {"AutoDisableGigabit", 0},
            {"GigaLite", 0},
            {"AutoDisablePhy", 0},
            {"PnPCapabilities", 0x00000018},
        };

        for (const char* inst : {"0000", "0001", "0002"}) {
            std::string inst_path = "ControlSet001\\Control\\Class\\{4d36e972-e325-11ce-bfc1-08002be10318}\\" + std::string(inst);
            uint32_t inst_off = hive_open_path(anti_flap_hive, inst_path);
            assert(inst_off != 0xFFFFFFFF);

            for (const auto& key_name : anti_flap_string_keys) {
                std::string val = hive_get_string(anti_flap_hive, inst_off, key_name);
                assert(val == "0");
                assert(hive_value_type(anti_flap_hive, inst_off, key_name) == 1 /* REG_SZ */);
            }

            for (const auto& [dw_name, exp_val] : anti_flap_dword_keys) {
                uint32_t dw_val = 0xFFFFFFFF;
                assert(hive_get_dword(anti_flap_hive, inst_off, dw_name, &dw_val));
                assert(dw_val == exp_val);
                assert(hive_value_type(anti_flap_hive, inst_off, dw_name) == 4 /* REG_DWORD */);
            }
        }

        // The flat driver-level Parameters mirror belongs to e1d68x64 (the miniport that
        // reads it); Services\rt640x64\Parameters is purged, never armed -- see
        // test_boot_conflict_resolution_and_hive_inspection for the same guarantee in a
        // round-trip through the on-disk hive.
        assert(hive_open_path(anti_flap_hive, "ControlSet001\\Services\\rt640x64\\Parameters") == 0xFFFFFFFF);
        uint32_t rt_params_off = hive_open_path(anti_flap_hive, "ControlSet001\\Services\\e1d68x64\\Parameters");
        assert(rt_params_off != 0xFFFFFFFF);
        for (const auto& key_name : anti_flap_string_keys) {
            std::string val = hive_get_string(anti_flap_hive, rt_params_off, key_name);
            assert(val == "0");
            assert(hive_value_type(anti_flap_hive, rt_params_off, key_name) == 1 /* REG_SZ */);
        }
        for (const auto& [dw_name, exp_val] : anti_flap_dword_keys) {
            uint32_t dw_val = 0xFFFFFFFF;
            assert(hive_get_dword(anti_flap_hive, rt_params_off, dw_name, &dw_val));
            assert(dw_val == exp_val);
        }

        // Negative control: instance 0003 (Intel) must NOT have Realtek anti-flap values injected
        {
            std::string intel_path = "ControlSet001\\Control\\Class\\{4d36e972-e325-11ce-bfc1-08002be10318}\\0003";
            uint32_t intel_off = hive_open_path(anti_flap_hive, intel_path);
            assert(intel_off != 0xFFFFFFFF);
            assert(hive_get_string(anti_flap_hive, intel_off, "EEE").empty());
            assert(hive_get_string(anti_flap_hive, intel_off, "LinkDownPowerSaving").empty());
            assert(hive_value_type(anti_flap_hive, intel_off, "*EEE") == 0xFFFFFFFF);
            assert(hive_value_type(anti_flap_hive, intel_off, "PowerSavingMode") == 0xFFFFFFFF);
            assert(hive_value_type(anti_flap_hive, intel_off, "PnPCapabilities") == 0xFFFFFFFF);
        }

        // Verify CDDB hardware binding for Realtek RTL8168
        uint32_t cddb_hw_off = hive_open_path(
            anti_flap_hive,
            "ControlSet001\\Control\\CriticalDeviceDatabase\\pci#ven_10ec&dev_8168"
        );
        assert(cddb_hw_off != 0xFFFFFFFF);
        assert(hive_get_string(anti_flap_hive, cddb_hw_off, "Service") == "rt640x64");
        assert(hive_get_string(anti_flap_hive, cddb_hw_off, "ClassGUID") == "{4d36e972-e325-11ce-bfc1-08002be10318}");

        // Verify hive header sequence numbers and XOR checksum on flush
        uint32_t af_pseq = hive_rd32(&anti_flap_hive[0x04]);
        uint32_t af_sseq = hive_rd32(&anti_flap_hive[0x08]);
        assert(af_pseq == af_sseq);
        uint32_t post_csum = PnpDriverArmer::calculate_regf_header_checksum(anti_flap_hive.data());
        uint32_t post_stored = hive_rd32(&anti_flap_hive[0x1FC]);
        assert(post_csum == post_stored);

        // Offline file roundtrip: arm_offline_system_hive should process this hive on disk cleanly
        const std::filesystem::path test_hive_path = scratch_dir / "SYSTEM_ANTIFLAP";
        {
            std::ofstream out(test_hive_path, std::ios::binary | std::ios::trunc);
            out.write(reinterpret_cast<const char*>(anti_flap_hive.data()), static_cast<std::streamsize>(anti_flap_hive.size()));
            out.flush();
        }

        // Create transaction logs (SYSTEM_ANTIFLAP.LOG1 and LOG2) to test unlinking/truncation
        const std::filesystem::path test_log1 = scratch_dir / "SYSTEM_ANTIFLAP.LOG1";
        const std::filesystem::path test_log2 = scratch_dir / "SYSTEM_ANTIFLAP.LOG2";
        {
            std::ofstream l1(test_log1, std::ios::binary | std::ios::trunc);
            l1.write("DIRTY_LOG_1_DATA", 16);
            std::ofstream l2(test_log2, std::ios::binary | std::ios::trunc);
            l2.write("DIRTY_LOG_2_DATA", 16);
        }
        assert(std::filesystem::exists(test_log1) && std::filesystem::file_size(test_log1) > 0);
        assert(std::filesystem::exists(test_log2) && std::filesystem::file_size(test_log2) > 0);

        auto file_arm_res = PnpDriverArmer::arm_offline_system_hive(test_hive_path);
        assert(file_arm_res.is_ok());

        // Verify that transaction logs were unlinked or truncated to 0 bytes
        std::error_code ec_log;
        bool log1_clean = !std::filesystem::exists(test_log1, ec_log) || std::filesystem::file_size(test_log1, ec_log) == 0;
        bool log2_clean = !std::filesystem::exists(test_log2, ec_log) || std::filesystem::file_size(test_log2, ec_log) == 0;
        assert(log1_clean);
        assert(log2_clean);

        std::vector<uint8_t> file_buf(std::filesystem::file_size(test_hive_path));
        {
            std::ifstream in(test_hive_path, std::ios::binary);
            in.read(reinterpret_cast<char*>(file_buf.data()), static_cast<std::streamsize>(file_buf.size()));
        }
        uint32_t disk_pseq = hive_rd32(&file_buf[0x04]);
        uint32_t disk_sseq = hive_rd32(&file_buf[0x08]);
        assert(disk_pseq == disk_sseq);

        // Verify offset 0x28 (HbinsDataSize) reflects the allocated data size
        uint32_t disk_hbins_size = hive_rd32(&file_buf[0x28]);
        assert(disk_hbins_size == file_buf.size() - 0x1000);

        uint32_t disk_csum = PnpDriverArmer::calculate_regf_header_checksum(file_buf.data());
        uint32_t disk_stored = hive_rd32(&file_buf[0x1FC]);
        assert(disk_csum == disk_stored);

        uint32_t disk_0000 = hive_open_path(file_buf, "ControlSet001\\Control\\Class\\{4d36e972-e325-11ce-bfc1-08002be10318}\\0000");
        assert(disk_0000 != 0xFFFFFFFF);
        // The "*" keywords survive the file round trip as REG_SZ, not REG_DWORD.
        assert(hive_value_type(file_buf, disk_0000, "*EEE") == 1 /* REG_SZ */);
        assert(hive_get_string(file_buf, disk_0000, "*EEE") == "0");
        uint32_t disk_psm = 0xFFFFFFFF;
        assert(hive_get_dword(file_buf, disk_0000, "PowerSavingMode", &disk_psm) && disk_psm == 0);
        assert(hive_value_type(file_buf, disk_0000, "*WaitAutoNegComplete") == 1 /* REG_SZ */);
        assert(hive_get_string(file_buf, disk_0000, "*WaitAutoNegComplete") == "0");
        assert(hive_get_string(file_buf, disk_0000, "LinkDownPowerSaving") == "0");
        assert(hive_get_string(file_buf, disk_0000, "*LsoV2IPv4") == "0");
        assert(hive_get_string(file_buf, disk_0000, "*TCPChecksumOffloadIPv4") == "0");
        assert(hive_get_string(file_buf, disk_0000, "*UDPChecksumOffloadIPv4") == "0");
        uint32_t disk_pnp_caps = 0;
        assert(hive_get_dword(file_buf, disk_0000, "PnPCapabilities", &disk_pnp_caps));
        assert(disk_pnp_caps == 0x00000018);
    }

    // 3. Offline file injection: write synthetic hive to disk and arm
    const std::filesystem::path hive_file = scratch_dir / "SYSTEM";
    {
        auto fresh_hive = PnpDriverArmer::create_synthetic_system_hive(1, initial_services);
        std::ofstream ofs(hive_file, std::ios::binary);
        ofs.write(reinterpret_cast<const char*>(fresh_hive.data()), fresh_hive.size());
    }

    auto arm_file_res = PnpDriverArmer::arm_offline_system_hive(hive_file);
    assert(arm_file_res.is_ok());
    const auto& file_report = arm_file_res.value();
    assert(file_report.success);
    assert(file_report.control_set == "ControlSet001");
    assert(file_report.armed_services.size() >= 5);
    assert(file_report.cddb_bindings.size() == expected_cddb_bindings.size());

    // Read back modified file from disk and verify values in buffer
    {
        std::ifstream ifs(hive_file, std::ios::binary);
        std::vector<uint8_t> read_back((std::istreambuf_iterator<char>(ifs)), std::istreambuf_iterator<char>());
        assert(read_back.size() >= 8192);
        // Header verification
        assert(std::memcmp(read_back.data(), "regf", 4) == 0);
        uint32_t rb_csum = PnpDriverArmer::calculate_regf_header_checksum(read_back.data());
        uint32_t rb_stored = static_cast<uint32_t>(read_back[0x1FC]) |
                             (static_cast<uint32_t>(read_back[0x1FD]) << 8) |
                             (static_cast<uint32_t>(read_back[0x1FE]) << 16) |
                             (static_cast<uint32_t>(read_back[0x1FF]) << 24);
        assert(rb_csum == rb_stored);

        // Sequence numbers match
        uint32_t rb_pseq = static_cast<uint32_t>(read_back[0x04]) | (static_cast<uint32_t>(read_back[0x05]) << 8);
        uint32_t rb_sseq = static_cast<uint32_t>(read_back[0x08]) | (static_cast<uint32_t>(read_back[0x09]) << 8);
        assert(rb_pseq == rb_sseq);

        // CDDB bindings must have survived the round-trip through the on-disk hive
        uint32_t rb_cddb = hive_open_path(read_back, "ControlSet001\\Control\\CriticalDeviceDatabase");
        assert(rb_cddb != 0xFFFFFFFF);
        for (const auto& binding : expected_cddb_bindings) {
            uint32_t rb_hwid = hive_find_subkey(read_back, rb_cddb, binding.first);
            assert(rb_hwid != 0xFFFFFFFF);
            assert(hive_get_string(read_back, rb_hwid, "Service") == binding.second);
            assert(hive_get_string(read_back, rb_hwid, "ClassGUID") == expected_net_guid);
        }
    }

    // 4. Test ControlSet002 resolution via Select\Current = 2
    const std::filesystem::path hive_file2 = scratch_dir / "SYSTEM_CS2";
    {
        auto cs2_hive = PnpDriverArmer::create_synthetic_system_hive(2, {{"msiscsi", 3}, {"rt640x64", 3}});
        std::ofstream ofs(hive_file2, std::ios::binary);
        ofs.write(reinterpret_cast<const char*>(cs2_hive.data()), cs2_hive.size());
    }
    auto cs2_res = PnpDriverArmer::arm_offline_system_hive(hive_file2);
    assert(cs2_res.is_ok());
    assert(cs2_res.value().control_set == "ControlSet002");
    assert(std::find(cs2_res.value().armed_services.begin(), cs2_res.value().armed_services.end(), "msiscsi") != cs2_res.value().armed_services.end());

    // CDDB bindings must be written under the *active* control set (ControlSet002 here),
    // since that is what the kernel aliases as CurrentControlSet at boot
    {
        std::ifstream ifs2(hive_file2, std::ios::binary);
        std::vector<uint8_t> cs2_read_back((std::istreambuf_iterator<char>(ifs2)), std::istreambuf_iterator<char>());
        assert(hive_open_path(cs2_read_back,
                              "ControlSet002\\Control\\CriticalDeviceDatabase\\pci#ven_10ec&dev_8168") != 0xFFFFFFFF);
        assert(hive_open_path(cs2_read_back,
                              "ControlSet002\\Control\\CriticalDeviceDatabase\\pci#ven_8086&dev_15b8") != 0xFFFFFFFF);
        assert(hive_open_path(cs2_read_back,
                              "ControlSet001\\Control\\CriticalDeviceDatabase") == 0xFFFFFFFF);
    }

    // 5. Test Error Handling: Corrupt / truncated hives & checksum recalculation
    // 5a. Verify 0x1FC XOR checksum recalculation
    {
        auto test_hive = PnpDriverArmer::create_synthetic_system_hive(1, {{"msiscsi", 3}});
        uint32_t expected_csum = PnpDriverArmer::calculate_regf_header_checksum(test_hive.data());
        uint32_t initial_stored_csum = hive_rd32(&test_hive[0x1FC]);
        assert(expected_csum == initial_stored_csum);

        // Mutate byte in header (offset 0x40)
        test_hive[0x40] ^= 0x5A;
        uint32_t mutated_csum = PnpDriverArmer::calculate_regf_header_checksum(test_hive.data());
        assert(mutated_csum != expected_csum);

        // Arming must recalculate and update checksum at 0x1FC
        auto arm_res = PnpDriverArmer::arm_hive_buffer(test_hive);
        assert(arm_res.is_ok());
        uint32_t final_csum = PnpDriverArmer::calculate_regf_header_checksum(test_hive.data());
        uint32_t final_stored = hive_rd32(&test_hive[0x1FC]);
        assert(final_csum == final_stored);
    }

    // 5b. Corrupted and malformed hive rejection (zero crash guarantee)
    {
        // Zero-length buffer
        std::vector<uint8_t> empty_buf;
        assert(PnpDriverArmer::arm_hive_buffer(empty_buf).is_err());

        // Buffer smaller than 8192 bytes
        std::vector<uint8_t> small_buf(4096, 0);
        assert(PnpDriverArmer::arm_hive_buffer(small_buf).is_err());

        // Buffer with invalid signature
        std::vector<uint8_t> bad_magic(65536, 0);
        std::memcpy(bad_magic.data(), "bad!", 4);
        assert(PnpDriverArmer::arm_hive_buffer(bad_magic).is_err());

        // Buffer with valid "regf" but invalid hbin signature at 0x1000
        std::vector<uint8_t> bad_hbin(65536, 0);
        std::memcpy(bad_hbin.data(), "regf", 4);
        assert(PnpDriverArmer::arm_hive_buffer(bad_hbin).is_err());

        // Buffer with valid "regf" and "hbin", but corrupted root cell offset
        std::vector<uint8_t> bad_root(65536, 0);
        std::memcpy(bad_root.data(), "regf", 4);
        std::memcpy(&bad_root[0x1000], "hbin", 4);
        write_le32(&bad_root[0x24], 0xFFFFFF00); // Out of bounds root cell
        assert(PnpDriverArmer::arm_hive_buffer(bad_root).is_err());

        // Buffer with valid root cell offset but non-nk signature at root cell
        std::vector<uint8_t> bad_nk(65536, 0);
        std::memcpy(bad_nk.data(), "regf", 4);
        std::memcpy(&bad_nk[0x1000], "hbin", 4);
        write_le32(&bad_nk[0x24], 0x20);
        write_le32(&bad_nk[0x1020], static_cast<uint32_t>(-64)); // allocated cell
        std::memcpy(&bad_nk[0x1024], "xx", 2); // corrupt signature instead of "nk"
        assert(PnpDriverArmer::arm_hive_buffer(bad_nk).is_err());

        // Buffer with valid root nk but missing ControlSet
        auto no_cs_hive = PnpDriverArmer::create_synthetic_system_hive(1, {});
        // Corrupt Select and ControlSet001 names in sublist so ControlSet cannot be resolved
        for (size_t i = 0x1000; i + 13 < no_cs_hive.size(); ++i) {
            if (std::memcmp(&no_cs_hive[i], "ControlSet001", 13) == 0) {
                std::memcpy(&no_cs_hive[i], "CorruptedSet1", 13);
            }
            if (std::memcmp(&no_cs_hive[i], "CurrentControlSet", 17) == 0) {
                std::memcpy(&no_cs_hive[i], "CorruptedSet2    ", 17);
            }
        }
        assert(PnpDriverArmer::arm_hive_buffer(no_cs_hive).is_err());
    }

    const std::filesystem::path corrupt_file = scratch_dir / "CORRUPT_HIVE";
    {
        std::ofstream ofs(corrupt_file, std::ios::binary);
        ofs << "NOT_A_REGF_FILE";
    }
    auto corrupt_res = PnpDriverArmer::arm_offline_system_hive(corrupt_file);
    assert(corrupt_res.is_err());

    auto non_existent_res = PnpDriverArmer::arm_offline_system_hive(scratch_dir / "DOES_NOT_EXIST");
    assert(non_existent_res.is_err());

    // 6. Test automated workflow hooks via ensure_image_armed()
    // Non-VHD / non-Windows image (e.g. .raw) passes through gracefully
    const std::filesystem::path raw_img = scratch_dir / "test.raw";
    {
        std::ofstream ofs(raw_img, std::ios::binary);
        std::vector<char> zeros(1024, 0);
        ofs.write(zeros.data(), zeros.size());
    }
    auto raw_arm_res = PnpDriverArmer::ensure_image_armed(raw_img);
    assert(raw_arm_res.is_ok());
    assert(raw_arm_res.value().success);

    // Direct hive file named SYSTEM also works with ensure_image_armed
    auto sys_arm_res = PnpDriverArmer::ensure_image_armed(hive_file);
    assert(sys_arm_res.is_ok());
    assert(sys_arm_res.value().success);

    std::filesystem::remove_all(scratch_dir, ec);
    std::cout << "  PASS: test_pnp_driver_arming_and_offline_registry_injection\n";
}

void test_dhcp_init_reboot_and_kernel_handoff() {
    std::cout << "[RUN] test_dhcp_init_reboot_and_kernel_handoff\n";

    DhcpServer server(NetworkAddress(192, 168, 1, 1));

    // 1. Simulate Windows 10 kernel dhcpcsvc broadcasting DHCPREQUEST in INIT-REBOOT state
    // ciaddr is 0, Option 50 is requested IP (192.168.1.102), no Option 54 (server identifier), Option 53 = 3
    DhcpHeader req_hdr{};
    req_hdr.op = 1; // BOOTREQUEST
    req_hdr.htype = 1; // Ethernet
    req_hdr.hlen = 6;
    req_hdr.xid = htonl(0x12345678);
    req_hdr.flags = htons(0x8000); // Broadcast bit
    req_hdr.ciaddr = 0; // In INIT-REBOOT state, ciaddr is 0
    req_hdr.chaddr[0] = 0xAA; req_hdr.chaddr[1] = 0xBB; req_hdr.chaddr[2] = 0xCC;
    req_hdr.chaddr[3] = 0x11; req_hdr.chaddr[4] = 0x22; req_hdr.chaddr[5] = 0x33;

    std::vector<uint8_t> req_packet(reinterpret_cast<const uint8_t*>(&req_hdr),
                                    reinterpret_cast<const uint8_t*>(&req_hdr) + sizeof(DhcpHeader));

    // Option 53: DHCPREQUEST (3)
    req_packet.push_back(53); req_packet.push_back(1); req_packet.push_back(3);

    // Option 50: Requested IP = 192.168.1.102
    req_packet.push_back(50); req_packet.push_back(4);
    req_packet.push_back(192); req_packet.push_back(168); req_packet.push_back(1); req_packet.push_back(102);

    // Option 12: Hostname = "WIN10-CLIENT"
    std::string hname = "WIN10-CLIENT";
    req_packet.push_back(12); req_packet.push_back(static_cast<uint8_t>(hname.size()));
    req_packet.insert(req_packet.end(), hname.begin(), hname.end());

    req_packet.push_back(255); // End option

    auto parse_res = DhcpServer::parse_packet(req_packet);
    assert(parse_res.is_ok());
    const auto& opts = parse_res.value();
    assert(opts.message_type == 3);
    assert(opts.requested_ip == NetworkAddress(192, 168, 1, 102));
    assert(opts.client_mac == "AA:BB:CC:11:22:33");
    assert(!opts.is_pxe_client);
    assert(!opts.is_ipxe_client);

    // Build DHCPACK reply for this INIT-REBOOT client
    NetworkAddress ack_ip(192, 168, 1, 102);
    auto reply_res = server.build_reply(req_hdr, opts, 5, ack_ip);
    assert(reply_res.is_ok());

    const auto& reply_bytes = reply_res.value();
    assert(reply_bytes.size() >= sizeof(DhcpHeader));

    const auto* reply_hdr = reinterpret_cast<const DhcpHeader*>(reply_bytes.data());
    assert(reply_hdr->op == 2); // BOOTREPLY
    assert(reply_hdr->xid == req_hdr.xid);
    assert(reply_hdr->flags & htons(0x8000)); // Broadcast flag preserved

    // Verify assigned client IP in yiaddr matches requested IP
    uint8_t expected_yi[4] = {192, 168, 1, 102};
    assert(std::memcmp(&reply_hdr->yiaddr, expected_yi, 4) == 0);

    // Verify file and sname are NOT populated with bootloader for standard OS client
    assert(reply_hdr->file[0] == '\0');

    // Parse reply options and verify essential DHCP network parameters
    auto reply_parse = DhcpServer::parse_packet(reply_bytes);
    assert(reply_parse.is_ok());
    assert(reply_parse.value().message_type == 5); // DHCPACK

    // Scan raw options in reply
    bool found_opt53_ack = false;
    bool found_opt1_mask = false;
    bool found_opt3_router = false;
    bool found_opt6_dns = false;
    bool found_opt51_lease = false;
    bool found_opt67_bootfile = false;

    size_t opt_offset = sizeof(DhcpHeader);
    while (opt_offset < reply_bytes.size()) {
        uint8_t c = reply_bytes[opt_offset++];
        if (c == 0) continue;
        if (c == 255) break;
        if (opt_offset >= reply_bytes.size()) break;
        uint8_t l = reply_bytes[opt_offset++];
        if (opt_offset + l > reply_bytes.size()) break;
        if (c == 53 && l == 1 && reply_bytes[opt_offset] == 5) found_opt53_ack = true;
        if (c == 1 && l == 4) found_opt1_mask = true;
        if (c == 3 && l == 4) found_opt3_router = true;
        if (c == 6 && l == 4) found_opt6_dns = true;
        if (c == 51 && l == 4) found_opt51_lease = true;
        if (c == 67) found_opt67_bootfile = true;
        opt_offset += l;
    }

    assert(found_opt53_ack);
    assert(found_opt1_mask);
    assert(found_opt3_router);
    assert(found_opt6_dns);
    assert(found_opt51_lease);
    assert(!found_opt67_bootfile); // Option 67 omitted for standard OS client!

    // 2. Also verify RENEWING state (ciaddr != 0, unicast flags)
    DhcpHeader renew_hdr = req_hdr;
    renew_hdr.flags = 0; // Unicast
    uint8_t ci_bytes[4] = {192, 168, 1, 102};
    std::memcpy(&renew_hdr.ciaddr, ci_bytes, 4);

    auto renew_reply = server.build_reply(renew_hdr, opts, 5, ack_ip);
    assert(renew_reply.is_ok());
    const auto* renew_reply_hdr = reinterpret_cast<const DhcpHeader*>(renew_reply.value().data());
    assert(std::memcmp(&renew_reply_hdr->ciaddr, ci_bytes, 4) == 0); // Preserved ciaddr
    assert((renew_reply_hdr->flags & htons(0x8000)) == 0); // Unicast flag preserved

    std::cout << "  PASS: test_dhcp_init_reboot_and_kernel_handoff\n";
}

void test_dhcp_option67_raw_wire_integrity() {
    std::cout << "[RUN] test_dhcp_option67_raw_wire_integrity\n";

    DhcpServer server(NetworkAddress(192, 168, 1, 100));
    server.set_subnet_mask(NetworkAddress(255, 255, 255, 0));
    server.set_gateway(NetworkAddress(192, 168, 1, 1));
    server.set_dns(NetworkAddress(192, 168, 1, 1));

    const std::string expected_bootfile = "http://192.168.1.100:18080/boot.ipxe";
    server.set_boot_script_url(expected_bootfile);
    assert(server.boot_script_url() == expected_bootfile);

    // Prepare iPXE client DHCPDISCOVER (Option 175 present)
    DhcpHeader req_hdr{};
    req_hdr.op = 1; // BOOTREQUEST
    req_hdr.htype = 1;
    req_hdr.hlen = 6;
    req_hdr.xid = 0x12345678;
    req_hdr.flags = htons(0x8000);
    req_hdr.magic_cookie[0] = 99; req_hdr.magic_cookie[1] = 130;
    req_hdr.magic_cookie[2] = 83; req_hdr.magic_cookie[3] = 99;
    req_hdr.chaddr[0] = 0xAA; req_hdr.chaddr[1] = 0xBB; req_hdr.chaddr[2] = 0xCC;
    req_hdr.chaddr[3] = 0xDD; req_hdr.chaddr[4] = 0xEE; req_hdr.chaddr[5] = 0xFF;

    DhcpDiscoveredOptions opts{};
    opts.message_type = 1; // Discover
    opts.is_ipxe_client = true;
    opts.client_mac = "AA:BB:CC:DD:EE:FF";

    // 1. Build DHCP OFFER (Type 2)
    auto offer_res = server.build_reply(req_hdr, opts, 2, NetworkAddress(192, 168, 1, 102));
    assert(offer_res.is_ok());
    const auto& offer_bytes = offer_res.value();
    assert(offer_bytes.size() >= 548); // RFC 2131 minimum 548 bytes

    const auto* offer_hdr = reinterpret_cast<const DhcpHeader*>(offer_bytes.data());
    // Verify BOOTP header file field
    assert(std::strcmp(reinterpret_cast<const char*>(offer_hdr->file), expected_bootfile.c_str()) == 0);

    // Locate Option 67 in raw wire bytes
    bool found_opt67 = false;
    size_t opt67_tag_offset = 0;
    size_t opt_offset = sizeof(DhcpHeader);
    while (opt_offset < offer_bytes.size()) {
        uint8_t c = offer_bytes[opt_offset++];
        if (c == 0) continue; // PAD
        if (c == 255) break;  // END
        if (opt_offset >= offer_bytes.size()) break;
        uint8_t l = offer_bytes[opt_offset++];
        if (opt_offset + l > offer_bytes.size()) break;

        if (c == 67) {
            found_opt67 = true;
            opt67_tag_offset = opt_offset - 2;
            assert(l == static_cast<uint8_t>(expected_bootfile.size())); // Must be 36 (0x24)
            std::string actual_url(reinterpret_cast<const char*>(offer_bytes.data() + opt_offset), l);
            assert(actual_url == expected_bootfile);

            // Print hex dump of the Option 67 region to console for wire proof
            std::cout << "  [WIRE PROOF] Option 67 found at packet offset 0x"
                      << std::hex << std::setw(4) << std::setfill('0') << opt67_tag_offset << std::dec << ":\n";
            std::cout << "  Raw bytes (Tag, Len, Value):\n  ";
            for (size_t b = 0; b < static_cast<size_t>(l + 2); ++b) {
                std::cout << std::hex << std::setw(2) << std::setfill('0')
                          << static_cast<int>(offer_bytes[opt67_tag_offset + b]) << " ";
                if ((b + 1) % 16 == 0) std::cout << "\n  ";
            }
            std::cout << std::dec << "\n";
            std::cout << "  Decoded URL: " << actual_url << "\n";
        }
        opt_offset += l;
    }
    assert(found_opt67);

    // Parse with DhcpServer::parse_packet and verify
    auto parsed_offer = DhcpServer::parse_packet(offer_bytes);
    assert(parsed_offer.is_ok());
    assert(parsed_offer.value().bootfile_name == expected_bootfile);

    // 2. Also verify DHCP ACK (Type 5) for iPXE Stage-2
    opts.message_type = 3; // Request
    auto ack_res = server.build_reply(req_hdr, opts, 5, NetworkAddress(192, 168, 1, 102));
    assert(ack_res.is_ok());
    const auto& ack_bytes = ack_res.value();
    auto parsed_ack = DhcpServer::parse_packet(ack_bytes);
    assert(parsed_ack.is_ok());
    assert(parsed_ack.value().bootfile_name == expected_bootfile);

    std::cout << "  PASS: test_dhcp_option67_raw_wire_integrity\n";
}

void test_ipxe_boot_script_rendering_and_wire_integrity() {
    std::cout << "Running test_ipxe_boot_script_rendering_and_wire_integrity...\n";

    // 1. In ipxe_script.hpp: Verify template defaults and explicit options
    {
        // Default options: must use ${next-server} and never emit literal unexpanded ${server_ip}
        ipxe::SanbootOptions def_opts;
        std::string def_script = ipxe::sanboot_script(def_opts);

        assert(!def_script.empty());
        assert(def_script.rfind("#!ipxe", 0) == 0);
        // Verify byte 0 is strictly '#', no BOM, no leading spaces/newlines
        assert(static_cast<uint8_t>(def_script[0]) == 0x23);
        assert(static_cast<uint8_t>(def_script[1]) == 0x21);
        assert(def_script.find("${server_ip}") == std::string::npos);
        assert(def_script.find("${target_iqn}") == std::string::npos);
        assert(def_script.find("set keep-san 1") != std::string::npos);
        assert(def_script.find("sanboot iscsi:${next-server}::::") != std::string::npos);

        // Explicit formatting: replaces %s with actual server IP and target IQN
        ipxe::SanbootOptions custom_opts;
        custom_opts.server_ip = "192.168.1.100";
        custom_opts.target_iqn = "iqn.2026-09.com.cobdiskless:os";
        std::string custom_script = ipxe::sanboot_script(custom_opts);

        const std::string expected_script =
            "#!ipxe\n"
            "set keep-san 1\n"
            "sanboot iscsi:192.168.1.100::::iqn.2026-09.com.cobdiskless:os\n";
        assert(custom_script == expected_script);
        assert(static_cast<uint8_t>(custom_script[0]) == 0x23);
        assert(custom_script.find("${server_ip}") == std::string::npos);
        assert(custom_script.find("${target_iqn}") == std::string::npos);
    }

    // 2. HttpDaemon handle_request("GET", "/boot.ipxe") serves clean SANBoot script
    {
        HttpDaemon daemon(NetworkAddress(127, 0, 0, 1, 0));
        daemon.set_server_ip(NetworkAddress(192, 168, 1, 100));
        daemon.set_target_iqn("iqn.2026-09.com.cobdiskless:os");

        HttpResponse resp = daemon.handle_request("GET", "/boot.ipxe");
        assert(resp.status == 200);
        assert(resp.content_type == "text/plain; charset=utf-8");
        assert(resp.body.rfind("#!ipxe", 0) == 0);
        assert(static_cast<uint8_t>(resp.body[0]) == 0x23);
        assert(resp.body.find("${server_ip}") == std::string::npos);
        assert(resp.body.find("${target_iqn}") == std::string::npos);
        assert(resp.body.find("set keep-san 1") != std::string::npos);
        assert(resp.body.find("sanboot iscsi:192.168.1.100::::iqn.2026-09.com.cobdiskless:os") != std::string::npos);
    }

    // 3. Live Socket test: curl-style GET /boot.ipxe over real TCP socket
    {
        HttpDaemon live_daemon(NetworkAddress(127, 0, 0, 1, 0));
        live_daemon.set_server_ip(NetworkAddress(192, 168, 1, 100));
        live_daemon.set_target_iqn("iqn.2026-09.com.cobdiskless:os");

        auto init_res = live_daemon.initialize();
        assert(init_res.is_ok());
        const uint16_t bound = live_daemon.bound_port();
        assert(bound != 0);

        SOCKET sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        assert(sock != INVALID_SOCKET);

        sockaddr_in srv{};
        srv.sin_family = AF_INET;
        srv.sin_port = htons(bound);
        srv.sin_addr.s_addr = htonl(0x7F000001u); // 127.0.0.1
        assert(connect(sock, reinterpret_cast<sockaddr*>(&srv), sizeof(srv)) == 0);

        const std::string curl_req = "GET /boot.ipxe HTTP/1.1\r\nHost: 127.0.0.1\r\nUser-Agent: curl/8.4.0\r\nAccept: */*\r\n\r\n";
        assert(send(sock, curl_req.c_str(), static_cast<int>(curl_req.size()), 0) == static_cast<int>(curl_req.size()));

        std::string raw_reply;
        char buf[2048];
        for (;;) {
            int n = recv(sock, buf, sizeof(buf), 0);
            if (n <= 0) break;
            raw_reply.append(buf, static_cast<size_t>(n));
        }
        closesocket(sock);

        // Verify status line
        assert(raw_reply.rfind("HTTP/1.1 200 OK\r\n", 0) == 0);

        // Extract body after \r\n\r\n
        const size_t body_pos = raw_reply.find("\r\n\r\n");
        assert(body_pos != std::string::npos);
        const std::string wire_body = raw_reply.substr(body_pos + 4);

        // Verify byte 0 is strictly '#!ipxe'
        assert(wire_body.size() >= 6);
        assert(wire_body[0] == '#');
        assert(wire_body[1] == '!');
        assert(wire_body[2] == 'i');
        assert(wire_body[3] == 'p');
        assert(wire_body[4] == 'x');
        assert(wire_body[5] == 'e');

        // Verify no leading whitespace, newlines, or UTF-8 BOM
        assert(static_cast<uint8_t>(wire_body[0]) == 0x23);

        // Verify content
        assert(wire_body.find("set keep-san 1") != std::string::npos);
        assert(wire_body.find("sanboot iscsi:192.168.1.100::::iqn.2026-09.com.cobdiskless:os") != std::string::npos);
        assert(wire_body.find("${server_ip}") == std::string::npos);
        assert(wire_body.find("${target_iqn}") == std::string::npos);

        live_daemon.shutdown();
    }

    std::cout << "  PASS: test_ipxe_boot_script_rendering_and_wire_integrity\n";
}

// =============================================================================
// WinPE Zero-Touch Hardware Provisioning Pipeline
// =============================================================================

/** @brief Collapses runs of spaces/tabs so column padding never breaks asserts. */
static std::string collapse_whitespace(const std::string& input) {
    std::string out;
    bool pending_space = false;
    for (char c : input) {
        if (c == ' ' || c == '\t') {
            pending_space = true;
            continue;
        }
        if (pending_space && !out.empty()) {
            out += ' ';
        }
        pending_space = false;
        out += c;
    }
    if (pending_space && !out.empty()) {
        out += ' ';
    }
    return out;
}

static void write_text_file(const std::filesystem::path& path, const std::string& content) {
    std::error_code ec;
    std::filesystem::create_directories(path.parent_path(), ec);
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    out.write(content.data(), static_cast<std::streamsize>(content.size()));
}

void test_client_manager_boot_state_machine() {
    std::cout << "[RUN] test_client_manager_boot_state_machine\n";

    const std::filesystem::path conf = "test_boot_clients.conf";
    const std::filesystem::path states = "test_boot_states.json";
    std::error_code ec;
    std::filesystem::remove(conf, ec);
    std::filesystem::remove(states, ec);

    {
        ClientManager mgr(conf);
        mgr.set_boot_state_file(states);

        // A MAC nobody ever PXE-booted has no persisted state yet.
        assert(!mgr.find_boot_state("aa:bb:cc:00:00:01").has_value());
        assert(mgr.boot_state_count() == 0);

        const ClientBootState fresh = mgr.boot_state_for("aa:bb:cc:00:00:01");
        assert(fresh.mac == "AA:BB:CC:00:00:01"); // normalized to uppercase colon form
        assert(fresh.status == ClientBootStatus::Unprofiled);
        assert(to_string(fresh.status) == "UNPROFILED");
        assert(fresh.target_vhd_path.empty());

        // Binding a target persists the first UNPROFILED record.
        const auto assigned = mgr.assign_boot_target(
            "aa:bb:cc:00:00:01", "C:/images/vhd/pc01.vhd",
            "iqn.2026-09.com.cobdiskless:pc01");
        assert(assigned.is_ok());
        assert(assigned.value().status == ClientBootStatus::Unprofiled);
        assert(mgr.boot_state_count() == 1);
        assert(std::filesystem::exists(states));

        // UNPROFILED -> STAGING (what GET /api/boot-script does)
        const auto staging = mgr.begin_staging("aa:bb:cc:00:00:01");
        assert(staging.is_ok());
        assert(staging.value().status == ClientBootStatus::Staging);
        assert(to_string(staging.value().status) == "STAGING");
        assert(mgr.find_boot_state("AA:BB:CC:00:00:01").value().status ==
               ClientBootStatus::Staging);
        assert(mgr.find_boot_state("AA:BB:CC:00:00:01").value().target_iqn ==
               "iqn.2026-09.com.cobdiskless:pc01");

        // STAGING -> READY (what POST /api/client/staged does)
        const auto ready = mgr.complete_staging("aa:bb:cc:00:00:01");
        assert(ready.is_ok());
        assert(ready.value().status == ClientBootStatus::Ready);
        assert(to_string(ready.value().status) == "READY");

        // Replaying the callback is idempotent: READY never regresses.
        const auto replay = mgr.complete_staging("aa:bb:cc:00:00:01");
        assert(replay.is_ok());
        assert(replay.value().status == ClientBootStatus::Ready);

        // Malformed identities are rejected instead of creating garbage records.
        assert(mgr.begin_staging("not-a-mac").is_err());
        assert(mgr.begin_staging("").is_err());
        assert(mgr.assign_boot_target("not-a-mac", "x.vhd", "iqn").is_err());
        assert(mgr.assign_boot_target("aa:bb:cc:00:00:01", "", "iqn").is_err());
        assert(mgr.boot_state_count() == 1);

        assert(mgr.list_boot_states().size() == 1);
        assert(mgr.list_boot_states().front().mac == "AA:BB:CC:00:00:01");
    }

    // JSON persistence round trip through a brand new manager instance.
    {
        ClientManager reloaded(conf);
        reloaded.set_boot_state_file(states);
        assert(reloaded.boot_state_file() == states);

        const auto state = reloaded.find_boot_state("AA:BB:CC:00:00:01");
        assert(state.has_value());
        assert(state->status == ClientBootStatus::Ready);
        assert(state->target_vhd_path.string() ==
               std::filesystem::path("C:/images/vhd/pc01.vhd").string());
        assert(state->target_iqn == "iqn.2026-09.com.cobdiskless:pc01");
        assert(!state->last_seen.empty());
        assert(reloaded.boot_state_count() == 1);
    }

    // Wire spelling round trip.
    assert(parse_client_boot_status("UNPROFILED") == ClientBootStatus::Unprofiled);
    assert(parse_client_boot_status("STAGING") == ClientBootStatus::Staging);
    assert(parse_client_boot_status("READY") == ClientBootStatus::Ready);
    assert(parse_client_boot_status("bogus") == ClientBootStatus::Unprofiled);

    std::filesystem::remove(conf, ec);
    std::filesystem::remove(states, ec);
    std::filesystem::remove("boot_states.json", ec);
    std::cout << "  PASS: test_client_manager_boot_state_machine\n";
}

void test_dynamic_boot_script_router() {
    std::cout << "[RUN] test_dynamic_boot_script_router\n";

    // Builder defaults must reproduce the documented scripts byte for byte.
    assert(ipxe::legacy_mbr_sanboot_script() ==
           "#!ipxe\n"
           "sanhook --drive 0x80 iscsi:${server_ip}::::${target_iqn}\n"
           "sanboot --no-describe\n");

    ipxe::LegacySanbootOptions concrete;
    concrete.server_ip = "192.168.1.10";
    concrete.target_iqn = "iqn.2026-09.com.cobdiskless:os";
    assert(ipxe::legacy_mbr_sanboot_script(concrete) ==
           "#!ipxe\n"
           "sanhook --drive 0x80 iscsi:192.168.1.10::::iqn.2026-09.com.cobdiskless:os\n"
           "sanboot --no-describe\n");

    const std::string expected_wimboot =
        "#!ipxe\n"
        "kernel http://${server_ip}:${port}/static/wim/wimboot\n"
        "initrd http://${server_ip}:${port}/static/wim/bootmgr bootmgr\n"
        "initrd http://${server_ip}:${port}/static/wim/bcd bcd\n"
        "initrd http://${server_ip}:${port}/static/wim/boot.sdi boot.sdi\n"
        "initrd http://${server_ip}:${port}/static/wim/boot.wim boot.wim\n"
        "boot\n";
    assert(collapse_whitespace(ipxe::wimboot_script()) == expected_wimboot);

    ipxe::WimbootOptions bound;
    bound.server_ip = "192.168.1.10";
    bound.port = 18080;
    assert(ipxe::wimboot_script(bound).find("kernel http://192.168.1.10:18080/static/wim/wimboot") !=
           std::string::npos);

    const std::filesystem::path conf = "test_router_clients.conf";
    const std::filesystem::path states = "test_router_states.json";
    std::error_code ec;
    std::filesystem::remove(conf, ec);
    std::filesystem::remove(states, ec);

    auto mgr = std::make_shared<ClientManager>(conf);
    mgr->set_boot_state_file(states);

    // Unbound daemon: keeps ${server_ip} / ${port} verbatim for iPXE to expand.
    HttpDaemon daemon(NetworkAddress(127, 0, 0, 1, 0));
    daemon.set_client_manager(mgr);

    assert(daemon.handle_request("GET", "/api/boot-script").status == 400);
    assert(daemon.handle_request("GET", "/api/boot-script?mac=nope").status == 400);
    assert(daemon.handle_request("POST", "/api/boot-script?mac=aa:bb:cc:00:00:01").status == 405);

    // --- UNPROFILED -> STAGING: wimboot branch -------------------------------
    const HttpResponse first = daemon.handle_request(
        "GET", "/api/boot-script?mac=aa:bb:cc:00:00:01&vendor=PXEClient&device=iPXE");
    assert(first.status == 200);
    assert(first.content_type == ipxe::kScriptContentType);
    assert(first.body.rfind("#!ipxe\n", 0) == 0);
    assert(collapse_whitespace(first.body) == expected_wimboot);
    assert(first.body.find("sanhook") == std::string::npos);
    assert(mgr->find_boot_state("AA:BB:CC:00:00:01").value().status == ClientBootStatus::Staging);

    // A repeat PXE boot while staging serves the identical script (idempotent).
    const HttpResponse second =
        daemon.handle_request("GET", "/api/boot-script?mac=AA:BB:CC:00:00:01");
    assert(second.status == 200);
    assert(second.body == first.body);

    // --- STAGING -> READY: Legacy BIOS SAN boot branch -----------------------
    assert(mgr->assign_boot_target("aa:bb:cc:00:00:01", "test_router_pc01.vhd",
                                   "iqn.2026-09.com.cobdiskless:pc01")
               .is_ok());
    assert(mgr->complete_staging("aa:bb:cc:00:00:01").is_ok());

    const HttpResponse ready =
        daemon.handle_request("GET", "/api/boot-script?mac=aa:bb:cc:00:00:01");
    assert(ready.status == 200);
    assert(ready.body ==
           "#!ipxe\n"
           "sanhook --drive 0x80 iscsi:${server_ip}::::iqn.2026-09.com.cobdiskless:pc01\n"
           "sanboot --no-describe\n");
    assert(ready.body.find("wimboot") == std::string::npos);

    // Another client must not inherit that READY state.
    const HttpResponse other =
        daemon.handle_request("GET", "/api/boot-script?mac=aa:bb:cc:00:00:02");
    assert(other.status == 200);
    assert(collapse_whitespace(other.body) == expected_wimboot);
    assert(mgr->find_boot_state("aa:bb:cc:00:00:02").value().status == ClientBootStatus::Staging);
    assert(mgr->find_boot_state("aa:bb:cc:00:00:01").value().status == ClientBootStatus::Ready);

    // No manager wired up -> honest 503 instead of the wrong script.
    HttpDaemon bare(NetworkAddress(127, 0, 0, 1, 0));
    assert(bare.handle_request("GET", "/api/boot-script?mac=aa:bb:cc:00:00:01").status == 503);

    std::filesystem::remove(conf, ec);
    std::filesystem::remove(states, ec);
    std::filesystem::remove("boot_states.json", ec);
    std::cout << "  PASS: test_dynamic_boot_script_router\n";
}

void test_staged_callback_lifecycle_and_static_assets() {
    std::cout << "[RUN] test_staged_callback_lifecycle_and_static_assets\n";

    std::error_code ec;
    const std::filesystem::path root = "test_stage_assets";
    std::filesystem::remove_all(root, ec);

    // Static asset tree served by GET /static/.
    write_text_file(root / "wim" / "bootmgr", "BOOTMGR-ASSET");
    write_text_file(root / "wim" / "bcd", "BCD-ASSET");
    write_text_file(root / "wim" / "startnet.cmd", "@echo off\r\nwpeinit\r\n");
    {
        std::filesystem::create_directories(root / "wim", ec);
        const std::string big(4 * 1024 * 1024, 'W');
        write_text_file(root / "wim" / "boot.wim", big);
    }

    // Two client targets, each a mounted-volume style directory with a SYSTEM hive.
    auto write_hive = [](const std::filesystem::path& target) {
        const std::filesystem::path hive_path =
            target / "Windows" / "System32" / "config" / "SYSTEM";
        std::filesystem::create_directories(hive_path.parent_path());
        const std::vector<uint8_t> hive = PnpDriverArmer::create_synthetic_system_hive(
            1, {{"msiscsi", 3}, {"Tcpip", 3}, {"NDIS", 3}, {"rt640x64", 3}, {"e1d68x64", 3}});
        std::ofstream ofs(hive_path, std::ios::binary | std::ios::trunc);
        ofs.write(reinterpret_cast<const char*>(hive.data()),
                  static_cast<std::streamsize>(hive.size()));
    };

    const std::filesystem::path pc01 = root / "pc01_vhd";
    const std::filesystem::path pc02 = root / "pc02_vhd";
    const std::filesystem::path pc03 = root / "pc03_vhd";
    write_hive(pc01);
    write_hive(pc02);
    write_hive(pc03);

    const std::filesystem::path conf = "test_stage_clients.conf";
    const std::filesystem::path states = "test_stage_states.json";
    std::filesystem::remove(conf, ec);
    std::filesystem::remove(states, ec);

    auto mgr = std::make_shared<ClientManager>(conf);
    mgr->set_boot_state_file(states);

    HttpDaemon daemon(NetworkAddress(127, 0, 0, 1, 0));
    daemon.set_client_manager(mgr);
    daemon.set_static_root(root);

    int arming_calls = 0;
    std::filesystem::path last_armed;
    daemon.set_hive_arming_function(
        [&](const std::filesystem::path& hive_path) -> Result<PnpDriverArmReport> {
            ++arming_calls;
            last_armed = hive_path;
            return PnpDriverArmer::arm_offline_system_hive(hive_path);
        });

    // --- request validation --------------------------------------------------
    assert(daemon.handle_request("GET", "/api/client/staged").status == 405);
    assert(daemon.handle_request("POST", "/api/client/staged", "").status == 400);
    assert(daemon.handle_request("POST", "/api/client/staged", "not json").status == 400);
    assert(daemon.handle_request("POST", "/api/client/staged", "{}").status == 400);
    assert(daemon.handle_request("POST", "/api/client/staged", "{\"mac\":\"bogus\"}").status == 400);
    assert(arming_calls == 0);

    // --- unknown MAC / missing target ---------------------------------------
    assert(daemon
               .handle_request("POST", "/api/client/staged",
                               "{\"mac\":\"aa:bb:cc:00:00:99\"}")
               .status == 404);
    assert(arming_calls == 0);

    const std::string mac01 = "AA:BB:CC:00:00:01";
    assert(mgr->assign_boot_target(mac01, pc01,
                                   "iqn.2026-09.com.cobdiskless:pc01")
               .is_ok());
    assert(mgr->begin_staging(mac01).is_ok());

    // No target VHD bound -> 404, nothing armed.
    assert(mgr->begin_staging("AA:BB:CC:00:00:77").is_ok());
    assert(daemon
               .handle_request("POST", "/api/client/staged",
                               "{\"mac\":\"aa:bb:cc:00:00:77\"}")
               .status == 404);
    assert(arming_calls == 0);

    // --- happy path ----------------------------------------------------------
    const HttpResponse staged = daemon.handle_request(
        "POST", "/api/client/staged", "{\"mac\":\"aa:bb:cc:00:00:01\"}");
    assert(staged.status == 200);
    assert(staged.content_type.rfind("application/json", 0) == 0);
    const auto staged_json = JsonValue::parse(staged.body);
    assert(staged_json.has_value());
    assert((*staged_json)["status"].as_string() == "READY");
    assert((*staged_json)["armed"].as_bool() == true);

    assert(arming_calls == 1);
    assert(last_armed == pc01 / "Windows" / "System32" / "config" / "SYSTEM");
    assert(mgr->find_boot_state(mac01).value().status == ClientBootStatus::Ready);

    // The handler must leave the hive provably boot-ready:
    // Start=0, BootFlags=0x1, Group=NDIS, Realtek PHY suppression, CDDB bindings.
    {
        std::ifstream ifs(last_armed, std::ios::binary);
        const std::vector<uint8_t> armed_bytes((std::istreambuf_iterator<char>(ifs)),
                                               std::istreambuf_iterator<char>());
        assert(!armed_bytes.empty());

        uint32_t value = 0;
        const uint32_t msi_off = hive_open_path(armed_bytes, "ControlSet001\\Services\\msiscsi");
        assert(msi_off != 0xFFFFFFFF);
        assert(hive_get_dword(armed_bytes, msi_off, "Start", &value) && value == 0);
        assert(hive_get_dword(armed_bytes, msi_off, "BootFlags", &value) && value == 0x1);

        const uint32_t tcp_off = hive_open_path(armed_bytes, "ControlSet001\\Services\\Tcpip");
        assert(tcp_off != 0xFFFFFFFF);
        assert(hive_get_dword(armed_bytes, tcp_off, "Start", &value) && value == 0);

        const uint32_t ndis_off = hive_open_path(armed_bytes, "ControlSet001\\Services\\NDIS");
        assert(ndis_off != 0xFFFFFFFF);
        assert(hive_get_dword(armed_bytes, ndis_off, "Start", &value) && value == 0);

        const uint32_t rt_off = hive_open_path(armed_bytes, "ControlSet001\\Services\\rt640x64");
        assert(rt_off != 0xFFFFFFFF);
        assert(hive_get_dword(armed_bytes, rt_off, "Start", &value) && value == 0);
        assert(hive_get_dword(armed_bytes, rt_off, "BootFlags", &value) && value == 0x1);
        assert(hive_get_string(armed_bytes, rt_off, "Group") == "NDIS");

        const uint32_t e1d_off = hive_open_path(armed_bytes, "ControlSet001\\Services\\e1d68x64");
        assert(e1d_off != 0xFFFFFFFF);
        assert(hive_get_dword(armed_bytes, e1d_off, "Start", &value) && value == 0);

        // Realtek's flat Parameters key is purged, never armed: the anti-flap mirror that
        // must still survive for a miniport that does read the driver-level key lands on
        // e1d68x64 instead.
        const uint32_t rt_params_gone =
            hive_open_path(armed_bytes, "ControlSet001\\Services\\rt640x64\\Parameters");
        assert(rt_params_gone == 0xFFFFFFFF);

        const uint32_t rt_params =
            hive_open_path(armed_bytes, "ControlSet001\\Services\\e1d68x64\\Parameters");
        assert(rt_params != 0xFFFFFFFF);
        assert(hive_value_type(armed_bytes, rt_params, "*EEE") == 1 /* REG_SZ */);
        assert(hive_get_string(armed_bytes, rt_params, "*EEE") == "0");
        assert(hive_get_dword(armed_bytes, rt_params, "PowerSavingMode", &value) && value == 0);
        assert(hive_value_type(armed_bytes, rt_params, "*WaitAutoNegComplete") == 1 /* REG_SZ */);
        assert(hive_get_string(armed_bytes, rt_params, "*WaitAutoNegComplete") == "0");
        assert(hive_get_string(armed_bytes, rt_params, "EEE") == "0");

        const uint32_t cddb =
            hive_open_path(armed_bytes, "ControlSet001\\Control\\CriticalDeviceDatabase");
        assert(cddb != 0xFFFFFFFF);
        assert(hive_find_subkey(armed_bytes, cddb, "pci#ven_10ec&dev_8168") != 0xFFFFFFFF);
        assert(hive_find_subkey(armed_bytes, cddb, "pci#ven_8086&dev_15b8") != 0xFFFFFFFF);
    }

    // Once READY, the router serves the SAN boot branch for this MAC.
    const HttpResponse after_ready =
        daemon.handle_request("GET", "/api/boot-script?mac=aa:bb:cc:00:00:01");
    assert(after_ready.status == 200);
    assert(after_ready.body.find("sanhook --drive 0x80") != std::string::npos);

    // --- arming failure ------------------------------------------------------
    assert(mgr->assign_boot_target("AA:BB:CC:00:00:02", pc02, "iqn.x:pc02").is_ok());
    assert(mgr->begin_staging("AA:BB:CC:00:00:02").is_ok());
    daemon.set_hive_arming_function(
        [](const std::filesystem::path&) -> Result<PnpDriverArmReport> {
            return Error(ErrorCode::IoFailure, "simulated mount failure");
        });

    const HttpResponse arming_failed = daemon.handle_request(
        "POST", "/api/client/staged", "{\"mac\":\"aa:bb:cc:00:00:02\"}");
    assert(arming_failed.status == 500);
    const auto arming_failed_json = JsonValue::parse(arming_failed.body);
    assert(arming_failed_json.has_value());
    assert((*arming_failed_json)["armed"].as_bool() == false);
    assert((*arming_failed_json)["status"].as_string() == "STAGING");
    assert((*arming_failed_json)["error"].as_string().find("simulated mount failure") !=
           std::string::npos);
    // A failed pass must never promote the client to READY.
    assert(mgr->find_boot_state("AA:BB:CC:00:00:02").value().status == ClientBootStatus::Staging);

    // --- verification failure ------------------------------------------------
    assert(mgr->assign_boot_target("AA:BB:CC:00:00:03", pc03, "iqn.x:pc03").is_ok());
    assert(mgr->begin_staging("AA:BB:CC:00:00:03").is_ok());
    daemon.set_hive_arming_function(
        [](const std::filesystem::path&) -> Result<PnpDriverArmReport> {
            PnpDriverArmReport report;
            report.success = true;
            report.boot_flags_armed = false;
            report.iscsi_stack_armed = false;
            report.message = "BootFlags missing";
            return report;
        });

    const HttpResponse unverified = daemon.handle_request(
        "POST", "/api/client/staged", "{\"mac\":\"aa:bb:cc:00:00:03\"}");
    assert(unverified.status == 500);
    const auto unverified_json = JsonValue::parse(unverified.body);
    assert(unverified_json.has_value());
    assert((*unverified_json)["error"].as_string().find("verification failed") !=
           std::string::npos);
    assert(mgr->find_boot_state("AA:BB:CC:00:00:03").value().status == ClientBootStatus::Staging);

    // --- static asset streaming ---------------------------------------------
    const HttpResponse bootmgr = daemon.handle_request("GET", "/static/wim/bootmgr");
    assert(bootmgr.status == 200);
    assert(bootmgr.streams_file());
    assert(bootmgr.body.empty()); // never buffered in memory
    assert(bootmgr.file_size == 13);
    assert(bootmgr.file_path ==
           std::filesystem::weakly_canonical(root / "wim" / "bootmgr"));
    assert(bootmgr.content_type.find("octet-stream") != std::string::npos);
    assert(bootmgr.serialize().find("Content-Length: 13\r\n") != std::string::npos);
    assert(bootmgr.serialize().find("BOOTMGR-ASSET") == std::string::npos);

    const HttpResponse boot_wim = daemon.handle_request("GET", "/static/wim/boot.wim");
    assert(boot_wim.status == 200);
    assert(boot_wim.streams_file());
    assert(boot_wim.body.empty());
    assert(boot_wim.file_size == 4 * 1024 * 1024);
    assert(boot_wim.serialize_headers().find("Content-Length: 4194304\r\n") != std::string::npos);

    const HttpResponse bcd = daemon.handle_request("GET", "/static/wim/bcd");
    assert(bcd.status == 200);
    assert(bcd.content_type.find("octet-stream") != std::string::npos);

    // Text assets keep a usable content type for browser-side inspection.
    const HttpResponse startnet = daemon.handle_request("GET", "/static/wim/startnet.cmd");
    assert(startnet.status == 200);
    assert(startnet.content_type.find("text/plain") != std::string::npos);
    assert(startnet.file_size == 20);

    // Path traversal and other misses stay 404; non-GET stays 405.
    assert(daemon.handle_request("GET", "/static/../test_stage_clients.conf").status == 404);
    assert(daemon.handle_request("GET", "/static/wim/../../clients.conf").status == 404);
    assert(daemon.handle_request("GET", "/static/missing.bin").status == 404);
    assert(daemon.handle_request("POST", "/static/wim/bootmgr").status == 405);

    HttpDaemon no_root(NetworkAddress(127, 0, 0, 1, 0));
    assert(no_root.handle_request("GET", "/static/wim/bootmgr").status == 404);

    std::filesystem::remove(conf, ec);
    std::filesystem::remove(states, ec);
    std::filesystem::remove("boot_states.json", ec);
    std::filesystem::remove_all(root, ec);
    std::cout << "  PASS: test_staged_callback_lifecycle_and_static_assets\n";
}

void test_live_static_stream_and_staged_post() {
    std::cout << "[RUN] test_live_static_stream_and_staged_post\n";

#if defined(_WIN32)
    WSADATA wsa{};
    assert(WSAStartup(MAKEWORD(2, 2), &wsa) == 0);
#endif

    std::error_code ec;
    const std::filesystem::path root = "test_live_assets";
    std::filesystem::remove_all(root, ec);

    // Large enough that serving it forces several 64 KiB chunks through the
    // socket loop - the whole point of streaming boot.wim instead of buffering.
    const size_t blob_size = 512 * 1024;
    {
        std::filesystem::create_directories(root / "wim", ec);
        std::vector<char> blob(blob_size);
        for (size_t i = 0; i < blob_size; ++i) {
            blob[i] = static_cast<char>(i & 0xFF);
        }
        std::ofstream out(root / "wim" / "blob.bin", std::ios::binary | std::ios::trunc);
        out.write(blob.data(), static_cast<std::streamsize>(blob.size()));
    }

    const std::filesystem::path vhd_target = root / "pc_live_vhd";
    {
        const std::filesystem::path hive_path =
            vhd_target / "Windows" / "System32" / "config" / "SYSTEM";
        std::filesystem::create_directories(hive_path.parent_path(), ec);
        const std::vector<uint8_t> hive = PnpDriverArmer::create_synthetic_system_hive(
            1, {{"msiscsi", 3}, {"Tcpip", 3}, {"NDIS", 3}, {"rt640x64", 3}, {"e1d68x64", 3}});
        std::ofstream ofs(hive_path, std::ios::binary | std::ios::trunc);
        ofs.write(reinterpret_cast<const char*>(hive.data()),
                  static_cast<std::streamsize>(hive.size()));
    }

    const std::filesystem::path conf = "test_live_stage.conf";
    const std::filesystem::path states = "test_live_stage.json";
    std::filesystem::remove(conf, ec);
    std::filesystem::remove(states, ec);

    auto mgr = std::make_shared<ClientManager>(conf);
    mgr->set_boot_state_file(states);

    HttpDaemon daemon(NetworkAddress(127, 0, 0, 1, 0));
    daemon.set_client_manager(mgr);
    daemon.set_static_root(root);
    assert(daemon.initialize().is_ok());
    assert(daemon.is_listening());
    const uint16_t port = daemon.bound_port();
    assert(port != 0);

    sockaddr_in server_addr{};
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = htonl(0x7F000001u); // 127.0.0.1

    auto exchange = [&](const std::string& request) -> std::string {
        SOCKET sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        assert(sock != INVALID_SOCKET);
        assert(connect(sock, reinterpret_cast<sockaddr*>(&server_addr), sizeof(server_addr)) == 0);
        assert(send(sock, request.c_str(), static_cast<int>(request.size()), 0) ==
               static_cast<int>(request.size()));

        std::string reply;
        char buffer[8192];
        for (;;) {
            const int n = recv(sock, buffer, sizeof(buffer), 0);
            if (n <= 0) {
                break;
            }
            reply.append(buffer, static_cast<size_t>(n));
        }
        closesocket(sock);
        return reply;
    };

    const auto split_body = [](const std::string& reply) -> std::string {
        assert(reply.rfind("HTTP/1.1 200 OK\r\n", 0) == 0);
        const size_t header_end = reply.find("\r\n\r\n");
        assert(header_end != std::string::npos);
        return reply.substr(header_end + 4);
    };

    // --- streamed static asset ---------------------------------------------
    const std::string asset_reply = exchange("GET /static/wim/blob.bin HTTP/1.1\r\n"
                                             "Host: 127.0.0.1\r\n\r\n");
    assert(asset_reply.rfind("HTTP/1.1 200 OK\r\n", 0) == 0);
    assert(asset_reply.find("Content-Length: 524288\r\n") != std::string::npos);
    assert(asset_reply.find("Content-Type: application/octet-stream") != std::string::npos);
    const std::string asset_body = split_body(asset_reply);
    assert(asset_body.size() == blob_size);
    assert(asset_body.front() == static_cast<char>(0x00));
    assert(asset_body[5000] == static_cast<char>(5000 & 0xFF));
    assert(asset_body.back() == static_cast<char>((blob_size - 1) & 0xFF));

    // --- HEAD: same headers, no payload --------------------------------------
    const std::string head_reply = exchange("HEAD /static/wim/blob.bin HTTP/1.1\r\n"
                                            "Host: 127.0.0.1\r\n\r\n");
    assert(head_reply.rfind("HTTP/1.1 200 OK\r\n", 0) == 0);
    assert(head_reply.find("Content-Length: 524288\r\n") != std::string::npos);
    const size_t head_header_end = head_reply.find("\r\n\r\n");
    assert(head_header_end != std::string::npos);
    assert(head_reply.size() == head_header_end + 4);

    // --- POST /api/client/staged with a real Content-Length body -------------
    assert(mgr->assign_boot_target("AA:BB:CC:00:00:01", vhd_target, "iqn.2026-09.live").is_ok());
    assert(mgr->begin_staging("AA:BB:CC:00:00:01").is_ok());
    assert(mgr->find_boot_state("AA:BB:CC:00:00:01").value().status == ClientBootStatus::Staging);

    const std::string json_body = "{\"mac\":\"aa:bb:cc:00:00:01\"}";
    const std::string post_request =
        "POST /api/client/staged HTTP/1.1\r\n"
        "Host: 127.0.0.1\r\n"
        "Content-Type: application/json\r\n"
        "Content-Length: " +
        std::to_string(json_body.size()) + "\r\n" +
        "\r\n" + json_body;

    const std::string post_reply = exchange(post_request);
    assert(post_reply.rfind("HTTP/1.1 200 OK\r\n", 0) == 0);
    assert(post_reply.find("Content-Type: application/json") != std::string::npos);
    const std::string post_body = split_body(post_reply);
    assert(post_body.find("\"READY\"") != std::string::npos);
    assert(post_body.find("\"armed\":true") != std::string::npos);
    assert(mgr->find_boot_state("AA:BB:CC:00:00:01").value().status == ClientBootStatus::Ready);

    // The armed hive really made it to disk behind the HTTP layer.
    const auto armed_state = mgr->find_boot_state("AA:BB:CC:00:00:01");
    assert(armed_state.has_value());
    assert(std::filesystem::is_regular_file(
        vhd_target / "Windows" / "System32" / "config" / "SYSTEM"));

    // --- READY client now receives the SAN boot script -----------------------
    const std::string boot_reply =
        exchange("GET /api/boot-script?mac=aa:bb:cc:00:00:01 HTTP/1.1\r\n"
                 "Host: 127.0.0.1\r\n\r\n");
    assert(boot_reply.rfind("HTTP/1.1 200 OK\r\n", 0) == 0);
    assert(boot_reply.find("sanhook --drive 0x80") != std::string::npos);
    assert(boot_reply.find("wimboot") == std::string::npos);

    daemon.shutdown();

    std::filesystem::remove(conf, ec);
    std::filesystem::remove(states, ec);
    std::filesystem::remove("boot_states.json", ec);
    std::filesystem::remove_all(root, ec);
    std::cout << "  PASS: test_live_static_stream_and_staged_post\n";
}

// ===========================================================================
// Regression tests for the 0x7B (INACCESSIBLE_BOOT_DEVICE) audit.
// ===========================================================================

// Issue 1 -- One logical session is shared by every TCP connection that dials
// the same initiator/IP: iPXE keeps its original connection open and idle while
// Windows' msiscsi initiator opens a brand new one against the same target and
// LUN. get_or_create_session() hands both connections the SAME ClientSession,
// so teardown must be driven by a connection refcount rather than by whichever
// socket happens to close first.
void test_iscsi_shared_session_connection_refcount() {
    std::cout << "[RUN] test_iscsi_shared_session_connection_refcount\n";

    const std::filesystem::path test_dir = "./test_scratch_shared_session";
    const std::filesystem::path base_path = test_dir / "golden_os.raw";
    const std::filesystem::path wb_dir = test_dir / "wb";

    std::error_code ec;
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(wb_dir, ec);

    {
        std::ofstream base_out(base_path, std::ios::binary);
        std::vector<uint8_t> data(1024 * 1024, 0x33);
        base_out.write(reinterpret_cast<const char*>(data.data()), static_cast<std::streamsize>(data.size()));
    }

    Configuration cfg;
    cfg.set_os_images_dir(test_dir);
    cfg.set_writeback_dir(wb_dir);

    auto registry = std::make_shared<GoldenImageRegistry>();
    auto img_mgr = std::make_shared<ImageManager>(registry);
    img_mgr->configure(cfg);
    assert(img_mgr->import_image(base_path, ImageRole::OsImage, ImageId("os_image")).is_ok());

    auto sess_mgr = std::make_shared<ClientSessionManager>(img_mgr, wb_dir);

    IscsiTargetConfig target_cfg;
    target_cfg.default_os_image_id = ImageId("os_image");
    IscsiTarget target(target_cfg, sess_mgr);

    ClientId client_id("AA:BB:CC:00:00:10");
    auto first = sess_mgr->get_or_create_session(
        client_id, NetworkAddress(192, 168, 1, 210), ImageId("os_image"));
    assert(first.is_ok());
    auto ipxe_conn = first.value();

    // msiscsi dials a second connection for the same target/LUN and must be
    // handed the very same session -- one initiator, one overlay, not two.
    auto second = sess_mgr->get_or_create_session(
        client_id, NetworkAddress(192, 168, 1, 210), ImageId("os_image"));
    assert(second.is_ok());
    auto msiscsi_conn = second.value();
    assert(msiscsi_conn.get() == ipxe_conn.get());

    // Both connections attach, exactly as handle_client_connection() now does.
    assert(target.retain_session_connection(ipxe_conn) == 1);
    assert(target.retain_session_connection(msiscsi_conn) == 2);
    assert(target.session_connection_count(ipxe_conn) == 2);
    assert(target.session_connection_count(msiscsi_conn) == 2);

    // iPXE's connection goes away first (idle watchdog or TCP FIN). The session
    // has to stay alive for the connection Windows is still booting from.
    assert(target.release_session_connection(ipxe_conn) == 1);
    assert(sess_mgr->find_session(client_id) != nullptr);
    assert(msiscsi_conn->state() != ClientState::Offline);

    // ...and that surviving connection can still read the boot volume. Under the
    // old unconditional terminate_session() this is the read that failed, because
    // the overlay had been close()d + purge()d and the image released underneath it.
    std::vector<std::byte> buf(512, std::byte{0});
    auto still_reads = IscsiTarget::execute_read(*msiscsi_conn, 40, 1, buf);
    assert(still_reads.is_ok());
    assert(still_reads.value() == 512);
    assert(std::to_integer<int>(buf[0]) == 0x33);

    // Last connection out tears the session down as before.
    assert(target.release_session_connection(msiscsi_conn) == 0);
    assert(target.session_connection_count(ipxe_conn) == 0);
    assert(sess_mgr->terminate_session(client_id).is_ok());
    assert(sess_mgr->find_session(client_id) == nullptr);

    // Negative control -- what the previous unconditional terminate_session() did
    // to a connection that was still mid-boot. terminate_session() close()s the
    // overlay (WritebackContext::is_open_ -> false), purges the writeback file and
    // erases the session, so the SURVIVING connection's next READ fails with
    // "Device not open" instead of returning sectors: CHECK CONDITION at the
    // initiator -> INACCESSIBLE_BOOT_DEVICE (0x7B) after winload.exe.
    auto zombie_read = IscsiTarget::execute_read(*msiscsi_conn, 40, 1, buf);
    assert(!zombie_read.is_ok());

    // Unattached sessions (refcount never taken) keep the original semantics.
    auto orphan = sess_mgr->get_or_create_session(
        ClientId("AA:BB:CC:00:00:11"), NetworkAddress(192, 168, 1, 211), ImageId("os_image"));
    assert(orphan.is_ok());
    assert(target.session_connection_count(orphan.value()) == 0);
    assert(target.release_session_connection(orphan.value()) == 0);
    assert(sess_mgr->terminate_session(ClientId("AA:BB:CC:00:00:11")).is_ok());

    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_iscsi_shared_session_connection_refcount\n";
}

// Issue 3 -- A hive Windows leaves dirty (Fast Startup / hiberboot / crash)
// carries mismatched REGF sequence numbers, which is exactly the condition
// under which the NT hive loader replays SYSTEM.LOG1/.LOG2 over the file. The
// armer has to detect that state and force the header clean on flush, otherwise
// the offline driver-arming changes are rolled back during kernel Phase 0.
void test_offline_hive_dirty_detection_and_clean_flush() {
    std::cout << "[RUN] test_offline_hive_dirty_detection_and_clean_flush\n";

    auto put_le32 = [](std::vector<uint8_t>& buf, size_t off, uint32_t v) {
        buf[off + 0] = static_cast<uint8_t>(v & 0xFFu);
        buf[off + 1] = static_cast<uint8_t>((v >> 8) & 0xFFu);
        buf[off + 2] = static_cast<uint8_t>((v >> 16) & 0xFFu);
        buf[off + 3] = static_cast<uint8_t>((v >> 24) & 0xFFu);
    };
    auto get_le32 = [](const std::vector<uint8_t>& buf, size_t off) -> uint32_t {
        return static_cast<uint32_t>(buf[off]) |
               (static_cast<uint32_t>(buf[off + 1]) << 8) |
               (static_cast<uint32_t>(buf[off + 2]) << 16) |
               (static_cast<uint32_t>(buf[off + 3]) << 24);
    };
    auto mentions = [](const std::vector<std::string>& haystack, const std::string& needle) {
        return std::any_of(haystack.begin(), haystack.end(),
                           [&](const std::string& s) { return s.find(needle) != std::string::npos; });
    };

    const std::vector<std::pair<std::string, uint32_t>> initial_services = {
        {"msiscsi", 3}, {"Tcpip", 1}, {"NDIS", 1}, {"rt640x64", 3}, {"e1d68x64", 2}};

    // 1. A clean hive must not be reported as dirty or as having been cleaned.
    auto clean_hive = PnpDriverArmer::create_synthetic_system_hive(1, initial_services);
    assert(get_le32(clean_hive, 0x04) == get_le32(clean_hive, 0x08));
    auto clean_res = PnpDriverArmer::arm_hive_buffer(clean_hive);
    assert(clean_res.is_ok());
    assert(clean_res.value().hive_dirty_on_entry == false);
    assert(clean_res.value().hive_cleaned_on_exit == false);
    assert(get_le32(clean_hive, 0x04) == get_le32(clean_hive, 0x08));

    // 2. Same hive forced dirty the way Fast Startup leaves it.
    auto dirty_hive = PnpDriverArmer::create_synthetic_system_hive(1, initial_services);
    put_le32(dirty_hive, 0x04, 7); // Primary Sequence Number
    put_le32(dirty_hive, 0x08, 5); // Secondary Sequence Number
    assert(get_le32(dirty_hive, 0x04) != get_le32(dirty_hive, 0x08));

    auto dirty_res = PnpDriverArmer::arm_hive_buffer(dirty_hive);
    assert(dirty_res.is_ok());
    const auto& rep = dirty_res.value();
    assert(rep.hive_dirty_on_entry == true);
    assert(rep.hive_cleaned_on_exit == true);
    assert(mentions(rep.warnings, "dirty on entry"));

    // The flushed header must be clean again -- Primary == Secondary is the only
    // thing that stops HvLoadHive from replaying the transaction logs.
    const uint32_t prim_after = get_le32(dirty_hive, 0x04);
    const uint32_t sec_after = get_le32(dirty_hive, 0x08);
    assert(prim_after == sec_after);
    assert(prim_after > 7);
    assert(PnpDriverArmer::calculate_regf_header_checksum(dirty_hive.data()) ==
           get_le32(dirty_hive, 0x1FC));

    // ...and the arming still actually happened.
    assert(std::find(rep.armed_services.begin(), rep.armed_services.end(), "msiscsi") !=
           rep.armed_services.end());
    assert(rep.hive_dirty_on_entry && !rep.control_set.empty());

    // 3. File-level path: dirty hive sitting next to a non-empty SYSTEM.LOG1.
    const std::filesystem::path scratch = "test_scratch_dirty_hive";
    std::error_code ec;
    std::filesystem::remove_all(scratch, ec);
    std::filesystem::create_directories(scratch, ec);
    const std::filesystem::path hive_path = scratch / "SYSTEM";
    {
        auto on_disk = PnpDriverArmer::create_synthetic_system_hive(1, initial_services);
        put_le32(on_disk, 0x04, 12);
        put_le32(on_disk, 0x08, 9);
        std::ofstream out(hive_path, std::ios::binary | std::ios::trunc);
        out.write(reinterpret_cast<const char*>(on_disk.data()),
                  static_cast<std::streamsize>(on_disk.size()));
    }
    {
        std::ofstream log(scratch / "SYSTEM.LOG1", std::ios::binary | std::ios::trunc);
        log << "stale fast-startup log records";
    }

    auto file_res = PnpDriverArmer::arm_offline_system_hive(hive_path);
    assert(file_res.is_ok());
    assert(file_res.value().hive_dirty_on_entry == true);
    assert(mentions(file_res.value().warnings, "SYSTEM.LOG1"));

    // The bytes actually written to disk must be clean.
    {
        std::ifstream in(hive_path, std::ios::binary);
        std::vector<uint8_t> header(0x200, 0);
        in.read(reinterpret_cast<char*>(header.data()), static_cast<std::streamsize>(header.size()));
        assert(in.gcount() == static_cast<std::streamsize>(header.size()));
        assert(get_le32(header, 0x04) == get_le32(header, 0x08));
        assert(get_le32(header, 0x04) > 12);
    }

    std::filesystem::remove_all(scratch, ec);
    std::cout << "  PASS: test_offline_hive_dirty_detection_and_clean_flush\n";
}

void test_dhcp_zero_config_boot_and_raw_logging() {
    std::cout << "[RUN] test_dhcp_zero_config_boot_and_raw_logging\n";
    std::error_code ec;
    std::filesystem::path test_dir = "test_zero_config_env";
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);

    // 1. Synthesize a Fixed VHD base image (128 KB)
    std::filesystem::path vhd_file = test_dir / "golden_win10.vhd";
    uint64_t v_size = 128 * 1024;
    {
        std::ofstream out(vhd_file, std::ios::binary);
        std::vector<uint8_t> data(v_size, 0xAA);
        out.write(reinterpret_cast<const char*>(data.data()), static_cast<std::streamsize>(data.size()));

        std::vector<uint8_t> footer(512, 0);
        std::memcpy(footer.data(), "conectix", 8);
        footer[0x3C] = 0; footer[0x3D] = 0; footer[0x3E] = 0; footer[0x3F] = 2; // Fixed
        for (int i = 0; i < 8; ++i) {
            footer[0x30 + i] = static_cast<uint8_t>((v_size >> ((7 - i) * 8)) & 0xFF);
        }
        uint32_t sum = 0;
        for (size_t i = 0; i < 512; ++i) sum += footer[i];
        uint32_t csum = ~sum;
        footer[64] = static_cast<uint8_t>((csum >> 24) & 0xFF);
        footer[65] = static_cast<uint8_t>((csum >> 16) & 0xFF);
        footer[66] = static_cast<uint8_t>((csum >> 8) & 0xFF);
        footer[67] = static_cast<uint8_t>(csum & 0xFF);
        out.write(reinterpret_cast<const char*>(footer.data()), 512);
    }

    // 2. Setup GoldenImageRegistry and ImageManager
    auto reg = std::make_shared<GoldenImageRegistry>();
    auto img_mgr = std::make_shared<ImageManager>(reg);
    Configuration cfg;
    cfg.set_os_images_dir(test_dir);
    img_mgr->configure(cfg);
    auto import_res = img_mgr->import_image(vhd_file, ImageRole::OsImage, ImageId("golden_win10"));
    assert(import_res.is_ok());
    img_mgr->set_default_os_image_id("golden_win10");

    // 3. Setup ClientManager with empty client list
    std::filesystem::path client_conf = test_dir / "clients.conf";
    auto client_mgr = std::make_shared<ClientManager>(client_conf);
    client_mgr->set_dhcp_pool_range(NetworkAddress(192, 168, 1, 100), NetworkAddress(192, 168, 1, 200));
    assert(client_mgr->client_count() == 0);

    // 4. Setup DhcpServer with ClientManager and ImageManager
    DhcpServer dhcp(
        NetworkAddress(192, 168, 1, 1),
        NetworkAddress(255, 255, 255, 0),
        NetworkAddress(192, 168, 1, 100),
        NetworkAddress(192, 168, 1, 200)
    );
    dhcp.set_client_manager(client_mgr);
    dhcp.set_image_manager(img_mgr);
    dhcp.set_gateway(NetworkAddress(192, 168, 1, 1));
    dhcp.set_dns_server(NetworkAddress(1, 1, 1, 1));

    // 5. Test Case 1: Arbitrary Realtek NIC MAC (Acer 2660) with UEFI x64 Arch (Option 93 = 7)
    std::string acer_mac = "00:E0:4C:68:01:23";
    DhcpHeader acer_hdr{};
    acer_hdr.op = 1;
    acer_hdr.htype = 1;
    acer_hdr.hlen = 6;
    acer_hdr.xid = htonl(0x41434552); // "ACER"
    acer_hdr.flags = htons(0x8000);
    acer_hdr.magic_cookie[0] = 99; acer_hdr.magic_cookie[1] = 130;
    acer_hdr.magic_cookie[2] = 83; acer_hdr.magic_cookie[3] = 99;
    acer_hdr.chaddr[0] = 0x00; acer_hdr.chaddr[1] = 0xE0; acer_hdr.chaddr[2] = 0x4C;
    acer_hdr.chaddr[3] = 0x68; acer_hdr.chaddr[4] = 0x01; acer_hdr.chaddr[5] = 0x23;

    std::vector<uint8_t> acer_pkt(reinterpret_cast<const uint8_t*>(&acer_hdr),
                                  reinterpret_cast<const uint8_t*>(&acer_hdr) + sizeof(DhcpHeader));
    // Option 53: DHCPDISCOVER (1)
    acer_pkt.push_back(53); acer_pkt.push_back(1); acer_pkt.push_back(1);
    // Option 93: UEFI x64 (Arch 7)
    acer_pkt.push_back(93); acer_pkt.push_back(2); acer_pkt.push_back(0); acer_pkt.push_back(7);
    // Option 60: PXEClient
    std::string pxe_vendor = "PXEClient:Arch:00007:UNDI:003016";
    acer_pkt.push_back(60); acer_pkt.push_back(static_cast<uint8_t>(pxe_vendor.size()));
    acer_pkt.insert(acer_pkt.end(), pxe_vendor.begin(), pxe_vendor.end());
    acer_pkt.push_back(255); // End

    auto parsed_acer = DhcpServer::parse_packet(acer_pkt);
    assert(parsed_acer.is_ok());
    const auto& acer_opts = parsed_acer.value();
    assert(acer_opts.client_mac == acer_mac);
    assert(acer_opts.client_arch == ClientArch::Efi_x64);
    assert(acer_opts.is_pxe_client);

    // Verify zero-config auto registration into ClientManager
    auto reg_acer = client_mgr->get_or_register_client(acer_opts.client_mac,
                                                       NetworkAddress(192, 168, 1, 100),
                                                       NetworkAddress(192, 168, 1, 200));
    assert(reg_acer.is_ok());
    auto acer_record = reg_acer.value();
    assert(acer_record.mac_address == acer_mac);
    assert(acer_record.ip_address == NetworkAddress(192, 168, 1, 100));

    // Check that golden image is assigned (or auto-assigned if empty)
    if (acer_record.os_image_path.empty()) {
        acer_record.os_image_id = img_mgr->default_os_image_id();
        auto info_res = img_mgr->get_image_info(ImageId(acer_record.os_image_id));
        assert(info_res.is_ok());
        acer_record.os_image_path = info_res.value().file_path;
        assert(client_mgr->save_client(acer_record).is_ok());
    }
    assert(acer_record.os_image_id == "golden_win10");
    assert(!acer_record.os_image_path.empty());

    // Build DHCP reply (DHCPOFFER)
    auto offer_acer = dhcp.build_reply(acer_hdr, acer_opts, 2, acer_record.ip_address);
    assert(offer_acer.is_ok());
    const auto& offer_bytes = offer_acer.value();
    const auto* offer_hdr = reinterpret_cast<const DhcpHeader*>(offer_bytes.data());
    assert(offer_hdr->op == 2); // BOOTREPLY
    assert(offer_hdr->xid == acer_hdr.xid);
    assert(std::string(reinterpret_cast<const char*>(offer_hdr->file)) == "ipxe.efi");

    // Verify yiaddr is 192.168.1.100
    uint8_t expected_yi[4] = {192, 168, 1, 100};
    assert(std::memcmp(&offer_hdr->yiaddr, expected_yi, 4) == 0);

    // Verify PXE options in DHCPOFFER
    auto offer_parse = DhcpServer::parse_packet(offer_bytes);
    assert(offer_parse.is_ok());
    assert(offer_parse.value().message_type == 2); // Offer
    assert(offer_parse.value().bootfile_name == "ipxe.efi");
    assert(offer_parse.value().tftp_server_name == "192.168.1.1");

    // 6. Test Case 2: Second unknown client with BIOS architecture (undionly.kpxe)
    std::string bios_mac = "00:E0:4C:99:88:77";
    DhcpHeader bios_hdr{};
    bios_hdr.op = 1;
    bios_hdr.htype = 1;
    bios_hdr.hlen = 6;
    bios_hdr.xid = htonl(0x42494F53); // "BIOS"
    bios_hdr.magic_cookie[0] = 99; bios_hdr.magic_cookie[1] = 130;
    bios_hdr.magic_cookie[2] = 83; bios_hdr.magic_cookie[3] = 99;
    bios_hdr.chaddr[0] = 0x00; bios_hdr.chaddr[1] = 0xE0; bios_hdr.chaddr[2] = 0x4C;
    bios_hdr.chaddr[3] = 0x99; bios_hdr.chaddr[4] = 0x88; bios_hdr.chaddr[5] = 0x77;

    std::vector<uint8_t> bios_pkt(reinterpret_cast<const uint8_t*>(&bios_hdr),
                                  reinterpret_cast<const uint8_t*>(&bios_hdr) + sizeof(DhcpHeader));
    bios_pkt.push_back(53); bios_pkt.push_back(1); bios_pkt.push_back(1);
    bios_pkt.push_back(93); bios_pkt.push_back(2); bios_pkt.push_back(0); bios_pkt.push_back(0); // BIOS Arch 0
    bios_pkt.push_back(255);

    auto parsed_bios = DhcpServer::parse_packet(bios_pkt);
    assert(parsed_bios.is_ok());
    assert(parsed_bios.value().client_arch == ClientArch::Bios_x86);

    auto reg_bios = client_mgr->get_or_register_client(parsed_bios.value().client_mac,
                                                       NetworkAddress(192, 168, 1, 100),
                                                       NetworkAddress(192, 168, 1, 200));
    assert(reg_bios.is_ok());
    assert(reg_bios.value().ip_address == NetworkAddress(192, 168, 1, 101));

    auto offer_bios = dhcp.build_reply(bios_hdr, parsed_bios.value(), 2, reg_bios.value().ip_address);
    assert(offer_bios.is_ok());
    const auto* bios_offer_hdr = reinterpret_cast<const DhcpHeader*>(offer_bios.value().data());
    assert(std::string(reinterpret_cast<const char*>(bios_offer_hdr->file)) == "undionly.kpxe");

    // 7. Test Case 3: TFTP dynamic script serves golden image target
    TftpServer tftp(NetworkAddress(192, 168, 1, 1), test_dir, 69);
    tftp.set_client_manager(client_mgr);
    tftp.set_image_manager(img_mgr);

    auto boot_ipxe_res = tftp.get_file_content("boot.ipxe");
    assert(boot_ipxe_res.is_ok());
    std::string script_str(reinterpret_cast<const char*>(boot_ipxe_res.value().data()), boot_ipxe_res.value().size());
    assert(script_str.find("#!ipxe") != std::string::npos);
    assert(script_str.find("iqn.2026-09.com.cobdiskless:golden_win10") != std::string::npos);
    assert(script_str.find("sanboot iscsi:192.168.1.1::::iqn.2026-09.com.cobdiskless:golden_win10") != std::string::npos);

    // 8. Test Case 4: Malformed packet rejection (no silent drops)
    std::vector<uint8_t> short_pkt(20, 0); // shorter than DhcpHeader
    auto short_res = DhcpServer::parse_packet(short_pkt);
    assert(short_res.is_err());

    std::vector<uint8_t> bad_cookie_pkt(sizeof(DhcpHeader), 0);
    // corrupt magic cookie
    bad_cookie_pkt[offsetof(DhcpHeader, magic_cookie)] = 0;
    auto bad_cookie_res = DhcpServer::parse_packet(bad_cookie_pkt);
    assert(bad_cookie_res.is_err());

    // TFTP short packet rejection
    std::vector<uint8_t> short_tftp(2, 0);
    auto tftp_short_res = TftpServer::parse_rrq_filename(short_tftp);
    assert(tftp_short_res.is_err());

    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_dhcp_zero_config_boot_and_raw_logging\n";
}

void test_dhcp_self_lease_and_tftp_ephemeral_routing() {
    std::cout << "[RUN] test_dhcp_self_lease_and_tftp_ephemeral_routing\n";
    std::error_code ec;
    std::filesystem::path test_dir = "test_dhcp_tftp_remediation";
    std::filesystem::remove_all(test_dir, ec);
    std::filesystem::create_directories(test_dir, ec);

    std::filesystem::path conf_file = test_dir / "clients.conf";
    auto client_mgr = std::make_shared<ClientManager>(conf_file);

    // 1. Verify ClientManager excludes server IP and gateway IP unconditionally
    NetworkAddress server_ip(192, 168, 1, 100);
    NetworkAddress gateway_ip(192, 168, 1, 101);
    client_mgr->set_server_interface_ip(server_ip);
    client_mgr->set_gateway_ip(gateway_ip);
    assert(client_mgr->server_interface_ip() == server_ip);
    assert(client_mgr->gateway_ip() == gateway_ip);
    assert(client_mgr->is_ip_excluded(server_ip));
    assert(client_mgr->is_ip_excluded(gateway_ip));

    // IP pool starts at 192.168.1.100. Because server is .100 and gateway is .101,
    // allocate_ip must skip .100 and .101, and return .102!
    auto alloc_res = client_mgr->allocate_ip(NetworkAddress(192, 168, 1, 100), NetworkAddress(192, 168, 1, 110));
    assert(alloc_res.is_ok());
    assert(alloc_res.value() == NetworkAddress(192, 168, 1, 102));

    // Exclude .102 manually; next allocation should return .103
    client_mgr->add_excluded_ip(NetworkAddress(192, 168, 1, 102));
    assert(client_mgr->is_ip_excluded(NetworkAddress(192, 168, 1, 102)));
    auto alloc_res2 = client_mgr->allocate_ip(NetworkAddress(192, 168, 1, 100), NetworkAddress(192, 168, 1, 110));
    assert(alloc_res2.is_ok());
    assert(alloc_res2.value() == NetworkAddress(192, 168, 1, 103));

    // 2. Polluted client config remediation:
    // Suppose a previous buggy run saved the host's listening IP (192.168.1.100) into clients.conf
    ClientRecord polluted;
    polluted.mac_address = "6C:4B:90:2F:61:EB";
    polluted.pc_name = "PC01";
    polluted.ip_address = server_ip; // 192.168.1.100 (Host collision trap!)
    assert(client_mgr->save_client(polluted).is_ok());

    // When client boots and calls get_or_register_client, ClientManager must detect the collision
    // with server_interface_ip_ and reallocate a safe IP!
    auto realloc_client = client_mgr->get_or_register_client("6C:4B:90:2F:61:EB",
                                                             NetworkAddress(192, 168, 1, 100),
                                                             NetworkAddress(192, 168, 1, 110));
    assert(realloc_client.is_ok());
    assert(realloc_client.value().ip_address != server_ip);
    assert(realloc_client.value().ip_address != gateway_ip);
    assert(realloc_client.value().ip_address == NetworkAddress(192, 168, 1, 103));

    // Explicit reallocate_ip test
    auto realloc_res = client_mgr->reallocate_ip("6C:4B:90:2F:61:EB",
                                                 NetworkAddress(192, 168, 1, 100),
                                                 NetworkAddress(192, 168, 1, 110));
    assert(realloc_res.is_ok());
    assert(realloc_res.value().ip_address != server_ip);
    assert(realloc_res.value().ip_address != gateway_ip);

    // 3. DhcpServer pool auto-sanitization:
    // If configured with pool_start == server_ip (e.g. 192.168.1.100), it must advance pool_start to 192.168.1.101
    DhcpServer dhcp_test(
        server_ip,
        NetworkAddress(255, 255, 255, 0),
        NetworkAddress(192, 168, 1, 100),
        NetworkAddress(192, 168, 1, 200)
    );
    dhcp_test.set_client_manager(client_mgr);
    assert(dhcp_test.ip_pool_start() == NetworkAddress(192, 168, 1, 101));

    // 4. TFTP Server duplicate RRQ superseding & cancellation:
    TftpServer tftp_srv(server_ip, test_dir, 6969);
    std::vector<uint8_t> dummy_payload(2048, 0x55);
    tftp_srv.register_virtual_file("test_boot.bin", dummy_payload);
    auto file_res = tftp_srv.get_file_content("test_boot.bin");
    assert(file_res.is_ok());
    assert(file_res.value().size() == 2048);

    // 5. DHCPNAK generation and server-self-lease rejection in build_reply:
    DhcpHeader req_hdr{};
    req_hdr.op = 1;
    req_hdr.htype = 1;
    req_hdr.hlen = 6;
    req_hdr.xid = 0x12345678;
    req_hdr.flags = htons(0x0000);
    uint8_t mac_bytes[6] = {0x6C, 0x4B, 0x90, 0x2F, 0x61, 0xEB};
    std::memcpy(req_hdr.chaddr, mac_bytes, 6);

    DhcpDiscoveredOptions nak_opts{};
    nak_opts.message_type = 3;
    nak_opts.client_mac = "6C:4B:90:2F:61:EB";
    nak_opts.requested_ip = server_ip; // 192.168.1.100

    // Refusing to ACK server IP in build_reply:
    auto bad_ack = dhcp_test.build_reply(req_hdr, nak_opts, 5 /* ACK */, server_ip);
    assert(bad_ack.is_err()); // MUST fail!

    // Building DHCPNAK (Opcode 2, Message Type 6, yiaddr = 0, siaddr = 0):
    auto nak_res = dhcp_test.build_reply(req_hdr, nak_opts, 6 /* DHCPNAK */, NetworkAddress(0, 0, 0, 0));
    assert(nak_res.is_ok());
    const auto& nak_bytes = nak_res.value();
    assert(nak_bytes.size() >= 300);
    const auto* nak_reply = reinterpret_cast<const DhcpHeader*>(nak_bytes.data());
    assert(nak_reply->op == 2);
    assert(nak_reply->xid == 0x12345678);
    assert(nak_reply->yiaddr == 0);
    assert(nak_reply->siaddr == 0);
    assert((ntohs(nak_reply->flags) & 0x8000) != 0); // Broadcast bit set

    // Parse options from the NAK packet:
    auto parsed_nak = DhcpServer::parse_packet(nak_bytes);
    assert(parsed_nak.is_ok());
    assert(parsed_nak.value().message_type == 6); // DHCPNAK!

    // 6. Test ClientManager::sanitize_records():
    ClientRecord dirty_rec;
    dirty_rec.mac_address = "AA:BB:CC:DD:EE:01";
    dirty_rec.pc_name = "DirtyPC";
    dirty_rec.ip_address = server_ip; // Polluted with server IP
    assert(client_mgr->save_client(dirty_rec).is_ok());
    assert(client_mgr->find_by_mac("AA:BB:CC:DD:EE:01")->ip_address == server_ip);

    size_t sanitized_cm = client_mgr->sanitize_records(NetworkAddress(192, 168, 1, 100), NetworkAddress(192, 168, 1, 110));
    assert(sanitized_cm >= 1);
    auto clean_rec = client_mgr->find_by_mac("AA:BB:CC:DD:EE:01");
    assert(clean_rec.has_value());
    assert(clean_rec->ip_address != server_ip);
    assert(clean_rec->ip_address != gateway_ip);
    assert(clean_rec->ip_address.octet(3) >= 102);

    // 7. Test ClientDatabase::sanitize_records():
    std::filesystem::path test_db_path = test_dir / "clients.json";
    {
        std::ofstream db_out(test_db_path);
        db_out << "{\n"
               << "  \"pool_start\": \"192.168.1.100\",\n"
               << "  \"pool_end\": \"192.168.1.200\",\n"
               << "  \"reserved\": [\"192.168.1.100\"],\n"
               << "  \"clients\": [\n"
               << "    {\"mac\": \"11:22:33:44:55:66\", \"hostname\": \"COLLIDE\", \"ip\": \"192.168.1.100\"}\n"
               << "  ]\n"
               << "}\n";
    }
    ClientDatabase cdb(test_db_path);
    cdb.set_reserved_addresses({server_ip, gateway_ip});
    assert(cdb.pool_start() == NetworkAddress(192, 168, 1, 101));
    auto entry = cdb.find_client_by_mac("11:22:33:44:55:66");
    assert(entry.has_value());
    assert(entry->ip_address != server_ip);
    assert(entry->ip_address != gateway_ip);
    assert(entry->ip_address.octet(3) >= 102);

    std::filesystem::remove_all(test_dir, ec);
    std::cout << "  PASS: test_dhcp_self_lease_and_tftp_ephemeral_routing\n";
}

void test_auto_arm_vhd_configuration_and_offline_discovery() {
    std::cout << "[RUN] test_auto_arm_vhd_configuration_and_offline_discovery\n";
    std::error_code ec;
    std::filesystem::path scratch = "scratch_auto_arm_test";
    std::filesystem::remove_all(scratch, ec);
    std::filesystem::create_directories(scratch, ec);

    // 1. Test Configuration default and toggle
    Configuration cfg = Configuration::create_default();
    assert(cfg.auto_arm_vhd_on_boot() == true);
    cfg.set_auto_arm_vhd_on_boot(false);
    assert(cfg.auto_arm_vhd_on_boot() == false);

    // 2. Test persistence in conf file
    std::filesystem::path conf_path = scratch / "test_auto_arm.conf";
    assert(cfg.save_to_file(conf_path).is_ok());

    Configuration loaded;
    assert(loaded.load_from_file(conf_path).is_ok());
    assert(loaded.auto_arm_vhd_on_boot() == false);

    cfg.set_auto_arm_vhd_on_boot(true);
    assert(cfg.save_to_file(conf_path).is_ok());
    assert(loaded.load_from_file(conf_path).is_ok());
    assert(loaded.auto_arm_vhd_on_boot() == true);

    // 2b. Explicit NIC boot profile: the default elects, an explicit value (global or
    //     per-image) is what auto_arm_vhd_on_boot re-applies on every launch instead of
    //     running a fresh election that could demote an already-selected NIC.
    assert(cfg.nic_profile() == "auto");
    assert(cfg.nic_profile_for("images/os/any_image.VHD") == "auto");

    cfg.set_nic_profile("Realtek");
    assert(cfg.nic_profile() == "realtek");
    assert(cfg.nic_profile_for("images/os/any_image.VHD") == "realtek");

    cfg.set_image_nic_profile("m71s", "REALTEK");
    assert(cfg.nic_profile_for("images/os/m71s.VHD") == "realtek");
    assert(cfg.nic_profile_for("D:\\images\\M71S.vhdx") == "realtek"); // casing + extension
    assert(cfg.nic_profile_for("images/os/DESKTOP-Q96KJSR.VHD") == "realtek"); // falls back

    // Per-image override without touching the global default.
    Configuration per_image;
    per_image.set_image_nic_profile("DESKTOP-Q96KJSR", "intel");
    assert(per_image.nic_profile() == "auto");
    assert(per_image.nic_profile_for("images/os/DESKTOP-Q96KJSR.VHD") == "intel");
    assert(per_image.nic_profile_for("images/os/m71s.VHD") == "auto");

    // `nic_profile = realtek` / `nic_profile.m71s = realtek` survive a conf round trip,
    // including the spaces around '=' an operator naturally types.
    const std::filesystem::path profile_conf = scratch / "nic_profile.conf";
    {
        std::ofstream out(profile_conf, std::ios::trunc);
        out << "# comment\n"
               "nic_profile = realtek\n"
               "nic_profile.m71s = realtek\n"
               "nic_profile.desk96 = intel\n";
    }
    Configuration from_text;
    assert(from_text.load_from_file(profile_conf).is_ok());
    assert(from_text.nic_profile() == "realtek");
    assert(from_text.nic_profile_for("images/os/m71s.VHD") == "realtek");
    assert(from_text.nic_profile_for("images/os/DESK96.VHD") == "intel");
    assert(from_text.nic_profile_for("images/os/other.VHD") == "realtek");

    // 3. Test arming an offline SYSTEM hive directly via arm_vhd_image
    const std::vector<std::pair<std::string, uint32_t>> initial_services = {
        {"msiscsi", 3}, {"Tcpip", 3}, {"NDIS", 3}, {"rt640x64", 3}
    };
    const std::filesystem::path hive_file = scratch / "SYSTEM";
    {
        auto hive_bytes = PnpDriverArmer::create_synthetic_system_hive(1, initial_services);
        std::ofstream out(hive_file, std::ios::binary | std::ios::trunc);
        out.write(reinterpret_cast<const char*>(hive_bytes.data()), static_cast<std::streamsize>(hive_bytes.size()));
    }
    // Also create companion transaction logs (.LOG1, .LOG2) to ensure they are truncated/wiped
    const std::filesystem::path log1 = scratch / "SYSTEM.LOG1";
    const std::filesystem::path log2 = scratch / "SYSTEM.LOG2";
    {
        std::ofstream l1(log1, std::ios::binary);
        l1 << "DIRTY_TRANSACTION_LOG_1";
        std::ofstream l2(log2, std::ios::binary);
        l2 << "DIRTY_TRANSACTION_LOG_2";
    }
    assert(std::filesystem::exists(log1, ec) && std::filesystem::file_size(log1, ec) > 0);
    assert(std::filesystem::exists(log2, ec) && std::filesystem::file_size(log2, ec) > 0);

    // Execute arm_vhd_image on the hive_file
    auto arm_res = PnpDriverArmer::arm_vhd_image(hive_file);
    assert(arm_res.is_ok());
    assert(arm_res.value().success);
    assert(!arm_res.value().armed_services.empty());

    // Verify companion logs were cleaned up (unlinked or truncated to 0 bytes)
    if (std::filesystem::exists(log1, ec)) {
        assert(std::filesystem::file_size(log1, ec) == 0);
    }
    if (std::filesystem::exists(log2, ec)) {
        assert(std::filesystem::file_size(log2, ec) == 0);
    }

    // 4. Test non-existent image returns error
    auto missing_res = PnpDriverArmer::arm_vhd_image(scratch / "non_existent.vhd");
    assert(missing_res.is_err());

    std::filesystem::remove_all(scratch, ec);
    std::cout << "  PASS: test_auto_arm_vhd_configuration_and_offline_discovery\n";
}

void test_offline_driver_store_harvesting_and_host_depot_fallback() {
    std::cout << "[TEST] Running test_offline_driver_store_harvesting_and_host_depot_fallback...\n";

    // 1. Verify critical_boot_drivers list
    const auto& critical_drivers = PnpDriverArmer::critical_boot_drivers();
    assert(critical_drivers.size() >= 2);
    assert(std::find(critical_drivers.begin(), critical_drivers.end(), "rt640x64.sys") != critical_drivers.end());
    assert(std::find(critical_drivers.begin(), critical_drivers.end(), "e1d68x64.sys") != critical_drivers.end());

    std::error_code ec;
    const std::filesystem::path scratch = "test_scratch_harvest";
    std::filesystem::remove_all(scratch, ec);
    std::filesystem::create_directories(scratch, ec);

    // 2. Scenario A: DriverStore Auto-Harvesting
    // Build guest Windows hierarchy:
    //   scratch / Windows / System32 / config / SYSTEM
    //   scratch / Windows / System32 / DriverStore / FileRepository / rt640x64.inf_amd64_deadbeef0123 / rt640x64.sys
    const std::filesystem::path hive_path = scratch / "Windows" / "System32" / "config" / "SYSTEM";
    std::filesystem::create_directories(hive_path.parent_path(), ec);
    const std::vector<std::pair<std::string, uint32_t>> initial_services = {
        {"msiscsi", 3}, {"Tcpip", 3}, {"NDIS", 3}, {"rt640x64", 3}
    };
    auto hive_bytes = PnpDriverArmer::create_synthetic_system_hive(1, initial_services);
    {
        std::ofstream out(hive_path, std::ios::binary | std::ios::trunc);
        out.write(reinterpret_cast<const char*>(hive_bytes.data()), static_cast<std::streamsize>(hive_bytes.size()));
    }

    const std::filesystem::path driver_repo = scratch / "Windows" / "System32" / "DriverStore" / "FileRepository" / "rt640x64.inf_amd64_deadbeef0123";
    std::filesystem::create_directories(driver_repo, ec);
    const std::filesystem::path harvested_src = driver_repo / "rt640x64.sys";
    const std::string mock_driver_payload = "REALTEK_PCIE_GBE_DRIVER_MOCK_PAYLOAD_PHASE0_OK";
    {
        std::ofstream drv(harvested_src, std::ios::binary | std::ios::trunc);
        drv.write(mock_driver_payload.data(), static_cast<std::streamsize>(mock_driver_payload.size()));
    }

    // Target driver must NOT exist prior to arming
    const std::filesystem::path target_driver = scratch / "Windows" / "System32" / "drivers" / "rt640x64.sys";
    assert(!std::filesystem::exists(target_driver, ec));

    // Execute offline hive arming which automatically invokes driver staging pipeline
    auto arm_res = PnpDriverArmer::arm_offline_system_hive(hive_path);
    assert(arm_res.is_ok());
    assert(arm_res.value().success);

    // Verify driver was auto-harvested into System32\drivers\rt640x64.sys
    assert(std::filesystem::exists(target_driver, ec));
    assert(std::filesystem::file_size(target_driver, ec) == mock_driver_payload.size());
    {
        std::ifstream in(target_driver, std::ios::binary);
        std::string content((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
        assert(content == mock_driver_payload);
    }

    // 3. Scenario B: Host Depot Fallback
    // For e1d68x64.sys, simulate that guest DriverStore has no matching folder.
    // Place e1d68x64.sys into host ./drivers/ depot.
    const std::filesystem::path host_depot = "./drivers";
    std::filesystem::create_directories(host_depot, ec);
    const std::filesystem::path host_driver = host_depot / "e1d68x64.sys";
    const std::string mock_intel_payload = "INTEL_I217_I218_I219_DRIVER_MOCK_DEPOT_PAYLOAD";
    {
        std::ofstream drv(host_driver, std::ios::binary | std::ios::trunc);
        drv.write(mock_intel_payload.data(), static_cast<std::streamsize>(mock_intel_payload.size()));
    }

    const std::filesystem::path intel_target = scratch / "Windows" / "System32" / "drivers" / "e1d68x64.sys";
    assert(!std::filesystem::exists(intel_target, ec));

    std::vector<std::string> warnings;
    bool staged = PnpDriverArmer::verify_or_stage_driver_file(scratch / "Windows" / "System32" / "drivers", "e1d68x64.sys", warnings);
    assert(staged);
    assert(std::filesystem::exists(intel_target, ec));
    assert(std::filesystem::file_size(intel_target, ec) == mock_intel_payload.size());
    {
        std::ifstream in(intel_target, std::ios::binary);
        std::string content((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
        assert(content == mock_intel_payload);
    }

    // Clean up host depot driver
    std::filesystem::remove(host_driver, ec);
    std::filesystem::remove(host_depot, ec);

    // 4. Scenario C: In-Place Verification (No-op when already present)
    warnings.clear();
    bool verified_rtk = PnpDriverArmer::verify_or_stage_driver_file(scratch / "Windows" / "System32" / "drivers", "rt640x64.sys", warnings);
    assert(verified_rtk);

    bool verified_intel = PnpDriverArmer::verify_or_stage_driver_file(scratch / "Windows" / "System32" / "drivers", "e1d68x64.sys", warnings);
    assert(verified_intel);

    // 5. Scenario D: Volume / directory inspection via ensure_image_armed
    auto vol_res = PnpDriverArmer::ensure_image_armed(scratch);
    assert(vol_res.is_ok());
    assert(vol_res.value().success);

    std::filesystem::remove_all(scratch, ec);
    std::cout << "  PASS: test_offline_driver_store_harvesting_and_host_depot_fallback\n";
}

void test_guest_arch_detection_and_universal_ndis_harvest() {
    std::cout << "[RUN] test_guest_arch_detection_and_universal_ndis_harvest\n";

    std::error_code ec;
    const std::filesystem::path scratch = "test_scratch_ndis_harvest";
    std::filesystem::remove_all(scratch, ec);
    std::filesystem::create_directories(scratch, ec);

    // ------------------------------------------------------------------
    // 1. Pure architecture classification (PE Machine field + volume layout)
    // ------------------------------------------------------------------
    assert(PnpDriverArmer::classify_pe_machine(0x8664) == GuestArch::X64); // IMAGE_FILE_MACHINE_AMD64
    assert(PnpDriverArmer::classify_pe_machine(0x014C) == GuestArch::X86); // IMAGE_FILE_MACHINE_I386
    assert(PnpDriverArmer::classify_pe_machine(0x01C4) == GuestArch::Unknown);
    assert(PnpDriverArmer::classify_volume_layout(true, GuestArch::Unknown) == GuestArch::X64);
    assert(PnpDriverArmer::classify_volume_layout(true, GuestArch::X86) == GuestArch::X64);
    assert(PnpDriverArmer::classify_volume_layout(false, GuestArch::X86) == GuestArch::X86);
    assert(PnpDriverArmer::classify_volume_layout(false, GuestArch::Unknown) == GuestArch::Unknown);
    assert(PnpDriverArmer::arch_name(GuestArch::X64) == "x64");
    assert(PnpDriverArmer::arch_name(GuestArch::X86) == "x86");
    assert(PnpDriverArmer::arch_name(GuestArch::Unknown) == "unknown");

    // ------------------------------------------------------------------
    // 2. Guest architecture detection from a mounted VHD volume
    // ------------------------------------------------------------------
    auto write_pe_image = [&](const std::filesystem::path& pe_path, uint16_t machine) {
        std::filesystem::create_directories(pe_path.parent_path(), ec);
        std::vector<uint8_t> image(0x100, 0);
        image[0x00] = 'M';
        image[0x01] = 'Z';
        const uint32_t lfanew = 0x80;
        image[0x3C] = static_cast<uint8_t>(lfanew & 0xFF);
        image[0x3D] = static_cast<uint8_t>((lfanew >> 8) & 0xFF);
        image[0x80] = 'P';
        image[0x81] = 'E';
        image[0x82] = 0;
        image[0x83] = 0;
        image[0x84] = static_cast<uint8_t>(machine & 0xFF);
        image[0x85] = static_cast<uint8_t>((machine >> 8) & 0xFF);
        std::ofstream out(pe_path, std::ios::binary | std::ios::trunc);
        out.write(reinterpret_cast<const char*>(image.data()), static_cast<std::streamsize>(image.size()));
    };

    const std::filesystem::path vol_x64 = scratch / "vol_x64";
    const std::filesystem::path vol_x86 = scratch / "vol_x86";
    const std::filesystem::path vol_bare = scratch / "vol_bare";

    // x64 guest: SysWOW64 present (primary signal) + AMD64 ntoskrnl (corroborating).
    write_pe_image(vol_x64 / "Windows" / "System32" / "ntoskrnl.exe", 0x8664);
    std::filesystem::create_directories(vol_x64 / "Windows" / "SysWOW64", ec);
    // x86 guest: no SysWOW64, I386 ntoskrnl.
    write_pe_image(vol_x86 / "Windows" / "System32" / "ntoskrnl.exe", 0x014C);
    // Layout without a readable kernel image -> undetermined.
    std::filesystem::create_directories(vol_bare / "Windows" / "System32", ec);

    assert(PnpDriverArmer::detect_guest_arch(vol_x64) == GuestArch::X64);
    assert(PnpDriverArmer::detect_guest_arch(vol_x64 / "Windows") == GuestArch::X64);
    assert(PnpDriverArmer::detect_guest_arch(vol_x86) == GuestArch::X86);
    assert(PnpDriverArmer::detect_guest_arch(vol_bare) == GuestArch::Unknown);
    assert(PnpDriverArmer::detect_guest_arch(scratch / "not_a_volume") == GuestArch::Unknown);

    // ------------------------------------------------------------------
    // 3. Mock DriverStore\FileRepository packages (multi-vendor, both arches)
    // ------------------------------------------------------------------
    auto make_package = [&](const std::filesystem::path& repo, const std::string& dir_name,
                            const std::string& inf_name, const std::string& inf_body,
                            const std::string& sys_name) {
        const std::filesystem::path dir = repo / dir_name;
        std::filesystem::create_directories(dir, ec);
        if (!inf_name.empty()) {
            std::ofstream inf(dir / inf_name, std::ios::binary | std::ios::trunc);
            inf << inf_body;
        }
        if (!sys_name.empty()) {
            std::ofstream sys(dir / sys_name, std::ios::binary | std::ios::trunc);
            sys << "MOCK_" << sys_name << "_PAYLOAD";
        }
    };

    // Broadcom: Class = Net, two PCI hardware IDs, explicit load-order group.
    const std::string broadcom_inf = R"INF(
[Version]
Signature   = "$Windows NT$"
Class       = Net
ClassGuid   = {4d36e972-e325-11ce-bfc1-08002be10318}
Provider    = %Broadcom%
DriverVer   = 01/01/2024,1.0.0.0

[DDInstall.NT.Services]
AddService = bnxtre,0x00000002,bnxtre_Service_Inst

[bnxtre_Service_Inst]
DisplayName    = %bnxtre.SVCDESC%
ServiceType    = 1
StartType      = 3
ErrorControl   = 1
ServiceBinary  = %13%\bnxtre.sys
LoadOrderGroup = NDIS

[Manufacturer]
%Broadcom% = Broadcom,NTamd64

[Broadcom.NTamd64]
%bcm.Device% = bcm, PCI\VEN_14E4&DEV_1680&SUBSYS_00001028&REV_10
%bcm.Device% = bcm, PCI\VEN_14E4&DEV_165F

[Strings]
Broadcom   = "Broadcom Inc."
bcm.Device = "Broadcom NetXtreme Gigabit Ethernet"
bnxtre.SVCDESC = "Broadcom NetXtreme NDIS 6.x Driver"
)INF";

    // Marvell: classified through ClassGuid only, carries an explicit group Tag.
    const std::string marvell_inf = R"INF(
[Version]
Signature   = "$Windows NT$"
ClassGuid   = {4d36e972-e325-11ce-bfc1-08002be10318}
Provider    = %Marvell%

[DDInstall.Services]
AddService = mrvlpcie,0x00000002,mrvlpcie_Service_Inst

[mrvlpcie_Service_Inst]
DisplayName    = %mrvl.SVCDESC%
ServiceType    = 1
StartType      = 3
ErrorControl   = 1
ServiceBinary  = %13%\mrvlpcie.sys
LoadOrderGroup = NDIS
Tag            = 7

[Manufacturer]
%Marvell% = Marvell,NTamd64

[Marvell.NTamd64]
%mrvl.Device% = mrvl, PCI\VEN_1B4B&DEV_2380&SUBSYS_88881849

[Strings]
Marvell    = "Marvell Technology Group"
mrvl.Device = "Marvell PCIe GbE Controller"
mrvl.SVCDESC = "Marvell NDIS 6.x Miniport Driver"
)INF";

    // Qualcomm Atheros: 32-bit package for the x86 guest.
    const std::string atheros_inf = R"INF(
[Version]
Signature = "$Windows NT$"
Class     = Net
ClassGuid = {4d36e972-e325-11ce-bfc1-08002be10318}
Provider  = %Atheros%

[DDInstall.Services]
AddService = athw,0x00000002,athw_Service_Inst

[athw_Service_Inst]
DisplayName    = %athw.SVCDESC%
ServiceType    = 1
StartType      = 3
ErrorControl   = 1
ServiceBinary  = %13%\athw.sys
LoadOrderGroup = NDIS

[Manufacturer]
%Atheros% = Atheros,NTx86

[Atheros.NTx86]
%athw.Device% = athw, PCI\VEN_1969&DEV_1091&SUBSYS_10811969

[Strings]
Atheros   = "Qualcomm Atheros"
athw.Device = "Qualcomm Atheros AR8161 Gigabit Ethernet"
athw.SVCDESC = "Qualcomm Atheros NDIS 6.x Miniport Driver"
)INF";

    // Aquantia: a real Class = Net package that only ships as a 32-bit package, so the
    // x64 guest must skip it (and its hardware ID must never reach the CDDB).
    const std::string aquantia_inf = R"INF(
[Version]
Signature = "$Windows NT$"
Class     = Net
ClassGuid = {4d36e972-e325-11ce-bfc1-08002be10318}
Provider  = %Aquantia%

[DDInstall.Services]
AddService = aqc107,0x00000002,aqc107_Service_Inst

[aqc107_Service_Inst]
ServiceType    = 1
StartType      = 3
ErrorControl   = 1
ServiceBinary  = %13%\aqc107.sys
LoadOrderGroup = NDIS

[Manufacturer]
%Aquantia% = Aquantia,NTx86

[Aquantia.NTx86]
%aqc.Device% = aqc, PCI\VEN_1D6A&DEV_0100

[Strings]
Aquantia = "Aquantia Corp."
aqc.Device = "Aquantia 5GbE Controller"
)INF";

    // Non-network package: Class = USB must never be harvested as a NIC driver.
    const std::string usb_inf = R"INF(
[Version]
Signature = "$Windows NT$"
Class     = USB
ClassGuid = {36fc9e65-c465-11d1-9916-00a0c9198da9}
Provider  = %Generic%

[DDInstall.Services]
AddService = usbmass,0x00000002,usbmass_Service_Inst

[usbmass_Service_Inst]
ServiceType    = 1
StartType      = 3
ErrorControl   = 1
ServiceBinary  = %13%\usbmass.sys

[Generic]
%usb.Device% = usb, USB\VID_0781&PID_5567

[Strings]
Generic = "Generic"
usb.Device = "USB Mass Storage"
)INF";

    // VMware VMnetNIC: Class = Net *and* a PCI VEN/DEV ID, but the adapter is virtual,
    // so the virtual-name blacklist has to win over the "has PCI IDs" rule.
    const std::string vmnet_inf = R"INF(
[Version]
Signature = "$Windows NT$"
Class     = Net
ClassGuid = {4d36e972-e325-11ce-bfc1-08002be10318}
Provider  = %VMware%

[DDInstall.Services]
AddService = vmnetadapter,0x00000002,vmnetadapter_Service_Inst

[vmnetadapter_Service_Inst]
ServiceType    = 1
StartType      = 3
ErrorControl   = 1
ServiceBinary  = %13%\vmnetadapter.sys
LoadOrderGroup = NDIS

[Manufacturer]
%VMware% = VMware,NTamd64

[VMware.NTamd64]
%vmnet.Device% = vmnet, PCI\VEN_15AD&DEV_07B0

[Strings]
VMware = "VMware, Inc."
vmnet.Device = "VMware VMNET Adapter"
)INF";

    // Oracle VirtualBox host-only adapter: ROOT\ enumerated software device that also
    // matches the VBoxNetAdp blacklist entry.
    const std::string vbox_inf = R"INF(
[Version]
Signature = "$Windows NT$"
Class     = Net
ClassGuid = {4d36e972-e325-11ce-bfc1-08002be10318}
Provider  = %Oracle%

[DDInstall.Services]
AddService = VBoxNetAdp,0x00000002,VBoxNetAdp_Service_Inst

[VBoxNetAdp_Service_Inst]
ServiceType    = 1
StartType      = 3
ErrorControl   = 1
ServiceBinary  = %13%\VBoxNetAdp.sys
LoadOrderGroup = NDIS

[Manufacturer]
%Oracle% = Oracle,NTamd64

[Oracle.NTamd64]
%vbox.Device% = vbox, ROOT\VBOXNETADP&NETCARD_0001

[Strings]
Oracle = "Oracle Corporation"
vbox.Device = "VirtualBox Host-Only Ethernet Adapter"
)INF";

    // OpenVPN TAP-Windows adapter for the 32-bit guest: blacklisted name *and*
    // ROOT\ hardware ID, so both rejection rules apply.
    const std::string tap_inf = R"INF(
[Version]
Signature = "$Windows NT$"
Class     = Net
ClassGuid = {4d36e972-e325-11ce-bfc1-08002be10318}
Provider  = %OpenVPN%

[DDInstall.Services]
AddService = tap0901,0x00000002,tap0901_Service_Inst

[tap0901_Service_Inst]
ServiceType    = 1
StartType      = 3
ErrorControl   = 1
ServiceBinary  = %13%\tap0901.sys
LoadOrderGroup = NDIS

[Manufacturer]
%OpenVPN% = OpenVPN,NTx86

[OpenVPN.NTx86]
%tap.Device% = tap, ROOT\TAP0901&{8e800e8b-...}

[Strings]
OpenVPN = "OpenVPN Inc."
tap.Device = "TAP-Windows Adapter V9"
)INF";

    const std::filesystem::path repo_x64 = vol_x64 / "Windows" / "System32" / "DriverStore" / "FileRepository";
    make_package(repo_x64, "netbcm.inf_amd64_aaa", "netbcm.inf", broadcom_inf, "bnxtre.sys");
    make_package(repo_x64, "netmrv.inf_amd64_bbb", "netmrv.inf", marvell_inf, "mrvlpcie.sys");
    make_package(repo_x64, "netaqc.inf_x86_ccc", "netaqc.inf", aquantia_inf, "aqc107.sys");
    make_package(repo_x64, "rtlan.inf_amd64_eee", "", "", "rtlan.sys");            // prefix match but no PCI ID
    make_package(repo_x64, "usbmass.inf_amd64_ddd", "usbmass.inf", usb_inf, "usbmass.sys"); // Class != Net
    make_package(repo_x64, "chipset.inf_amd64_fff", "", "", "chipset.sys");        // not a network INF prefix
    // Virtual / software adapters: must never be harvested or boot-armed.
    make_package(repo_x64, "vmnetadapter.inf_amd64_vvv", "vmnet.inf", vmnet_inf, "vmnetadapter.sys");
    make_package(repo_x64, "vboxnetadp.inf_amd64_www", "vboxnetadp.inf", vbox_inf, "VBoxNetAdp.sys");

    const std::filesystem::path repo_x86 = vol_x86 / "Windows" / "System32" / "DriverStore" / "FileRepository";
    make_package(repo_x86, "netathw.inf_x86_111", "athw.inf", atheros_inf, "athw.sys");
    make_package(repo_x86, "netbcm.inf_amd64_aaa", "netbcm.inf", broadcom_inf, "bnxtre.sys");
    make_package(repo_x86, "tap0901.inf_x86_ttt", "tap0901.inf", tap_inf, "tap0901.sys");

    // ------------------------------------------------------------------
    // 4. Generic harvesting of the mock packages, filtered by architecture
    // ------------------------------------------------------------------
    std::vector<std::string> harvest_warns;
    const auto x64_pkgs = PnpDriverArmer::harvest_ndis_packages(vol_x64, &harvest_warns);
    assert(harvest_warns.empty());
    // Only the two physical PCI NIC packages survive: architecture, Class, prefix,
    // PCI hardware-ID and virtual-adapter filters all apply.
    assert(x64_pkgs.size() == 2);

    auto find_pkg = [](const std::vector<NdisPackageInfo>& pkgs, const std::string& dir) -> const NdisPackageInfo* {
        for (const auto& p : pkgs) {
            if (p.package_dir_name == dir) return &p;
        }
        return nullptr;
    };

    const NdisPackageInfo* broadcom = find_pkg(x64_pkgs, "netbcm.inf_amd64_aaa");
    assert(broadcom != nullptr);
    assert(broadcom->service_name == "bnxtre");
    assert(broadcom->driver_file == "bnxtre.sys");
    assert(broadcom->arch == GuestArch::X64);
    assert(broadcom->inf_name == "netbcm.inf");
    assert(broadcom->group == "NDIS");
    assert(broadcom->image_path == "system32\\drivers\\bnxtre.sys");
    assert(std::filesystem::exists(broadcom->source_sys, ec));
    assert(broadcom->hardware_ids.size() == 2);
    assert(std::find(broadcom->hardware_ids.begin(), broadcom->hardware_ids.end(),
                     "pci#ven_14e4&dev_1680") != broadcom->hardware_ids.end());
    assert(std::find(broadcom->hardware_ids.begin(), broadcom->hardware_ids.end(),
                     "pci#ven_14e4&dev_165f") != broadcom->hardware_ids.end());

    const NdisPackageInfo* marvell = find_pkg(x64_pkgs, "netmrv.inf_amd64_bbb");
    assert(marvell != nullptr);
    assert(marvell->service_name == "mrvlpcie");
    assert(marvell->driver_file == "mrvlpcie.sys");
    assert(marvell->has_tag && marvell->tag == 7);
    assert(marvell->hardware_ids.size() == 1);
    assert(marvell->hardware_ids[0] == "pci#ven_1b4b&dev_2380");

    // Prefix-matched package with no PCI\VEN_... hardware ID at all: not physical,
    // so it must never be harvested (and therefore never armed or CDDB-bound).
    assert(find_pkg(x64_pkgs, "rtlan.inf_amd64_eee") == nullptr);

    // Virtual / software adapters are rejected outright, even when they carry a real
    // Class = Net INF with a PCI VEN/DEV ID (vmnetadapter).
    assert(find_pkg(x64_pkgs, "vmnetadapter.inf_amd64_vvv") == nullptr);
    assert(find_pkg(x64_pkgs, "vboxnetadp.inf_amd64_www") == nullptr);

    // Architecture + class filters: 32-bit, non-network and unknown-prefix packages are out.
    assert(find_pkg(x64_pkgs, "netaqc.inf_x86_ccc") == nullptr);
    assert(find_pkg(x64_pkgs, "usbmass.inf_amd64_ddd") == nullptr);
    assert(find_pkg(x64_pkgs, "chipset.inf_amd64_fff") == nullptr);

    const auto x86_pkgs = PnpDriverArmer::harvest_ndis_packages(vol_x86, &harvest_warns);
    assert(harvest_warns.empty());
    assert(x86_pkgs.size() == 1);
    assert(x86_pkgs[0].package_dir_name == "netathw.inf_x86_111");
    assert(x86_pkgs[0].service_name == "athw");
    assert(x86_pkgs[0].arch == GuestArch::X86);
    assert(x86_pkgs[0].hardware_ids.size() == 1);
    assert(x86_pkgs[0].hardware_ids[0] == "pci#ven_1969&dev_1091");
    // The TAP-Windows package in this 32-bit guest is a software adapter.
    assert(find_pkg(x86_pkgs, "tap0901.inf_x86_ttt") == nullptr);

    // ---- Virtual / software adapter blacklist (pure helpers) ----
    for (const char* name : {"VBoxNetAdp", "vboxnetadp.inf_amd64_www", "vmnetadapter",
                             "tap0901", "tuntap", "openvpn-dco", "ndiswan2", "rasman",
                             "ROOT\\TAP0901&{8e800e8b}"} ) {
        assert(PnpDriverArmer::is_virtual_adapter_name(name));
    }
    for (const char* name : {"rt640x64", "e1d68x64", "b57nd64a", "k1116x64", "bnxtre",
                             "mrvlpcie", "athw", "netathw.inf_x86_111"}) {
        assert(!PnpDriverArmer::is_virtual_adapter_name(name));
    }

    assert(PnpDriverArmer::is_physical_ndis_package(*broadcom));
    assert(PnpDriverArmer::is_physical_ndis_package(*marvell));
    assert(PnpDriverArmer::is_physical_ndis_package(x86_pkgs[0]));

    NdisPackageInfo virtual_pkg;
    virtual_pkg.package_dir_name = "vmnetadapter.inf_amd64_vvv";
    virtual_pkg.service_name = "vmnetadapter";
    virtual_pkg.driver_file = "vmnetadapter.sys";
    virtual_pkg.hardware_ids = {"pci#ven_15ad&dev_07b0"}; // PCI ID alone is not enough
    assert(!PnpDriverArmer::is_physical_ndis_package(virtual_pkg));

    NdisPackageInfo no_pci = virtual_pkg;
    no_pci.package_dir_name = "rtlan.inf_amd64_eee";
    no_pci.service_name = "rtlan";
    no_pci.driver_file = "rtlan.sys";
    no_pci.hardware_ids.clear(); // no PCI\VEN_... -> not physical
    assert(!PnpDriverArmer::is_physical_ndis_package(no_pci));

    NdisPackageInfo root_pkg;
    root_pkg.package_dir_name = "tap0901.inf_x86_ttt";
    root_pkg.service_name = "tap0901";
    root_pkg.driver_file = "tap0901.sys";
    root_pkg.hardware_ids = {"pci#ven_15ad&dev_07b0"};
    root_pkg.has_root_id = true; // ROOT\ enumeration wins over a hybrid PCI ID
    assert(!PnpDriverArmer::is_physical_ndis_package(root_pkg));

    // A volume without a FileRepository harvests nothing (and says so).
    std::vector<std::string> empty_warns;
    assert(PnpDriverArmer::harvest_ndis_packages(vol_bare, &empty_warns).empty());
    assert(!empty_warns.empty());

    // ------------------------------------------------------------------
    // 5. Staging: CopyFileW every harvested .sys into <Volume>\Windows\System32\drivers
    // ------------------------------------------------------------------
    std::vector<std::string> stage_warns;
    std::vector<std::string> staged;
    const std::filesystem::path sys32_x64 = vol_x64 / "Windows" / "System32";
    assert(PnpDriverArmer::stage_harvested_drivers(sys32_x64, x64_pkgs, stage_warns, &staged));
    assert(stage_warns.empty());
    assert(staged.size() == 2);
    assert(staged[0] == "bnxtre.sys" && staged[1] == "mrvlpcie.sys");
    for (const char* drv : {"bnxtre.sys", "mrvlpcie.sys"}) {
        const std::filesystem::path target = sys32_x64 / "drivers" / drv;
        assert(std::filesystem::exists(target, ec));
        std::ifstream in(target, std::ios::binary);
        std::string content((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
        assert(content == std::string("MOCK_") + drv + "_PAYLOAD");
    }
    // Idempotent: already staged drivers are left untouched.
    std::vector<std::string> staged_again;
    assert(PnpDriverArmer::stage_harvested_drivers(sys32_x64, x64_pkgs, stage_warns, &staged_again));
    assert(staged_again.empty());

    // ------------------------------------------------------------------
    // 6. Generic hive arming for every discovered vendor service
    // ------------------------------------------------------------------
    auto ndis_hive = PnpDriverArmer::create_synthetic_system_hive(
        1, {{"msiscsi", 3}, {"Tcpip", 1}, {"NDIS", 1}, {"rt640x64", 3}});
    auto arm_res = PnpDriverArmer::arm_hive_buffer(ndis_hive, x64_pkgs);
    assert(arm_res.is_ok());
    const auto& rep = arm_res.value();
    assert(rep.success);
    assert(rep.boot_flags_armed);
    assert(rep.iscsi_stack_armed);

    for (const char* svc : {"bnxtre", "mrvlpcie"}) {
        assert(std::find(rep.injected_services.begin(), rep.injected_services.end(), svc) !=
               rep.injected_services.end());

        const std::string base = std::string("ControlSet001\\Services\\") + svc;
        const uint32_t svc_off = hive_open_path(ndis_hive, base);
        assert(svc_off != 0xFFFFFFFF);

        uint32_t value = 0;
        assert(hive_get_dword(ndis_hive, svc_off, "Start", &value) && value == 0x0);
        assert(hive_get_dword(ndis_hive, svc_off, "Type", &value) && value == 0x1);
        assert(hive_get_dword(ndis_hive, svc_off, "ErrorControl", &value) && value == 0x1);
        assert(hive_get_dword(ndis_hive, svc_off, "BootFlags", &value) && value == 0x1);
        assert(hive_get_string(ndis_hive, svc_off, "Group") == "NDIS");
        assert(hive_get_string(ndis_hive, svc_off, "ImagePath") ==
               std::string("system32\\drivers\\") + svc + ".sys");

        // Anti-flap / power-saving overrides in the driver's Parameters key
        const uint32_t params_off = hive_open_path(ndis_hive, base + "\\Parameters");
        assert(params_off != 0xFFFFFFFF);
        assert(hive_value_type(ndis_hive, params_off, "*EEE") == 1 /* REG_SZ */);
        assert(hive_get_string(ndis_hive, params_off, "*EEE") == "0");
        assert(hive_get_dword(ndis_hive, params_off, "PowerSavingMode", &value) && value == 0);
        assert(hive_get_dword(ndis_hive, params_off, "GigaLite", &value) && value == 0);
        assert(hive_get_dword(ndis_hive, params_off, "AutoDisableGigabit", &value) && value == 0);
        // Never wait for PHY negotiation during boot (boot-logo hang risk).
        assert(hive_value_type(ndis_hive, params_off, "*WaitAutoNegComplete") == 1 /* REG_SZ */);
        assert(hive_get_string(ndis_hive, params_off, "*WaitAutoNegComplete") == "0");
        assert(hive_get_dword(ndis_hive, params_off, "PnPCapabilities", &value) && value == 0x00000018);
        assert(hive_get_string(ndis_hive, params_off, "EEE") == "0");

        // DMA / TSO / checksum offload disables: ndis.sys 0xD1 during Phase 0 iSCSI I/O.
        for (const char* offload_key : {"*LsoV2IPv4", "*LsoV2IPv6", "*IPChecksumOffloadIPv4",
                                        "*TCPChecksumOffloadIPv4", "*UDPChecksumOffloadIPv4"}) {
            assert(hive_get_string(ndis_hive, params_off, offload_key) == "0");
        }
    }

    // The INF-supplied group tag is preserved, services without one get none.
    {
        const uint32_t mrvl_off = hive_open_path(ndis_hive, "ControlSet001\\Services\\mrvlpcie");
        uint32_t tag = 0;
        assert(hive_get_dword(ndis_hive, mrvl_off, "Tag", &tag) && tag == 7);
        const uint32_t bcm_off = hive_open_path(ndis_hive, "ControlSet001\\Services\\bnxtre");
        assert(!hive_get_dword(ndis_hive, bcm_off, "Tag", &tag));
    }

    // Dynamic CDDB bindings: every harvested PCI hardware ID -> its discovered service,
    // alongside the well-known static fallbacks.
    {
        const uint32_t cddb = hive_open_path(ndis_hive, "ControlSet001\\Control\\CriticalDeviceDatabase");
        assert(cddb != 0xFFFFFFFF);
        auto assert_binding = [&](const std::string& hardware_id, const std::string& service) {
            const uint32_t hwid_off = hive_find_subkey(ndis_hive, cddb, hardware_id);
            assert(hwid_off != 0xFFFFFFFF);
            assert(hive_get_string(ndis_hive, hwid_off, "Service") == service);
            assert(hive_get_string(ndis_hive, hwid_off, "ClassGUID") == "{4d36e972-e325-11ce-bfc1-08002be10318}");
        };
        assert_binding("pci#ven_10ec&dev_8168", "rt640x64"); // static fallback still injected
        assert_binding("pci#ven_14e4&dev_1680", "bnxtre");
        assert_binding("pci#ven_14e4&dev_165f", "bnxtre");
        assert_binding("pci#ven_1b4b&dev_2380", "mrvlpcie");
        // Packages filtered out by architecture / class / virtual-adapter rules never
        // reach the CDDB.
        assert(hive_find_subkey(ndis_hive, cddb, "pci#ven_1d6a&dev_0100") == 0xFFFFFFFF);
        assert(hive_find_subkey(ndis_hive, cddb, "pci#ven_1969&dev_1091") == 0xFFFFFFFF);
        assert(hive_find_subkey(ndis_hive, cddb, "pci#ven_0781&dev_5567") == 0xFFFFFFFF);
        assert(hive_find_subkey(ndis_hive, cddb, "pci#ven_15ad&dev_07b0") == 0xFFFFFFFF);
    }

    // 6b. Defensive gate: even a virtual package handed straight to the armer is
    //     refused -- no Start = 0 service key, no CDDB binding, no BootFlags.
    {
        auto virt_hive = PnpDriverArmer::create_synthetic_system_hive(
            1, {{"msiscsi", 3}, {"Tcpip", 1}, {"NDIS", 1}, {"rt640x64", 3}});
        auto virt_res = PnpDriverArmer::arm_hive_buffer(virt_hive, {virtual_pkg, root_pkg, no_pci});
        assert(virt_res.is_ok());
        const auto& vrep = virt_res.value();
        assert(vrep.success);

        for (const char* svc : {"vmnetadapter", "VBoxNetAdp", "tap0901", "rtlan"}) {
            assert(hive_open_path(virt_hive, std::string("ControlSet001\\Services\\") + svc) == 0xFFFFFFFF);
            assert(std::find(vrep.armed_services.begin(), vrep.armed_services.end(), svc) ==
                   vrep.armed_services.end());
            assert(std::find(vrep.injected_services.begin(), vrep.injected_services.end(), svc) ==
                   vrep.injected_services.end());
        }

        const uint32_t vcddb = hive_open_path(virt_hive, "ControlSet001\\Control\\CriticalDeviceDatabase");
        assert(vcddb != 0xFFFFFFFF);
        assert(hive_find_subkey(virt_hive, vcddb, "pci#ven_15ad&dev_07b0") == 0xFFFFFFFF);
    }

    // ------------------------------------------------------------------
    // 7. End-to-end: arm the on-disk SYSTEM hive of the 32-bit guest volume
    // ------------------------------------------------------------------
    const std::filesystem::path e2e_hive_path = vol_x86 / "Windows" / "System32" / "config" / "SYSTEM";
    std::filesystem::create_directories(e2e_hive_path.parent_path(), ec);
    {
        const auto seed = PnpDriverArmer::create_synthetic_system_hive(
            1, {{"msiscsi", 3}, {"Tcpip", 1}, {"NDIS", 1}, {"rt640x64", 3}});
        std::ofstream out(e2e_hive_path, std::ios::binary | std::ios::trunc);
        out.write(reinterpret_cast<const char*>(seed.data()), static_cast<std::streamsize>(seed.size()));
    }

    auto e2e = PnpDriverArmer::arm_offline_system_hive(e2e_hive_path);
    assert(e2e.is_ok());
    const auto& e2e_rep = e2e.value();
    assert(e2e_rep.success);
    assert(e2e_rep.guest_arch == "x86");
    assert(e2e_rep.harvested_packages.size() == 1);
    assert(e2e_rep.harvested_packages[0] == "netathw.inf_x86_111");
    assert(e2e_rep.staged_binaries.size() == 1);
    assert(e2e_rep.staged_binaries[0] == "athw.sys");
    assert(std::filesystem::exists(vol_x86 / "Windows" / "System32" / "drivers" / "athw.sys", ec));
    // The amd64 package must not have been staged into a 32-bit guest.
    assert(!std::filesystem::exists(vol_x86 / "Windows" / "System32" / "drivers" / "bnxtre.sys", ec));

    std::ifstream armed_in(e2e_hive_path, std::ios::binary);
    const std::vector<uint8_t> armed_bytes((std::istreambuf_iterator<char>(armed_in)),
                                           std::istreambuf_iterator<char>());
    assert(armed_bytes.size() >= 8192);

    const uint32_t athw_off = hive_open_path(armed_bytes, "ControlSet001\\Services\\athw");
    assert(athw_off != 0xFFFFFFFF);
    uint32_t value = 0;
    assert(hive_get_dword(armed_bytes, athw_off, "Start", &value) && value == 0x0);
    assert(hive_get_dword(armed_bytes, athw_off, "Type", &value) && value == 0x1);
    assert(hive_get_dword(armed_bytes, athw_off, "ErrorControl", &value) && value == 0x1);
    assert(hive_get_dword(armed_bytes, athw_off, "BootFlags", &value) && value == 0x1);
    assert(hive_get_string(armed_bytes, athw_off, "Group") == "NDIS");
    assert(hive_get_string(armed_bytes, athw_off, "ImagePath") == "system32\\drivers\\athw.sys");

    const uint32_t athw_params = hive_open_path(armed_bytes, "ControlSet001\\Services\\athw\\Parameters");
    assert(athw_params != 0xFFFFFFFF);
    assert(hive_value_type(armed_bytes, athw_params, "*EEE") == 1 /* REG_SZ */);
    assert(hive_get_string(armed_bytes, athw_params, "*EEE") == "0");
    assert(hive_get_dword(armed_bytes, athw_params, "PowerSavingMode", &value) && value == 0);
    assert(hive_get_dword(armed_bytes, athw_params, "GigaLite", &value) && value == 0);
    assert(hive_get_dword(armed_bytes, athw_params, "AutoDisableGigabit", &value) && value == 0);
    assert(hive_value_type(armed_bytes, athw_params, "*WaitAutoNegComplete") == 1 /* REG_SZ */);
    assert(hive_get_string(armed_bytes, athw_params, "*WaitAutoNegComplete") == "0");
    assert(hive_get_dword(armed_bytes, athw_params, "PnPCapabilities", &value) && value == 0x00000018);

    const uint32_t cddb_off = hive_open_path(armed_bytes, "ControlSet001\\Control\\CriticalDeviceDatabase");
    assert(cddb_off != 0xFFFFFFFF);
    const uint32_t athw_hwid = hive_find_subkey(armed_bytes, cddb_off, "pci#ven_1969&dev_1091");
    assert(athw_hwid != 0xFFFFFFFF);
    assert(hive_get_string(armed_bytes, athw_hwid, "Service") == "athw");
    assert(hive_get_string(armed_bytes, athw_hwid, "ClassGUID") == "{4d36e972-e325-11ce-bfc1-08002be10318}");
    // x64-only package hardware IDs must not be bound in this 32-bit guest image.
    assert(hive_find_subkey(armed_bytes, cddb_off, "pci#ven_14e4&dev_1680") == 0xFFFFFFFF);

    // DMA / TSO / checksum offload disables reached the offline image too.
    for (const char* offload_key : {"*LsoV2IPv4", "*LsoV2IPv6", "*IPChecksumOffloadIPv4",
                                    "*TCPChecksumOffloadIPv4", "*UDPChecksumOffloadIPv4"}) {
        assert(hive_get_string(armed_bytes, athw_params, offload_key) == "0");
    }

    // Rejected software adapter: no service key, no CDDB binding, nothing staged.
    assert(hive_open_path(armed_bytes, "ControlSet001\\Services\\tap0901") == 0xFFFFFFFF);
    assert(!std::filesystem::exists(vol_x86 / "Windows" / "System32" / "drivers" / "tap0901.sys", ec));

    // The flushed header stays clean and self-consistent after the extra writes.
    const uint32_t pseq = hive_rd32(&armed_bytes[0x04]);
    const uint32_t sseq = hive_rd32(&armed_bytes[0x08]);
    assert(pseq == sseq);
    assert(PnpDriverArmer::calculate_regf_header_checksum(armed_bytes.data()) ==
           hive_rd32(&armed_bytes[0x1FC]));

    std::filesystem::remove_all(scratch, ec);
    std::cout << "  PASS: test_guest_arch_detection_and_universal_ndis_harvest\n";
}

void test_stage15_crash_dump_paging_and_offload_kill_switch() {
    std::cout << "[RUN] test_stage15_crash_dump_paging_and_offload_kill_switch\n";

    // UTF-16LE REG_MULTI_SZ payload with a single string + final terminator
    auto multi_sz = [](const std::string& s) {
        std::vector<uint8_t> out;
        out.reserve((s.size() + 2) * 2);
        for (char c : s) {
            out.push_back(static_cast<uint8_t>(c));
            out.push_back(0);
        }
        out.push_back(0);
        out.push_back(0);
        return out;
    };

    // ------------------------------------------------------------------------
    // 1. Fresh synthetic hive: every Stage 15 fix is created from scratch.
    //    VBoxNetLwf is seeded at Start = 0 (boot) so the neutralisation is visible.
    // ------------------------------------------------------------------------
    auto hive = PnpDriverArmer::create_synthetic_system_hive(1, {
        {"msiscsi", 3}, {"Tcpip", 3}, {"NDIS", 3}, {"rt640x64", 3}, {"VBoxNetLwf", 0}});

    // Nothing under Control yet -- the armer has to create CrashControl / Memory Management.
    assert(hive_open_path(hive, "ControlSet001\\Control\\CrashControl") == 0xFFFFFFFF);

    auto first = PnpDriverArmer::arm_hive_buffer(hive);
    assert(first.is_ok());
    const auto& rep = first.value();
    assert(rep.success);
    assert(rep.crash_dump_disabled);
    assert(rep.paging_files_cleared);
    assert(rep.tcpip_offload_disabled);
    assert(rep.vbox_lwf_disabled);
    assert(rep.message.find("Stage 15") != std::string::npos);

    uint32_t v = 0;
    const uint32_t crash = hive_open_path(hive, "ControlSet001\\Control\\CrashControl");
    assert(crash != 0xFFFFFFFF);
    assert(hive_get_dword(hive, crash, "CrashDumpEnabled", &v) && v == 0);   // no dump_ndis / dump_netio
    assert(hive_get_dword(hive, crash, "LogEvent", &v) && v == 0);
    assert(hive_get_dword(hive, crash, "SendAlert", &v) && v == 0);
    assert(hive_get_dword(hive, crash, "AutoReboot", &v) && v == 0);         // no reboot loop
    assert(hive_get_dword(hive, crash, "DisplayParameters", &v) && v == 1);  // BSOD shows the 4 arguments
    assert(hive_value_type(hive, crash, "CrashDumpEnabled") == 4);           // REG_DWORD

    const uint32_t mm = hive_open_path(hive, "ControlSet001\\Control\\Session Manager\\Memory Management");
    assert(mm != 0xFFFFFFFF);
    assert(hive_get_string(hive, mm, "PagingFiles").empty());
    assert(hive_get_string(hive, mm, "ExistingPageFiles").empty());
    assert(hive_value_type(hive, mm, "PagingFiles") == 7);        // REG_MULTI_SZ
    assert(hive_value_type(hive, mm, "ExistingPageFiles") == 7);

    const uint32_t tcp = hive_open_path(hive, "ControlSet001\\Services\\Tcpip\\Parameters");
    assert(tcp != 0xFFFFFFFF);
    assert(hive_get_dword(hive, tcp, "DisableTaskOffload", &v) && v == 1);  // global offload kill switch
    assert(hive_get_dword(hive, tcp, "EnableRSS", &v) && v == 0);
    assert(hive_get_dword(hive, tcp, "EnableTCPA", &v) && v == 0);

    const uint32_t vbox = hive_open_path(hive, "ControlSet001\\Services\\VBoxNetLwf");
    assert(vbox != 0xFFFFFFFF);
    assert(hive_get_dword(hive, vbox, "Start", &v) && v == 4);              // boot-start -> disabled
    // The filter is only neutralised, never promoted into the boot-armed service set.
    assert(std::find(rep.armed_services.begin(), rep.armed_services.end(), "VBoxNetLwf") ==
           rep.armed_services.end());

    // ------------------------------------------------------------------------
    // 2. Re-corrupt the armed state and arm again: an image that already HAS a
    //    paging file / dump stack / offload must be corrected, not skipped.
    // ------------------------------------------------------------------------
    assert(hive_poke_dword(hive, crash, "CrashDumpEnabled", 1));      // dump stack on again
    assert(hive_poke_dword(hive, crash, "AutoReboot", 1));
    assert(hive_poke_dword(hive, crash, "DisplayParameters", 0));     // hide the bugcheck arguments
    // The MULTI_SZ data cell only has room for one UTF-16 char; "A" is enough to
    // make the value non-empty (i.e. a paging file that must be cleared).
    assert(hive_poke_string_data(hive, mm, "PagingFiles", multi_sz("A")));
    assert(hive_poke_string_data(hive, mm, "ExistingPageFiles", multi_sz("A")));
    assert(hive_poke_dword(hive, tcp, "DisableTaskOffload", 0));
    assert(hive_poke_dword(hive, tcp, "EnableRSS", 1));
    assert(hive_poke_dword(hive, tcp, "EnableTCPA", 1));
    assert(hive_poke_dword(hive, vbox, "Start", 0));

    // Pre-state sanity: the image really is back in the failing configuration.
    assert(hive_get_dword(hive, crash, "CrashDumpEnabled", &v) && v == 1);
    assert(!hive_get_string(hive, mm, "PagingFiles").empty());
    assert(hive_get_dword(hive, tcp, "DisableTaskOffload", &v) && v == 0);
    assert(hive_get_dword(hive, vbox, "Start", &v) && v == 0);

    auto second = PnpDriverArmer::arm_hive_buffer(hive);
    assert(second.is_ok());
    assert(second.value().success);
    assert(second.value().crash_dump_disabled);
    assert(second.value().paging_files_cleared);
    assert(second.value().tcpip_offload_disabled);
    assert(second.value().vbox_lwf_disabled);

    assert(hive_get_dword(hive, crash, "CrashDumpEnabled", &v) && v == 0);
    assert(hive_get_dword(hive, crash, "AutoReboot", &v) && v == 0);
    assert(hive_get_dword(hive, crash, "DisplayParameters", &v) && v == 1);
    assert(hive_get_string(hive, mm, "PagingFiles").empty());
    assert(hive_get_string(hive, mm, "ExistingPageFiles").empty());
    assert(hive_value_type(hive, mm, "PagingFiles") == 7);
    assert(hive_get_dword(hive, tcp, "DisableTaskOffload", &v) && v == 1);
    assert(hive_get_dword(hive, tcp, "EnableRSS", &v) && v == 0);
    assert(hive_get_dword(hive, tcp, "EnableTCPA", &v) && v == 0);
    assert(hive_get_dword(hive, vbox, "Start", &v) && v == 4);

    // ------------------------------------------------------------------------
    // 3. No VBoxNetLwf on the image: the key must NOT be invented.
    // ------------------------------------------------------------------------
    auto hive_no_vbox = PnpDriverArmer::create_synthetic_system_hive(1, {
        {"msiscsi", 3}, {"Tcpip", 3}, {"NDIS", 3}, {"rt640x64", 3}});
    auto third = PnpDriverArmer::arm_hive_buffer(hive_no_vbox);
    assert(third.is_ok());
    assert(third.value().success);
    assert(third.value().crash_dump_disabled);
    assert(third.value().paging_files_cleared);
    assert(third.value().tcpip_offload_disabled);
    assert(third.value().vbox_lwf_disabled); // nothing to disable
    assert(hive_open_path(hive_no_vbox, "ControlSet001\\Services\\VBoxNetLwf") == 0xFFFFFFFF);

    // ------------------------------------------------------------------------
    // 4. End-to-end: the flushed SYSTEM hive file carries every fix.
    // ------------------------------------------------------------------------
    const std::filesystem::path scratch = "test_scratch_stage15";
    std::error_code ec;
    std::filesystem::remove_all(scratch, ec);
    std::filesystem::create_directories(scratch / "Windows" / "System32" / "config", ec);
    const std::filesystem::path hive_path = scratch / "Windows" / "System32" / "config" / "SYSTEM";
    {
        auto file_hive = PnpDriverArmer::create_synthetic_system_hive(1, {
            {"msiscsi", 3}, {"Tcpip", 3}, {"NDIS", 3}, {"rt640x64", 3}, {"VBoxNetLwf", 0}});
        std::ofstream out(hive_path, std::ios::binary | std::ios::trunc);
        out.write(reinterpret_cast<const char*>(file_hive.data()),
                  static_cast<std::streamsize>(file_hive.size()));
    }

    auto e2e = PnpDriverArmer::arm_offline_system_hive(hive_path);
    assert(e2e.is_ok());
    const auto& e2e_rep = e2e.value();
    assert(e2e_rep.success);
    assert(e2e_rep.crash_dump_disabled);
    assert(e2e_rep.paging_files_cleared);
    assert(e2e_rep.tcpip_offload_disabled);
    assert(e2e_rep.vbox_lwf_disabled);

    std::ifstream armed_in(hive_path, std::ios::binary);
    const std::vector<uint8_t> armed((std::istreambuf_iterator<char>(armed_in)),
                                     std::istreambuf_iterator<char>());
    assert(armed.size() >= 8192);

    const uint32_t e2e_crash = hive_open_path(armed, "ControlSet001\\Control\\CrashControl");
    assert(e2e_crash != 0xFFFFFFFF);
    assert(hive_get_dword(armed, e2e_crash, "CrashDumpEnabled", &v) && v == 0);
    assert(hive_get_dword(armed, e2e_crash, "SendAlert", &v) && v == 0);
    assert(hive_get_dword(armed, e2e_crash, "AutoReboot", &v) && v == 0);
    assert(hive_get_dword(armed, e2e_crash, "DisplayParameters", &v) && v == 1);

    const uint32_t e2e_mm = hive_open_path(armed, "ControlSet001\\Control\\Session Manager\\Memory Management");
    assert(e2e_mm != 0xFFFFFFFF);
    assert(hive_get_string(armed, e2e_mm, "PagingFiles").empty());
    assert(hive_get_string(armed, e2e_mm, "ExistingPageFiles").empty());
    assert(hive_value_type(armed, e2e_mm, "PagingFiles") == 7);

    const uint32_t e2e_tcp = hive_open_path(armed, "ControlSet001\\Services\\Tcpip\\Parameters");
    assert(e2e_tcp != 0xFFFFFFFF);
    assert(hive_get_dword(armed, e2e_tcp, "DisableTaskOffload", &v) && v == 1);
    assert(hive_get_dword(armed, e2e_tcp, "EnableRSS", &v) && v == 0);
    assert(hive_get_dword(armed, e2e_tcp, "EnableTCPA", &v) && v == 0);

    const uint32_t e2e_vbox = hive_open_path(armed, "ControlSet001\\Services\\VBoxNetLwf");
    assert(e2e_vbox != 0xFFFFFFFF);
    assert(hive_get_dword(armed, e2e_vbox, "Start", &v) && v == 4);

    // Header stays clean and self-consistent after the extra writes.
    const uint32_t pseq = hive_rd32(&armed[0x04]);
    const uint32_t sseq = hive_rd32(&armed[0x08]);
    assert(pseq == sseq);
    assert(PnpDriverArmer::calculate_regf_header_checksum(armed.data()) == hive_rd32(&armed[0x1FC]));

    std::filesystem::remove_all(scratch, ec);
    std::cout << "  PASS: test_stage15_crash_dump_paging_and_offload_kill_switch\n";
}

void test_os_family_gating_and_safe_driver_staging() {
    std::cout << "[RUN] test_os_family_gating_and_safe_driver_staging\n";

    std::error_code ec;
    const std::filesystem::path scratch = "test_scratch_os_family";
    std::filesystem::remove_all(scratch, ec);
    std::filesystem::create_directories(scratch, ec);
    using OF = GuestOsFamily;

    auto write_bytes = [&](const std::filesystem::path& p, const std::vector<uint8_t>& bytes) {
        std::filesystem::create_directories(p.parent_path(), ec);
        std::ofstream out(p, std::ios::binary | std::ios::trunc);
        out.write(reinterpret_cast<const char*>(bytes.data()),
                  static_cast<std::streamsize>(bytes.size()));
    };
    auto read_bytes = [&](const std::filesystem::path& p) -> std::string {
        std::ifstream in(p, std::ios::binary);
        return std::string((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    };

    // ------------------------------------------------------------------
    // 1. Pure OS version classifier
    // ------------------------------------------------------------------
    assert(PnpDriverArmer::os_family_name(OF::Legacy) == "legacy");
    assert(PnpDriverArmer::os_family_name(OF::Modern) == "modern");
    assert(PnpDriverArmer::os_family_name(OF::Unknown) == "unknown");

    // NT 5.x and NT 6.0 / 6.1 boot from the CriticalDeviceDatabase.
    assert(PnpDriverArmer::classify_os_version(5, 1, 2600) == OF::Legacy);   // XP
    assert(PnpDriverArmer::classify_os_version(5, 2, 3790) == OF::Legacy);   // Server 2003
    assert(PnpDriverArmer::classify_os_version(6, 0, 6002) == OF::Legacy);   // Vista / 2008
    assert(PnpDriverArmer::classify_os_version(6, 1, 7601) == OF::Legacy);   // Win7 / 2008 R2
    // NT 6.2+ resolves boot drivers from the DriverStore.
    assert(PnpDriverArmer::classify_os_version(6, 2, 9200) == OF::Modern);   // Win8
    assert(PnpDriverArmer::classify_os_version(6, 3, 9600) == OF::Modern);   // Win8.1
    assert(PnpDriverArmer::classify_os_version(10, 0, 19045) == OF::Modern); // Win10
    assert(PnpDriverArmer::classify_os_version(10, 0, 26100) == OF::Modern); // Win11
    // Build-number-only evidence (CurrentBuildNumber / kernel version resource).
    assert(PnpDriverArmer::classify_os_version(0, 0, 7601) == OF::Legacy);
    assert(PnpDriverArmer::classify_os_version(0, 0, 9200) == OF::Modern);
    // Major/minor without a build number is still enough to decide.
    assert(PnpDriverArmer::classify_os_version(6, 1, 0) == OF::Legacy);
    assert(PnpDriverArmer::classify_os_version(6, 0, 0) == OF::Legacy);
    assert(PnpDriverArmer::classify_os_version(6, 2, 0) == OF::Modern);
    // No evidence at all.
    assert(PnpDriverArmer::classify_os_version(0, 0, 0) == OF::Unknown);

    const std::vector<std::pair<std::string, uint32_t>> boot_services = {
        {"msiscsi", 3}, {"Tcpip", 3}, {"NDIS", 3}, {"rt640x64", 3}};

    // ------------------------------------------------------------------
    // 2. Synthetic Legacy hive (6.1): CDDB bindings are written
    // ------------------------------------------------------------------
    auto legacy_hive = PnpDriverArmer::create_synthetic_system_hive(1, boot_services, {}, "6.1");
    assert(PnpDriverArmer::detect_os_family_from_hive(legacy_hive) == OF::Legacy);

    auto legacy_res = PnpDriverArmer::arm_hive_buffer(legacy_hive);
    assert(legacy_res.is_ok());
    const auto& legacy_rep = legacy_res.value();
    assert(legacy_rep.success);
    assert(legacy_rep.guest_os_family == "legacy");
    assert(!legacy_rep.cddb_bindings.empty());
    assert(legacy_rep.cddb_purged.empty());
    assert(hive_open_path(legacy_hive,
                          "ControlSet001\\Control\\CriticalDeviceDatabase\\pci#ven_10ec&dev_8168") !=
           0xFFFFFFFF);
    assert(legacy_rep.message.find("OS family legacy") != std::string::npos);
    assert(legacy_rep.message.find("CDDB injected") != std::string::npos);
    assert(legacy_rep.summary().find("Guest OS Family:   legacy") != std::string::npos);

    // ------------------------------------------------------------------
    // 3. Synthetic Modern hive (10.0): CDDB injection is skipped entirely
    // ------------------------------------------------------------------
    auto modern_hive = PnpDriverArmer::create_synthetic_system_hive(1, boot_services, {}, "10.0");
    assert(PnpDriverArmer::detect_os_family_from_hive(modern_hive) == OF::Modern);

    auto modern_res = PnpDriverArmer::arm_hive_buffer(modern_hive);
    assert(modern_res.is_ok());
    const auto& modern_rep = modern_res.value();
    assert(modern_rep.success);
    assert(modern_rep.guest_os_family == "modern");
    assert(modern_rep.cddb_bindings.empty());
    assert(modern_rep.cddb_purged.empty());
    // The whole CriticalDeviceDatabase must stay absent on a Modern target -- a
    // pci#ven_* key here fabricates the ghost devnode that ndis.sys 0xD1 comes from.
    assert(hive_open_path(modern_hive, "ControlSet001\\Control\\CriticalDeviceDatabase") == 0xFFFFFFFF);
    // Only the CDDB write is gated: the boot stack is still armed as usual.
    assert(modern_rep.iscsi_stack_armed);
    assert(modern_rep.boot_flags_armed);
    uint32_t value = 0;
    const uint32_t rt_off = hive_open_path(modern_hive, "ControlSet001\\Services\\rt640x64");
    assert(rt_off != 0xFFFFFFFF);
    assert(hive_get_dword(modern_hive, rt_off, "Start", &value) && value == 0);
    assert(hive_open_path(modern_hive, "ControlSet001\\Control\\CrashControl") != 0xFFFFFFFF);
    assert(modern_rep.message.find("CDDB skipped") != std::string::npos);
    assert(modern_rep.summary().find("Guest OS Family:   modern") != std::string::npos);

    // ------------------------------------------------------------------
    // 4. Modern purge: bindings left behind by an earlier (Legacy) pass are removed
    // ------------------------------------------------------------------
    auto purged_hive = PnpDriverArmer::create_synthetic_system_hive(1, boot_services, {}, "6.1");
    auto seed_res = PnpDriverArmer::arm_hive_buffer(purged_hive);
    assert(seed_res.is_ok() && seed_res.value().success);
    assert(!seed_res.value().cddb_bindings.empty());
    const char* cddb_base = "ControlSet001\\Control\\CriticalDeviceDatabase";
    assert(hive_open_path(purged_hive, std::string(cddb_base) + "\\pci#ven_10ec&dev_8168") != 0xFFFFFFFF);
    assert(hive_open_path(purged_hive, std::string(cddb_base) + "\\pci#ven_8086&dev_15b8") != 0xFFFFFFFF);

    // The guest was upgraded to NT 6.2+ since: rewrite the version evidence in place.
    const uint32_t win_off = hive_open_path(purged_hive, "ControlSet001\\Control\\Windows");
    assert(win_off != 0xFFFFFFFF);
    assert(hive_poke_dword(purged_hive, win_off, "CurrentMajorVersionNumber", 10));
    assert(hive_poke_dword(purged_hive, win_off, "CurrentMinorVersionNumber", 0));
    assert(hive_poke_string_data(purged_hive, win_off, "CurrentVersion",
                                 {'1', 0, '0', 0, '.', 0, '0', 0, 0, 0}));
    assert(PnpDriverArmer::detect_os_family_from_hive(purged_hive) == OF::Modern);

    auto purge_res = PnpDriverArmer::arm_hive_buffer(purged_hive);
    assert(purge_res.is_ok());
    const auto& purge_rep = purge_res.value();
    assert(purge_rep.success);
    assert(purge_rep.guest_os_family == "modern");
    assert(purge_rep.cddb_bindings.empty());
    assert(!purge_rep.cddb_purged.empty());
    assert(std::find(purge_rep.cddb_purged.begin(), purge_rep.cddb_purged.end(),
                     "pci#ven_10ec&dev_8168") != purge_rep.cddb_purged.end());

    // The CDDB key itself survives (now empty); every pci#ven_* child is gone.
    assert(hive_open_path(purged_hive, cddb_base) != 0xFFFFFFFF);
    for (const std::string& hwid : purge_rep.cddb_purged) {
        assert(hive_open_path(purged_hive, std::string(cddb_base) + "\\" + hwid) == 0xFFFFFFFF);
    }

    // Sibling Control keys, the control set and the armed services are untouched.
    assert(hive_open_path(purged_hive, "ControlSet001\\Control\\Windows") != 0xFFFFFFFF);
    assert(hive_open_path(purged_hive, "ControlSet001\\Control\\CrashControl") != 0xFFFFFFFF);
    assert(hive_open_path(purged_hive, "ControlSet001\\Control\\Session Manager\\Memory Management") !=
           0xFFFFFFFF);
    assert(hive_open_path(purged_hive, "ControlSet001\\Services\\rt640x64") != 0xFFFFFFFF);
    assert(hive_open_path(purged_hive, "Select") != 0xFFFFFFFF);
    assert(PnpDriverArmer::calculate_regf_header_checksum(purged_hive.data()) ==
           hive_rd32(&purged_hive[0x1FC]));

    // Re-arming is idempotent: nothing left to purge, still nothing injected.
    auto again = PnpDriverArmer::arm_hive_buffer(purged_hive);
    assert(again.is_ok() && again.value().success);
    assert(again.value().cddb_bindings.empty());
    assert(again.value().cddb_purged.empty());

    // ------------------------------------------------------------------
    // 5. Offline volume detection: SYSTEM hive -> SOFTWARE hive -> ntoskrnl.exe
    // ------------------------------------------------------------------
    // (a) SYSTEM hive Control\Windows wins.
    const std::filesystem::path vol_sys = scratch / "vol_sys";
    write_bytes(vol_sys / "Windows" / "System32" / "config" / "SYSTEM",
                PnpDriverArmer::create_synthetic_system_hive(1, boot_services, {}, "6.1"));
    assert(PnpDriverArmer::detect_guest_os_family(vol_sys) == OF::Legacy);
    assert(PnpDriverArmer::detect_guest_os_family(vol_sys / "Windows") == OF::Legacy);

    // (b) No version in the SYSTEM hive -> the SOFTWARE hive's version key is read.
    const std::filesystem::path vol_sw = scratch / "vol_sw";
    write_bytes(vol_sw / "Windows" / "System32" / "config" / "SYSTEM",
                PnpDriverArmer::create_synthetic_system_hive(1, boot_services));
    write_bytes(vol_sw / "Windows" / "System32" / "config" / "SOFTWARE",
                PnpDriverArmer::create_synthetic_system_hive(1, {}, {}, "10.0"));
    assert(PnpDriverArmer::detect_guest_os_family(vol_sw) == OF::Modern);

    // The same fallback works on one hive: Control\Windows without usable evidence
    // falls through to Microsoft\Windows NT\CurrentVersion at the hive root.
    auto fallback_hive = PnpDriverArmer::create_synthetic_system_hive(1, boot_services, {}, "10.0");
    const uint32_t cs_win = hive_open_path(fallback_hive, "ControlSet001\\Control\\Windows");
    assert(cs_win != 0xFFFFFFFF);
    assert(hive_poke_dword(fallback_hive, cs_win, "CurrentMajorVersionNumber", 0));
    assert(hive_poke_dword(fallback_hive, cs_win, "CurrentMinorVersionNumber", 0));
    assert(hive_poke_string_data(fallback_hive, cs_win, "CurrentBuildNumber", {0, 0}));
    assert(hive_poke_string_data(fallback_hive, cs_win, "CurrentVersion", {0, 0}));
    assert(PnpDriverArmer::detect_os_family_from_hive(fallback_hive) == OF::Modern);

    // (c) Neither hive carries a version -> the kernel's version resource settles it.
    auto write_kernel = [&](const std::filesystem::path& pe_path, uint32_t major, uint32_t minor,
                            uint32_t build) {
        std::vector<uint8_t> image(0x400, 0);
        image[0x00] = 'M';
        image[0x01] = 'Z';
        hive_wr32(image.data() + 0x3C, 0x80); // e_lfanew
        image[0x80] = 'P';
        image[0x81] = 'E';
        image[0x82] = 0;
        image[0x83] = 0;
        // VS_FIXEDFILEINFO (signature 0xFEEF04BD + dwStrucVersion 0x00010000)
        // at a DWORD-aligned file offset.
        const size_t fixed = 0x200;
        hive_wr32(image.data() + fixed + 0, 0xFEEF04BDu);
        hive_wr32(image.data() + fixed + 4, 0x00010000u);
        hive_wr32(image.data() + fixed + 8, (major << 16) | (minor & 0xFFFFu));
        hive_wr32(image.data() + fixed + 12, (build & 0xFFFFu) << 16);
        write_bytes(pe_path, image);
    };

    const std::filesystem::path vol_krnl = scratch / "vol_krnl";
    write_kernel(vol_krnl / "Windows" / "System32" / "ntoskrnl.exe", 6, 1, 7601);
    assert(PnpDriverArmer::detect_guest_os_family(vol_krnl) == OF::Legacy);
    assert(PnpDriverArmer::detect_os_family_from_kernel(
               vol_krnl / "Windows" / "System32" / "ntoskrnl.exe") == OF::Legacy);

    const std::filesystem::path vol_krnl10 = scratch / "vol_krnl10";
    write_kernel(vol_krnl10 / "Windows" / "System32" / "ntoskrnl.exe", 10, 0, 26100);
    assert(PnpDriverArmer::detect_guest_os_family(vol_krnl10) == OF::Modern);

    // No evidence anywhere, and no Windows tree at all.
    const std::filesystem::path vol_junk = scratch / "vol_junk";
    write_bytes(vol_junk / "Windows" / "System32" / "ntoskrnl.exe",
                std::vector<uint8_t>{'n', 'o', 't', ' ', 'a', ' ', 'p', 'e'});
    assert(PnpDriverArmer::detect_guest_os_family(vol_junk) == OF::Unknown);
    assert(PnpDriverArmer::detect_guest_os_family(scratch / "nope") == OF::Unknown);
    assert(PnpDriverArmer::detect_os_family_from_kernel(vol_junk / "no_such_kernel") == OF::Unknown);

    // ------------------------------------------------------------------
    // 6. End to end: arm_offline_system_hive carries the volume family into arming
    // ------------------------------------------------------------------
    const std::filesystem::path vol_e2e = scratch / "vol_e2e";
    write_bytes(vol_e2e / "Windows" / "System32" / "config" / "SYSTEM",
                PnpDriverArmer::create_synthetic_system_hive(1, boot_services, {}, "10.0"));
    auto e2e_res =
        PnpDriverArmer::arm_offline_system_hive(vol_e2e / "Windows" / "System32" / "config" / "SYSTEM");
    assert(e2e_res.is_ok());
    const auto& e2e_rep = e2e_res.value();
    assert(e2e_rep.success);
    assert(e2e_rep.guest_os_family == "modern");
    assert(e2e_rep.cddb_bindings.empty());

    // ------------------------------------------------------------------
    // 7. Safe staging: an existing guest driver binary is never overwritten
    // ------------------------------------------------------------------
    const std::filesystem::path vol_stage = scratch / "vol_stage";
    const std::filesystem::path sys32 = vol_stage / "Windows" / "System32";
    const std::filesystem::path drivers_dir = sys32 / "drivers";

    NdisPackageInfo inbox_pkg;
    inbox_pkg.package_dir_name = "netbnx.inf_amd64_aaa";
    inbox_pkg.service_name = "bnxtre";
    inbox_pkg.driver_file = "bnxtre.sys";
    inbox_pkg.source_sys = sys32 / "DriverStore" / "FileRepository" / "netbnx.inf_amd64_aaa" / "bnxtre.sys";
    write_bytes(inbox_pkg.source_sys, std::vector<uint8_t>{
        'M', 'O', 'C', 'K', '_', 'D', 'R', 'I', 'V', 'E', 'R', 'S', 'T', 'O', 'R', 'E'});

    // The guest image already ships its own (working) bnxtre.sys.
    const std::vector<uint8_t> installed_binary = {
        'I', 'N', 'B', 'O', 'X', '_', 'V', 'E', 'N', 'D', 'O', 'R', '_', 'B', 'I', 'N', 'A', 'R', 'Y'};
    write_bytes(drivers_dir / "bnxtre.sys", installed_binary);

    std::vector<std::string> stage_warns;
    std::vector<std::string> staged;
    assert(PnpDriverArmer::stage_harvested_drivers(sys32, {inbox_pkg}, stage_warns, &staged));
    assert(stage_warns.empty());
    assert(staged.empty()); // skipped, not staged
    assert(read_bytes(drivers_dir / "bnxtre.sys") == std::string(installed_binary.begin(),
                                                                 installed_binary.end()));

    // The critical-boot staging path honours the same no-overwrite rule.
    assert(PnpDriverArmer::verify_or_stage_driver_file(drivers_dir, "bnxtre.sys", stage_warns));
    assert(stage_warns.empty());
    assert(read_bytes(drivers_dir / "bnxtre.sys") == std::string(installed_binary.begin(),
                                                                 installed_binary.end()));

    // Once the binary is really missing the package is staged normally.
    std::filesystem::remove(drivers_dir / "bnxtre.sys", ec);
    assert(!ec);
    std::vector<std::string> staged_late;
    assert(PnpDriverArmer::stage_harvested_drivers(sys32, {inbox_pkg}, stage_warns, &staged_late));
    assert(stage_warns.empty());
    assert(staged_late.size() == 1 && staged_late[0] == "bnxtre.sys");
    assert(read_bytes(drivers_dir / "bnxtre.sys") == "MOCK_DRIVERSTORE");

    std::filesystem::remove_all(scratch, ec);
    std::cout << "  PASS: test_os_family_gating_and_safe_driver_staging\n";
}

// Phase-0 stop 0xA (IRQL_NOT_LESS_OR_EQUAL, Arg1 = 0x8, Arg2 = DISPATCH_LEVEL) on the
// ThinkCentre M71s / RTL8111E: anti-flap values the miniport does not implement, or that
// arrive as REG_DWORD where NDIS expects a string, are parsed through the driver's
// advanced-property string descriptor at DISPATCH_LEVEL. This covers both gates:
//   * schema -- <Index>\Ndi\params\<ParamName> must exist or the write is skipped;
//   * type   -- every NDIS standardized "*" keyword is REG_SZ, never REG_DWORD;
//   * family -- NDIS 6.30+ keywords (*EEE, *GreenEthernet) are dropped on legacy guests.
void test_ndi_schema_gated_reg_sz_anti_flap() {
    std::cout << "[RUN] test_ndi_schema_gated_reg_sz_anti_flap\n";

    std::error_code ec;
    const std::filesystem::path scratch = "test_scratch_ndi_schema";
    std::filesystem::remove_all(scratch, ec);
    std::filesystem::create_directories(scratch, ec);

    // Capture the armer's own log so the mandated skip messages can be asserted verbatim.
    std::vector<std::string> captured;
    Logger::default_logger().set_sink(
        [&](LogLevel /*level*/, std::string_view /*category*/, std::string_view message,
            std::string_view /*formatted*/) {
            captured.emplace_back(message);
        });
    auto log_contains = [&](const std::string& needle) -> bool {
        for (const std::string& line : captured) {
            if (line.find(needle) != std::string::npos) return true;
        }
        return false;
    };

    const std::string inst_prefix =
        "ControlSet001\\Control\\Class\\{4d36e972-e325-11ce-bfc1-08002be10318}\\";
    // The flat driver-level Parameters key the schema gate is contrasted against. It is
    // e1d68x64's: Realtek's copy (Services\rt640x64\Parameters) is purged by the armer,
    // because the Realtek miniport never reads a driver-level Parameters key at all.
    const std::string rt_params_path = "ControlSet001\\Services\\e1d68x64\\Parameters";
    const std::string rt_purged_path = "ControlSet001\\Services\\rt640x64\\Parameters";

    // 0000 advertises the whole advanced-property set; 0001 is older PHY silicon that
    // never declares *EEE / *GreenEthernet (the RTL8111E Rev 06 in the incident).
    const std::vector<PnpDriverArmer::SyntheticNetAdapter> adapters = {
        {"0000", "Realtek PCIe GbE Family Controller", "PCI\\VEN_10EC&DEV_8168&SUBSYS_000010EC",
         "pci\\ven_10ec&dev_8168", full_anti_flap_ndi_schema()},
        {"0001", "Realtek PCIe GbE Family Controller", "PCI\\VEN_10EC&DEV_8168",
         "pci\\ven_10ec&dev_8168", ndi_schema_without({"*EEE", "*GreenEthernet"})},
    };
    const std::vector<std::pair<std::string, uint32_t>> services = {
        {"msiscsi", 3}, {"rt640x64", 3}, {"Tcpip", 1}, {"NDIS", 1}};

    {
        // ---------------------------------------------------------------------
        // 1. NDIS 6.30+ guest: the Ndi\params schema decides, and the "*" type rule holds.
        // ---------------------------------------------------------------------
        captured.clear();
        auto modern_hive = PnpDriverArmer::create_synthetic_system_hive(1, services, adapters, "10.0");
        auto modern_res = PnpDriverArmer::arm_hive_buffer(modern_hive);
        assert(modern_res.is_ok());
        assert(modern_res.value().success);
        assert(modern_res.value().guest_os_family == "modern");

        const uint32_t a0000 = hive_open_path(modern_hive, inst_prefix + "0000");
        const uint32_t a0001 = hive_open_path(modern_hive, inst_prefix + "0001");
        assert(a0000 != 0xFFFFFFFF);
        assert(a0001 != 0xFFFFFFFF);

        // Declared in Ndi\params -> written, strictly as REG_SZ "0".
        assert(hive_value_type(modern_hive, a0000, "*EEE") == 1 /* REG_SZ */);
        assert(hive_get_string(modern_hive, a0000, "*EEE") == "0");
        assert(hive_value_type(modern_hive, a0000, "*GreenEthernet") == 1 /* REG_SZ */);
        assert(hive_get_string(modern_hive, a0000, "*GreenEthernet") == "0");

        // Not declared -> never written, and the skip is reported to the operator.
        assert(hive_value_type(modern_hive, a0001, "*EEE") == 0xFFFFFFFF);
        assert(hive_value_type(modern_hive, a0001, "*GreenEthernet") == 0xFFFFFFFF);
        assert(log_contains("Adapter 0001 does not declare *EEE in Ndi\\params; skipping injection."));
        assert(log_contains(
            "Adapter 0001 does not declare *GreenEthernet in Ndi\\params; skipping injection."));

        // The rest of 0001's declared set still lands untouched by the gate.
        uint32_t dw = 0xFFFFFFFF;
        assert(hive_get_string(modern_hive, a0001, "EEE") == "0");
        assert(hive_get_dword(modern_hive, a0001, "GigaLite", &dw) && dw == 0);
        assert(hive_value_type(modern_hive, a0001, "*LsoV2IPv4") == 1 /* REG_SZ */);
        assert(hive_get_string(modern_hive, a0001, "*LsoV2IPv4") == "0");
        // PnPCapabilities is a device-instance capability mask, not an NDIS advanced
        // property: it is never schema-gated and stays a REG_DWORD.
        assert(hive_get_dword(modern_hive, a0001, "PnPCapabilities", &dw) && dw == 0x00000018);
        assert(hive_value_type(modern_hive, a0001, "PnPCapabilities") == 4 /* REG_DWORD */);

        // Strict typing: no NDIS standardized "*" keyword may exist as a REG_DWORD.
        for (const char* star : {"*EEE", "*GreenEthernet", "*FlowControl", "*WaitAutoNegComplete",
                                 "*GigaLite", "*WakeOnMagicPacket", "*PowerSavingMode",
                                 "*InterruptModeration", "*LsoV2IPv4", "*LsoV2IPv6"}) {
            assert(hive_value_type(modern_hive, a0000, star) == 1 /* REG_SZ */);
            assert(hive_get_string(modern_hive, a0000, star) == "0");
        }

        // The schema gate is scoped to adapter instance keys only: the driver's own flat
        // Parameters key has no Ndi\params and keeps every override.
        const uint32_t rt_params = hive_open_path(modern_hive, rt_params_path);
        assert(rt_params != 0xFFFFFFFF);
        assert(hive_value_type(modern_hive, rt_params, "*EEE") == 1 /* REG_SZ */);
        assert(hive_get_string(modern_hive, rt_params, "*EEE") == "0");

        // ... while the Realtek flat key the miniport never reads is gone outright.
        assert(hive_open_path(modern_hive, rt_purged_path) == 0xFFFFFFFF);
    }

    {
        // ---------------------------------------------------------------------
        // 2. Legacy guest (NT 6.1 / NDIS 6.20): *EEE and *GreenEthernet are rejected
        //    even though the miniport declares them in Ndi\params.
        // ---------------------------------------------------------------------
        captured.clear();
        auto legacy_hive = PnpDriverArmer::create_synthetic_system_hive(1, services, adapters, "6.1");
        auto legacy_res = PnpDriverArmer::arm_hive_buffer(legacy_hive);
        assert(legacy_res.is_ok());
        assert(legacy_res.value().success);
        assert(legacy_res.value().guest_os_family == "legacy");

        const uint32_t l0000 = hive_open_path(legacy_hive, inst_prefix + "0000");
        assert(l0000 != 0xFFFFFFFF);
        assert(hive_value_type(legacy_hive, l0000, "*EEE") == 0xFFFFFFFF);
        assert(hive_value_type(legacy_hive, l0000, "*GreenEthernet") == 0xFFFFFFFF);
        assert(log_contains("Adapter 0000: *EEE is an NDIS 6.30+ keyword; skipped for legacy guest"));

        // The NDIS 6.20-safe vendor keywords and every non-modern parameter survive.
        assert(hive_get_string(legacy_hive, l0000, "EEE") == "0");
        assert(hive_get_string(legacy_hive, l0000, "EnableGreenEthernet") == "0");
        assert(hive_value_type(legacy_hive, l0000, "*LsoV2IPv4") == 1 /* REG_SZ */);
        uint32_t dw = 0xFFFFFFFF;
        assert(hive_get_dword(legacy_hive, l0000, "GigaLite", &dw) && dw == 0);
        assert(hive_get_dword(legacy_hive, l0000, "PnPCapabilities", &dw) && dw == 0x00000018);

        // Same rejection inside the driver's own (non-Realtek) Parameters key, and the
        // Realtek flat key is absent here too.
        assert(hive_open_path(legacy_hive, rt_purged_path) == 0xFFFFFFFF);
        const uint32_t l_rt = hive_open_path(legacy_hive, rt_params_path);
        assert(l_rt != 0xFFFFFFFF);
        assert(hive_value_type(legacy_hive, l_rt, "*EEE") == 0xFFFFFFFF);
        assert(hive_value_type(legacy_hive, l_rt, "*GreenEthernet") == 0xFFFFFFFF);
        assert(hive_get_string(legacy_hive, l_rt, "EEE") == "0");
        assert(hive_value_type(legacy_hive, l_rt, "*LsoV2IPv4") == 1 /* REG_SZ */);
    }

    Logger::default_logger().reset_to_default_sink();
    std::filesystem::remove_all(scratch, ec);
    std::cout << "  PASS: test_ndi_schema_gated_reg_sz_anti_flap\n";
}

// ---------------------------------------------------------------------------
// Boot-conflict resolution: the multi-NIC Start = 0 decoupling, the purge of the
// flat Services\<Realtek driver>\Parameters anti-flap key, the SHA-256 identity
// helper behind the inspection, and the read-only inspection dump itself.
//
// Covers the M71s stop 0xA regression (STOP 0x0000000A, Arg1 = 0x8,
// Arg2 = DISPATCH_LEVEL) end to end: dual boot-NIC image -> --fix-boot-conflicts
// -> re-inspection proves only one vendor family is left at SERVICE_BOOT_START.
// ---------------------------------------------------------------------------
void test_boot_conflict_resolution_and_hive_inspection() {
    std::cout << "[RUN] test_boot_conflict_resolution_and_hive_inspection\n";

    auto mentions = [](const std::vector<std::string>& haystack, const std::string& needle) {
        return std::any_of(haystack.begin(), haystack.end(),
                           [&](const std::string& s) { return s.find(needle) != std::string::npos; });
    };

    // ---- 1. SHA-256 known-answer vectors (the inspection's binary identity check) ----
    assert(PnpDriverArmer::sha256_hex(nullptr, 0) ==
           "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
    const char* abc = "abc";
    assert(PnpDriverArmer::sha256_hex(reinterpret_cast<const uint8_t*>(abc), 3) ==
           "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
    const char* two_block = "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq";
    assert(PnpDriverArmer::sha256_hex(reinterpret_cast<const uint8_t*>(two_block),
                                      std::strlen(two_block)) ==
           "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1");
    assert(PnpDriverArmer::sha256_file("definitely-not-a-real-file.sys").empty());

    // ---- 2. Profile vocabulary ----
    assert(PnpDriverArmer::nic_profile_name(NicBootProfile::Auto) == "auto");
    assert(PnpDriverArmer::nic_profile_name(NicBootProfile::Realtek) == "realtek");
    assert(PnpDriverArmer::nic_profile_name(NicBootProfile::Intel) == "intel");
    assert(PnpDriverArmer::nic_profile_name(NicBootProfile::Multi) == "multi");

    bool ok = false;
    assert(PnpDriverArmer::parse_nic_profile("auto", &ok) == NicBootProfile::Auto && ok);
    assert(PnpDriverArmer::parse_nic_profile("REALTEK", &ok) == NicBootProfile::Realtek && ok);
    assert(PnpDriverArmer::parse_nic_profile("Intel", &ok) == NicBootProfile::Intel && ok);
    assert(PnpDriverArmer::parse_nic_profile("multi-nic", &ok) == NicBootProfile::Multi && ok);
    ok = true;
    PnpDriverArmer::parse_nic_profile("realtek-r1", &ok);
    assert(!ok);

    assert(PnpDriverArmer::is_realtek_service_name("rt640x64"));
    assert(PnpDriverArmer::is_realtek_service_name("RT64WIN7"));
    assert(!PnpDriverArmer::is_realtek_service_name("e1d68x64"));
    assert(PnpDriverArmer::is_intel_service_name("e1d68x64"));
    assert(!PnpDriverArmer::is_intel_service_name("rt640x64"));

    // ---- 3. Evidence-driven profile election ----
    const std::vector<std::pair<std::string, uint32_t>> services = {
        {"msiscsi", 3}, {"Tcpip", 1}, {"NDIS", 1}, {"rt640x64", 3}, {"e1d68x64", 3}};
    const std::vector<std::pair<std::string, uint32_t>> dual_boot_services = {
        {"msiscsi", 3}, {"Tcpip", 1}, {"NDIS", 1}, {"rt640x64", 0}, {"e1d68x64", 0}};

    const std::vector<PnpDriverArmer::SyntheticNetAdapter> realtek_only = {
        {"0000", "Realtek PCIe GbE Family Controller", "PCI\\VEN_10EC&DEV_8168",
         "pci\\ven_10ec&dev_8168", {}},
    };
    const std::vector<PnpDriverArmer::SyntheticNetAdapter> intel_only = {
        {"0000", "Intel(R) Ethernet Connection I219-LM", "PCI\\VEN_8086&DEV_15B8",
         "pci\\ven_8086&dev_15b8", {}},
    };
    const std::vector<PnpDriverArmer::SyntheticNetAdapter> both = {
        {"0000", "Realtek PCIe GbE Family Controller", "PCI\\VEN_10EC&DEV_8168",
         "pci\\ven_10ec&dev_8168", {}},
        {"0001", "Intel(R) Ethernet Connection I219-LM", "PCI\\VEN_8086&DEV_15B8",
         "pci\\ven_8086&dev_15b8", {}},
    };

    {
        auto rt_hive = PnpDriverArmer::create_synthetic_system_hive(1, services, realtek_only);
        assert(PnpDriverArmer::detect_nic_boot_profile(rt_hive) == NicBootProfile::Realtek);
        auto intel_hive = PnpDriverArmer::create_synthetic_system_hive(1, services, intel_only);
        assert(PnpDriverArmer::detect_nic_boot_profile(intel_hive) == NicBootProfile::Intel);
        auto both_hive = PnpDriverArmer::create_synthetic_system_hive(1, services, both);
        assert(PnpDriverArmer::detect_nic_boot_profile(both_hive) == NicBootProfile::Multi);
        // No vendor evidence at all must NOT narrow the profile: demoting blind on an
        // image we cannot read is how a healthy dual-NIC box turns into a 0x7B.
        auto blind_hive = PnpDriverArmer::create_synthetic_system_hive(1, services);
        assert(PnpDriverArmer::detect_nic_boot_profile(blind_hive) == NicBootProfile::Multi);
    }

    // ---- 4. Demotion + flat Realtek Parameters purge, on the in-memory buffer path ----
    // The seed reproduces the state an earlier armer pass left behind: anti-flap values
    // parked in Services\rt640x64\Parameters, a key the Realtek miniport never reads.
    const std::vector<PnpDriverArmer::SyntheticServiceParameter> poisoned = {
        {"rt640x64", "*EEE", false, 0, "1"},
        {"rt640x64", "PowerSavingMode", true, 1, ""},
        {"rt640x64", "PnPCapabilities", true, 0x00000018, ""},
    };
    const std::string rt_params = "ControlSet001\\Services\\rt640x64\\Parameters";

    auto hive = PnpDriverArmer::create_synthetic_system_hive(1, services, both, "", poisoned);
    uint32_t dw = 0xFFFFFFFF;
    {
        const uint32_t seeded = hive_open_path(hive, rt_params);
        assert(seeded != 0xFFFFFFFF);
        assert(hive_get_dword(hive, seeded, "PowerSavingMode", &dw) && dw == 1);
        assert(hive_get_dword(hive, seeded, "PnPCapabilities", &dw) && dw == 0x00000018);
        assert(hive_get_string(hive, seeded, "*EEE") == "1");
    }

    auto arm_res = PnpDriverArmer::arm_hive_buffer(hive, {}, GuestOsFamily::Unknown,
                                                   NicBootProfile::Realtek);
    assert(arm_res.is_ok());
    const auto& rep = arm_res.value();
    assert(rep.success);
    assert(rep.nic_profile == "realtek");
    assert(mentions(rep.demoted_services, "e1d68x64"));
    assert(!mentions(rep.demoted_services, "rt640x64"));
    assert(mentions(rep.service_parameters_purged, "Services\\rt640x64\\Parameters"));
    assert(rep.iscsi_stack_armed);
    assert(rep.boot_flags_armed);

    // The winner stays boot-start and NDIS-grouped...
    const uint32_t rt_off = hive_open_path(hive, "ControlSet001\\Services\\rt640x64");
    assert(rt_off != 0xFFFFFFFF);
    assert(hive_get_dword(hive, rt_off, "Start", &dw) && dw == 0);
    assert(hive_get_string(hive, rt_off, "Group") == "NDIS");
    assert(hive_get_dword(hive, rt_off, "BootFlags", &dw) && dw == 0x1);

    // ...while the loser leaves Phase 0 entirely: demand-start, no boot flag.
    const uint32_t intel_off = hive_open_path(hive, "ControlSet001\\Services\\e1d68x64");
    assert(intel_off != 0xFFFFFFFF);
    assert(hive_get_dword(hive, intel_off, "Start", &dw) && dw == 3);
    assert(hive_get_dword(hive, intel_off, "BootFlags", &dw) && dw == 0);

    // Anti-flap cleanup: the poisoned key is removed outright, not merely emptied.
    assert(hive_open_path(hive, rt_params) == 0xFFFFFFFF);
    // The mirror a miniport which DOES read a flat Parameters key still gets.
    const uint32_t intel_params =
        hive_open_path(hive, "ControlSet001\\Services\\e1d68x64\\Parameters");
    assert(intel_params != 0xFFFFFFFF);
    assert(hive_value_type(hive, intel_params, "*EEE") == 1 /* REG_SZ */);
    assert(hive_get_string(hive, intel_params, "*EEE") == "0");

    // All that cell surgery must leave a self-consistent regf header.
    assert(PnpDriverArmer::calculate_regf_header_checksum(hive.data()) ==
           hive_rd32(&hive[0x1FC]));

    // ---- 5. Read-only inspection of the disarmed buffer ----
    auto insp_res = PnpDriverArmer::inspect_hive_buffer(hive);
    assert(insp_res.is_ok());
    const auto& insp = insp_res.value();
    assert(insp.success);
    assert(insp.control_set == "ControlSet001");
    assert(insp.net_adapters.size() == 2);
    assert(!insp.summary().empty());
    assert(insp.summary().find("=== CobDiskless Offline SYSTEM Hive Inspection ===") == 0);
    assert(mentions(insp.findings, "Services\\rt640x64: Start=0 (SERVICE_BOOT_START), Group=NDIS"));
    assert(mentions(insp.findings, "Services\\e1d68x64: Start=3 (SERVICE_DEMAND_START)"));
    assert(mentions(insp.findings, "Services\\rt640x64\\Parameters absent (expected)."));
    // The conflicting pair is gone, so the diagnostic must not cry wolf.
    assert(!mentions(insp.findings, "BOOT CONFLICT"));

    for (const auto& svc : insp.nic_services) {
        if (svc.service_name == "rt640x64") {
            assert(svc.present && svc.start == 0 && svc.group == "NDIS");
            assert(svc.has_boot_flags && svc.boot_flags == 0x1);
            assert(!svc.has_parameters);
        } else if (svc.service_name == "e1d68x64") {
            assert(svc.present && svc.start == 3);
        }
    }

    // ---- 6. inspect -> fix -> re-inspect round trip on a real hive file ----
    std::error_code ec;
    const std::filesystem::path scratch = "test_scratch_boot_conflict";
    std::filesystem::remove_all(scratch, ec);
    std::filesystem::create_directories(scratch, ec);
    const std::filesystem::path hive_file = scratch / "SYSTEM";

    // The incident image: both vendor families at SERVICE_BOOT_START, plus the poisoned
    // flat Realtek key a previous pass left behind.
    const auto conflict_hive =
        PnpDriverArmer::create_synthetic_system_hive(1, dual_boot_services, both, "", poisoned);
    {
        std::ofstream out(hive_file, std::ios::binary | std::ios::trunc);
        out.write(reinterpret_cast<const char*>(conflict_hive.data()),
                  static_cast<std::streamsize>(conflict_hive.size()));
    }
    assert(std::filesystem::exists(hive_file, ec));

    auto pre_res = PnpDriverArmer::inspect_offline_hive(hive_file);
    assert(pre_res.is_ok());
    assert(pre_res.value().success);
    assert(mentions(pre_res.value().findings, "BOOT CONFLICT"));

    auto fix_res = PnpDriverArmer::fix_boot_conflicts_offline_hive(hive_file);
    assert(fix_res.is_ok());
    assert(fix_res.value().success);
    assert(fix_res.value().nic_profile == "realtek");
    assert(mentions(fix_res.value().demoted_services, "e1d68x64"));
    assert(mentions(fix_res.value().service_parameters_purged,
                    "Services\\rt640x64\\Parameters"));

    auto post_res = PnpDriverArmer::inspect_offline_hive(hive_file);
    assert(post_res.is_ok());
    const auto& post = post_res.value();
    assert(post.success);
    assert(!mentions(post.findings, "BOOT CONFLICT"));
    assert(mentions(post.findings, "Services\\rt640x64\\Parameters absent (expected)."));
    for (const auto& svc : post.nic_services) {
        if (svc.service_name == "rt640x64") {
            assert(svc.present && svc.start == 0 && svc.group == "NDIS");
        } else if (svc.service_name == "e1d68x64") {
            assert(svc.present && svc.start == 3);
        }
    }

    // The repaired file must still open as a regf hive.
    {
        std::ifstream in(hive_file, std::ios::binary);
        char sig[4] = {};
        in.read(sig, 4);
        assert(in && std::string(sig, 4) == "regf");
    }

    std::filesystem::remove_all(scratch, ec);
    std::cout << "  PASS: test_boot_conflict_resolution_and_hive_inspection\n";
}

// ---------------------------------------------------------------------------
// Profile election on a realistic un-armed image: an Intel H61 chipset's PCI
// devnodes plus a single Realtek NIC. Only the Network Adapter instances under
// Control\Class\{4d36e972-...} may decide the profile, the image must elect
// Realtek, and rt640x64 must stay at SERVICE_BOOT_START -- no matter how much
// Intel VEN_8086 evidence exists outside that class key.
//
// Regression guard for the field incident where auto-arming elected "intel" on
// Realtek-only M71s images and demanded-started rt640x64, leaving the clients
// unable to reach Phase 0.
// ---------------------------------------------------------------------------
void test_nic_profile_election_ignores_chipset_devnodes() {
    std::cout << "[RUN] test_nic_profile_election_ignores_chipset_devnodes\n";

    auto mentions = [](const std::vector<std::string>& haystack, const std::string& needle) {
        return std::any_of(haystack.begin(), haystack.end(),
                           [&](const std::string& s) { return s.find(needle) != std::string::npos; });
    };

    // The incident image: both NIC families already at SERVICE_BOOT_START.
    const std::vector<std::pair<std::string, uint32_t>> dual_boot = {
        {"msiscsi", 3}, {"Tcpip", 1}, {"NDIS", 1}, {"rt640x64", 0}, {"e1d68x64", 0}};

    // Intel H61 chipset functions: parent PCI devnodes that are NOT network adapters.
    const std::vector<std::string> chipset_devnodes = {
        "VEN_8086&DEV_1C5A&SUBSYS_10281028", // LPC
        "VEN_8086&DEV_1C22&SUBSYS_10281028", // SMBus
        "VEN_8086&DEV_1C02&SUBSYS_10281028", // SATA
        "VEN_8086&DEV_1C3A&SUBSYS_10281028", // MEI
    };

    // What every Windows image carries staged in the DriverStore regardless of the board.
    NdisPackageInfo intel_pkg;
    intel_pkg.package_dir_name = "e1d68x64.inf_amd64_intel";
    intel_pkg.service_name = "e1d68x64";
    intel_pkg.driver_file = "e1d68x64.sys";
    intel_pkg.hardware_ids = {"PCI\\VEN_8086&DEV_15B8", "pci\\ven_8086&dev_15b8"};

    const std::vector<PnpDriverArmer::SyntheticNetAdapter> realtek_nic = {
        {"0000", "Realtek PCIe GbE Family Controller", "PCI\\VEN_10EC&DEV_8168",
         "pci\\ven_10ec&dev_8168", {}, "rt640x64"},
    };

    // ---- 1. Realtek NIC wins over chipset devnodes + an Intel DriverStore package ----
    auto hive = PnpDriverArmer::create_synthetic_system_hive(
        1, dual_boot, realtek_nic, "", {}, chipset_devnodes);
    assert(PnpDriverArmer::detect_nic_boot_profile(hive, {intel_pkg}) ==
           NicBootProfile::Realtek);

    // ---- 2. Chipset devnodes on their own must never elect "intel" -------------------
    // No Net class adapter: nothing proves an Intel NIC is wired up, so the image stays
    // blind (Multi) instead of demoting rt640x64 on a Realtek client.
    auto blind = PnpDriverArmer::create_synthetic_system_hive(
        1, dual_boot, {}, "", {}, chipset_devnodes);
    assert(PnpDriverArmer::detect_nic_boot_profile(blind, {intel_pkg}) ==
           NicBootProfile::Multi);
    assert(PnpDriverArmer::detect_nic_boot_profile(blind) == NicBootProfile::Multi);

    // ---- 3. The instance's Service value alone is enough evidence --------------------
    const std::vector<PnpDriverArmer::SyntheticNetAdapter> service_only = {
        {"0000", "", "", "", {}, "rt640x64"},
    };
    auto service_hive =
        PnpDriverArmer::create_synthetic_system_hive(1, dual_boot, service_only);
    assert(PnpDriverArmer::detect_nic_boot_profile(service_hive) ==
           NicBootProfile::Realtek);

    // ---- 4. Arming the un-armed incident image --------------------------------------
    auto arm_res = PnpDriverArmer::arm_hive_buffer(hive, {intel_pkg},
                                                   GuestOsFamily::Unknown,
                                                   NicBootProfile::Auto);
    assert(arm_res.is_ok());
    const auto& rep = arm_res.value();
    assert(rep.success);
    assert(rep.nic_profile == "realtek");
    assert(!mentions(rep.demoted_services, "rt640x64"));
    assert(mentions(rep.demoted_services, "e1d68x64"));

    uint32_t dw = 0xFFFFFFFF;
    const uint32_t rt_off = hive_open_path(hive, "ControlSet001\\Services\\rt640x64");
    assert(rt_off != 0xFFFFFFFF);
    assert(hive_get_dword(hive, rt_off, "Start", &dw) && dw == 0);
    assert(hive_get_dword(hive, rt_off, "BootFlags", &dw) && dw == 0x1);

    const uint32_t intel_off = hive_open_path(hive, "ControlSet001\\Services\\e1d68x64");
    assert(intel_off != 0xFFFFFFFF);
    assert(hive_get_dword(hive, intel_off, "Start", &dw) && dw == 3);
    assert(hive_get_dword(hive, intel_off, "BootFlags", &dw) && dw == 0);

    // ---- 5. The resolved profile is pinned so auto_arm_vhd_on_boot cannot re-elect ----
    const uint32_t pin_off =
        hive_open_path(hive, "ControlSet001\\Control\\CobDiskless");
    assert(pin_off != 0xFFFFFFFF);
    assert(hive_get_string(hive, pin_off, "NicBootProfile") == "realtek");

    // Re-running with Auto on an image that carries no hardware evidence at all reuses
    // the profile it was already patched with instead of blindly re-electing Multi (and
    // therefore never re-promoting e1d68x64 back into Phase 0 behind the operator's back).
    auto unpinned = PnpDriverArmer::create_synthetic_system_hive(1, dual_boot);
    {
        auto first = PnpDriverArmer::arm_hive_buffer(unpinned, {}, GuestOsFamily::Unknown,
                                                     NicBootProfile::Intel);
        assert(first.is_ok());
        assert(first.value().nic_profile == "intel");
        assert(hive_get_string(unpinned,
                               hive_open_path(unpinned, "ControlSet001\\Control\\CobDiskless"),
                               "NicBootProfile") == "intel");
    }
    {
        auto second = PnpDriverArmer::arm_hive_buffer(unpinned, {}, GuestOsFamily::Unknown,
                                                      NicBootProfile::Auto);
        assert(second.is_ok());
        assert(second.value().nic_profile == "intel");
    }
    // An explicit choice always wins over the pin, and rewrites it.
    {
        auto third = PnpDriverArmer::arm_hive_buffer(unpinned, {}, GuestOsFamily::Unknown,
                                                     NicBootProfile::Realtek);
        assert(third.is_ok());
        assert(third.value().nic_profile == "realtek");
        assert(hive_get_string(unpinned,
                               hive_open_path(unpinned, "ControlSet001\\Control\\CobDiskless"),
                               "NicBootProfile") == "realtek");
    }

    std::cout << "  PASS: test_nic_profile_election_ignores_chipset_devnodes\n";
}

// ---- Offline PE identity + legacy DriverStore rollback ----------------------------
//
// Builds the smallest PE image the offline readers accept and drives both halves of the
// M71s RTL8111E incident: version/section extraction from an offline binary (so the
// faulting offset 0xE534 can be attributed to .text), and the rollback policy that must
// prefer the inbox/OEM build below the 10.35 legacy ceiling over the panicking one.

namespace {

// DOS header -> PE\0\0 -> COFF header -> PE32+ optional header -> a two-entry Section
// Table (.text at RVA 0x1000 with 0xD800 bytes, .data at 0xF000) -> a complete
// VS_VERSION_INFO resource at file offset 0x400 carrying both the VS_FIXEDFILEINFO
// numbers and the StringFileInfo strings. Every node is 4-byte aligned, exactly like the
// version resource a real rt640x64.sys ships.
std::vector<uint8_t> build_driver_pe(const std::string& file_version,
                                     const std::string& product_version,
                                     const std::string& file_version_string,
                                     const std::string& product_version_string) {
    auto put_u16 = [](std::vector<uint8_t>& out, uint16_t value) {
        out.push_back(static_cast<uint8_t>(value & 0xFF));
        out.push_back(static_cast<uint8_t>((value >> 8) & 0xFF));
    };
    auto put_u32 = [](std::vector<uint8_t>& out, uint32_t value) {
        for (int shift = 0; shift < 32; shift += 8) {
            out.push_back(static_cast<uint8_t>((value >> shift) & 0xFF));
        }
    };
    auto put_wstr = [](std::vector<uint8_t>& out, const std::string& text) {
        for (char c : text) {
            out.push_back(static_cast<uint8_t>(c));
            out.push_back(0);
        }
        out.push_back(0);
        out.push_back(0);
    };
    auto pad4 = [](std::vector<uint8_t>& out) {
        while (out.size() % 4 != 0) out.push_back(0);
    };
    auto patch_len = [](std::vector<uint8_t>& out) {
        const uint16_t length = static_cast<uint16_t>(out.size());
        out[0] = static_cast<uint8_t>(length & 0xFF);
        out[1] = static_cast<uint8_t>((length >> 8) & 0xFF);
    };
    auto version_pair = [](const std::string& text, uint32_t* ms, uint32_t* ls) {
        unsigned part[4] = {0, 0, 0, 0};
        size_t pos = 0;
        for (unsigned i = 0; i < 4 && pos < text.size(); ++i) {
            unsigned value = 0;
            while (pos < text.size() && text[pos] >= '0' && text[pos] <= '9') {
                value = value * 10u + static_cast<unsigned>(text[pos] - '0');
                ++pos;
            }
            part[i] = value & 0xFFFFu;
            if (pos < text.size() && text[pos] == '.') ++pos;
        }
        *ms = (part[0] << 16) | part[1];
        *ls = (part[2] << 16) | part[3];
    };

    uint32_t file_ms = 0;
    uint32_t file_ls = 0;
    uint32_t prod_ms = 0;
    uint32_t prod_ls = 0;
    version_pair(file_version, &file_ms, &file_ls);
    version_pair(product_version, &prod_ms, &prod_ls);

    auto string_node = [&](const std::string& key, const std::string& value) {
        std::vector<uint8_t> node;
        put_u16(node, 0);                                        // wLength, patched
        put_u16(node, static_cast<uint16_t>(value.size() + 1));  // characters incl. NUL
        put_u16(node, 1);                                        // text
        put_wstr(node, key);
        pad4(node);
        put_wstr(node, value);
        patch_len(node);
        return node;
    };
    auto branch_node = [&](const std::string& key, uint16_t type,
                           const std::vector<std::vector<uint8_t>>& children) {
        std::vector<uint8_t> node;
        put_u16(node, 0);  // wLength, patched
        put_u16(node, 0);  // no value
        put_u16(node, type);
        put_wstr(node, key);
        pad4(node);
        for (const auto& child : children) {
            node.insert(node.end(), child.begin(), child.end());
            pad4(node);
        }
        patch_len(node);
        return node;
    };

    const auto string_table =
        branch_node("040904B0", 1, {string_node("FileVersion", file_version_string),
                                    string_node("ProductVersion", product_version_string)});
    const auto string_file_info = branch_node("StringFileInfo", 1, {string_table});

    std::vector<uint8_t> resource;
    put_u16(resource, 0);     // wLength, patched
    put_u16(resource, 0x34);  // VS_FIXEDFILEINFO is 52 bytes
    put_u16(resource, 0);     // binary value
    put_wstr(resource, "VS_VERSION_INFO");
    pad4(resource);  // -> 40 bytes, so the fixed info starts on a 4-byte boundary
    put_u32(resource, 0xFEEF04BD);
    put_u32(resource, 0x00010000);
    put_u32(resource, file_ms);
    put_u32(resource, file_ls);
    put_u32(resource, prod_ms);
    put_u32(resource, prod_ls);
    for (int i = 0; i < 7; ++i) put_u32(resource, 0);  // flags/OS/type/subtype/date
    resource.insert(resource.end(), string_file_info.begin(), string_file_info.end());
    pad4(resource);
    patch_len(resource);

    std::vector<uint8_t> image(0x1000, 0);
    image[0] = 'M';
    image[1] = 'Z';
    image[0x3C] = 0x80;  // e_lfanew
    image[0x80] = 'P';
    image[0x81] = 'E';

    const size_t coff = 0x84;
    image[coff + 0] = 0x64;   // Machine = IMAGE_FILE_MACHINE_AMD64
    image[coff + 1] = 0x86;
    image[coff + 2] = 2;      // NumberOfSections
    image[coff + 16] = 0xE0;  // SizeOfOptionalHeader (PE32+)

    const size_t optional = coff + 20;  // 0x98
    image[optional] = 0x0B;             // OptionalHeader Magic = PE32+
    image[optional + 1] = 0x02;

    const size_t table = optional + 0xE0;  // 0x178
    auto write_section = [&](size_t at, const char* name, uint32_t virtual_size,
                             uint32_t virtual_address, uint32_t raw_size,
                             uint32_t characteristics) {
        for (size_t i = 0; i < 8 && name[i] != '\0'; ++i) {
            image[at + i] = static_cast<uint8_t>(name[i]);
        }
        auto write_u32 = [&](size_t offset, uint32_t value) {
            image[at + offset + 0] = static_cast<uint8_t>(value & 0xFF);
            image[at + offset + 1] = static_cast<uint8_t>((value >> 8) & 0xFF);
            image[at + offset + 2] = static_cast<uint8_t>((value >> 16) & 0xFF);
            image[at + offset + 3] = static_cast<uint8_t>((value >> 24) & 0xFF);
        };
        write_u32(8, virtual_size);
        write_u32(12, virtual_address);
        write_u32(16, raw_size);
        write_u32(36, characteristics);
    };
    write_section(table, ".text", 0xD800, 0x1000, 0x400, 0x60000020);
    write_section(table + 40, ".data", 0x2000, 0xF000, 0x200, 0xC0000040);

    const size_t resource_offset = 0x400;
    assert(resource_offset + resource.size() <= image.size());
    std::copy(resource.begin(), resource.end(), image.begin() + static_cast<long>(resource_offset));
    return image;
}

} // namespace

void test_pe_version_extraction_and_driver_rollback() {
    std::cout << "[RUN] test_pe_version_extraction_and_driver_rollback\n";

    std::error_code ec;
    const std::filesystem::path modern_repo =
        "test_scratch_driver_rollback/Windows/System32/DriverStore/FileRepository";

    auto write_bytes = [](const std::filesystem::path& path,
                          const std::vector<uint8_t>& data) {
        std::ofstream out(path, std::ios::binary | std::ios::trunc);
        out.write(reinterpret_cast<const char*>(data.data()),
                  static_cast<std::streamsize>(data.size()));
        out.flush();
        return out.good();
    };
    auto write_text = [](const std::filesystem::path& path, const std::string& text) {
        std::ofstream out(path, std::ios::binary | std::ios::trunc);
        out << text;
        out.flush();
        return out.good();
    };

    // ---- 1. Version resource + section table straight out of an offline PE ----------
    const auto modern = build_driver_pe("10.39.1118.2021", "10.39.0.0",
                                        "10.39.1118.2021", "10.39.0.0");
    const auto modern_info = PnpDriverArmer::parse_pe_version_info(modern);
    assert(modern_info.valid);
    assert(modern_info.file_version == "10.39.1118.2021");
    assert(modern_info.product_version == "10.39.0.0");
    assert(modern_info.file_version_string == "10.39.1118.2021");
    assert(modern_info.product_version_string == "10.39.0.0");

    const auto modern_sections = PnpDriverArmer::parse_pe_sections(modern);
    assert(modern_sections.size() == 2);
    assert(modern_sections[0].name == ".text");
    assert(modern_sections[0].virtual_address == 0x1000);
    assert(modern_sections[0].virtual_size == 0xD800);
    assert(modern_sections[1].name == ".data");
    assert(modern_sections[1].virtual_address == 0xF000);

    // The incident offset must be attributable to code, not merely "somewhere in the file".
    assert(PnpDriverArmer::find_section_index_for_rva(modern_sections, 0xE534) == 0);
    assert(PnpDriverArmer::find_section_index_for_rva(modern_sections, 0x1000) == 0);
    assert(PnpDriverArmer::find_section_index_for_rva(modern_sections, 0xE800) == -1);
    assert(PnpDriverArmer::find_section_index_for_rva(modern_sections, 0xF000) == 1);
    assert(PnpDriverArmer::find_section_index_for_rva(modern_sections, 0x0000) == -1);

    // Anything that is not a PE image must degrade to "unknown" instead of throwing.
    const std::vector<uint8_t> garbage(64, 0x41);
    assert(!PnpDriverArmer::parse_pe_version_info(garbage).valid);
    assert(PnpDriverArmer::parse_pe_sections(garbage).empty());
    std::vector<uint8_t> mz_only(0x80, 0);
    mz_only[0] = 'M';
    mz_only[1] = 'Z';
    mz_only[0x3C] = 0x40;  // e_lfanew points at zeros, not PE\0\0
    assert(!PnpDriverArmer::parse_pe_version_info(mz_only).valid);
    assert(PnpDriverArmer::parse_pe_sections(mz_only).empty());
    assert(!PnpDriverArmer::read_pe_version_info("definitely-not-a-real-driver.sys").valid);
    assert(PnpDriverArmer::read_pe_sections("definitely-not-a-real-driver.sys").empty());

    // ---- 2. The legacy ceiling that separates the safe builds from the panicking one --
    assert(PnpDriverArmer::legacy_compatible_driver_version("9.1.408.0"));
    assert(PnpDriverArmer::legacy_compatible_driver_version("9.1.408.2"));
    assert(PnpDriverArmer::legacy_compatible_driver_version("10.1.307.2017"));
    assert(PnpDriverArmer::legacy_compatible_driver_version("10.1.0.0"));
    assert(PnpDriverArmer::legacy_compatible_driver_version("10.0.1.0"));
    assert(!PnpDriverArmer::legacy_compatible_driver_version("10.35.1118.2019"));
    assert(!PnpDriverArmer::legacy_compatible_driver_version("10.39.1118.2021"));
    assert(!PnpDriverArmer::legacy_compatible_driver_version("11.0.1.0"));
    assert(!PnpDriverArmer::legacy_compatible_driver_version(""));
    assert(!PnpDriverArmer::legacy_compatible_driver_version("garbage"));
    assert(!PnpDriverArmer::legacy_compatible_driver_version("10.x.0.0"));

    // ---- 3. Hardware-id normalisation (CLI input == what the INF walker emits) -------
    assert(PnpDriverArmer::generic_realtek_gbe_hw_id() == "PCI\\VEN_10EC&DEV_8168");
    assert(PnpDriverArmer::normalize_hardware_id("PCI\\VEN_10EC&DEV_8168") ==
           "pci#ven_10ec&dev_8168");
    assert(PnpDriverArmer::normalize_hardware_id("pci#ven_10ec&dev_8168") ==
           "pci#ven_10ec&dev_8168");
    assert(PnpDriverArmer::normalize_hardware_id(
               "PCI\\VEN_10EC&DEV_8168&SUBSYS_00001028&REV_06") ==
           "pci#ven_10ec&dev_8168");

    // ---- 4. Rollback selection: legacy preferred, oldest wins, modern is refused -----
    auto make_candidate = [](const std::string& package, const std::string& version,
                             bool declares, bool present) {
        DriverPackageCandidate candidate;
        candidate.package_dir_name = package;
        candidate.file_version = version;
        candidate.present = present;
        if (declares) candidate.hardware_ids.push_back("pci#ven_10ec&dev_8168");
        candidate.legacy_compatible = PnpDriverArmer::legacy_compatible_driver_version(version);
        return candidate;
    };

    const std::vector<DriverPackageCandidate> mixed = {
        make_candidate("netrt640.inf_amd64_modern", "10.39.1118.2021", true, true),
        make_candidate("netrt640.inf_amd64_oem", "9.1.408.0", true, true),
        make_candidate("netrtl8168.inf_amd64_inbox", "10.1.307.2017", true, true),
        make_candidate("netrt640.inf_amd64_other", "9.1.408.0", false, true),
        make_candidate("netrt640.inf_amd64_gone", "9.1.408.0", true, false),
    };
    size_t chosen = static_cast<size_t>(-1);
    std::string reason;
    assert(PnpDriverArmer::select_driver_rollback_candidate(mixed, "", &chosen, &reason));
    assert(chosen == 1);  // 9.1.408.0: legacy-compatible AND older than the 10.1.x inbox
    assert(reason.empty());

    // A DriverStore holding only the panicking build must refuse: rolling the very binary
    // that faults on RTL8111E Rev 06 back into place would defeat the rollback.
    const std::vector<DriverPackageCandidate> modern_only = {
        make_candidate("netrt640.inf_amd64_modern", "10.39.1118.2021", true, true),
    };
    assert(!PnpDriverArmer::select_driver_rollback_candidate(modern_only, "", &chosen, &reason));
    assert(chosen == static_cast<size_t>(-1));
    assert(reason.find("10.35") != std::string::npos);

    // A package that never declares the device id must never win, however old it is.
    const std::vector<DriverPackageCandidate> wrong_hwid = {
        make_candidate("netrt640.inf_amd64_other", "9.1.408.0", false, true),
    };
    assert(!PnpDriverArmer::select_driver_rollback_candidate(wrong_hwid, "", &chosen, &reason));
    assert(reason.find("no package declaring") != std::string::npos);
    assert(!PnpDriverArmer::select_driver_rollback_candidate({}, "", &chosen, &reason));

    // ---- 5. End to end: scan a synthetic DriverStore and roll the legacy build in -----
    const auto legacy_pe =
        build_driver_pe("9.1.408.0", "9.1.408.0", "9.1.408.0", "9.1.408.0");

    const std::string inf_text =
        "[Version]\n"
        "Signature=\"$Windows NT$\"\n"
        "Class=Net\n"
        "ClassGuid={4d36e972-e325-11ce-bfc1-08002be10318}\n"
        "Provider=%Realtek%\n"
        "DriverVer=04/18/2019,9.1.408.0\n"
        "\n"
        "[Manufacturer]\n"
        "%Realtek%=Realtek,NTamd64\n"
        "\n"
        "[Realtek.NTamd64]\n"
        "%RTL8168.DeviceDesc%=RT8168, PCI\\VEN_10EC&DEV_8168\n";

    const std::filesystem::path root = "test_scratch_driver_rollback";
    const std::filesystem::path drivers = root / "Windows" / "System32" / "drivers";
    std::filesystem::remove_all(root, ec);
    std::filesystem::create_directories(drivers, ec);
    std::filesystem::create_directories(modern_repo / "netrt640.inf_amd64_modern", ec);
    std::filesystem::create_directories(modern_repo / "netrt640.inf_amd64_oem", ec);
    // Windows' own inbox package name: same payload, but without an INF it must stay
    // ineligible because its hardware id cannot be proven from a guess.
    std::filesystem::create_directories(modern_repo / "netrtl8168.inf_amd64_inbox", ec);

    assert(write_bytes(drivers / "rt640x64.sys", modern));
    assert(write_bytes(modern_repo / "netrt640.inf_amd64_modern" / "rt640x64.sys", modern));
    assert(write_bytes(modern_repo / "netrt640.inf_amd64_oem" / "rt640x64.sys", legacy_pe));
    assert(write_bytes(modern_repo / "netrtl8168.inf_amd64_inbox" / "rt640x64.sys", legacy_pe));
    assert(write_text(modern_repo / "netrt640.inf_amd64_modern" / "netrt640.inf", inf_text));
    assert(write_text(modern_repo / "netrt640.inf_amd64_oem" / "netrt640.inf", inf_text));

    const auto scanned = PnpDriverArmer::scan_driver_packages(root, "rt640x64.sys", "");
    assert(scanned.size() == 3);
    for (const auto& entry : scanned) {
        if (entry.package_dir_name == "netrt640.inf_amd64_oem") {
            assert(entry.present && entry.file_version == "9.1.408.0");
            assert(entry.inf_readable && entry.supports_target_hw_id && entry.legacy_compatible);
            assert(!entry.sha256.empty());
        } else if (entry.package_dir_name == "netrt640.inf_amd64_modern") {
            assert(entry.file_version == "10.39.1118.2021");
            assert(entry.supports_target_hw_id && !entry.legacy_compatible);
        } else if (entry.package_dir_name == "netrtl8168.inf_amd64_inbox") {
            assert(entry.file_version == "9.1.408.0");
            assert(!entry.inf_readable && !entry.supports_target_hw_id);
        } else {
            assert(false && "unexpected DriverStore package");
        }
    }

    auto restored = PnpDriverArmer::restore_inbox_driver(root);
    assert(restored.is_ok());
    const DriverRestoreReport& rr = restored.value();
    assert(rr.success);
    assert(rr.performed);
    assert(rr.selected_package == "netrt640.inf_amd64_oem");
    assert(rr.target_hw_id == "pci#ven_10ec&dev_8168");
    assert(rr.previous_version == "10.39.1118.2021");
    assert(rr.restored_version == "9.1.408.0");
    assert(rr.restored_supports_hw_id);
    assert(rr.restored_is_legacy_compatible);
    assert(!rr.summary().empty());

    // The active binary now IS the OEM package, and the outgoing one is kept as .prev so
    // the rollback itself can be rolled back.
    const std::string modern_sha =
        PnpDriverArmer::sha256_file(modern_repo / "netrt640.inf_amd64_modern" / "rt640x64.sys");
    assert(PnpDriverArmer::sha256_file(drivers / "rt640x64.sys") ==
           PnpDriverArmer::sha256_file(modern_repo / "netrt640.inf_amd64_oem" / "rt640x64.sys"));
    assert(rr.restored_sha256 == PnpDriverArmer::sha256_file(drivers / "rt640x64.sys"));
    assert(!rr.backup_path.empty());
    assert(PnpDriverArmer::sha256_file(rr.backup_path) == modern_sha);

    // Re-running must be a no-op rather than shuffling binaries around.
    auto again = PnpDriverArmer::restore_inbox_driver(root);
    assert(again.is_ok());
    assert(again.value().success);
    assert(!again.value().performed);
    assert(again.value().restored_version == "9.1.408.0");

    // ---- 6. Faulting-driver triage of the restored volume ---------------------------
    auto inspected = PnpDriverArmer::inspect_driver_binary(root);
    assert(inspected.is_ok());
    const DriverBinaryInspection& triage = inspected.value();
    assert(triage.success && triage.present && triage.pe_valid);
    assert(triage.driver_file == "rt640x64.sys");
    assert(triage.file_version == "9.1.408.0");
    assert(triage.product_version == "9.1.408.0");
    assert(triage.size == legacy_pe.size());
    assert(triage.rva == 0xE534);
    assert(triage.rva_checked && triage.rva_in_text && triage.rva_section == ".text");
    assert(triage.sections.size() == 2);
    assert(triage.candidates.size() == 3);
    assert(triage.findings.size() >= 5);
    assert(triage.summary().find("inside .text") != std::string::npos);

    // The .sys path is an accepted target too, and resolves to the same volume.
    auto via_sys = PnpDriverArmer::inspect_driver_binary(drivers / "rt640x64.sys", 0xE534);
    assert(via_sys.is_ok());
    assert(via_sys.value().success);
    assert(via_sys.value().volume_path == root);
    assert(via_sys.value().driver_path == drivers / "rt640x64.sys");
    assert(via_sys.value().file_version == "9.1.408.0");

    // ---- 7. A DriverStore holding only the panicking build must refuse ---------------
    const std::filesystem::path bad_root = "test_scratch_driver_rollback_modern";
    const std::filesystem::path bad_drivers = bad_root / "Windows" / "System32" / "drivers";
    const std::filesystem::path bad_repo =
        bad_root / "Windows" / "System32" / "DriverStore" / "FileRepository" /
        "netrt640.inf_amd64_modern";
    std::filesystem::remove_all(bad_root, ec);
    std::filesystem::create_directories(bad_drivers, ec);
    std::filesystem::create_directories(bad_repo, ec);
    assert(write_bytes(bad_drivers / "rt640x64.sys", modern));
    assert(write_bytes(bad_repo / "rt640x64.sys", modern));
    assert(write_text(bad_repo / "netrt640.inf", inf_text));

    auto refused = PnpDriverArmer::restore_inbox_driver(bad_root);
    assert(refused.is_ok());
    assert(!refused.value().success);
    assert(refused.value().selected_package.empty());
    assert(!refused.value().performed);
    assert(refused.value().message.find("10.35") != std::string::npos);
    assert(PnpDriverArmer::sha256_file(bad_drivers / "rt640x64.sys") ==
           PnpDriverArmer::sha256_file(bad_repo / "rt640x64.sys"));

    // ---- 8. Target resolution rejects things that are not volumes --------------------
    auto bogus = PnpDriverArmer::inspect_driver_binary(
        std::filesystem::path("definitely-not-a-volume-xyzzy"));
    assert(bogus.is_err());

    std::filesystem::remove_all(root, ec);
    std::filesystem::remove_all(bad_root, ec);
    std::cout << "  PASS: test_pe_version_extraction_and_driver_rollback\n";
}

// ---------------------------------------------------------------------------
// NT volume GUID root resolution.
//
// A mounted VHD hands the CLI `\\?\Volume{GUID}\Windows\System32\config\SYSTEM`.
// On this toolchain std::filesystem::path applies POSIX separator rules to that
// string, so parent_path() yields "" and every ancestor walk collapses
// immediately -- the armer then logged
//   "Could not resolve a volume root above \\?\Volume{...}\Windows\System32\config\SYSTEM"
// and silently skipped the NDIS harvest and OS-family classification for the
// whole pass. The namespace is therefore parsed as text FIRST and never walked.
// ---------------------------------------------------------------------------
void test_volume_root_guid_parsing() {
    std::cout << "[RUN] test_volume_root_guid_parsing\n";

    const std::string vol = "\\\\?\\Volume{3e128489-0000-0000-0000-602200000000}";

    // ---- 1. Pure prefix extraction (no filesystem access at all) ----------------
    assert(PnpDriverArmer::nt_volume_guid_root(
               vol + "\\Windows\\System32\\config\\SYSTEM").string() == vol);
    // Case-insensitive `Volume{`; both separators accepted after the closing brace.
    assert(PnpDriverArmer::nt_volume_guid_root(
               "\\\\?\\volume{ABCDEF00-1111-2222-3333-444444444444}/Windows/System32/config/SYSTEM")
               .string() == "\\\\?\\volume{ABCDEF00-1111-2222-3333-444444444444}");
    // Only the namespace prefix is returned -- the Windows directory below it is not.
    assert(PnpDriverArmer::nt_volume_guid_root(vol + "\\").string() == vol);

    // Not a namespace: unclosed GUID, missing separator, plain drive path, relative path.
    assert(PnpDriverArmer::nt_volume_guid_root("\\\\?\\Volume{abc\\Windows").empty());
    assert(PnpDriverArmer::nt_volume_guid_root("\\\\?\\Volume{abc}Windows").empty());
    assert(PnpDriverArmer::nt_volume_guid_root("\\\\?\\NotAVolume{abc}\\Windows").empty());
    assert(PnpDriverArmer::nt_volume_guid_root("C:\\Windows\\System32\\config\\SYSTEM").empty());
    assert(PnpDriverArmer::nt_volume_guid_root("config\\SYSTEM").empty());
    assert(PnpDriverArmer::nt_volume_guid_root("").empty());

    // ---- 2. volume_root_from_hive: a namespace path is never walked -------------
    // `<root>\Windows` does not exist for this (deliberately absent) GUID, so the
    // honest answer is "": no walking, and above all no wrong-but-non-empty root
    // that would disable the harvest for the whole pass.
    assert(PnpDriverArmer::volume_root_from_hive(
               "\\\\?\\Volume{00000000-0000-0000-0000-000000000000}\\Windows\\System32\\config\\SYSTEM")
               .empty());

    // ---- 3. The real volume this machine boots from ----------------------------
    // Live proof of the positive branch: `<volume>\Windows` exists, so the resolver
    // hands back exactly `\\?\Volume{...}` (no trailing separator, never the walk).
    wchar_t win_dir[400] = {0};
    wchar_t vol_path[400] = {0};
    wchar_t vol_name[400] = {0};
    if (GetWindowsDirectoryW(win_dir, 400) != 0 &&
        GetVolumePathNameW(win_dir, vol_path, 400) &&
        GetVolumeNameForVolumeMountPointW(vol_path, vol_name, 400)) {
        std::string root = std::filesystem::path(vol_name).string();
        while (!root.empty() && (root.back() == '\\' || root.back() == '/')) root.pop_back();
        assert(!root.empty());

        const std::filesystem::path probe(root + "\\Windows\\System32\\config\\SYSTEM");
        assert(PnpDriverArmer::nt_volume_guid_root(probe).string() == root);
        assert(PnpDriverArmer::volume_root_from_hive(probe).string() == root);
        // A directory under the same volume is NOT the volume root.
        assert(PnpDriverArmer::volume_root_from_hive(
                   root + "\\Windows\\System32\\drivers\\etc\\hosts").string() == root);
    }

    // ---- 4. Plain directory trees still resolve by walking ----------------------
    std::error_code ec;
    const std::filesystem::path scratch = "test_scratch_volume_guid";
    std::filesystem::remove_all(scratch, ec);
    std::filesystem::create_directories(scratch / "Windows" / "System32" / "config", ec);

    assert(PnpDriverArmer::volume_root_from_hive(
               scratch / "Windows" / "System32" / "config" / "SYSTEM").string() == scratch.string());
    // Nothing above a path with no Windows tree -> "" (never a wrong-but-non-empty root).
    assert(PnpDriverArmer::volume_root_from_hive("no_such_tree/Windows/System32/config/SYSTEM").empty());

    std::filesystem::remove_all(scratch, ec);
    std::cout << "  PASS: test_volume_root_guid_parsing\n";
}

// ---------------------------------------------------------------------------
// Stale NicBootProfile pin eviction.
//
// A pin under <ControlSet>\Control\CobDiskless\NicBootProfile is a *memory* of
// an earlier pass, not evidence about this image. When Tier A (Net class
// adapter instances) contradicts it the pin must lose -- which is exactly the
// M71s incident: an earlier build wrote "intel" on a single-vendor RTL8111E
// board and every later auto-arm trusted it, demoted rt640x64 to Start = 3 and
// the image never booted again.
// ---------------------------------------------------------------------------
void test_stale_profile_pin_evicted() {
    std::cout << "[RUN] test_stale_profile_pin_evicted\n";

    auto mentions = [](const std::vector<std::string>& haystack, const std::string& needle) {
        return std::any_of(haystack.begin(), haystack.end(),
                           [&](const std::string& s) { return s.find(needle) != std::string::npos; });
    };

    // Capture the armer's own log: the eviction has to be *reported*, not silent.
    std::vector<std::string> captured;
    Logger::default_logger().set_sink(
        [&](LogLevel /*level*/, std::string_view /*category*/, std::string_view message,
            std::string_view /*formatted*/) {
            captured.emplace_back(message);
        });
    auto log_contains = [&](const std::string& needle) -> bool {
        for (const std::string& line : captured) {
            if (line.find(needle) != std::string::npos) return true;
        }
        return false;
    };

    // Both NIC families boot-started: demotion and re-promotion are both observable.
    const std::vector<std::pair<std::string, uint32_t>> dual_boot = {
        {"msiscsi", 3}, {"Tcpip", 1}, {"NDIS", 1}, {"rt640x64", 0}, {"e1d68x64", 0}};

    const std::vector<PnpDriverArmer::SyntheticNetAdapter> realtek_nic = {
        {"0000", "Realtek PCIe GbE Family Controller", "PCI\\VEN_10EC&DEV_8168",
         "pci\\ven_10ec&dev_8168", {}, "rt640x64"},
    };

    NdisPackageInfo intel_pkg;
    intel_pkg.package_dir_name = "e1d68x64.inf_amd64_intel";
    intel_pkg.service_name = "e1d68x64";
    intel_pkg.driver_file = "e1d68x64.sys";
    intel_pkg.hardware_ids = {"PCI\\VEN_8086&DEV_15B8"};

    const std::string pin_path = "ControlSet001\\Control\\CobDiskless";
    const std::string rt_path = "ControlSet001\\Services\\rt640x64";
    const std::string intel_path = "ControlSet001\\Services\\e1d68x64";

    // ---- 1. An earlier build pinned "intel" on this board -----------------------
    auto hive = PnpDriverArmer::create_synthetic_system_hive(1, dual_boot, realtek_nic);
    {
        auto pinned = PnpDriverArmer::arm_hive_buffer(hive, {}, GuestOsFamily::Unknown,
                                                      NicBootProfile::Intel);
        assert(pinned.is_ok());
        assert(pinned.value().success);
        assert(pinned.value().nic_profile == "intel");
        assert(hive_get_string(hive, hive_open_path(hive, pin_path), "NicBootProfile") == "intel");
        assert(mentions(pinned.value().demoted_services, "rt640x64"));

        uint32_t dw = 0xFFFFFFFF;
        const uint32_t rt = hive_open_path(hive, rt_path);
        assert(rt != 0xFFFFFFFF);
        assert(hive_get_dword(hive, rt, "Start", &dw) && dw == 3); // demoted by the bad pin
        assert(hive_get_dword(hive, rt, "BootFlags", &dw) && dw == 0);
    }

    // ---- 2. Auto must evict it: Tier A evidence outranks a memory ----------------
    captured.clear();
    {
        auto armed = PnpDriverArmer::arm_hive_buffer(hive, {intel_pkg},
                                                     GuestOsFamily::Unknown,
                                                     NicBootProfile::Auto);
        assert(armed.is_ok());
        assert(armed.value().success);
        assert(armed.value().nic_profile == "realtek");
        assert(log_contains(
            "Conflicting/stale profile pin 'intel' evicted by Tier A Realtek evidence"));

        uint32_t dw = 0xFFFFFFFF;
        const uint32_t rt = hive_open_path(hive, rt_path);
        assert(rt != 0xFFFFFFFF);
        assert(hive_get_dword(hive, rt, "Start", &dw) && dw == 0); // re-promoted
        assert(hive_get_dword(hive, rt, "BootFlags", &dw) && dw == 0x1);

        const uint32_t intel = hive_open_path(hive, intel_path);
        assert(intel != 0xFFFFFFFF);
        assert(hive_get_dword(hive, intel, "Start", &dw) && dw == 3);
        assert(mentions(armed.value().demoted_services, "e1d68x64"));
        assert(!mentions(armed.value().demoted_services, "rt640x64"));

        // The evicted pin is replaced, not merely ignored.
        assert(hive_get_string(hive, hive_open_path(hive, pin_path), "NicBootProfile") == "realtek");
    }

    // ---- 3. A corroborated pin is reused instead of being re-elected -------------
    {
        auto blind = PnpDriverArmer::create_synthetic_system_hive(1, dual_boot);
        auto first = PnpDriverArmer::arm_hive_buffer(blind, {}, GuestOsFamily::Unknown,
                                                     NicBootProfile::Intel);
        assert(first.is_ok());
        assert(hive_get_string(blind, hive_open_path(blind, pin_path), "NicBootProfile") == "intel");

        captured.clear();
        auto second = PnpDriverArmer::arm_hive_buffer(blind, {}, GuestOsFamily::Unknown,
                                                      NicBootProfile::Auto);
        assert(second.is_ok());
        // No Net class adapter -> Tier A says nothing -> the pin still decides.
        assert(second.value().nic_profile == "intel");
        assert(!log_contains("evicted by Tier A"));
        assert(log_contains("reusing it instead of re-electing"));
    }

    // ---- 4. An explicit --nic-profile overwrites the pin unconditionally ---------
    {
        auto overwritten = PnpDriverArmer::arm_hive_buffer(hive, {}, GuestOsFamily::Unknown,
                                                           NicBootProfile::Intel);
        assert(overwritten.is_ok());
        assert(overwritten.value().nic_profile == "intel");
        assert(hive_get_string(hive, hive_open_path(hive, pin_path), "NicBootProfile") == "intel");
    }

    Logger::default_logger().reset_to_default_sink();
    std::cout << "  PASS: test_stale_profile_pin_evicted\n";
}

// ---------------------------------------------------------------------------
// RFC 2347/2348 option negotiation: an RRQ carrying blksize/tsize/timeout must
// be answered with an OACK (opcode 6) and must wait for ACK block 0 before any
// DATA. Answering with DATA 1 is precisely what left ROMs that understood their
// own RRQ sitting in PXE-E32 "TFTP open timeout" -- server and client each
// waiting for the other, forever.
// ---------------------------------------------------------------------------
void test_tftp_option_negotiation_oack() {
    std::cout << "[RUN] test_tftp_option_negotiation_oack\n";

    auto make_rrq = [](const std::string& file,
                       const std::vector<std::pair<std::string, std::string>>& opts) {
        std::vector<uint8_t> pkt = {0x00, 0x01};
        auto put = [&](const std::string& s) {
            pkt.insert(pkt.end(), s.begin(), s.end());
            pkt.push_back(0x00);
        };
        put(file);
        put("octet");
        for (const auto& kv : opts) {
            put(kv.first);
            put(kv.second);
        }
        return pkt;
    };
    auto oack_get = [](const std::vector<uint8_t>& buf, const std::string& key) -> std::string {
        const size_t len = buf.size();
        if (len < 2) return "";
        size_t pos = 2;
        auto take = [&](size_t& p) {
            size_t nul = p;
            while (nul < len && buf[nul] != 0) ++nul;
            std::string out(reinterpret_cast<const char*>(buf.data() + p), nul - p);
            p = nul + 1;
            return out;
        };
        while (pos < len) {
            const std::string k = take(pos);
            if (pos >= len) break;
            const std::string v = take(pos);
            if (k == key) return v;
        }
        return "";
    };

    // ---- 1. RRQ with options parses into a clamped option block ------------------
    auto parsed = TftpServer::parse_rrq(
        make_rrq("boot.ipxe", {{"blksize", "1468"}, {"tsize", "0"}}));
    assert(parsed.is_ok());
    assert(parsed.value().filename == "boot.ipxe");
    assert(!parsed.value().options.empty()); // -> OACK path, not RFC 1350
    assert(parsed.value().options.has_blksize);
    assert(parsed.value().options.blksize == TftpServer::kMaxBlockSize); // 1468 -> 1428
    assert(parsed.value().options.has_tsize);
    assert(parsed.value().options.tsize == 0);
    assert(!parsed.value().options.has_timeout);

    // ---- 2. The OACK echoes exactly what was negotiated -------------------------
    // RFC 2359: the RRQ asks with tsize=0 and the server answers with the real size.
    TftpRequestOptions answered = parsed.value().options;
    const size_t file_size = 330;
    answered.tsize = file_size;
    const std::vector<uint8_t> oack = TftpServer::create_oack_packet(answered);
    assert(oack.size() > 2);
    assert(oack[0] == 0x00 && oack[1] == 0x06); // opcode 6 = OACK, never 3 = DATA
    assert(oack_get(oack, "blksize") == "1428");
    assert(oack_get(oack, "tsize") == std::to_string(file_size));
    assert(oack_get(oack, "timeout") == ""); // not negotiated, not echoed

    // ---- 3. Unusable / unknown options degrade to plain RFC 1350 ----------------
    // RFC 2347 forbids acknowledging nothing, so an option block that negotiated
    // no usable option must take the immediate DATA 1 path, not emit an empty OACK.
    auto too_small = TftpServer::parse_rrq(make_rrq("boot.ipxe", {{"blksize", "4"}}));
    assert(too_small.is_ok());
    assert(too_small.value().options.empty());

    auto unknown = TftpServer::parse_rrq(
        make_rrq("boot.ipxe", {{"windowsize", "8"}, {"multicast", "0"}}));
    assert(unknown.is_ok());
    assert(unknown.value().options.empty());

    auto t_hi = TftpServer::parse_rrq(make_rrq("boot.ipxe", {{"timeout", "999"}}));
    assert(t_hi.is_ok());
    assert(t_hi.value().options.has_timeout);
    assert(t_hi.value().options.timeout == TftpServer::kMaxTimeoutSec);

    auto t_lo = TftpServer::parse_rrq(make_rrq("boot.ipxe", {{"timeout", "0"}}));
    assert(t_lo.is_ok());
    assert(t_lo.value().options.empty());

    // Malformed value drops only that option, never the request.
    auto t_bad = TftpServer::parse_rrq(
        make_rrq("boot.ipxe", {{"blksize", "abc"}, {"tsize", "1234"}}));
    assert(t_bad.is_ok());
    assert(!t_bad.value().options.has_blksize);
    assert(t_bad.value().options.has_tsize && t_bad.value().options.tsize == 1234);

    // ---- 4. Live exchange: OACK first, ACK 0, then DATA -------------------------
#if defined(_WIN32)
    WSADATA wsa;
    assert(WSAStartup(MAKEWORD(2, 2), &wsa) == 0);
#endif
    std::error_code ec;
    const std::filesystem::path dir = "test_scratch_tftp_oack";
    std::filesystem::remove_all(dir, ec);
    std::filesystem::create_directories(dir, ec);

    {
        const uint16_t port = 10071;
        TftpServer tftp(NetworkAddress(127, 0, 0, 1), dir, port);
        assert(tftp.initialize().is_ok());
        std::this_thread::sleep_for(std::chrono::milliseconds(50));

        auto content = tftp.get_file_content("boot.ipxe");
        assert(content.is_ok());
        const std::string real_size = std::to_string(content.value().size());
        assert(content.value().size() < 1428); // one DATA block completes the transfer

        SOCKET s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        assert(s != INVALID_SOCKET);
        DWORD tv_ms = 3000;
        setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv_ms), sizeof(tv_ms));

        sockaddr_in srv{};
        srv.sin_family = AF_INET;
        srv.sin_port = htons(port);
        srv.sin_addr.s_addr = inet_addr("127.0.0.1");

        const auto rrq = make_rrq("boot.ipxe", {{"blksize", "1468"}, {"tsize", "0"}});
        assert(sendto(s, reinterpret_cast<const char*>(rrq.data()), static_cast<int>(rrq.size()), 0,
                      reinterpret_cast<const sockaddr*>(&srv), sizeof(srv)) ==
               static_cast<int>(rrq.size()));

        std::vector<uint8_t> buf(2048);
        sockaddr_in from{};
        int from_len = sizeof(from);
        int recvd = recvfrom(s, reinterpret_cast<char*>(buf.data()), static_cast<int>(buf.size()), 0,
                             reinterpret_cast<sockaddr*>(&from), &from_len);
        assert(recvd > 0);
        // The very first packet is the OACK. A DATA packet here is the PXE-E32 bug.
        assert(buf[0] == 0x00 && buf[1] == 0x06);
        assert(oack_get(buf, "blksize") == "1428");
        assert(oack_get(buf, "tsize") == real_size);

        // ACK block 0 goes to the TID (the ephemeral session port the OACK came from).
        const std::vector<uint8_t> ack0 = {0x00, 0x04, 0x00, 0x00};
        assert(sendto(s, reinterpret_cast<const char*>(ack0.data()), static_cast<int>(ack0.size()), 0,
                      reinterpret_cast<const sockaddr*>(&from), sizeof(from)) ==
               static_cast<int>(ack0.size()));

        from_len = sizeof(from);
        recvd = recvfrom(s, reinterpret_cast<char*>(buf.data()), static_cast<int>(buf.size()), 0,
                         reinterpret_cast<sockaddr*>(&from), &from_len);
        assert(recvd > 0);
        assert(buf[0] == 0x00 && buf[1] == 0x03);        // DATA
        assert(buf[2] == 0x00 && buf[3] == 0x01);        // block 1
        assert(recvd - 4 <= 1428);                       // negotiated blksize honoured

        const std::vector<uint8_t> ack1 = {0x00, 0x04, 0x00, 0x01};
        sendto(s, reinterpret_cast<const char*>(ack1.data()), static_cast<int>(ack1.size()), 0,
               reinterpret_cast<const sockaddr*>(&from), sizeof(from));
        std::this_thread::sleep_for(std::chrono::milliseconds(50));

        closesocket(s);
        tftp.shutdown();
    }

    std::filesystem::remove_all(dir, ec);
#if defined(_WIN32)
    WSACleanup();
#endif
    std::cout << "  PASS: test_tftp_option_negotiation_oack\n";
}

// ---------------------------------------------------------------------------
// RFC 1350: a classic RRQ with no option block must be answered immediately
// with DATA block 1 -- no OACK, no waiting for ACK 0.
// ---------------------------------------------------------------------------
void test_tftp_standard_rrq_rfc1350() {
    std::cout << "[RUN] test_tftp_standard_rrq_rfc1350\n";

    auto make_rrq = [](const std::string& file,
                       const std::vector<std::pair<std::string, std::string>>& opts) {
        std::vector<uint8_t> pkt = {0x00, 0x01};
        auto put = [&](const std::string& s) {
            pkt.insert(pkt.end(), s.begin(), s.end());
            pkt.push_back(0x00);
        };
        put(file);
        put("octet");
        for (const auto& kv : opts) {
            put(kv.first);
            put(kv.second);
        }
        return pkt;
    };

    // ---- 1. The parse decides RFC 1350, not RFC 2347 ---------------------------
    auto classic = TftpServer::parse_rrq(make_rrq("boot.ipxe", {}));
    assert(classic.is_ok());
    assert(classic.value().filename == "boot.ipxe");
    assert(classic.value().options.empty());

    // The byte-for-byte form a PXE ROM actually sends (no mode, no options).
    const std::vector<uint8_t> raw = {
        0x00, 0x01, 'b', 'o', 'o', 't', '.', 'i', 'p', 'x', 'e', 0x00, 'o', 'c', 't', 'e', 't', 0x00};
    auto raw_res = TftpServer::parse_rrq(raw);
    assert(raw_res.is_ok());
    assert(raw_res.value().options.empty());
    assert(raw_res.value().filename == "boot.ipxe");

    // ---- 2. Live exchange: the first datagram is DATA 1 ------------------------
#if defined(_WIN32)
    WSADATA wsa;
    assert(WSAStartup(MAKEWORD(2, 2), &wsa) == 0);
#endif
    std::error_code ec;
    const std::filesystem::path dir = "test_scratch_tftp_rfc1350";
    std::filesystem::remove_all(dir, ec);
    std::filesystem::create_directories(dir, ec);

    {
        const uint16_t port = 10072;
        TftpServer tftp(NetworkAddress(127, 0, 0, 1), dir, port);
        assert(tftp.initialize().is_ok());
        std::this_thread::sleep_for(std::chrono::milliseconds(50));

        SOCKET s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        assert(s != INVALID_SOCKET);
        DWORD tv_ms = 3000;
        setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv_ms), sizeof(tv_ms));

        sockaddr_in srv{};
        srv.sin_family = AF_INET;
        srv.sin_port = htons(port);
        srv.sin_addr.s_addr = inet_addr("127.0.0.1");

        const auto rrq = make_rrq("boot.ipxe", {});
        assert(sendto(s, reinterpret_cast<const char*>(rrq.data()), static_cast<int>(rrq.size()), 0,
                      reinterpret_cast<const sockaddr*>(&srv), sizeof(srv)) ==
               static_cast<int>(rrq.size()));

        std::vector<uint8_t> buf(2048);
        sockaddr_in from{};
        int from_len = sizeof(from);
        int recvd = recvfrom(s, reinterpret_cast<char*>(buf.data()), static_cast<int>(buf.size()), 0,
                             reinterpret_cast<sockaddr*>(&from), &from_len);
        assert(recvd >= 4);
        assert(buf[0] == 0x00 && buf[1] == 0x03); // DATA, straight away
        assert(buf[2] == 0x00 && buf[3] == 0x01); // block 1
        assert(recvd - 4 <= 512);                 // RFC 1350 default block size

        // ACK block 1 so the session completes cleanly before shutdown.
        const std::vector<uint8_t> ack1 = {0x00, 0x04, 0x00, 0x01};
        sendto(s, reinterpret_cast<const char*>(ack1.data()), static_cast<int>(ack1.size()), 0,
               reinterpret_cast<const sockaddr*>(&from), sizeof(from));
        std::this_thread::sleep_for(std::chrono::milliseconds(50));

        closesocket(s);
        tftp.shutdown();
    }

    std::filesystem::remove_all(dir, ec);
#if defined(_WIN32)
    WSACleanup();
#endif
    std::cout << "  PASS: test_tftp_standard_rrq_rfc1350\n";
}

// ---------------------------------------------------------------------------
// Early-boot hardening registry contract: the three fixes that decide whether
// a network-disk guest survives Phase 0 at all.
//
//   * Services\disk\TimeOutValue = 60      -> no 0x7A / 0x7B on a slow LUN
//   * Tcpip\Parameters\DisableTaskOffload  -> global LSO/checksum kill switch
//   * *LsoV2* / *ChecksumOffload* = "0"    -> no DMA storm into the boot iSCSI
//     (REG_SZ, never REG_DWORD: a "*" keyword read as a DWORD is stop 0xA)
// ---------------------------------------------------------------------------
void test_early_boot_hardening_registry() {
    std::cout << "[RUN] test_early_boot_hardening_registry\n";

    const std::string inst_prefix =
        "ControlSet001\\Control\\Class\\{4d36e972-e325-11ce-bfc1-08002be10318}\\";

    const std::vector<PnpDriverArmer::SyntheticNetAdapter> adapters = {
        {"0000", "Realtek PCIe GbE Family Controller", "PCI\\VEN_10EC&DEV_8168",
         "pci\\ven_10ec&dev_8168", full_anti_flap_ndi_schema(), "rt640x64"},
    };
    const std::vector<std::pair<std::string, uint32_t>> services = {
        {"msiscsi", 3}, {"rt640x64", 0}, {"Tcpip", 1}, {"NDIS", 1}};

    auto assert_hardened = [&](const std::vector<uint8_t>& hive) {
        uint32_t v = 0xFFFFFFFF;

        // (1) disk class I/O timeout
        const uint32_t disk = hive_open_path(hive, "ControlSet001\\Services\\disk");
        assert(disk != 0xFFFFFFFF);
        assert(hive_value_type(hive, disk, "TimeOutValue") == 4 /* REG_DWORD */);
        assert(hive_get_dword(hive, disk, "TimeOutValue", &v) && v == 60);

        // (2) global offload kill
        const uint32_t tcp = hive_open_path(hive, "ControlSet001\\Services\\Tcpip\\Parameters");
        assert(tcp != 0xFFFFFFFF);
        assert(hive_get_dword(hive, tcp, "DisableTaskOffload", &v) && v == 1);

        // (3) every LSO / checksum keyword zeroed, strictly as REG_SZ "0"
        const uint32_t inst = hive_open_path(hive, inst_prefix + "0000");
        assert(inst != 0xFFFFFFFF);
        for (const char* kw : {"*LsoV2IPv4", "*LsoV2IPv6", "*IPChecksumOffloadIPv4",
                               "*TCPChecksumOffloadIPv4", "*UDPChecksumOffloadIPv4",
                               "*TCPChecksumOffloadIPv6", "*UDPChecksumOffloadIPv6"}) {
            assert(hive_value_type(hive, inst, kw) == 1 /* REG_SZ */);
            assert(hive_get_string(hive, inst, kw) == "0");
        }
    };

    auto hive = PnpDriverArmer::create_synthetic_system_hive(1, services, adapters, "10.0");

    // Nothing of this exists on a fresh image -- the armer has to create it.
    assert(hive_open_path(hive, "ControlSet001\\Services\\disk") == 0xFFFFFFFF);

    auto first = PnpDriverArmer::arm_hive_buffer(hive);
    assert(first.is_ok());
    assert(first.value().success);
    assert(first.value().disk_timeout_armed);
    assert(first.value().tcpip_offload_disabled);
    assert(first.value().summary().find("Stage 15 disk Timeout") != std::string::npos);
    assert(first.value().summary().find("EXTENDED (TimeOutValue=60)") != std::string::npos);
    assert_hardened(hive);

    // ---- Re-corrupt and re-arm: already-corrected state must be corrected again --
    const uint32_t disk = hive_open_path(hive, "ControlSet001\\Services\\disk");
    const uint32_t tcp = hive_open_path(hive, "ControlSet001\\Services\\Tcpip\\Parameters");
    const uint32_t inst = hive_open_path(hive, inst_prefix + "0000");
    assert(disk != 0xFFFFFFFF && tcp != 0xFFFFFFFF && inst != 0xFFFFFFFF);
    assert(hive_poke_dword(hive, disk, "TimeOutValue", 10));
    assert(hive_poke_dword(hive, tcp, "DisableTaskOffload", 0));
    {
        // REG_SZ "1" (same UTF-16LE cell size as "0")
        const std::vector<uint8_t> one = {0x31, 0x00, 0x00, 0x00};
        assert(hive_poke_string_data(hive, inst, "*LsoV2IPv4", one));
    }

    uint32_t v = 0;
    assert(hive_get_dword(hive, disk, "TimeOutValue", &v) && v == 10);
    assert(hive_get_dword(hive, tcp, "DisableTaskOffload", &v) && v == 0);
    assert(hive_get_string(hive, inst, "*LsoV2IPv4") == "1");

    auto second = PnpDriverArmer::arm_hive_buffer(hive);
    assert(second.is_ok());
    assert(second.value().success);
    assert(second.value().disk_timeout_armed);
    assert(second.value().tcpip_offload_disabled);
    assert_hardened(hive);

    std::cout << "  PASS: test_early_boot_hardening_registry\n";
}

int main() {
    std::cout << "=========================================================\n";
    std::cout << "CobDisklessCore Test Suite\n";
    std::cout << "=========================================================\n";

    // Phase 3 Tests
    test_common_types();
    test_errors_and_results();
    test_logging();
    test_configuration_validation();
    test_subsystem_deterministic_lifecycle();
    test_subsystem_failure_rollback();
    test_storage_block_device();

    // Phase 4 Tests
    test_mbr_detection();
    test_gpt_detection();
    test_boot_mode_recognition();
    test_filesystem_recognition();
    test_raw_image_backend();
    test_vhd_image_backend();
    test_golden_image_readonly_invariant();
    test_golden_image_registry();

    // Phase 5 Tests
    test_configuration_persistence_and_directories();
    test_storage_tester_health_and_benchmark();

    // Phase 6 Tests
    test_image_manager_lifecycle_and_safe_handling();

    // Phase 7 Tests
    test_cow_block_device_lifecycle();
    test_client_session_manager_isolation();

    // Phase 8 Tests
    test_dhcp_architecture_detection_and_pxe_provisioning();
    test_tftp_server_virtual_payloads_and_ipxe_script();

    // Phase 9 Tests
    test_iscsi_target_scsi_emulation_and_client_dispatch();

    // Phase 10 Tests
    test_block_cache_lru_and_read_ahead();

    // Phase 11 Tests
    test_production_hardening_and_recovery();

    // Phase 12 Tests
    test_end_to_end_diskless_boot_pipeline();

    // Phase 13 Reality Verification & Hardening Tests
    test_vhdx_rejection_and_vhd_handling();
    test_real_socket_networking();
    test_concurrency_and_stress();

    // Complete Diskless Management & Deep Virtual Disk Inspection Tests
    test_client_manager_lifecycle_and_persistence();
    test_storage_manager_drive_roles_and_validation();
    test_vhd_windows_deep_inspection();
    test_dhcp_client_auto_registration_pipeline();

    // End-to-End Block Data Path & Windows Client Boot Tests
    test_storage_roles_explicit_confirmation_requirement();
    test_iscsi_rfc3720_login_and_data_segment_drainage();
    test_iscsi_windows_boot_scsi_command_suite();
    test_iscsi_write10_and_sync_cache_persistence();
    test_iscsi_multi_lun_os_and_game_dispatch();

    // Real Hardware Recovery Tests
    test_real_hardware_recovery_dhcp_tftp_cache();
    test_vhd_vhdx_import_suite();

    // Super Client Image Update Pipeline Tests
    test_super_client_image_update_pipeline();

    // Image Persistence and Auto-load Pipeline Tests
    test_image_persistence_and_autoload_pipeline();

    // Multi-Client Copy-on-Write Writeback Isolation & Lifecycle Tests
    test_multi_client_writeback_isolation_and_lifecycle();

    // Client Enrollment, Dynamic Network Sniffing & Hostname Provisioning Tests
    test_host_network_pool_and_client_registry();
    test_http_enrollment_and_ipxe_scripts();
    test_http_daemon_live_socket();

    // Config Lookup & Port Collision Resilience Tests
    test_config_file_resolution_and_default_port();
    test_dynamic_port_propagation_on_collision();

    // Automated PNP Driver Arming & Offline Registry Injection Tests
    test_pnp_driver_arming_and_offline_registry_injection();

    // Multi-NIC boot-start decoupling, flat Parameters purge & offline hive inspection
    test_boot_conflict_resolution_and_hive_inspection();

    // DHCP INIT-REBOOT Kernel Handoff Tests
    test_dhcp_init_reboot_and_kernel_handoff();

    // DHCP Option 67 Raw Wire Payload Integrity Tests
    test_dhcp_option67_raw_wire_integrity();

    // iPXE Boot Script Rendering & Wire Integrity Tests
    test_ipxe_boot_script_rendering_and_wire_integrity();

    // WinPE Zero-Touch Hardware Provisioning Pipeline Tests
    test_client_manager_boot_state_machine();
    test_dynamic_boot_script_router();
    test_staged_callback_lifecycle_and_static_assets();
    test_live_static_stream_and_staged_post();

    // Zero-touch provisioning audit regression suites
    test_iscsi_shared_session_connection_refcount();
    test_offline_hive_dirty_detection_and_clean_flush();
    test_dhcp_zero_config_boot_and_raw_logging();
    test_dhcp_self_lease_and_tftp_ephemeral_routing();
    test_auto_arm_vhd_configuration_and_offline_discovery();
    test_offline_driver_store_harvesting_and_host_depot_fallback();
    test_guest_arch_detection_and_universal_ndis_harvest();
    test_stage15_crash_dump_paging_and_offload_kill_switch();
    test_os_family_gating_and_safe_driver_staging();
    test_ndi_schema_gated_reg_sz_anti_flap();

    // Offline PE identity + legacy RTL8111E DriverStore rollback
    test_pe_version_extraction_and_driver_rollback();

    // NIC profile election: net-class-only hardware scanning + Realtek precedence
    test_nic_profile_election_ignores_chipset_devnodes();

    // NT volume GUID root resolution + stale NicBootProfile pin eviction
    test_volume_root_guid_parsing();
    test_stale_profile_pin_evicted();

    // TFTP RFC 2347/2348 option negotiation (OACK) vs RFC 1350 immediate DATA
    test_tftp_option_negotiation_oack();
    test_tftp_standard_rrq_rfc1350();

    // Early-boot hardening registry contract (disk timeout, offload kill)
    test_early_boot_hardening_registry();

    std::cout << "=========================================================\n";
    std::cout << "ALL TESTS PASSED SUCCESSFULLY (74/74 suites)\n";
    std::cout << "=========================================================\n";
    return 0;
}
