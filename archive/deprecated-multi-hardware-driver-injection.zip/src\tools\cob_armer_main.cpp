// ============================================================================
// cob-armer - standalone offline SYSTEM hive armer for CobDiskless clients.
//
//   Usage: cob-armer <path_to_SYSTEM_hive>
//
// The tool is the human/automation entry point for the exact same arming pass
// that POST /api/client/staged runs automatically after WinPE has injected NIC
// drivers into a client's target VHD. It is deliberately thin: all of the
// registry surgery lives in CobDisklessCore so the CLI, the HTTP callback and
// the tests can never drift apart.
//
// Exit codes:
//   0  armed and verified (or inspection completed)
//   2  usage / bad arguments
//   3  hive missing or not readable/writable
//   4  file is not a regf hive
//   5  arming pass failed
//   6  arming finished but verification failed
//   7  inspection failed / inspected hive was not healthy
//   1  unexpected internal failure
// ============================================================================

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <string_view>
#include <vector>

#include "CobDisklessCore/config/simple_json.hpp"
#include "CobDisklessCore/image/pnp_driver_armer.hpp"

namespace {

using cobdiskless::JsonValue;
using cobdiskless::DriverBinaryInspection;
using cobdiskless::DriverRestoreReport;
using cobdiskless::NicBootProfile;
using cobdiskless::PnpDriverArmReport;
using cobdiskless::PnpDriverArmer;
using cobdiskless::PnpHiveInspectionReport;

constexpr int kExitOk = 0;
constexpr int kExitUnexpected = 1;
constexpr int kExitUsage = 2;
constexpr int kExitIo = 3;
constexpr int kExitNotAHive = 4;
constexpr int kExitArmingFailed = 5;
constexpr int kExitVerificationFailed = 6;
constexpr int kExitInspectFailed = 7;

const char* kUsage =
    "Usage: cob-armer <path_to_SYSTEM_hive> [options]\n"
    "       cob-armer --inspect <hive|volume|vhd> [--volume <root>]\n"
    "       cob-armer --fix-boot-conflicts <path_to_SYSTEM_hive> [--nic-profile <name>]\n"
    "       cob-armer --inspect-driver <volume|vhd|sys> [--rva <0xHEX>] [--driver <name>]\n"
    "       cob-armer --restore-inbox-driver <volume|vhd> [--driver <name>] [--hw-id <id>]\n"
    "\n"
    "Arms an offline Windows SYSTEM hive for modern Windows 10/11 iSCSI boot:\n"
    "  * promotes msiscsi / Tcpip / NDIS and the NIC drivers to SERVICE_BOOT_START\n"
    "  * writes BootFlags = 0x00000001 (CM_SERVICE_NETWORK_BOOT_LOAD)\n"
    "  * forces Group = NDIS on network boot services\n"
    "  * injects the CriticalDeviceDatabase bindings on legacy guests (XP/2003/Vista/7)\n"
    "    and skips + purges them on Windows 8+ (modern PnP resolves via DriverStore)\n"
    "  * disables Realtek PHY power saving (*EEE / PowerSavingMode)\n"
    "  * elects ONE NIC vendor family as the boot NIC (see --nic-profile) so two\n"
    "    miniports never both land at Start = 0 during Phase 0\n"
    "\n"
    "Options:\n"
    "  --inspect <path>       read-only diagnostic dump of a SYSTEM hive, a mounted\n"
    "                         volume root, or a raw .vhd/.vhdx: Services\\<drv> Start /\n"
    "                         Group / BootFlags / Parameters, every binding under\n"
    "                         Control\\Class\\{4d36e972-...}, and the SHA-256 + PE version\n"
    "                         of staged vs DriverStore copies of rt640x64.sys/e1d68x64.sys\n"
    "  --volume <root>        mount point that owns <path> (optional; derived from the\n"
    "                         hive path when it sits in the usual \\Windows\\System32\\config tree)\n"
    "  --fix-boot-conflicts   repair a dual boot-NIC image: demote the losing vendor\n"
    "                         family to Start=3, verify rt640x64 is Start=0/Group=NDIS,\n"
    "                         purge Services\\<realtek>\\Parameters, flush the hive with\n"
    "                         synchronized sequence numbers and truncated .LOG1/.LOG2\n"
    "  --nic-profile <name>   auto | realtek | intel | multi  (default: auto)\n"
    "                           auto    pick from the image's own adapter bindings\n"
    "                           realtek only rt640x64 family boots; e1d68x64 -> Start=3\n"
    "                           intel   only e1d68x64 family boots; rt640x64 -> Start=3\n"
    "                           multi   keep every NIC driver boot-start (explicit dual NIC)\n"
    "  --inspect-driver <p>   faulting-driver triage: FileVersion + ProductVersion of the\n"
    "                         active binary at <p>\\Windows\\System32\\drivers\\<driver>, its\n"
    "                         SHA-256 and section table, plus whether the faulting RVA\n"
    "                         falls inside .text. Accepts a volume root, a .vhd/.vhdx, a\n"
    "                         SYSTEM hive or the .sys itself (a .sys argument also becomes\n"
    "                         the driver being triaged)\n"
    "  --rva <0xHEX>          instruction offset to attribute (default 0xE534, the M71s\n"
    "                         stop 0xA faulting RIP relative to the driver base)\n"
    "  --driver <name>        driver file to triage or restore (default rt640x64.sys)\n"
    "  --hw-id <id>           device id the restored package must declare from its INF\n"
    "                         (default PCI\\VEN_10EC&DEV_8168, shared by RTL8111E/H/8168)\n"
    "  --restore-inbox-driver roll <driver> back to the OLDEST DriverStore package that is\n"
    "                         below the 10.35 legacy ceiling and declares --hw-id (the\n"
    "                         9.1.408.x / 10.1.x inbox and OEM builds that still initialise\n"
    "                         RTL8111E Rev 06). The outgoing binary is saved as\n"
    "                         <driver>.prev first -- this is the only path in the armer\n"
    "                         allowed to overwrite an existing staged .sys\n"
    "  --self-test            arm a generated synthetic hive and verify the result\n"
    "  -h, --help             show this message\n"
    "\n"
    "Exit codes: 0 success, 2 usage, 3 I/O error, 4 not a regf hive,\n"
    "            5 arming failed, 6 verification failed, 7 inspection failed,\n"
    "            1 unexpected error\n";

/// Services the report must list for a fully armed image.
const std::vector<std::string>& required_arming_services() {
    static const std::vector<std::string> services = {
        "msiscsi", "Tcpip", "NDIS", "rt640x64", "e1d68x64",
    };
    return services;
}

std::string lowercase(std::string_view text) {
    std::string out(text);
    std::transform(out.begin(), out.end(), out.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return out;
}

bool contains_ci(const std::vector<std::string>& haystack, const std::string& needle) {
    const std::string wanted = lowercase(needle);
    return std::any_of(haystack.begin(), haystack.end(), [&](const std::string& entry) {
        return lowercase(entry) == wanted;
    });
}

/// True when the file exists, is a regular file and is both readable and writable.
bool check_openable(const std::filesystem::path& path) {
    std::error_code ec;
    if (!std::filesystem::exists(path, ec) || ec) {
        std::cerr << "[ERROR] Hive does not exist: " << path.string() << "\n";
        return false;
    }
    if (!std::filesystem::is_regular_file(path, ec) || ec) {
        std::cerr << "[ERROR] Not a regular file: " << path.string() << "\n";
        return false;
    }
    if (std::filesystem::file_size(path, ec) < 0x1000 || ec) {
        std::cerr << "[ERROR] File is too small to be a SYSTEM hive: " << path.string() << "\n";
        return false;
    }

    // std::filesystem has no portable access() equivalent, so probe both modes.
    {
        std::ifstream in(path, std::ios::binary);
        if (!in.is_open()) {
            std::cerr << "[ERROR] Hive is not readable (check permissions): " << path.string()
                      << "\n";
            return false;
        }
    }
    {
        std::fstream out(path, std::ios::in | std::ios::out | std::ios::binary);
        if (!out.is_open()) {
            std::cerr << "[ERROR] Hive is not writable (check permissions): " << path.string()
                      << "\n";
            return false;
        }
    }
    return true;
}

/// Validates the 4-byte "regf" signature every Windows registry hive starts with.
bool check_regf_header(const std::filesystem::path& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in.is_open()) {
        return false;
    }
    char signature[4] = {};
    if (!in.read(signature, sizeof(signature))) {
        std::cerr << "[ERROR] Cannot read hive header from: " << path.string() << "\n";
        return false;
    }
    if (std::string_view(signature, sizeof(signature)) != "regf") {
        std::cerr << "[ERROR] Not a Windows registry hive (missing 'regf' header): "
                  << path.string() << "\n";
        return false;
    }
    return true;
}

JsonValue string_array(const std::vector<std::string>& items) {
    JsonValue array = JsonValue::make_array();
    for (const auto& item : items) {
        array.push_back(JsonValue(item));
    }
    return array;
}

/// Serializes the full PnpDriverArmReport as machine-readable JSON.
JsonValue report_to_json(const PnpDriverArmReport& report) {
    JsonValue root = JsonValue::make_object();
    root["success"] = report.success;
    root["target"] = report.target_path.string();
    root["control_set"] = report.control_set;
    root["boot_flags_armed"] = report.boot_flags_armed;
    root["iscsi_stack_armed"] = report.iscsi_stack_armed;
    root["armed_services"] = string_array(report.armed_services);
    // "updated_services" is the operator-facing alias for every service touched.
    root["updated_services"] = string_array(report.armed_services);
    root["modified_services"] = string_array(report.modified_services);
    root["injected_services"] = string_array(report.injected_services);
    root["missing_services"] = string_array(report.missing_services);
    root["cddb_bindings"] = string_array(report.cddb_bindings);
    root["guest_os_family"] = report.guest_os_family;
    root["cddb_purged"] = string_array(report.cddb_purged);
    root["nic_profile"] = report.nic_profile;
    root["demoted_services"] = string_array(report.demoted_services);
    root["service_parameters_purged"] = string_array(report.service_parameters_purged);
    root["warnings"] = string_array(report.warnings);
    root["message"] = report.message;
    root["summary"] = report.summary();
    return root;
}

/// Prints the human-readable report block on stderr, the JSON document on stdout.
void emit_report(const PnpDriverArmReport& report) {
    std::cerr << "[INFO] " << report.summary() << "\n";

    std::cerr << "[INFO] Updated services (" << report.armed_services.size() << "):";
    if (report.armed_services.empty()) {
        std::cerr << " <none>";
    }
    for (const auto& service : report.armed_services) {
        std::cerr << " " << service;
    }
    std::cerr << "\n";

    std::cerr << "[INFO] CriticalDeviceDatabase bindings (" << report.cddb_bindings.size() << "):";
    if (report.cddb_bindings.empty()) {
        std::cerr << " <none>";
    }
    for (const auto& binding : report.cddb_bindings) {
        std::cerr << " " << binding;
    }
    std::cerr << "\n";

    std::cerr << "[INFO] Guest OS family: " << (report.guest_os_family.empty() ? "unknown" : report.guest_os_family);
    if (report.guest_os_family == "modern") {
        std::cerr << " (NT 6.2+, CriticalDeviceDatabase skipped)";
    } else {
        std::cerr << " (NT 5.x/6.1, CriticalDeviceDatabase required to avoid 0x7B)";
    }
    std::cerr << "\n";
    if (!report.cddb_purged.empty()) {
        std::cerr << "[INFO] Purged poisoned CriticalDeviceDatabase keys ("
                  << report.cddb_purged.size() << "):";
        for (const auto& key : report.cddb_purged) {
            std::cerr << " " << key;
        }
        std::cerr << "\n";
    }

    std::cerr << "[INFO] NIC boot profile: " << (report.nic_profile.empty() ? "auto" : report.nic_profile);
    if (!report.demoted_services.empty()) {
        std::cerr << " (demoted:";
        for (const auto& service : report.demoted_services) {
            std::cerr << " " << service;
        }
        std::cerr << " -> Start=3)";
    }
    std::cerr << "\n";

    if (!report.service_parameters_purged.empty()) {
        std::cerr << "[INFO] Purged flat service Parameters key(s) ("
                  << report.service_parameters_purged.size() << "):";
        for (const auto& key : report.service_parameters_purged) {
            std::cerr << " " << key;
        }
        std::cerr << "\n";
    }

    std::cerr << "[INFO] boot_flags_armed=" << (report.boot_flags_armed ? "true" : "false")
              << " iscsi_stack_armed=" << (report.iscsi_stack_armed ? "true" : "false") << "\n";

    for (const auto& warning : report.warnings) {
        std::cerr << "[WARN] " << warning << "\n";
    }

    std::cout << report_to_json(report).dump(2) << std::endl;
}

/// Serializes the read-only inspection report as machine-readable JSON.
JsonValue inspection_to_json(const PnpHiveInspectionReport& report) {
    JsonValue root = JsonValue::make_object();
    root["success"] = report.success;
    root["hive"] = report.hive_path.string();
    root["volume"] = report.volume_path.string();
    root["control_set"] = report.control_set;
    root["guest_os_family"] = report.guest_os_family;
    root["message"] = report.message;

    JsonValue services = JsonValue::make_array();
    for (const auto& service : report.nic_services) {
        JsonValue entry = JsonValue::make_object();
        entry["service"] = service.service_name;
        entry["present"] = service.present;
        entry["start"] = service.start;
        entry["group"] = service.group;
        entry["has_boot_flags"] = service.has_boot_flags;
        entry["boot_flags"] = service.boot_flags;
        entry["has_parameters"] = service.has_parameters;
        entry["parameter_values"] = string_array(service.parameter_values);
        entry["parameter_subkeys"] = string_array(service.parameter_subkeys);
        services.push_back(entry);
    }
    root["services"] = services;

    JsonValue adapters = JsonValue::make_array();
    for (const auto& adapter : report.net_adapters) {
        JsonValue entry = JsonValue::make_object();
        entry["subkey"] = adapter.subkey;
        entry["driver_desc"] = adapter.driver_desc;
        entry["matching_device_id"] = adapter.matching_device_id;
        entry["component_id"] = adapter.component_id;
        adapters.push_back(entry);
    }
    root["net_class_bindings"] = adapters;

    JsonValue drivers = JsonValue::make_array();
    for (const auto& driver : report.driver_files) {
        JsonValue entry = JsonValue::make_object();
        entry["service"] = driver.service_name;
        entry["file"] = driver.driver_file;
        entry["deployed"] = driver.deployed.string();
        entry["deployed_present"] = driver.deployed_present;
        entry["deployed_sha256"] = driver.deployed_sha256;
        entry["deployed_version"] = driver.deployed_version;
        entry["source"] = driver.source.string();
        entry["source_present"] = driver.source_present;
        entry["source_sha256"] = driver.source_sha256;
        entry["source_version"] = driver.source_version;
        entry["identical"] = driver.identical;
        drivers.push_back(entry);
    }
    root["driver_files"] = drivers;

    root["findings"] = string_array(report.findings);
    root["summary"] = report.summary();
    return root;
}

/// Prints the human-readable inspection block on stderr, the JSON document on stdout.
void emit_inspection(const PnpHiveInspectionReport& report) {
    std::cerr << "[INFO] " << report.summary() << "\n";
    for (const auto& line : report.findings) {
        if (line.rfind("HAZARD:", 0) == 0 || line.rfind("BOOT CONFLICT:", 0) == 0 ||
            line.rfind("FATAL:", 0) == 0 || line.rfind("MISMATCH", 0) != std::string::npos) {
            std::cerr << "[WARN] " << line << "\n";
        }
    }
    std::cout << inspection_to_json(report).dump(2) << std::endl;
}

std::string hex32(uint32_t value) {
    char buffer[16];
    std::snprintf(buffer, sizeof(buffer), "0x%X", value);
    return buffer;
}

/// Parses --rva: 0x-prefixed hex or plain decimal. RVA 0 is rejected because it is the
/// image header, never an instruction.
bool parse_rva(const std::string& text, uint32_t* out) {
    if (out == nullptr || text.empty()) return false;
    int base = 10;
    std::string digits = text;
    if (digits.size() > 2 && digits[0] == '0' && (digits[1] == 'x' || digits[1] == 'X')) {
        base = 16;
        digits = digits.substr(2);
    }
    if (digits.empty()) return false;

    uint64_t value = 0;
    for (char c : digits) {
        int digit = -1;
        if (c >= '0' && c <= '9') digit = c - '0';
        else if (c >= 'a' && c <= 'f') digit = c - 'a' + 10;
        else if (c >= 'A' && c <= 'F') digit = c - 'A' + 10;
        if (digit < 0 || digit >= base) return false;
        value = value * static_cast<uint64_t>(base) + static_cast<uint64_t>(digit);
        if (value > 0xFFFFFFFFull) return false;
    }
    if (value == 0) return false;
    *out = static_cast<uint32_t>(value);
    return true;
}

/// Serializes the faulting-driver triage (version resource + section map) as JSON.
JsonValue driver_inspection_to_json(const DriverBinaryInspection& report) {
    JsonValue root = JsonValue::make_object();
    root["success"] = report.success;
    root["driver"] = report.driver_file;
    root["volume"] = report.volume_path.string();
    root["path"] = report.driver_path.string();
    root["present"] = report.present;
    root["pe_valid"] = report.pe_valid;
    root["size"] = report.size;
    root["sha256"] = report.sha256;
    root["file_version"] = report.file_version;
    root["product_version"] = report.product_version;
    root["file_version_string"] = report.file_version_string;
    root["product_version_string"] = report.product_version_string;
    root["rva"] = report.rva;
    root["rva_hex"] = hex32(report.rva);
    root["rva_in_text"] = report.rva_in_text;
    root["rva_section"] = report.rva_section;

    JsonValue sections = JsonValue::make_array();
    for (const auto& section : report.sections) {
        JsonValue entry = JsonValue::make_object();
        entry["name"] = section.name;
        entry["virtual_address"] = section.virtual_address;
        entry["virtual_size"] = section.virtual_size;
        entry["raw_size"] = section.raw_size;
        entry["characteristics"] = section.characteristics;
        sections.push_back(entry);
    }
    root["sections"] = sections;

    JsonValue candidates = JsonValue::make_array();
    for (const auto& candidate : report.candidates) {
        JsonValue entry = JsonValue::make_object();
        entry["package"] = candidate.package_dir_name;
        entry["sys"] = candidate.sys_path.string();
        entry["inf"] = candidate.inf_path.string();
        entry["file_version"] = candidate.file_version;
        entry["product_version"] = candidate.product_version;
        entry["sha256"] = candidate.sha256;
        entry["size"] = candidate.size;
        entry["inf_readable"] = candidate.inf_readable;
        entry["hardware_ids"] = string_array(candidate.hardware_ids);
        entry["supports_target_hw_id"] = candidate.supports_target_hw_id;
        entry["legacy_compatible"] = candidate.legacy_compatible;
        candidates.push_back(entry);
    }
    root["candidates"] = candidates;

    root["findings"] = string_array(report.findings);
    root["message"] = report.message;
    root["summary"] = report.summary();
    return root;
}

/// Prints the triage block on stderr (warnings first) and the JSON document on stdout.
void emit_driver_inspection(const DriverBinaryInspection& report) {
    std::cerr << "[INFO] " << report.summary() << "\n";
    for (const auto& line : report.findings) {
        if (line.rfind("HAZARD:", 0) == 0 || line.rfind("no eligible", 0) == 0 ||
            line.rfind("RVA ", 0) == 0) {
            std::cerr << "[INFO] " << line << "\n";
        }
    }
    std::cout << driver_inspection_to_json(report).dump(2) << std::endl;
}

/// Serializes the DriverStore rollback result as JSON.
JsonValue driver_restore_to_json(const DriverRestoreReport& report) {
    JsonValue root = JsonValue::make_object();
    root["success"] = report.success;
    root["driver"] = report.driver_file;
    root["volume"] = report.volume_path.string();
    root["path"] = report.active_path.string();
    root["target_hw_id"] = report.target_hw_id;
    root["performed"] = report.performed;
    root["selected_package"] = report.selected_package;
    root["restored_from"] = report.restored_from.string();
    root["backup_path"] = report.backup_path.string();
    root["previous_version"] = report.previous_version;
    root["previous_sha256"] = report.previous_sha256;
    root["restored_version"] = report.restored_version;
    root["restored_sha256"] = report.restored_sha256;
    root["restored_supports_hw_id"] = report.restored_supports_hw_id;
    root["restored_is_legacy_compatible"] = report.restored_is_legacy_compatible;

    JsonValue candidates = JsonValue::make_array();
    for (const auto& candidate : report.candidates) {
        JsonValue entry = JsonValue::make_object();
        entry["package"] = candidate.package_dir_name;
        entry["file_version"] = candidate.file_version;
        entry["sha256"] = candidate.sha256;
        entry["hardware_ids"] = string_array(candidate.hardware_ids);
        entry["supports_target_hw_id"] = candidate.supports_target_hw_id;
        entry["legacy_compatible"] = candidate.legacy_compatible;
        candidates.push_back(entry);
    }
    root["candidates"] = candidates;
    root["warnings"] = string_array(report.warnings);
    root["message"] = report.message;
    root["summary"] = report.summary();
    return root;
}

void emit_driver_restore(const DriverRestoreReport& report) {
    std::cerr << "[INFO] " << report.summary() << "\n";
    if (report.performed) {
        std::cerr << "[INFO] Rolled in " << report.selected_package << " from "
                  << report.restored_from.string() << "\n";
        if (!report.backup_path.empty()) {
            std::cerr << "[INFO] Previous binary kept at " << report.backup_path.string() << "\n";
        }
    }
    for (const auto& warning : report.warnings) {
        std::cerr << "[WARN] " << warning << "\n";
    }
    std::cout << driver_restore_to_json(report).dump(2) << std::endl;
}

/// Verifies the two behavioural guarantees the pipeline depends on.
bool verify_report(const PnpDriverArmReport& report, std::string& reason) {
    if (!report.success) {
        reason = report.message.empty() ? "arming pass reported failure" : report.message;
        return false;
    }
    if (!report.boot_flags_armed) {
        reason = "BootFlags = 0x1 (CM_SERVICE_NETWORK_BOOT_LOAD) missing on a network service";
        return false;
    }
    if (!report.iscsi_stack_armed) {
        reason = "iSCSI boot stack (msiscsi/Tcpip/ndis) is not boot-start";
        return false;
    }
    for (const auto& service : required_arming_services()) {
        if (!contains_ci(report.armed_services, service)) {
            reason = "service was not armed: " + service;
            return false;
        }
    }
    return true;
}

int run_arm(const std::filesystem::path& hive_path, NicBootProfile profile) {
    if (!check_openable(hive_path)) {
        return kExitIo;
    }
    if (!check_regf_header(hive_path)) {
        return kExitNotAHive;
    }

    std::cerr << "[INFO] Arming offline SYSTEM hive: " << hive_path.string()
              << " (nic-profile=" << PnpDriverArmer::nic_profile_name(profile) << ")\n";

    auto armed = PnpDriverArmer::arm_offline_system_hive(hive_path, profile);
    if (armed.is_err()) {
        std::cerr << "[ERROR] Arming failed: " << armed.error().message() << "\n";
        return kExitArmingFailed;
    }

    const PnpDriverArmReport& report = armed.value();
    emit_report(report);

    std::string reason;
    if (!verify_report(report, reason)) {
        std::cerr << "[ERROR] Verification failed: " << reason << "\n";
        return kExitVerificationFailed;
    }

    std::cerr << "[INFO] Hive armed and verified.\n";
    return kExitOk;
}

/// Read-only diagnostic dump: services, Net class bindings, driver binary identity.
int run_inspect(const std::filesystem::path& target, const std::filesystem::path& volume) {
    std::cerr << "[INFO] Inspecting offline image: " << target.string() << "\n";

    auto inspected = volume.empty() ? PnpDriverArmer::inspect_vhd_image(target)
                                    : PnpDriverArmer::inspect_offline_hive(target, volume);
    if (inspected.is_err()) {
        std::cerr << "[ERROR] Inspection failed: " << inspected.error().message() << "\n";
        return kExitInspectFailed;
    }

    const PnpHiveInspectionReport& report = inspected.value();
    emit_inspection(report);
    if (!report.success) {
        std::cerr << "[ERROR] Inspection completed but the hive is not healthy: "
                  << report.message << "\n";
        return kExitInspectFailed;
    }
    std::cerr << "[INFO] Inspection complete.\n";
    return kExitOk;
}

/// Repair pass for a dual boot-NIC image, followed by a read-only re-inspection so the
/// operator sees the post-fix state without a second invocation.
int run_fix(const std::filesystem::path& target, NicBootProfile profile) {
    if (!check_openable(target)) {
        return kExitIo;
    }
    if (!check_regf_header(target)) {
        return kExitNotAHive;
    }

    std::cerr << "[INFO] Fixing boot conflicts in: " << target.string()
              << " (nic-profile=" << PnpDriverArmer::nic_profile_name(profile) << ")\n";

    auto fixed = PnpDriverArmer::fix_boot_conflicts_offline_hive(target, profile);
    if (fixed.is_err()) {
        std::cerr << "[ERROR] Boot conflict fix failed: " << fixed.error().message() << "\n";
        return kExitArmingFailed;
    }

    const PnpDriverArmReport& report = fixed.value();
    emit_report(report);
    if (!report.success) {
        for (const auto& warning : report.warnings) {
            std::cerr << "[ERROR] " << warning << "\n";
        }
        return kExitVerificationFailed;
    }

    std::cerr << "[INFO] Boot conflicts fixed and verified.\n";
    return kExitOk;
}

/// Faulting-driver triage: version resource, SHA-256, section map and the RVA verdict.
int run_inspect_driver(const std::filesystem::path& target, uint32_t rva,
                       const std::string& driver) {
    std::cerr << "[INFO] Inspecting driver binary in: " << target.string()
              << " (RVA " << hex32(rva) << ", driver="
              << (driver.empty() ? std::string("rt640x64.sys") : driver) << ")\n";

    auto inspected = PnpDriverArmer::inspect_driver_binary(target, rva, driver);
    if (inspected.is_err()) {
        std::cerr << "[ERROR] Driver inspection failed: " << inspected.error().message() << "\n";
        std::error_code ec;
        if (!std::filesystem::exists(target, ec)) return kExitIo;
        return kExitInspectFailed;
    }

    const DriverBinaryInspection& report = inspected.value();
    emit_driver_inspection(report);
    if (!report.success) {
        std::cerr << "[ERROR] Driver inspection completed but the binary is not healthy: "
                  << report.message << "\n";
        return kExitInspectFailed;
    }
    std::cerr << "[INFO] Driver inspection complete.\n";
    return kExitOk;
}

/// Roll the active driver back to the legacy DriverStore package for RTL8111E silicon.
int run_restore_driver(const std::filesystem::path& target, const std::string& driver,
                       const std::string& hw_id) {
    std::cerr << "[INFO] Restoring inbox driver in: " << target.string()
              << " (driver=" << (driver.empty() ? std::string("rt640x64.sys") : driver)
              << ")\n";

    auto restored = PnpDriverArmer::restore_inbox_driver(target, driver, hw_id);
    if (restored.is_err()) {
        std::cerr << "[ERROR] Driver restore failed: " << restored.error().message() << "\n";
        std::error_code ec;
        if (!std::filesystem::exists(target, ec)) return kExitIo;
        return kExitArmingFailed;
    }

    const DriverRestoreReport& report = restored.value();
    emit_driver_restore(report);
    if (!report.success) {
        // "Nothing eligible" is an arming-class failure; "copied but not verified" means the
        // file changed and the post-condition did not hold, which is a verification failure.
        return report.selected_package.empty() ? kExitArmingFailed : kExitVerificationFailed;
    }
    std::cerr << "[INFO] Inbox driver restore complete.\n";
    return kExitOk;
}

/// Generates a synthetic SYSTEM hive, arms it, and verifies the result end to end.
int run_self_test() {
    const std::filesystem::path temp_dir =
        std::filesystem::temp_directory_path() / "cob_armer_self_test";
    std::error_code ec;
    std::filesystem::remove_all(temp_dir, ec);
    std::filesystem::create_directories(temp_dir, ec);
    if (ec) {
        std::cerr << "[ERROR] Cannot create temp directory: " << temp_dir.string() << "\n";
        return kExitUnexpected;
    }

    const std::filesystem::path hive_path = temp_dir / "SYSTEM";

    // Every service starts disabled/demand so the armer has to promote all of them.
    std::vector<std::pair<std::string, uint32_t>> services = {
        {"msiscsi", 3}, {"Tcpip", 3}, {"NDIS", 3}, {"rt640x64", 3}, {"e1d68x64", 3},
    };
    std::vector<uint8_t> hive = PnpDriverArmer::create_synthetic_system_hive(1, services);
    if (hive.empty()) {
        std::cerr << "[ERROR] Failed to generate a synthetic SYSTEM hive\n";
        return kExitUnexpected;
    }

    {
        std::ofstream out(hive_path, std::ios::binary | std::ios::trunc);
        if (!out.is_open()) {
            std::cerr << "[ERROR] Cannot write synthetic hive: " << hive_path.string() << "\n";
            return kExitIo;
        }
        out.write(reinterpret_cast<const char*>(hive.data()),
                  static_cast<std::streamsize>(hive.size()));
        out.flush();
        if (!out.good()) {
            std::cerr << "[ERROR] Short write while creating synthetic hive\n";
            return kExitIo;
        }
    }

    const int exit_code = run_arm(hive_path, NicBootProfile::Auto);

    std::filesystem::remove_all(temp_dir, ec);
    if (exit_code == kExitOk) {
        std::cerr << "[INFO] Self test passed.\n";
    }
    return exit_code;
}

} // namespace

int main(int argc, char** argv) {
    std::vector<std::string> args(argv + 1, argv + argc);

    std::filesystem::path target;
    std::filesystem::path volume;
    bool has_target = false;
    bool inspect = false;
    bool fix_boot_conflicts = false;
    bool inspect_driver = false;
    bool restore_inbox_driver = false;
    bool self_test = false;
    uint32_t rva = 0xE534;  // the M71s stop 0xA faulting RIP relative to the driver base
    std::string driver;
    std::string hw_id;
    NicBootProfile profile = NicBootProfile::Auto;

    // An option "takes" the next token when that token does not itself look like a flag,
    // so `cob-armer --inspect <path>`, `cob-armer <path> --inspect` and
    // `cob-armer --nic-profile realtek <path>` all parse the way an operator expects.
    auto takes_value = [&](size_t index) {
        return index + 1 < args.size() && (args[index + 1].empty() || args[index + 1][0] != '-');
    };

    for (size_t i = 0; i < args.size(); ++i) {
        const std::string& arg = args[i];

        if (arg == "-h" || arg == "--help") {
            std::cout << kUsage;
            return kExitOk;
        }
        if (arg == "--self-test") {
            self_test = true;
            continue;
        }
        if (arg == "--inspect") {
            inspect = true;
            if (takes_value(i)) {
                target = args[++i];
                has_target = true;
            }
            continue;
        }
        if (arg == "--volume") {
            if (!takes_value(i)) {
                std::cerr << "cob-armer: --volume requires a directory argument\n\n" << kUsage;
                return kExitUsage;
            }
            volume = args[++i];
            continue;
        }
        if (arg == "--nic-profile") {
            if (!takes_value(i)) {
                std::cerr << "cob-armer: --nic-profile requires auto|realtek|intel|multi\n\n"
                          << kUsage;
                return kExitUsage;
            }
            const std::string value = args[++i];
            bool ok = false;
            profile = PnpDriverArmer::parse_nic_profile(value, &ok);
            if (!ok) {
                std::cerr << "cob-armer: unknown --nic-profile value '" << value << "'\n\n"
                          << kUsage;
                return kExitUsage;
            }
            continue;
        }
        if (arg == "--fix-boot-conflicts") {
            fix_boot_conflicts = true;
            if (takes_value(i)) {
                target = args[++i];
                has_target = true;
            }
            continue;
        }
        if (arg == "--inspect-driver") {
            inspect_driver = true;
            if (takes_value(i)) {
                target = args[++i];
                has_target = true;
            }
            continue;
        }
        if (arg == "--restore-inbox-driver") {
            restore_inbox_driver = true;
            if (takes_value(i)) {
                target = args[++i];
                has_target = true;
            }
            continue;
        }
        if (arg == "--rva") {
            if (!takes_value(i)) {
                std::cerr << "cob-armer: --rva requires 0xHEX or a decimal offset\n\n" << kUsage;
                return kExitUsage;
            }
            const std::string value = args[++i];
            if (!parse_rva(value, &rva)) {
                std::cerr << "cob-armer: bad --rva value '" << value
                          << "' (expected 0xHEX or a decimal offset > 0)\n\n" << kUsage;
                return kExitUsage;
            }
            continue;
        }
        if (arg == "--driver") {
            if (!takes_value(i)) {
                std::cerr << "cob-armer: --driver requires a file name\n\n" << kUsage;
                return kExitUsage;
            }
            driver = args[++i];
            continue;
        }
        if (arg == "--hw-id") {
            if (!takes_value(i)) {
                std::cerr << "cob-armer: --hw-id requires e.g. PCI\\VEN_10EC&DEV_8168\n\n"
                          << kUsage;
                return kExitUsage;
            }
            hw_id = args[++i];
            continue;
        }
        if (!arg.empty() && arg[0] == '-' && arg != "-") {
            std::cerr << "cob-armer: unknown option '" << arg << "'\n\n" << kUsage;
            return kExitUsage;
        }

        if (has_target) {
            std::cerr << "cob-armer: unexpected extra argument '" << arg << "'\n\n" << kUsage;
            return kExitUsage;
        }
        target = arg;
        has_target = true;
    }

    if (self_test) {
        return run_self_test();
    }

    if (!has_target) {
        std::cerr << "cob-armer: missing required argument <path_to_SYSTEM_hive>\n\n" << kUsage;
        return kExitUsage;
    }

    if (inspect_driver && restore_inbox_driver) {
        std::cerr << "cob-armer: --inspect-driver and --restore-inbox-driver are mutually "
                     "exclusive\n\n"
                  << kUsage;
        return kExitUsage;
    }

    try {
        // Driver triage/rollback take a volume root (or a .vhd/.vhdx / the .sys itself)
        // instead of a hive, so they are dispatched before the registry paths.
        if (restore_inbox_driver) {
            return run_restore_driver(target, driver, hw_id);
        }
        if (inspect_driver) {
            return run_inspect_driver(target, rva, driver);
        }
        if (fix_boot_conflicts && inspect) {
            // inspect -> fix -> re-inspect: the repair is only trustworthy if the
            // post-fix state is dumped immediately afterwards.
            const int fix_code = run_fix(target, profile);
            if (fix_code != kExitOk) {
                return fix_code;
            }
            return run_inspect(target, volume);
        }
        if (fix_boot_conflicts) {
            return run_fix(target, profile);
        }
        if (inspect) {
            return run_inspect(target, volume);
        }
        return run_arm(target, profile);
    } catch (const std::exception& ex) {
        std::cerr << "[ERROR] Unexpected failure: " << ex.what() << "\n";
        return kExitUnexpected;
    }
}
