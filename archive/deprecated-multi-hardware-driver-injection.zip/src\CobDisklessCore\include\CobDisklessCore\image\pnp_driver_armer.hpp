#pragma once

#include "CobDisklessCore/errors/result.hpp"
#include <filesystem>
#include <string>
#include <vector>
#include <cstdint>
#include <span>

namespace cobdiskless {

// Guest OS architecture of the image being armed, derived from the mounted
// VHD volume (SysWOW64 presence and/or the PE Machine field of ntoskrnl.exe).
// x64 guests must stage _amd64_ driver packages, x86 guests _x86_ ones.
enum class GuestArch {
    Unknown = 0,
    X86     = 1,
    X64     = 2
};

// Guest OS family of the image being armed, derived offline from the target OS
// version (SYSTEM hive ControlSet00x\Control\Windows, SOFTWARE hive
// Microsoft\Windows NT\CurrentVersion and/or the ntoskrnl.exe version resource).
//
//   Legacy (NT 5.x / 6.1): XP, Server 2003, Vista, Server 2008, Win7
//   Modern (NT 6.2+):      Win8, 8.1, 10, 11
//
// The split matters because the two families boot from completely different
// places: Legacy resolves boot drivers from Control\CriticalDeviceDatabase
// (missing bindings => 0x7B), Modern resolves them from the DriverStore and
// treats a CDDB pci#ven_* entry as a ghost devnode (=> ndis.sys 0xD1).
enum class GuestOsFamily {
    Unknown = 0,  // No version evidence found; behaviour falls back to Legacy
    Legacy  = 1,  // NT 5.x / 6.1 -- CDDB injection required
    Modern  = 2   // NT 6.2+     -- CDDB skipped and purged
};

// Which NIC vendor family is allowed to stay at SERVICE_BOOT_START (Start = 0) while the
// other vendors are demoted to SERVICE_DEMAND_START (Start = 3).
//
// Leaving rt640x64 (Realtek) *and* e1d68x64 (Intel) at Start = 0 at the same time makes
// Windows run DriverEntry + miniport initialization for silicon that is not on the board.
// On the single-vendor ThinkCentre M71s (Realtek RTL8111E) that raised
// STOP 0x0000000A (IRQL_NOT_LESS_OR_EQUAL, Arg1 = 0x8, Arg2 = DISPATCH_LEVEL) at Phase 0.
//
//   Auto    -> decide from the hardware bindings the image itself carries (default)
//   Realtek -> the rt640x64 family stays boot-start, every other NIC vendor is demoted
//   Intel   -> the e1d68x64 family stays boot-start, every other NIC vendor is demoted
//   Multi   -> explicitly multi-NIC: both families keep Start = 0
enum class NicBootProfile {
    Auto = 0,
    Realtek = 1,
    Intel = 2,
    Multi = 3
};

// A NDIS (Class = Net) driver package discovered in
// <Volume>\Windows\System32\DriverStore\FileRepository.
struct NdisPackageInfo {
    std::string package_dir_name;                       // FileRepository folder (e.g. netbcm.inf_amd64_<pfn>)
    std::filesystem::path package_dir;                  // Full folder path
    std::string inf_name;                               // INF the metadata came from (may be empty)
    std::string service_name;                           // AddService name, falling back to the .sys basename
    std::string driver_file;                            // e.g. bnxtre.sys
    std::filesystem::path source_sys;                   // Full path of the .sys inside FileRepository
    std::string image_path;                             // Registry ImagePath (system32\drivers\<drv>)
    std::string group{"NDIS"};                          // Load-order group (INF LoadOrderGroup, else NDIS)
    uint32_t tag{0};                                    // Optional group tag from the INF
    bool has_tag{false};
    std::vector<std::string> hardware_ids;              // Lowercase CDDB keys: pci#ven_xxxx&dev_yyyy
    GuestArch arch{GuestArch::Unknown};                 // Package architecture (_amd64_ / _x86_)
    // The INF also enumerates ROOT\... devices -> software-enumerated (virtual) adapter.
    bool has_root_id{false};
};

struct PnpDriverArmReport {
    bool success{false};
    std::filesystem::path target_path;
    std::string control_set;
    std::vector<std::string> armed_services;     // All services armed (modified + injected)
    std::vector<std::string> modified_services;  // Pre-existing services modified
    std::vector<std::string> injected_services;  // Missing services injected from scratch
    std::vector<std::string> missing_services;   // Any services that could not be armed
    std::vector<std::string> cddb_bindings;      // CriticalDeviceDatabase HW ID -> service bindings injected
    bool boot_flags_armed{false};                // Every network service carries BootFlags = 0x1 (CM_SERVICE_NETWORK_BOOT_LOAD)
    bool iscsi_stack_armed{false};               // msiscsi/Tcpip/ndis are boot-start (msiscsi also BootFlags = 0x1)
    // Boot Stage 15 stability fixes (the ndis.sys 0xD1 source when Windows brings up the
    // Crash Dump stack / paging file on an active iSCSI boot volume).
    // Control\CrashControl: CrashDumpEnabled/LogEvent/SendAlert/AutoReboot = 0 and
    // DisplayParameters = 1 (no dump_ndis / dump_netio, no reboot loop, BSOD prints args).
    bool crash_dump_disabled{false};
    // Session Manager\Memory Management: PagingFiles and ExistingPageFiles emptied
    // (REG_MULTI_SZ "") so nothing pages over the live iSCSI session.
    bool paging_files_cleared{false};
    // Services\Tcpip\Parameters: DisableTaskOffload = 1, EnableRSS = 0, EnableTCPA = 0 --
    // global kernel kill switch for LSO/checksum offload on every NIC.
    bool tcpip_offload_disabled{false};
    // Services\VBoxNetLwf neutralised (Start = 4); true when the filter is absent too.
    bool vbox_lwf_disabled{false};
    // Services\disk\TimeOutValue raised to 60s. The Windows default (10-30s) is shorter
    // than a routine STP reconvergence or an iSCSI retransmit burst on the storage
    // network, and a boot LUN that misses that window is a bugcheck (0x7A
    // KERNEL_DATA_INPAGE_ERROR / 0x7B INACCESSIBLE_BOOT_DEVICE), not a slow disk.
    bool disk_timeout_armed{false};
    // The hive arrived with Primary Sequence Number != Secondary Sequence Number,
    // i.e. Windows left it dirty (Fast Startup / hiberboot or a crash). The arming
    // path forces the header clean again so SYSTEM.LOG1/SYSTEM.LOG2 cannot be
    // replayed over the offline changes during NT kernel hive initialization.
    bool hive_dirty_on_entry{false};
    // True only when the hive actually arrived dirty AND the flush rewrote the
    // header with matching sequence numbers (dirty state neutralised).
    bool hive_cleaned_on_exit{false};
    // Guest OS architecture detected from the mounted volume ("x64" / "x86" / "unknown").
    std::string guest_arch;
    // Guest OS family detected from the target OS version ("legacy" / "modern" / "unknown").
    // Legacy => CDDB hardware ID bindings are written (prevents 0x7B); Modern => CDDB is
    // skipped entirely and any pre-existing pci#ven_* binding is purged (prevents 0xD1).
    std::string guest_os_family;
    // CriticalDeviceDatabase pci#ven_* subkeys deleted because the target is NT 6.2+.
    std::vector<std::string> cddb_purged;
    // NIC boot-start profile that was actually applied ("auto" / "realtek" / "intel" /
    // "multi") -- "auto" reports the concrete profile the bindings resolved to.
    std::string nic_profile;
    // NIC driver services demoted to Start = 3 (SERVICE_DEMAND_START) because their vendor
    // family lost the boot-start election. PnP still starts them on demand; they simply
    // no longer run during Phase 0.
    std::vector<std::string> demoted_services;
    // Services\<Realtek driver>\Parameters blocks purged. The Realtek miniport reads its
    // hardware configuration from Control\Class\{4d36e972-...} only, so a flat Parameters
    // block left behind by an earlier pass is dead weight that DriverEntry may still walk.
    std::vector<std::string> service_parameters_purged;
    // FileRepository package folders harvested as generic NDIS drivers.
    std::vector<std::string> harvested_packages;
    // Driver binaries copied from FileRepository into <Volume>\Windows\System32\drivers.
    std::vector<std::string> staged_binaries;
    std::vector<std::string> warnings;
    std::string message;

    [[nodiscard]] std::string summary() const;
};

// ---- Read-only offline hive inspection (diagnostics) ------------------------------

// Snapshot of one NIC driver service under ControlSet00x\Services\<name>.
struct NicServiceInspection {
    std::string service_name;
    bool present{false};
    int32_t start{-1};                  // Start value, -1 when the value is absent
    std::string group;                  // load-order group ("" when absent)
    uint32_t boot_flags{0};
    bool has_boot_flags{false};
    // The flat Parameters subkey a pre-existing pass may have injected values into.
    bool has_parameters{false};
    std::vector<std::string> parameter_values;  // value names under Parameters
    std::vector<std::string> parameter_subkeys; // subkey names under Parameters
};

// One adapter instance under Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}.
struct NetAdapterInspection {
    std::string subkey;             // "0000"
    std::string driver_desc;
    std::string matching_device_id;
    std::string component_id;
};

// Identity check of a staged .sys against the DriverStore copy it came from.
struct DriverFileInspection {
    std::string service_name;            // "rt640x64"
    std::string driver_file;             // "rt640x64.sys"
    std::filesystem::path deployed;      // <Volume>\Windows\System32\drivers\rt640x64.sys
    bool deployed_present{false};
    std::string deployed_sha256;         // "" when the file is absent/unreadable
    std::string deployed_version;        // "a.b.c.d" from the PE version resource, else ""
    std::filesystem::path source;        // DriverStore\FileRepository copy (may be empty)
    bool source_present{false};
    std::string source_sha256;
    std::string source_version;
    // true only when both files exist and their SHA-256 digests agree.
    bool identical{false};
};

// Structured, read-only diagnostic dump of an offline SYSTEM hive. Nothing here mutates
// the hive: this is the "before" half of the inspect -> fix -> re-inspect workflow.
struct PnpHiveInspectionReport {
    bool success{false};
    std::filesystem::path hive_path;
    std::filesystem::path volume_path;   // "" when the hive was inspected without a volume
    std::string control_set;             // resolved from Select\Current
    std::string guest_os_family;         // "legacy" / "modern" / "unknown"
    std::vector<NicServiceInspection> nic_services;
    std::vector<NetAdapterInspection> net_adapters;
    std::vector<DriverFileInspection> driver_files;
    // Operator-facing bullet lines derived from the snapshot above.
    std::vector<std::string> findings;
    std::string message;

    [[nodiscard]] std::string summary() const;
};

// ---- Offline PE identity: version resource + section table -----------------------

// One Section Table entry of a PE image.
struct PeSection {
    std::string name;            // ".text" (the 8-byte field, NUL-trimmed)
    uint32_t virtual_address{0}; // RVA the section starts at
    uint32_t virtual_size{0};    // VirtualSize   -- bytes once mapped into memory
    uint32_t raw_size{0};        // SizeOfRawData -- bytes occupied on disk
    uint32_t characteristics{0};
};

// VS_VERSION_INFO of an offline PE image. `file_version` / `product_version` come from the
// fixed VS_FIXEDFILEINFO block (the authoritative a.b.c.d numbers); the `*_string` fields
// carry the human-readable StringFileInfo values when the resource ships them. Empty
// strings and valid == false mean the image carries no usable version resource.
struct PeVersionInfo {
    bool valid{false};
    std::string file_version;           // dwFileVersionMS/LS   -> "a.b.c.d"
    std::string product_version;        // dwProductVersionMS/LS -> "a.b.c.d"
    std::string file_version_string;    // StringFileInfo "FileVersion"    ("" if absent)
    std::string product_version_string; // StringFileInfo "ProductVersion" ("" if absent)
};

// ---- Offline driver binary inspection (faulting-RVA triage) ----------------------

// A FileRepository package that could be rolled in as the active <driver_file>.
struct DriverPackageCandidate {
    std::string package_dir_name;       // "netrt640.inf_amd64_<pfn>"
    std::filesystem::path package_dir;
    std::filesystem::path sys_path;     // <pkg>\rt640x64.sys (flat or one level nested)
    std::filesystem::path inf_path;     // the package INF ("" when the INF is absent)
    bool present{false};                // sys_path exists
    std::string file_version;
    std::string product_version;
    std::string sha256;
    uint64_t size{0};
    bool inf_readable{false};
    std::vector<std::string> hardware_ids;  // normalised pci#ven_xxxx&dev_yyyy
    bool supports_target_hw_id{false};      // INF declares PCI\VEN_10EC&DEV_8168
    bool legacy_compatible{false};          // FileVersion < 10.35 (RTL8111E Rev 06 safe)
};

// Identity + section layout of one staged driver binary, plus the answer to the
// incident question: does this RVA land inside .text?
struct DriverBinaryInspection {
    bool success{false};
    std::string driver_file{"rt640x64.sys"};
    std::filesystem::path volume_path;  // "" when the target was not a mountable volume
    std::filesystem::path driver_path;  // <Volume>\Windows\System32\drivers\<driver_file>
    bool present{false};
    bool pe_valid{false};               // MZ / PE\0\0 headers parsed
    uint64_t size{0};
    std::string sha256;
    std::string file_version;           // VS_FIXEDFILEINFO FileVersion
    std::string product_version;        // VS_FIXEDFILEINFO ProductVersion
    std::string file_version_string;    // StringFileInfo FileVersion ("" if absent)
    std::string product_version_string; // StringFileInfo ProductVersion ("" if absent)
    std::vector<PeSection> sections;
    // RVA containment check (the M71s incident offset is 0xE534).
    uint32_t rva{0};
    bool rva_checked{false};
    bool rva_in_text{false};
    std::string rva_section;            // section covering the RVA, "" when none does
    // Candidate DriverStore packages that could replace this binary, plus the verdict
    // on the one that should have been there.
    std::vector<DriverPackageCandidate> candidates;
    std::vector<std::string> findings;  // operator-facing bullet lines
    std::string message;

    [[nodiscard]] std::string summary() const;
};

// ---- DriverStore rollback (legacy RTL8111E restore) ------------------------------

// Result of --restore-inbox-driver: which package was rolled in, what the active binary
// was before, and whether the result still matches the generic Realtek device id.
struct DriverRestoreReport {
    bool success{false};
    std::string driver_file{"rt640x64.sys"};
    std::string target_hw_id;
    std::filesystem::path volume_path;
    std::filesystem::path active_path;
    bool performed{false};              // false = active binary already the chosen package
    std::string selected_package;       // package dir name ("" when nothing was eligible)
    std::filesystem::path restored_from;
    std::filesystem::path backup_path;  // <driver_file>.prev written before the overwrite
    std::string previous_version;
    std::string previous_sha256;
    std::string restored_version;
    std::string restored_sha256;
    bool restored_supports_hw_id{false};     // active binary IS the package declaring it
    bool restored_is_legacy_compatible{false};
    std::vector<DriverPackageCandidate> candidates;
    std::vector<std::string> warnings;
    std::string message;

    [[nodiscard]] std::string summary() const;
};

class PnpDriverArmer {
public:
    // List of critical boot storage & network services to arm for diskless boot
    static const std::vector<std::string>& critical_boot_services();

    // List of critical boot NIC driver binaries to stage
    static const std::vector<std::string>& critical_boot_drivers();

    // Stage critical boot NIC drivers into <system32_dir>\drivers
    static bool stage_critical_boot_drivers(
        const std::filesystem::path& system32_dir,
        std::vector<std::string>& warnings
    );

    // High-level automated inspection and arming for a VHD image
    static Result<PnpDriverArmReport> arm_vhd_image(
        const std::filesystem::path& vhd_path,
        NicBootProfile profile = NicBootProfile::Auto
    );

    // Direct offline hive file parsing & arming (operates on \Windows\System32\config\SYSTEM)
    static Result<PnpDriverArmReport> arm_offline_system_hive(
        const std::filesystem::path& hive_path,
        NicBootProfile profile = NicBootProfile::Auto
    );

    // Direct in-memory binary regf hive parsing & arming.
    // `harvested` carries the NDIS packages discovered by harvest_ndis_packages() so every
    // discovered vendor driver gets boot-started, anti-flap parameters and a CDDB binding.
    // `os_family` is the guest OS family already resolved from the mounted volume (ntoskrnl /
    // SOFTWARE hive); pass Unknown to derive it from the version values inside this hive.
    // `profile` decides which NIC vendor family keeps Start = 0 (see NicBootProfile).
    static Result<PnpDriverArmReport> arm_hive_buffer(
        std::vector<uint8_t>& hive_data,
        const std::vector<NdisPackageInfo>& harvested = {},
        GuestOsFamily os_family = GuestOsFamily::Unknown,
        NicBootProfile profile = NicBootProfile::Auto
    );

    // ---- NT volume namespace (`\\?\Volume{GUID}\`) resolution -------------------------
    // Extracts the `\\?\Volume{...}` root a path lives under ("" when the path is not an
    // NT volume-namespace path). Pure parsing: no filesystem access, so a caller can tell
    // "this is a mounted-volume path" apart from "this is a plain directory tree".
    static std::filesystem::path nt_volume_guid_root(const std::filesystem::path& hive_path);

    // Resolves the volume that owns a SYSTEM hive: the `\\?\Volume{...}` root for a
    // mounted-volume path (validated against `<root>\Windows`), otherwise the closest
    // ancestor holding a Windows tree. Returns "" when no volume root can be resolved --
    // never a wrong-but-non-empty root, which would silently disable the NDIS harvest and
    // OS-family detection for the whole pass.
    static std::filesystem::path volume_root_from_hive(const std::filesystem::path& hive_path);

    // ---- NIC boot-start profile ----------------------------------------------------
    // "auto" / "realtek" / "intel" / "multi" label for PnpDriverArmReport::nic_profile.
    static std::string nic_profile_name(NicBootProfile profile);

    // Parses a CLI --nic-profile argument. Returns false (and leaves *ok == false) on an
    // unrecognised value; `ok` may be nullptr when the caller does not care.
    static NicBootProfile parse_nic_profile(const std::string& text, bool* ok = nullptr);

    // True for every Realtek miniport service the armer knows about (rt640x64, ...).
    static bool is_realtek_service_name(const std::string& service_name);

    // True for every Intel miniport service the armer knows about (e1d68x64, ...).
    static bool is_intel_service_name(const std::string& service_name);

    // Decides the boot-start profile from the evidence the image itself carries: the
    // adapter instances under Control\Class\{4d36e972-...} first, then the harvested
    // DriverStore packages. Returns NicBootProfile::Multi when both vendor families are
    // bound (or when the image carries no vendor evidence at all -- see the warning on
    // PnpDriverArmReport::warnings -- because demoting on absent evidence risks a 0x7B
    // with nothing to diagnose).
    static NicBootProfile detect_nic_boot_profile(
        const std::vector<uint8_t>& hive_data,
        const std::vector<NdisPackageInfo>& harvested = {},
        const std::string& control_set = ""
    );

    // ---- Offline hive inspection (read-only diagnostics) ---------------------------
    // Dumps Services\<nic>\Start + Parameters, the net-class adapter bindings and the
    // SHA-256/PE-version identity of the staged .sys vs its DriverStore source.
    // `volume_path` is the mounted volume root (used to locate System32\drivers and
    // DriverStore\FileRepository); pass "" to skip the file-identity half.
    static Result<PnpHiveInspectionReport> inspect_hive_buffer(
        const std::vector<uint8_t>& hive_data,
        const std::filesystem::path& hive_path = {},
        const std::filesystem::path& volume_path = {}
    );

    // Same, reading the hive from disk first.
    static Result<PnpHiveInspectionReport> inspect_offline_hive(
        const std::filesystem::path& hive_path,
        const std::filesystem::path& volume_path = {}
    );

    // Same, for a target image: a raw SYSTEM hive, a mounted volume/Windows directory or
    // a .vhd/.vhdx (attached read/write through the VirtDisk API, then detached).
    static Result<PnpHiveInspectionReport> inspect_vhd_image(
        const std::filesystem::path& image_path
    );

    // ---- Self-healing re-arm --------------------------------------------------------
    // Demotes the losing NIC vendor family to Start = 3, verifies the selected primary is
    // Start = 0 with Group = "NDIS", purges Services\<Realtek driver>\Parameters and
    // flushes the hive with synchronized sequence numbers and truncated .LOG1/.LOG2.
    static Result<PnpDriverArmReport> fix_boot_conflicts_offline_hive(
        const std::filesystem::path& hive_path,
        NicBootProfile profile = NicBootProfile::Realtek
    );

    // ---- Offline PE identity -------------------------------------------------------
    // Pure parsers over an image already in memory (unit-test friendly) and file wrappers.
    static PeVersionInfo parse_pe_version_info(const std::vector<uint8_t>& bytes);
    static PeVersionInfo read_pe_version_info(const std::filesystem::path& path);
    static std::vector<PeSection> parse_pe_sections(const std::vector<uint8_t>& bytes);
    static std::vector<PeSection> read_pe_sections(const std::filesystem::path& path);

    // Index of the section whose mapped range covers `rva`, or -1 when no section does.
    static int find_section_index_for_rva(const std::vector<PeSection>& sections, uint32_t rva);

    // "PCI\VEN_10EC&DEV_8168" -> "pci#ven_10ec&dev_8168" (the form extract_pci_hardware_ids
    // and CriticalDeviceDatabase bindings use), so CLI input and INF output compare equal.
    static std::string normalize_hardware_id(const std::string& hardware_id);

    // Generic Realtek PCIe GbE device id shared by RTL8111E / RTL8111H / RTL8168 silicon.
    static std::string generic_realtek_gbe_hw_id();

    // True for the Realtek driver lineages that still initialise RTL8111E Rev 06 PHYs.
    // Everything strictly below 10.35 (the 9.1.408.x and 10.1.x inbox/OEM builds) counts;
    // an unparseable/empty version returns false -- unknown versions are never assumed safe.
    static bool legacy_compatible_driver_version(const std::string& file_version);

    // ---- Faulting driver triage ----------------------------------------------------
    // Identity + section layout of <image_or_volume>\Windows\System32\drivers\<driver_file>
    // together with the RVA containment answer. `image_or_volume` may be a volume root, a
    // Windows/System32/drivers directory, the .sys itself, a SYSTEM hive, or a .vhd/.vhdx
    // (attached through the shared MountedVhdVolume helper, detached on return).
    // The default rva is the M71s stop 0xA offset (0xE534).
    static Result<DriverBinaryInspection> inspect_driver_binary(
        const std::filesystem::path& image_or_volume,
        uint32_t rva = 0xE534,
        const std::string& driver_file = "rt640x64.sys"
    );

    // ---- DriverStore rollback (legacy RTL8111E restore) ----------------------------
    // FileRepository packages matching netrt640*.inf_* (plus the Windows inbox alias
    // netrtl8168*.inf_*) that carry <driver_file>, each with its version, hash and the
    // hardware ids declared by its INF.
    static std::vector<DriverPackageCandidate> scan_driver_packages(
        const std::filesystem::path& volume_path,
        const std::string& driver_file = "rt640x64.sys",
        const std::string& target_hw_id = ""
    );

    // Policy used when targeting legacy hardware revisions: among packages that are present
    // and declare `target_hw_id`, prefer legacy-compatible builds (FileVersion < 10.35) and
    // then the oldest of those; ties break on sha256 then package name so the answer never
    // depends on directory iteration order. Returns false + a human reason when nothing
    // qualifies.
    static bool select_driver_rollback_candidate(
        const std::vector<DriverPackageCandidate>& candidates,
        const std::string& target_hw_id,
        size_t* chosen_index,
        std::string* reason
    );

    // Replaces <image_or_volume>\Windows\System32\drivers\<driver_file> with the selected
    // legacy DriverStore package. This is the ONLY code path allowed to overwrite an
    // existing staged .sys: the current binary is saved to <driver_file>.prev before the
    // copy, and the post-condition (hash equality + INF hardware id) is re-verified from
    // disk before `success` is set.
    static Result<DriverRestoreReport> restore_inbox_driver(
        const std::filesystem::path& image_or_volume,
        const std::string& driver_file = "rt640x64.sys",
        const std::string& target_hw_id = ""
    );

    // SHA-256 of a memory block / file as lowercase hex ("" when the file is unreadable).
    static std::string sha256_hex(const uint8_t* data, size_t length);
    static std::string sha256_file(const std::filesystem::path& path);

    // ---- Guest architecture detection ---------------------------------------------
    // "x64" / "x86" / "unknown" label for PnpDriverArmReport::guest_arch
    static std::string arch_name(GuestArch arch);

    // Pure PE Machine field classifier (IMAGE_FILE_MACHINE_AMD64 / _I386)
    static GuestArch classify_pe_machine(uint16_t machine);

    // Pure volume-layout classifier: a 64-bit guest always carries Windows\SysWOW64,
    // which is the primary signal; the PE Machine field of ntoskrnl.exe is the fallback.
    static GuestArch classify_volume_layout(bool has_syswow64, GuestArch pe_machine);

    // Detect the guest architecture of a mounted volume (accepts either the volume root
    // or the \Windows directory).
    static GuestArch detect_guest_arch(const std::filesystem::path& volume_path);

    // ---- Guest OS family (Legacy NT5/6.1 vs Modern NT6.2+) detection ---------------
    // "legacy" / "modern" / "unknown" label for PnpDriverArmReport::guest_os_family.
    static std::string os_family_name(GuestOsFamily family);

    // Pure OS version classifier. Any argument may be 0 to mean "no evidence"; build
    // numbers are only consulted when the major/minor pair cannot decide on its own.
    // NT 5.x / 6.0 / 6.1 => Legacy, NT 6.2+ (build 9200 and up) => Modern.
    static GuestOsFamily classify_os_version(uint32_t major, uint32_t minor, uint32_t build);

    // Read version evidence out of an already-loaded SYSTEM / SOFTWARE hive WITHOUT
    // modifying it: ControlSet00x\Control\Windows first, then the hive root path
    // Microsoft\Windows NT\CurrentVersion (which is what the SOFTWARE hive carries).
    // `control_set` picks the active ControlSet; when empty it is resolved via Select\Current.
    static GuestOsFamily detect_os_family_from_hive(
        const std::vector<uint8_t>& hive_data,
        const std::string& control_set = ""
    );

    // VS_FIXEDFILEINFO version resource of an offline kernel image (ntoskrnl.exe).
    static GuestOsFamily detect_os_family_from_kernel(const std::filesystem::path& kernel_path);

    // Offline guest OS family of a mounted volume (accepts either the volume root or the
    // \Windows directory): SYSTEM hive, then SOFTWARE hive, then ntoskrnl.exe.
    static GuestOsFamily detect_guest_os_family(const std::filesystem::path& volume_path);

    // ---- Universal NDIS (Class = Net) driver harvester ------------------------------
    // Scan <Volume>\Windows\System32\DriverStore\FileRepository for network driver
    // packages, filtered by Class = Net / ClassGuid and by guest architecture.
    static std::vector<NdisPackageInfo> harvest_ndis_packages(
        const std::filesystem::path& volume_path,
        std::vector<std::string>* warnings = nullptr
    );

    // Copy every harvested .sys into <system32_dir>\drivers (CopyFileW on Windows).
    // A driver binary that already exists on the guest disk is NEVER overwritten: the
    // pre-installed inbox binary is known to boot, an inbox DriverStore copy is not.
    static bool stage_harvested_drivers(
        const std::filesystem::path& system32_dir,
        const std::vector<NdisPackageInfo>& packages,
        std::vector<std::string>& warnings,
        std::vector<std::string>* staged_out = nullptr
    );

    // ---- Virtual / software adapter blacklist ---------------------------------------
    // True when an adapter/service/package name is a virtual or software-only NIC
    // (VBoxNetAdp, vmnet*, TAP/TUN, OpenVPN, NDISWAN, rasman, ROOT\* devices). Those
    // must never become boot-start drivers: they have no PCI function behind them, so
    // Start = 0 / CriticalDeviceDatabase bindings on them only add a Phase 0 failure.
    static bool is_virtual_adapter_name(const std::string& adapter_name);

    // Physical-hardware gate applied to every harvested package: it must carry PCI
    // VEN/DEV hardware IDs, must not be ROOT\ software-enumerated, and must not match
    // the virtual adapter blacklist above.
    static bool is_physical_ndis_package(const NdisPackageInfo& package);

    // Loaded registry key arming via Windows Registry API or PowerShell (e.g. HKLM\CobDiskless_SYSTEM)
    static Result<PnpDriverArmReport> arm_loaded_registry_key(
        const std::string& subkey_path,
        NicBootProfile profile = NicBootProfile::Auto
    );

    // Ensure an image is armed before iSCSI mounts or serves blocks
    static Result<PnpDriverArmReport> ensure_image_armed(const std::filesystem::path& image_path);

    // Verify or stage driver binary (.sys) in image \Windows\System32\drivers directory.
    // When the binary is already present on the guest disk it is accepted as-is and the
    // copy step is skipped -- an existing, working driver is never overwritten.
    static bool verify_or_stage_driver_file(
        const std::filesystem::path& drivers_dir,
        const std::string& driver_file,
        std::vector<std::string>& warnings
    );

    struct SyntheticNetAdapter {
        std::string subkey_name{"0000"};
        std::string driver_desc;
        std::string matching_device_id;
        std::string component_id;
        // Advanced properties this synthetic miniport declares under
        // <subkey_name>\Ndi\params\<ParamName>. PnpDriverArmer only injects an anti-flap
        // parameter that appears here, so a test can model both a driver that advertises
        // *EEE and one whose older PHY silicon does not (RTL8111E Rev 06). Empty means the
        // adapter carries no Ndi\params schema at all.
        std::vector<std::string> ndi_params;
        // The miniport service the adapter bound to (the instance's "Service" value), e.g.
        // "rt640x64". Exact family evidence for the profile election that needs no
        // DriverDesc/MatchingDeviceId spelling at all. Empty = the value is not seeded.
        std::string service{};
    };

    // Helper for offline tooling and unit testing: create a minimal valid synthetic SYSTEM hive.
    // `current_version` ("6.1" = Win7, "10.0" = Win10/11, empty = no version evidence) seeds the
    // OS version in both places the offline detector looks: ControlSet00x\Control\Windows and the
    // Microsoft\Windows NT\CurrentVersion root path the SOFTWARE hive carries -- so one synthetic
    // hive can stand in for either file.
    //
    // A value that lives under a service's own flat Parameters subkey. `service_parameters` seeds
    // that key before the hive is handed to anything, which is how a test reproduces the state a
    // previous armer pass left behind under Services\rt640x64\Parameters (the key the Realtek
    // miniport never reads, and which the current pass is supposed to purge).
    struct SyntheticServiceParameter {
        std::string service;   // e.g. "rt640x64"
        std::string name;      // e.g. "*EEE"
        bool is_dword{true};
        uint32_t dword{0};
        std::string text;      // used when is_dword == false (REG_SZ)
    };

    // `pci_devnode_ids` optionally seeds Enum\PCI\<id> hardware IDs at the hive root
    // (e.g. "VEN_8086&DEV_1C5A", the Intel H61 chipset functions). Those are parent PCI
    // devnodes for devices that are NOT network adapters; the profile election must never
    // read them, and a test seeds them to prove it does not.
    static std::vector<uint8_t> create_synthetic_system_hive(
        uint32_t current_control_set,
        const std::vector<std::pair<std::string, uint32_t>>& services_with_initial_start,
        const std::vector<SyntheticNetAdapter>& net_adapters = {},
        const std::string& current_version = "",
        const std::vector<SyntheticServiceParameter>& service_parameters = {},
        const std::vector<std::string>& pci_devnode_ids = {}
    );

    // Helper: calculate 32-bit XOR checksum of the first 508 bytes (127 DWORDs) of a regf header
    static uint32_t calculate_regf_header_checksum(const uint8_t* header_bytes);
};

} // namespace cobdiskless
