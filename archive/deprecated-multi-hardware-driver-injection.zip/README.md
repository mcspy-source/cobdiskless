﻿# Archived: cross-hardware driver injection pipeline

Frozen copy of the code removed by the "Deprecate Cross-Hardware Driver Injection"
pivot (2026-09-26), kept so the old behaviour can be recovered if the pivot is ever
reverted.  The live tree no longer contains any of this.

## What was archived

* `pnp_driver_armer.cpp` / `pnp_driver_armer.hpp`
    * vendor profile election (`NicBootProfile`, `elect_nic_boot_profile`,
      `elect_tier_a_profile`, `detect_nic_boot_profile`)
    * the `Control\CobDiskless\NicBootProfile` pin (write / read / stale-pin eviction)
    * service demotion (`Start = 3`, `BootFlags = 0`) for the "losing" NIC family
    * CDDB cross-bindings (`Control\CriticalDeviceDatabase` vendor injections)
    * DriverStore / host-depot / `System32\drivers` harvesting and `.sys` staging
      (`harvest_ndis_packages`, `stage_harvested_drivers`,
      `stage_critical_boot_drivers`, `verify_or_stage_driver_file`)
    * schema-gated NDIS "anti-flap" and offload REG_SZ injection
      (`*EEE`, `*GreenEthernet`, `PnPCapabilities`, `*LsoV2*`, `*ChecksumOffload*`)
    * DriverStore rollback (`restore_inbox_driver`, `scan_driver_packages`,
      `select_driver_rollback_candidate`, `inspect_driver_binary`)
    * `--fix-boot-conflicts` / `--inspect-driver` support
* `cob_armer_main.cpp`  - CLI flags `--nic-profile`, `--fix-boot-conflicts`,
  `--inspect-driver`, `--restore-inbox-driver`
* `admin_app.cpp`       - `nic_profile_for()` config plumbing
* `tests/core_test.cpp` - the suites that asserted the removed behaviour
  (demotion, CDDB injection, harvesting, vendor election, pin eviction, rollback)

## What the live tree does instead (100% native VHD)

The armer only flips registry flags on an image already captured from the target
machine:

    Net class instance `Service`  -> Start = 0, BootFlags = 0x1
    Services\msiscsi              -> Start = 0, BootFlags = 0x1
    Services\Tcpip                -> Start = 0
    Services\ndis                 -> Start = 0
    Services\iscsiprt (if present)-> Start = 0
    Services\disk\TimeOutValue    -> 60      (REG_DWORD)
    Tcpip\Parameters\DisableTaskOffload -> 1 (REG_DWORD)
    Stage 15                      -> crash dump stack cleared, PagingFiles cleared

No `.sys` is ever copied, no CDDB entry is ever written, no service is ever
demoted, no vendor profile is ever elected.
