#include "CobDisklessCore/image/pnp_driver_armer.hpp"
#include "CobDisklessCore/logging/logger.hpp"
#include <cstring>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <iostream>
#include <functional>
#include <memory>

#include <cstdio>
#include <stdio.h>

#if defined(_MSC_VER)
#define POPEN_FUNC _popen
#define PCLOSE_FUNC _pclose
#else
extern "C" FILE* popen(const char* command, const char* mode);
extern "C" int pclose(FILE* stream);
#define POPEN_FUNC popen
#define PCLOSE_FUNC pclose
#endif

#include <thread>
#include <chrono>

#if defined(_WIN32) || defined(__CYGWIN__) || defined(__MSYS__)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#include <windows.h>
#include <virtdisk.h>
#include <winioctl.h>
#if defined(__CYGWIN__) || defined(__MSYS__)
#include <sys/cygwin.h>
#endif
// The Windows SDK exports these as object-like macros (winsvc.h / cfgmgr32.h). This
// translation unit defines strongly typed equivalents below with the same values, so the
// macros are dropped here to keep the constexpr declarations (and their uses) intact.
#undef SERVICE_ERROR_NORMAL
#undef CM_SERVICE_NETWORK_BOOT_LOAD
#endif

namespace cobdiskless {

namespace {

struct DirEntryInfo {
    std::filesystem::path path;
    std::string filename;
    bool is_directory{false};
};

#if defined(_WIN32) || defined(__CYGWIN__) || defined(__MSYS__)
// Microsoft Vendor GUID for Virtual Storage: EC984AEC-A0F9-47E9-901F-71415A66345B
static const GUID VIRTUAL_STORAGE_TYPE_VENDOR_MICROSOFT_VAL = {
    0xEC984AEC, 0xA0F9, 0x47e9, { 0x90, 0x1F, 0x71, 0x41, 0x5A, 0x66, 0x34, 0x5B }
};

static void enable_token_privilege(LPCWSTR priv_name) {
    HANDLE hToken = NULL;
    if (OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken)) {
        LUID luid;
        if (LookupPrivilegeValueW(NULL, priv_name, &luid)) {
            TOKEN_PRIVILEGES tp{};
            tp.PrivilegeCount = 1;
            tp.Privileges[0].Luid = luid;
            tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
            AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(tp), NULL, NULL);
        }
        CloseHandle(hToken);
    }
}

static std::wstring to_native_win_path(const std::filesystem::path& p) {
    std::wstring direct = p.wstring();
    // `\\?\` / `\\.\` extended paths are already Win32-canonical, but
    // std::filesystem::path on this toolchain (MSYS2/Cygwin libstdc++) uses POSIX separator
    // rules, so every join it performs appends '/'. cygwin_conv_path() cannot parse an
    // extended path either, and Win32 stops translating '/' -> '\' the moment `\\?\` is
    // present -- which is exactly how a `\\?\Volume{GUID}\Windows/System32` probe came back
    // "does not exist" and silently disabled the NDIS harvest. Normalize here, once.
    if (direct.rfind(L"\\\\?\\", 0) == 0 || direct.rfind(L"\\\\.\\", 0) == 0) {
        for (wchar_t& ch : direct) {
            if (ch == L'/') ch = L'\\';
        }
        return direct;
    }
#if defined(__CYGWIN__) || defined(__MSYS__)
    std::string posix_path = p.string();
    const ssize_t size = ::cygwin_conv_path(CCP_POSIX_TO_WIN_W, posix_path.c_str(), nullptr, 0);
    if (size > 0 && static_cast<size_t>(size) >= sizeof(wchar_t)) {
        std::wstring out(size / sizeof(wchar_t), L'\0');
        if (::cygwin_conv_path(CCP_POSIX_TO_WIN_W, posix_path.c_str(), out.data(), size) >= 0) {
            while (!out.empty() && out.back() == L'\0') {
                out.pop_back();
            }
            return out;
        }
    }
#endif
    return direct;
}

static Result<std::vector<uint8_t>> read_hive_file(const std::filesystem::path& path) {
    const std::wstring wpath = to_native_win_path(path);
    HANDLE hFile = CreateFileW(wpath.c_str(), GENERIC_READ,
                               FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                               NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile != INVALID_HANDLE_VALUE) {
        LARGE_INTEGER fsz;
        if (GetFileSizeEx(hFile, &fsz)) {
            if (fsz.QuadPart < 8192) {
                CloseHandle(hFile);
                return Error(ErrorCode::InvalidConfiguration, "SYSTEM hive file is too small (" + std::to_string(fsz.QuadPart) + " bytes)");
            }
            std::vector<uint8_t> buffer(static_cast<size_t>(fsz.QuadPart));
            DWORD bytesRead = 0;
            DWORD toRead = static_cast<DWORD>(fsz.QuadPart);
            if (ReadFile(hFile, buffer.data(), toRead, &bytesRead, NULL) && bytesRead == toRead) {
                CloseHandle(hFile);
                return buffer;
            }
        }
        CloseHandle(hFile);
    }

    // Fallback to std::ifstream
    std::error_code ec;
    if (!std::filesystem::exists(path, ec) || !std::filesystem::is_regular_file(path, ec)) {
        return Error(ErrorCode::StorageFailure, "SYSTEM hive file not found: " + path.string());
    }
    uint64_t fsize = std::filesystem::file_size(path, ec);
    if (fsize < 8192) {
        return Error(ErrorCode::InvalidConfiguration, "SYSTEM hive file is too small (" + std::to_string(fsize) + " bytes)");
    }
    std::ifstream in(path, std::ios::binary);
    if (!in.is_open()) {
        return Error(ErrorCode::StorageFailure, "Failed to open SYSTEM hive for reading: " + path.string());
    }
    std::vector<uint8_t> buffer(static_cast<size_t>(fsize));
    in.read(reinterpret_cast<char*>(buffer.data()), static_cast<std::streamsize>(fsize));
    return buffer;
}

static Result<void> write_hive_file(const std::filesystem::path& path, const std::vector<uint8_t>& buffer) {
    const std::wstring wpath = to_native_win_path(path);
    HANDLE hFile = CreateFileW(wpath.c_str(), GENERIC_WRITE,
                               FILE_SHARE_READ,
                               NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile != INVALID_HANDLE_VALUE) {
        DWORD bytesWritten = 0;
        BOOL ok = WriteFile(hFile, buffer.data(), static_cast<DWORD>(buffer.size()), &bytesWritten, NULL);
        FlushFileBuffers(hFile);
        CloseHandle(hFile);
        if (ok && bytesWritten == buffer.size()) {
            return {};
        }
        return Error(ErrorCode::StorageFailure, "Failed to write complete SYSTEM hive to: " + path.string());
    }

    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    if (!out.is_open()) {
        return Error(ErrorCode::StorageFailure, "Failed to open SYSTEM hive for writing: " + path.string());
    }
    out.write(reinterpret_cast<const char*>(buffer.data()), static_cast<std::streamsize>(buffer.size()));
    out.flush();
    return {};
}

static bool path_exists_win32_or_std(const std::filesystem::path& p) {
    const std::wstring wpath = to_native_win_path(p);
    DWORD attr = GetFileAttributesW(wpath.c_str());
    if (attr != INVALID_FILE_ATTRIBUTES) {
        return true;
    }
    std::error_code ec;
    return std::filesystem::exists(p, ec);
}

static bool dir_exists_win32_or_std(const std::filesystem::path& p) {
    const std::wstring wpath = to_native_win_path(p);
    DWORD attr = GetFileAttributesW(wpath.c_str());
    if (attr != INVALID_FILE_ATTRIBUTES) {
        return (attr & FILE_ATTRIBUTE_DIRECTORY) != 0;
    }
    std::error_code ec;
    return std::filesystem::is_directory(p, ec);
}

static bool file_exists_win32_or_std(const std::filesystem::path& p) {
    const std::wstring wpath = to_native_win_path(p);
    DWORD attr = GetFileAttributesW(wpath.c_str());
    if (attr != INVALID_FILE_ATTRIBUTES) {
        return (attr & FILE_ATTRIBUTE_DIRECTORY) == 0;
    }
    std::error_code ec;
    return std::filesystem::is_regular_file(p, ec);
}

static bool ensure_directory_win32_or_std(const std::filesystem::path& dir) {
    if (dir_exists_win32_or_std(dir)) return true;
    const std::wstring wdir = to_native_win_path(dir);
    auto parent = dir.parent_path();
    if (!parent.empty() && parent != dir && !dir_exists_win32_or_std(parent)) {
        ensure_directory_win32_or_std(parent);
    }
    if (CreateDirectoryW(wdir.c_str(), NULL) || GetLastError() == ERROR_ALREADY_EXISTS) {
        return true;
    }
    std::error_code ec;
    std::filesystem::create_directories(dir, ec);
    return dir_exists_win32_or_std(dir);
}

static bool copy_file_win32_or_std(const std::filesystem::path& src, const std::filesystem::path& dst,
                                   bool overwrite_existing = true) {
    // Safe staging contract: a driver binary that already exists on the guest disk was
    // installed by the image itself and is known to boot, so it is kept as-is rather
    // than replaced with an inbox DriverStore copy that may not match the hardware.
    if (!overwrite_existing && file_exists_win32_or_std(dst)) return true;

    auto dst_parent = dst.parent_path();
    if (!dst_parent.empty() && !dir_exists_win32_or_std(dst_parent)) {
        ensure_directory_win32_or_std(dst_parent);
    }
    const std::wstring wsrc = to_native_win_path(src);
    const std::wstring wdst = to_native_win_path(dst);
    // bFailIfExists = TRUE whenever we are in "never overwrite" mode.
    if (CopyFileW(wsrc.c_str(), wdst.c_str(), overwrite_existing ? FALSE : TRUE)) {
        return true;
    }
    if (!overwrite_existing && file_exists_win32_or_std(dst)) return true; // lost a creation race
    std::error_code ec;
    std::filesystem::copy_file(src, dst,
                               overwrite_existing
                                   ? std::filesystem::copy_options::overwrite_existing
                                   : std::filesystem::copy_options::skip_existing,
                               ec);
    return !ec;
}

static std::vector<DirEntryInfo> list_directory_entries(const std::filesystem::path& dir_path) {
    std::vector<DirEntryInfo> entries;
    std::wstring search_pattern = to_native_win_path(dir_path);
    if (!search_pattern.empty() && search_pattern.back() != L'\\' && search_pattern.back() != L'/') {
        search_pattern += L"\\*";
    } else {
        search_pattern += L"*";
    }

    WIN32_FIND_DATAW fd{};
    HANDLE hFind = FindFirstFileW(search_pattern.c_str(), &fd);
    if (hFind != INVALID_HANDLE_VALUE) {
        do {
            if (std::wcscmp(fd.cFileName, L".") == 0 || std::wcscmp(fd.cFileName, L"..") == 0) {
                continue;
            }
            int utf8_len = WideCharToMultiByte(CP_UTF8, 0, fd.cFileName, -1, NULL, 0, NULL, NULL);
            std::string name_utf8;
            if (utf8_len > 1) {
                name_utf8.resize(utf8_len - 1);
                WideCharToMultiByte(CP_UTF8, 0, fd.cFileName, -1, name_utf8.data(), utf8_len, NULL, NULL);
            }
            DirEntryInfo entry;
            entry.path = dir_path / (name_utf8.empty() ? std::filesystem::path(fd.cFileName) : std::filesystem::path(name_utf8));
            entry.filename = name_utf8;
            entry.is_directory = (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0;
            entries.push_back(std::move(entry));
        } while (FindNextFileW(hFind, &fd));
        FindClose(hFind);
        return entries;
    }
    std::error_code ec;
    for (const auto& item : std::filesystem::directory_iterator(dir_path, ec)) {
        DirEntryInfo entry;
        entry.path = item.path();
        entry.filename = item.path().filename().string();
        entry.is_directory = item.is_directory(ec);
        entries.push_back(std::move(entry));
    }
    return entries;
}
#else
static Result<std::vector<uint8_t>> read_hive_file(const std::filesystem::path& path) {
    std::error_code ec;
    if (!std::filesystem::exists(path, ec) || !std::filesystem::is_regular_file(path, ec)) {
        return Error(ErrorCode::StorageFailure, "SYSTEM hive file not found: " + path.string());
    }
    uint64_t fsize = std::filesystem::file_size(path, ec);
    if (fsize < 8192) {
        return Error(ErrorCode::InvalidConfiguration, "SYSTEM hive file is too small (" + std::to_string(fsize) + " bytes)");
    }
    std::ifstream in(path, std::ios::binary);
    if (!in.is_open()) {
        return Error(ErrorCode::StorageFailure, "Failed to open SYSTEM hive for reading: " + path.string());
    }
    std::vector<uint8_t> buffer(static_cast<size_t>(fsize));
    in.read(reinterpret_cast<char*>(buffer.data()), static_cast<std::streamsize>(fsize));
    return buffer;
}

static Result<void> write_hive_file(const std::filesystem::path& path, const std::vector<uint8_t>& buffer) {
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    if (!out.is_open()) {
        return Error(ErrorCode::StorageFailure, "Failed to open SYSTEM hive for writing: " + path.string());
    }
    out.write(reinterpret_cast<const char*>(buffer.data()), static_cast<std::streamsize>(buffer.size()));
    out.flush();
    return {};
}

static bool path_exists_win32_or_std(const std::filesystem::path& p) {
    std::error_code ec;
    return std::filesystem::exists(p, ec);
}
static bool dir_exists_win32_or_std(const std::filesystem::path& p) {
    std::error_code ec;
    return std::filesystem::is_directory(p, ec);
}
static bool file_exists_win32_or_std(const std::filesystem::path& p) {
    std::error_code ec;
    return std::filesystem::is_regular_file(p, ec);
}
static bool ensure_directory_win32_or_std(const std::filesystem::path& dir) {
    std::error_code ec;
    std::filesystem::create_directories(dir, ec);
    return std::filesystem::is_directory(dir, ec);
}
static bool copy_file_win32_or_std(const std::filesystem::path& src, const std::filesystem::path& dst,
                                   bool overwrite_existing = true) {
    // Never replace a driver binary the guest image already has (see the Windows branch).
    if (!overwrite_existing && file_exists_win32_or_std(dst)) return true;
    auto dst_parent = dst.parent_path();
    if (!dst_parent.empty()) {
        ensure_directory_win32_or_std(dst_parent);
    }
    std::error_code ec;
    std::filesystem::copy_file(src, dst,
                               overwrite_existing
                                   ? std::filesystem::copy_options::overwrite_existing
                                   : std::filesystem::copy_options::skip_existing,
                               ec);
    return !ec;
}
static std::vector<DirEntryInfo> list_directory_entries(const std::filesystem::path& dir_path) {
    std::vector<DirEntryInfo> entries;
    std::error_code ec;
    for (const auto& item : std::filesystem::directory_iterator(dir_path, ec)) {
        DirEntryInfo entry;
        entry.path = item.path();
        entry.filename = item.path().filename().string();
        entry.is_directory = item.is_directory(ec);
        entries.push_back(std::move(entry));
    }
    return entries;
}
#endif

inline uint16_t read_le16(const uint8_t* p) noexcept {
    return static_cast<uint16_t>(p[0] | (static_cast<uint16_t>(p[1]) << 8));
}

inline uint32_t read_le32(const uint8_t* p) noexcept {
    return static_cast<uint32_t>(p[0]) |
          (static_cast<uint32_t>(p[1]) << 8) |
          (static_cast<uint32_t>(p[2]) << 16) |
          (static_cast<uint32_t>(p[3]) << 24);
}

inline void write_le16(uint8_t* p, uint16_t val) noexcept {
    p[0] = static_cast<uint8_t>(val & 0xFF);
    p[1] = static_cast<uint8_t>((val >> 8) & 0xFF);
}

inline void write_le32(uint8_t* p, uint32_t val) noexcept {
    p[0] = static_cast<uint8_t>(val & 0xFF);
    p[1] = static_cast<uint8_t>((val >> 8) & 0xFF);
    p[2] = static_cast<uint8_t>((val >> 16) & 0xFF);
    p[3] = static_cast<uint8_t>((val >> 24) & 0xFF);
}

bool string_iequal(std::string_view a, std::string_view b) noexcept {
    if (a.size() != b.size()) return false;
    for (size_t i = 0; i < a.size(); ++i) {
        if (std::tolower(static_cast<unsigned char>(a[i])) !=
            std::tolower(static_cast<unsigned char>(b[i]))) {
            return false;
        }
    }
    return true;
}

bool is_realtek_string(std::string_view str) noexcept {
    if (str.empty()) return false;
    std::string s(str);
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
    return s.find("realtek") != std::string::npos ||
           s.find("rt640") != std::string::npos ||
           s.find("rtump") != std::string::npos ||
           s.find("rtux") != std::string::npos ||
           s.find("10ec") != std::string::npos;
}

bool string_contains_ci(std::string_view haystack, std::string_view needle) noexcept {
    if (needle.empty()) return true;
    if (haystack.size() < needle.size()) return false;
    auto it = std::search(
        haystack.begin(), haystack.end(),
        needle.begin(), needle.end(),
        [](char ch1, char ch2) {
            return std::tolower(static_cast<unsigned char>(ch1)) ==
                   std::tolower(static_cast<unsigned char>(ch2));
        }
    );
    return it != haystack.end();
}

// Realtek Anti-Flap parameters to inject into adapter instance keys under
// Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}\<instance> and
// Services\rt640x64\Parameters.
// Realtek PHYs perform a hardware soft-reset (~500ms carrier drop) during Phase 0
// when Energy Efficient Ethernet (EEE), Green Ethernet, GigaLite, PowerSavingMode,
// FlowControl, or InterruptModeration are enabled, causing NDIS_STATUS_MEDIA_DISCONNECT
// right as msiscsi initializes (resulting in 0x7B INACCESSIBLE_BOOT_DEVICE).
struct AntiFlapDwordParam {
    const char* name;
    uint32_t value;
};

constexpr AntiFlapDwordParam REALTEK_ANTI_FLAP_DWORDS[] = {
    {"*EEE", 0},
    {"AdvancedEEE", 0},
    {"PowerSavingMode", 0},
    {"ReduceSpeedOnPowerDown", 0},
    {"AutoDisableGigabit", 0},
    {"GigaLite", 0},
    {"*FlowControl", 0},
    // 0 = do NOT stall the boot on PHY auto-negotiation. A non-zero value makes the
    // miniport wait for link during Phase 0, which shows up as an infinite boot-logo
    // hang whenever the negotiation delay is longer than the driver expects.
    {"*WaitAutoNegComplete", 0},
    {"*GreenEthernet", 0},
    {"*GigaLite", 0},
    {"*WakeOnMagicPacket", 0},
    {"AutoDisablePhy", 0},
    {"PnPCapabilities", 0x00000018},
};

// DMA / TSO / checksum offload disables written as REG_SZ "0" next to the anti-flap
// block above, for every armed *physical* NDIS miniport:
//
//   *LsoV2IPv4 = "0", *LsoV2IPv6 = "0", *IPChecksumOffloadIPv4 = "0",
//   *TCPChecksumOffloadIPv4 = "0", *UDPChecksumOffloadIPv4 = "0",
//   *TCPChecksumOffloadIPv6 = "0", *UDPChecksumOffloadIPv6 = "0"
//
// During Phase 0 the iSCSI boot stack owns the receive buffers. When the NIC still
// performs checksum/segmentation offload it DMAs descriptors and split packets the
// boot-time descriptors never accounted for, and ndis.sys faults with
// 0xD1 (DRIVER_IRQL_NOT_LESS_OR_EQUAL) while servicing the completion IRQL. IPv6 variants
// are included for the same reason: a dual-stack miniport keeps its v6 TSO engine running
// even when only v4 traffic is up, and the DMA storm does not care which family the
// segment belongs to.
constexpr const char* const REALTEK_ANTI_FLAP_STRINGS[] = {
    "EEE",
    "EnableGreenEthernet",
    "*PowerSavingMode",
    "LinkDownPowerSaving",
    "FlowControl",
    "*InterruptModeration",
    // -- offload disables (see above) --
    "*LsoV2IPv4",
    "*LsoV2IPv6",
    "*IPChecksumOffloadIPv4",
    "*TCPChecksumOffloadIPv4",
    "*UDPChecksumOffloadIPv4",
    "*TCPChecksumOffloadIPv6",
    "*UDPChecksumOffloadIPv6"
};

// NDIS 6.30+ (NT 6.2 / Windows 8) standardized keywords. They do not exist on NDIS 6.20
// and earlier, and forcing them through a miniport built for older PHY silicon (RTL8111E
// Rev 06) is what raised the ThinkCentre M71s Phase-0 stop 0xA: the miniport forwards the
// unknown keyword to NDIS advanced-property string parsing at DISPATCH_LEVEL and faults on
// the resulting NULL buffer. Legacy guests therefore never receive them -- neither on the
// adapter instance key nor in the driver's own Parameters key.
constexpr const char* const NDIS_MODERN_KEYWORDS[] = {
    "*EEE",
    "*GreenEthernet",
};

// A "*" prefix marks an NDIS standardized keyword. NDIS hands those to the miniport as
// advanced-property *strings*, so they must be written as REG_SZ; a REG_DWORD makes the
// miniport parse an uninitialised buffer at DISPATCH_LEVEL (stop 0xA, Arg1 = 0x8).
constexpr bool is_asterisk_keyword(const char* name) noexcept {
    return name != nullptr && name[0] == '*';
}

bool is_modern_ndis_keyword(const char* name) noexcept {
    for (const char* modern : NDIS_MODERN_KEYWORDS) {
        if (string_iequal(name, modern)) return true;
    }
    return false;
}

// PnPCapabilities is a device-instance capability mask that PnP reads straight off the
// instance key; it is not an NDIS advanced property, so it is never schema-gated.
bool is_ndi_advanced_property(const char* name) noexcept {
    return !string_iequal(name, "PnPCapabilities");
}

// Network adapter class GUID ({4d36e972-...} = Net class) used by CriticalDeviceDatabase
// entries so the PnP manager classifies the device correctly during early boot.
constexpr const char* NETWORK_CLASS_GUID = "{4d36e972-e325-11ce-bfc1-08002be10318}";

// Hardware ID -> service bindings that must exist in
// <ControlSet>\Control\CriticalDeviceDatabase.
//
// Root cause of 0x7B INACCESSIBLE_BOOT_DEVICE: even with Start = 0, the PnP manager
// (pci.sys) will not bind a PCI device to its NIC driver during Phase 0 unless a
// device-to-driver association is present in the CriticalDeviceDatabase. Without it the
// iSCSI/network stack never comes up and the boot volume stays inaccessible.
struct CriticalDeviceDatabaseBinding {
    const char* hardware_id; // Subkey name under CriticalDeviceDatabase (as stored by Windows)
    const char* service;     // Boot-start service the hardware ID is bound to
};

const std::vector<CriticalDeviceDatabaseBinding>& critical_device_database_bindings() {
    static const std::vector<CriticalDeviceDatabaseBinding> bindings = {
        // Realtek RTL8168/8111 (the primary diskless boot NIC)
        {"pci#ven_10ec&dev_8168", "rt640x64"},
        // Realtek class code fallback (Base Class 02 = Network controller, Subclass 00 = Ethernet)
        {"pci#ven_10ec&cc_0200", "rt640x64"},
        // Realtek generic vendor wildcard fallback
        {"pci#ven_10ec*", "rt640x64"},
        // Realtek subsystem variant (Acer machines, RTL8169 family)
        {"pci#ven_10ec&dev_8169", "rt640x64"},
        // Intel I219/I218
        {"pci#ven_8086&dev_15b8", "e1d68x64"},
    };
    return bindings;
}

// -----------------------------------------------------------------------------
// Guest architecture detection + universal NDIS (Class = Net) package harvesting
// -----------------------------------------------------------------------------

// PE Machine field values (IMAGE_FILE_MACHINE_I386 / IMAGE_FILE_MACHINE_AMD64).
constexpr uint16_t PE_MACHINE_I386  = 0x014C;
constexpr uint16_t PE_MACHINE_AMD64 = 0x8664;

std::string to_lower_copy(std::string_view in) {
    std::string out(in);
    std::transform(out.begin(), out.end(), out.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return out;
}

std::string trim_copy(std::string_view in) {
    size_t begin = 0;
    size_t end = in.size();
    while (begin < end && std::isspace(static_cast<unsigned char>(in[begin]))) ++begin;
    while (end > begin && std::isspace(static_cast<unsigned char>(in[end - 1]))) --end;
    return std::string(in.substr(begin, end - begin));
}

std::string strip_quotes_copy(std::string_view in) {
    std::string s = trim_copy(in);
    if (s.size() >= 2 && ((s.front() == '"' && s.back() == '"') ||
                          (s.front() == '%' && s.back() == '%'))) {
        s = s.substr(1, s.size() - 2);
    }
    return s;
}

// Split an INF value list ("a, b , c") into trimmed, non-empty tokens.
std::vector<std::string> split_csv_copy(std::string_view value) {
    std::vector<std::string> tokens;
    size_t pos = 0;
    while (pos <= value.size()) {
        size_t comma = value.find(',', pos);
        size_t end = (comma == std::string_view::npos) ? value.size() : comma;
        std::string token = trim_copy(value.substr(pos, end - pos));
        if (!token.empty()) tokens.push_back(std::move(token));
        if (comma == std::string_view::npos) break;
        pos = comma + 1;
    }
    return tokens;
}

bool ends_with_ci(const std::string& value, std::string_view suffix) {
    if (value.size() < suffix.size()) return false;
    return string_iequal(value.substr(value.size() - suffix.size()), suffix);
}

// <Volume>\Windows (accepts either the volume root or the Windows directory itself).
std::filesystem::path locate_windows_dir(const std::filesystem::path& volume_path) {
    if (volume_path.empty()) return {};
    if (dir_exists_win32_or_std(volume_path / "Windows" / "System32")) {
        return volume_path / "Windows";
    }
    if (dir_exists_win32_or_std(volume_path / "System32")) {
        return volume_path;
    }
    return {};
}

// Length of the `\\?\Volume{GUID}\` prefix at the head of `path` (INCLUDING the closing
// separator), or 0 when `path` is not an NT volume-namespace path.
//
// This is pure string work on purpose. std::filesystem::path on this toolchain (MSYS2/
// Cygwin libstdc++) follows POSIX separator rules, so a Win32 path full of backslashes is
// ONE component: `parent_path()` on `\\?\Volume{GUID}\Windows\System32\config\SYSTEM`
// returns "" and no amount of walking can ever reach the root. The namespace prefix is
// therefore recognised on the raw bytes (both '/' and '\' accepted as separators after the
// closing brace, the `Volume{` keyword matched case-insensitively).
size_t nt_volume_guid_prefix_len(const std::string& path) {
    auto is_sep = [](char c) { return c == '\\' || c == '/'; };
    // shortest possible match: `\\?\Volume{}\` = 12 bytes.
    if (path.size() < 12) return 0;
    if (!is_sep(path[0]) || !is_sep(path[1]) || path[2] != '?' || !is_sep(path[3])) return 0;

    // The keyword is stored already-lowercased and compared against a lowercased input
    // byte. Lowercasing the *input only* and then comparing against a mixed-case
    // "Volume{" matches nothing at all -- `tolower('V') == 'v' != 'V'` -- so every
    // namespace path silently fell through to the (incapable) directory walk, which is
    // the exact bug this helper exists to fix.
    constexpr std::string_view keyword = "volume{";
    for (size_t i = 0; i < keyword.size(); ++i) {
        const char lower = static_cast<char>(
            std::tolower(static_cast<unsigned char>(path[4 + i])));
        if (lower != keyword[i]) return 0;
    }

    const size_t brace = path.find('}', 4 + keyword.size());
    if (brace == std::string::npos) return 0;                 // GUID never closed
    if (brace + 1 >= path.size()) return 0;                   // no trailing separator
    if (!is_sep(path[brace + 1])) return 0;
    return brace + 2;
}

// Walk up from a SYSTEM hive file to the volume that owns the Windows installation
// above it (returns the directory `locate_windows_dir()` accepts -- the volume root when
// one exists, otherwise the Windows directory itself).
//
// This replaces the old `system32_dir.parent_path()` derivation, which subtracted a fixed
// number of components: for any hive path that is not exactly the canonical
// <Volume>\Windows\System32\CONFIG\SYSTEM shape (a relative "System32\config\SYSTEM", a
// bare "config\SYSTEM", an odd trailing separator) it collapsed to "" and the NDIS
// harvest then logged
//   "No Windows directory found, skipping NDIS driver harvest for: "
// with nothing after the colon, silently disabling OS-family classification and driver
// harvesting for the whole pass. Walking the actual tree cannot name an empty root for a
// Windows tree that really exists, and returns "" only when there is none above.
//
// The NT volume namespace (`\\?\Volume{GUID}\Windows\System32\config\SYSTEM`, the shape a
// mounted VHD hands out on the command line) is handled FIRST and never falls through to
// the walk -- see nt_volume_guid_prefix_len() for why walking it cannot work.
std::filesystem::path resolve_volume_root_from_hive(const std::filesystem::path& hive_path) {
    const std::string raw = hive_path.string();

    // 1. NT volume namespace: the root is exactly `\\?\Volume{GUID}`.
    //    `<volume_root>\Windows` is the proof that a Windows install lives on that volume;
    //    when it is missing there is nothing above to walk, so "" (the caller names the
    //    hive it could not resolve) is the only honest answer.
    std::string win_form = raw;
    for (char& c : win_form) {
        if (c == '/') c = '\\';
    }
    if (const size_t prefix = nt_volume_guid_prefix_len(win_form); prefix != 0) {
        std::string root = win_form.substr(0, prefix - 1); // drop the closing separator
        const std::string windows_dir = root + "\\Windows";
        if (dir_exists_win32_or_std(std::filesystem::path(windows_dir))) {
            if (!root.empty() && root.back() == '\\') root.pop_back();
            return std::filesystem::path(root);
        }
        return {};
    }

    // 2. Plain directory tree. Normalize to '/' first: on this toolchain '\' is an
    //    ordinary character, so an un-normalized Win32 path is a single component and
    //    parent_path() would return "" immediately.
    std::string walk_form = raw;
    for (char& c : walk_form) {
        if (c == '\\') c = '/';
    }
    std::filesystem::path dir = std::filesystem::path(walk_form).parent_path();
    std::filesystem::path fallback;
    for (int depth = 0; depth < 8 && !dir.empty(); ++depth) {
        if (dir_exists_win32_or_std(dir / "Windows" / "System32")) return dir;
        if (fallback.empty() && dir_exists_win32_or_std(dir / "System32")) {
            fallback = dir; // this component is the Windows directory itself
        }
        if (fallback.empty() && dir_exists_win32_or_std(dir / "drivers")) {
            const std::filesystem::path parent = dir.parent_path();
            // <...>\System32 -> its parent is the Windows directory; a single-component
            // relative path has no parent, and the current directory is then the root.
            fallback = parent.empty() ? std::filesystem::path(".") : parent;
        }
        const std::filesystem::path parent = dir.parent_path();
        if (parent.empty() || parent == dir) break;
        dir = parent;
    }
    return fallback;
}

// Read the PE Machine field of an image (DOS header -> e_lfanew -> "PE\0\0" -> Machine).
bool read_pe_machine(const std::filesystem::path& pe_path, uint16_t* out_machine) {
    if (!out_machine) return false;
    std::ifstream in(pe_path, std::ios::binary);
    if (!in.is_open()) return false;

    uint8_t dos_header[64] = {0};
    in.read(reinterpret_cast<char*>(dos_header), sizeof(dos_header));
    if (in.gcount() != static_cast<std::streamsize>(sizeof(dos_header))) return false;
    if (dos_header[0] != 'M' || dos_header[1] != 'Z') return false;

    uint32_t lfanew = read_le32(&dos_header[0x3C]);
    if (lfanew < 0x40 || lfanew > (1u << 20)) return false;

    in.seekg(static_cast<std::streamoff>(lfanew), std::ios::beg);
    uint8_t sig[4] = {0};
    in.read(reinterpret_cast<char*>(sig), sizeof(sig));
    if (in.gcount() != 4 || sig[0] != 'P' || sig[1] != 'E' || sig[2] != 0 || sig[3] != 0) {
        return false;
    }

    uint8_t machine[2] = {0};
    in.read(reinterpret_cast<char*>(machine), sizeof(machine));
    if (in.gcount() != 2) return false;
    *out_machine = read_le16(machine);
    return true;
}

// Read a text file as ASCII/UTF-8, transparently decoding UTF-16 (INF files ship both ways).
bool read_text_file(const std::filesystem::path& path, std::string* out) {
    if (!out) return false;
    std::ifstream in(path, std::ios::binary);
    if (!in.is_open()) return false;
    std::vector<uint8_t> bytes((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    if (bytes.empty()) return false;

    size_t start = 0;
    bool utf16le = false;
    bool utf16be = false;
    if (bytes.size() >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF) {
        start = 3;
    } else if (bytes.size() >= 2 && bytes[0] == 0xFF && bytes[1] == 0xFE) {
        utf16le = true;
        start = 2;
    } else if (bytes.size() >= 2 && bytes[0] == 0xFE && bytes[1] == 0xFF) {
        utf16be = true;
        start = 2;
    } else {
        // BOM-less heuristic: an ASCII INF never contains NUL bytes, UTF-16LE puts them
        // on every even offset.
        size_t sample = std::min(bytes.size(), static_cast<size_t>(512));
        size_t nul_even = 0;
        size_t nul_odd = 0;
        for (size_t i = 0; i < sample; ++i) {
            if (bytes[i] == 0) {
                if (i % 2 == 0) ++nul_even;
                else ++nul_odd;
            }
        }
        if (sample >= 16 && nul_odd == 0 && nul_even > sample / 8) {
            utf16le = true;
        }
    }

    out->clear();
    if (utf16le || utf16be) {
        for (size_t i = start; i + 1 < bytes.size(); i += 2) {
            uint16_t ch = utf16le
                ? static_cast<uint16_t>(bytes[i] | (static_cast<uint16_t>(bytes[i + 1]) << 8))
                : static_cast<uint16_t>((static_cast<uint16_t>(bytes[i]) << 8) | bytes[i + 1]);
            out->push_back(ch < 0x80 ? static_cast<char>(ch) : '?');
        }
    } else if (start < bytes.size()) {
        out->assign(reinterpret_cast<const char*>(bytes.data() + start), bytes.size() - start);
    }
    return true;
}

// Hardware IDs are single whitespace/list tokens: they stop at any list, quote or
// whitespace delimiter.
bool is_hardware_id_delimiter(char c) noexcept {
    return c == ',' || c == ';' || c == '"' || c == '%' || c == '\t' ||
           c == '\r' || c == '\n' || c == ' ' || c == ']';
}

// Collect every PCI\VEN_xxxx&DEV_yyyy style hardware ID in an INF and normalise it to
// the CriticalDeviceDatabase subkey form Windows uses: lowercase "pci#ven_xxxx&dev_yyyy".
std::vector<std::string> extract_pci_hardware_ids(const std::string& text) {
    std::vector<std::string> ids;
    const std::string lowered = to_lower_copy(text);

    auto push_unique = [&](const std::string& id) {
        if (std::find(ids.begin(), ids.end(), id) == ids.end()) {
            ids.push_back(id);
        }
    };

    size_t pos = 0;
    while ((pos = lowered.find("pci\\", pos)) != std::string::npos) {
        size_t end = pos;
        while (end < lowered.size() && !is_hardware_id_delimiter(lowered[end])) {
            ++end;
        }
        std::string token = lowered.substr(pos, end - pos);
        pos = (end > pos) ? end : pos + 1;

        // pci\ven_14e4&dev_1680&subsys_...  ->  pci#ven_14e4&dev_1680
        const std::string key_prefix = "pci#";
        if (token.size() <= key_prefix.size()) continue;

        std::string ven;
        std::string dev;
        bool class_code_ethernet = false;
        size_t cursor = key_prefix.size(); // skip "pci\", already rewrites to "pci#"
        while (cursor < token.size()) {
            size_t amp = token.find('&', cursor);
            std::string part = token.substr(cursor, (amp == std::string::npos ? token.size() : amp) - cursor);
            if (part.rfind("ven_", 0) == 0) ven = part;
            else if (part.rfind("dev_", 0) == 0) dev = part;
            else if (part.rfind("cc_0200", 0) == 0) class_code_ethernet = true;
            if (amp == std::string::npos) break;
            cursor = amp + 1;
        }

        if (ven.empty()) {
            // PCI\<something else> -- only ven_* keys are useful for CDDB binding
            continue;
        }
        if (!dev.empty()) {
            push_unique(key_prefix + ven + "&" + dev);
        }
        if (class_code_ethernet) {
            push_unique(key_prefix + ven + "&cc_0200");
        }
    }
    return ids;
}

// True when the INF also enumerates ROOT\... hardware IDs. A ROOT-enumerated device
// has no PCI function behind it: TAP/TUN, WAN miniports, VPN and other software
// adapters are plugged into the root bus by a driver install, so they are never
// physical boot-path hardware.
bool has_root_hardware_id(const std::string& text) {
    const std::string lowered = to_lower_copy(text);
    size_t pos = 0;
    while ((pos = lowered.find("root\\", pos)) != std::string::npos) {
        // Only a standalone ROOT\ token counts -- never the tail of "boot\", "aroot\", ...
        const bool at_boundary =
            pos == 0 || !std::isalnum(static_cast<unsigned char>(lowered[pos - 1]));

        size_t end = pos;
        while (end < lowered.size() && !is_hardware_id_delimiter(lowered[end])) {
            ++end;
        }
        if (at_boundary && end > pos + 5) return true; // "root\" plus identifier text
        pos = (end > pos) ? end : pos + 1;
    }
    return false;
}

struct InfMetadata {
    bool class_net{false};
    std::string service_name;   // AddService first token
    std::string group;          // LoadOrderGroup / ServiceGroup
    bool has_tag{false};
    uint32_t tag{0};
    std::vector<std::string> hardware_ids;
    bool has_root_id{false};    // ROOT\ software-enumerated device
};

// Minimal but tolerant INF walker: Class / ClassGuid classification, AddService name,
// load-order group + tag and PCI hardware IDs.
InfMetadata parse_ndis_inf(const std::string& text) {
    InfMetadata meta;
    meta.hardware_ids = extract_pci_hardware_ids(text);
    meta.has_root_id = has_root_hardware_id(text);

    const std::string net_guid = to_lower_copy(NETWORK_CLASS_GUID);
    const std::string net_guid_bare = net_guid.substr(1, net_guid.size() - 2);

    std::string section;
    std::istringstream stream(text);
    std::string raw_line;
    while (std::getline(stream, raw_line)) {
        if (!raw_line.empty() && raw_line.back() == '\r') raw_line.pop_back();
        size_t comment = raw_line.find(';');
        if (comment != std::string::npos) raw_line.erase(comment);
        std::string line = trim_copy(raw_line);
        if (line.empty()) continue;

        if (line.front() == '[' && line.back() == ']') {
            section = to_lower_copy(trim_copy(line.substr(1, line.size() - 2)));
            continue;
        }

        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string key = to_lower_copy(trim_copy(line.substr(0, eq)));
        std::string value = trim_copy(line.substr(eq + 1));

        if (key == "class") {
            if (to_lower_copy(strip_quotes_copy(value)) == "net") {
                meta.class_net = true;
            }
        } else if (key == "classguid") {
            std::string guid = to_lower_copy(strip_quotes_copy(value));
            guid.erase(std::remove(guid.begin(), guid.end(), '{'), guid.end());
            guid.erase(std::remove(guid.begin(), guid.end(), '}'), guid.end());
            if (guid == net_guid_bare) {
                meta.class_net = true;
            }
        } else if (key == "addservice" && section.find("service") != std::string::npos) {
            auto tokens = split_csv_copy(value);
            if (!tokens.empty() && meta.service_name.empty()) {
                meta.service_name = strip_quotes_copy(tokens[0]);
            }
        } else if ((key == "loadordergroup" || key == "servicegroup") && !section.empty()) {
            auto tokens = split_csv_copy(value);
            if (!tokens.empty() && meta.group.empty()) {
                meta.group = strip_quotes_copy(tokens[0]);
            }
        } else if (key == "tag" && section.find("service") != std::string::npos) {
            auto tokens = split_csv_copy(value);
            std::string raw = tokens.empty() ? value : tokens[0];
            uint32_t parsed = 0;
            bool ok = !raw.empty();
            size_t idx = 0;
            int base = 10;
            if (raw.size() > 2 && raw[0] == '0' && (raw[1] == 'x' || raw[1] == 'X')) {
                base = 16;
                idx = 2;
            }
            for (; idx < raw.size(); ++idx) {
                char c = raw[idx];
                uint32_t digit;
                if (c >= '0' && c <= '9') digit = static_cast<uint32_t>(c - '0');
                else if (base == 16 && c >= 'a' && c <= 'f') digit = static_cast<uint32_t>(c - 'a' + 10);
                else if (base == 16 && c >= 'A' && c <= 'F') digit = static_cast<uint32_t>(c - 'A' + 10);
                else { ok = false; break; }
                if (digit >= static_cast<uint32_t>(base)) { ok = false; break; }
                parsed = parsed * static_cast<uint32_t>(base) + digit;
            }
            if (ok) {
                meta.tag = parsed;
                meta.has_tag = true;
            }
        }
    }
    return meta;
}

// Fallback classification for packages whose INF is compressed (.inf_): match the
// well-known network driver INF prefixes used by Windows driver packages.
bool folder_name_looks_network(const std::string& folder_lower) {
    static const char* const kNetworkPrefixes[] = {
        "net", "rt", "e1", "e2", "e9", "b57", "alx", "ath", "k1116", "mrvl", "aqc"
    };
    for (const char* prefix : kNetworkPrefixes) {
        if (folder_lower.rfind(prefix, 0) == 0) return true;
    }
    return false;
}

// "_amd64_" / "_x86_" token inside a FileRepository folder name.
GuestArch arch_from_package_name(const std::string& folder_lower) {
    if (folder_lower.find("_amd64_") != std::string::npos) return GuestArch::X64;
    if (folder_lower.find("_x86_") != std::string::npos) return GuestArch::X86;
    return GuestArch::Unknown;
}

// -----------------------------------------------------------------------------
// Read-only regf access.
//
// Offline OS family detection has to INSPECT a SYSTEM / SOFTWARE hive rather than
// arm it, so these helpers mirror the mutating lambda set inside arm_hive_buffer
// but take a const hive and never write a byte. arm_hive_buffer delegates its own
// lookups to them so the two interpretations of a hive cannot drift apart.
// -----------------------------------------------------------------------------
bool regf_cell(const std::vector<uint8_t>& hive, uint32_t cell_off,
               const uint8_t** out_payload, size_t* out_len) {
    if (cell_off == 0xFFFFFFFF) return false;
    if (cell_off > hive.size() || 0x1000 + static_cast<size_t>(cell_off) + 4 > hive.size()) return false;
    int32_t csize = static_cast<int32_t>(read_le32(&hive[0x1000 + cell_off]));
    if (csize >= 0) return false; // free cell
    size_t alloc_len = static_cast<size_t>(-static_cast<int64_t>(csize));
    if (alloc_len < 4 || 0x1000 + static_cast<size_t>(cell_off) + alloc_len > hive.size()) return false;
    if (out_payload) *out_payload = &hive[0x1000 + cell_off + 4];
    if (out_len) *out_len = alloc_len - 4;
    return true;
}

// Root nk cell offset of a hive, or 0xFFFFFFFF when the buffer is not a usable hive.
uint32_t regf_root_offset(const std::vector<uint8_t>& hive) {
    if (hive.size() < 0x1000 + 0x28) return 0xFFFFFFFF;
    if (hive[0] != 'r' || hive[1] != 'e' || hive[2] != 'g' || hive[3] != 'f') return 0xFFFFFFFF;
    uint32_t root = read_le32(&hive[0x24]);
    const uint8_t* nk = nullptr;
    size_t len = 0;
    if (!regf_cell(hive, root, &nk, &len) || len < 0x4C || read_le16(nk) != 0x6B6E) return 0xFFFFFFFF;
    return root;
}

// Walk every child listed by a subkey index cell ("lf"/"lh" flat lists, "li" pointer
// lists and "ri" root indexes of either). `visit` receives each child nk offset and
// returns false to stop the walk early.
template <typename Visitor>
void regf_walk_subkeys(const std::vector<uint8_t>& hive, uint32_t nk_cell_off, Visitor&& visit) {
    const uint8_t* nk = nullptr;
    size_t nk_len = 0;
    if (!regf_cell(hive, nk_cell_off, &nk, &nk_len) || nk_len < 0x20 || read_le16(nk) != 0x6B6E) return;

    uint32_t subkey_count = read_le32(nk + 0x14);
    uint32_t subkey_list_off = read_le32(nk + 0x1C);
    if (subkey_count == 0 || subkey_list_off == 0 || subkey_list_off == 0xFFFFFFFF) return;

    std::vector<uint32_t> sublists = { subkey_list_off };
    for (size_t lidx = 0; lidx < sublists.size(); ++lidx) {
        const uint8_t* sl = nullptr;
        size_t sl_size = 0;
        if (!regf_cell(hive, sublists[lidx], &sl, &sl_size) || sl_size < 4) continue;
        uint16_t sig = read_le16(sl);
        uint16_t count = read_le16(sl + 0x02);

        if (sig == 0x6972) { // "ri" root index -> visit its leaves in turn
            uint16_t max_c = static_cast<uint16_t>((sl_size - 4) / 4);
            count = std::min(count, max_c);
            for (uint16_t i = 0; i < count; ++i) {
                sublists.push_back(read_le32(sl + 0x04 + static_cast<uint32_t>(i) * 4));
            }
        } else if (sig == 0x666C || sig == 0x686C) { // "lf" / "lh"
            uint16_t max_c = static_cast<uint16_t>((sl_size - 4) / 8);
            count = std::min(count, max_c);
            for (uint16_t i = 0; i < count; ++i) {
                uint32_t child_off = read_le32(sl + 0x04 + static_cast<uint32_t>(i) * 8);
                if (child_off != 0 && child_off != 0xFFFFFFFF && !visit(child_off)) return;
            }
        } else if (sig == 0x696C) { // "li" index list
            uint16_t max_c = static_cast<uint16_t>((sl_size - 4) / 4);
            count = std::min(count, max_c);
            for (uint16_t i = 0; i < count; ++i) {
                uint32_t child_off = read_le32(sl + 0x04 + static_cast<uint32_t>(i) * 4);
                if (child_off != 0 && child_off != 0xFFFFFFFF && !visit(child_off)) return;
            }
        }
    }
}

// Locate a direct child subkey by name (0xFFFFFFFF when absent).
uint32_t regf_find_subkey(const std::vector<uint8_t>& hive, uint32_t nk_cell_off, const std::string& name) {
    uint32_t found = 0xFFFFFFFF;
    regf_walk_subkeys(hive, nk_cell_off, [&](uint32_t child_off) {
        const uint8_t* child_nk = nullptr;
        size_t child_len = 0;
        if (!regf_cell(hive, child_off, &child_nk, &child_len) ||
            child_len < 0x4C || read_le16(child_nk) != 0x6B6E) {
            return true;
        }
        uint16_t nlen = read_le16(child_nk + 0x48);
        if (static_cast<size_t>(0x4C) + nlen > child_len) return true;
        std::string child_name(reinterpret_cast<const char*>(child_nk + 0x4C), nlen);
        if (string_iequal(child_name, name)) {
            found = child_off;
            return false;
        }
        return true;
    });
    return found;
}

// Every direct child subkey offset, in index (sorted) order.
std::vector<uint32_t> regf_list_subkeys(const std::vector<uint8_t>& hive, uint32_t nk_cell_off) {
    std::vector<uint32_t> result;
    regf_walk_subkeys(hive, nk_cell_off, [&](uint32_t child_off) {
        result.push_back(child_off);
        return true;
    });
    return result;
}

// Backslash separated path below a starting nk cell (0xFFFFFFFF when it does not resolve).
uint32_t regf_open_path(const std::vector<uint8_t>& hive, uint32_t start_nk, const std::string& path) {
    uint32_t current = start_nk;
    size_t start = 0;
    while (start <= path.size() && current != 0xFFFFFFFF) {
        size_t sep = path.find('\\', start);
        std::string part = (sep == std::string::npos)
            ? path.substr(start)
            : path.substr(start, sep - start);
        if (!part.empty()) current = regf_find_subkey(hive, current, part);
        if (sep == std::string::npos) break;
        start = sep + 1;
    }
    return current;
}

// Name of an nk cell (false when the cell is not a readable key).
bool regf_nk_name(const std::vector<uint8_t>& hive, uint32_t nk_off, std::string* out) {
    const uint8_t* nk = nullptr;
    size_t len = 0;
    if (!regf_cell(hive, nk_off, &nk, &len) || len < 0x4C || read_le16(nk) != 0x6B6E) return false;
    uint16_t nlen = read_le16(nk + 0x48);
    if (static_cast<size_t>(0x4C) + nlen > len) return false;
    if (out) *out = std::string(reinterpret_cast<const char*>(nk + 0x4C), nlen);
    return true;
}

// REG_DWORD value of an nk cell (inline and heap data cells both).
bool regf_get_dword(const std::vector<uint8_t>& hive, uint32_t nk_cell_off,
                    const std::string& val_name, uint32_t* out_val) {
    const uint8_t* nk = nullptr;
    size_t nk_len = 0;
    if (!regf_cell(hive, nk_cell_off, &nk, &nk_len) || nk_len < 0x2C || read_le16(nk) != 0x6B6E) {
        return false;
    }

    uint32_t val_count = read_le32(nk + 0x24);
    uint32_t val_list_off = read_le32(nk + 0x28);
    if (val_count == 0 || val_list_off == 0 || val_list_off == 0xFFFFFFFF) return false;

    const uint8_t* vl = nullptr;
    size_t vl_len = 0;
    if (!regf_cell(hive, val_list_off, &vl, &vl_len)) return false;

    for (uint32_t i = 0; i < val_count; ++i) {
        if (static_cast<size_t>(i + 1) * 4 > vl_len) break;
        uint32_t vk_off = read_le32(vl + i * 4);
        const uint8_t* vk = nullptr;
        size_t vk_len = 0;
        if (!regf_cell(hive, vk_off, &vk, &vk_len) || vk_len < 0x14 || read_le16(vk) != 0x6B76) continue;

        uint16_t nlen = read_le16(vk + 0x02);
        if (static_cast<size_t>(0x14) + nlen > vk_len) continue;
        std::string name(reinterpret_cast<const char*>(vk + 0x14), nlen);
        if (!string_iequal(name, val_name)) continue;

        uint32_t dlen = read_le32(vk + 0x04);
        if (dlen & 0x80000000) {
            if (vk_len < 0x0C) return false;
            if (out_val) *out_val = read_le32(vk + 0x08);
            return true;
        }
        const uint8_t* dp = nullptr;
        size_t dp_len = 0;
        if (regf_cell(hive, read_le32(vk + 0x08), &dp, &dp_len) && dp_len >= 4 && out_val) {
            *out_val = read_le32(dp);
            return true;
        }
        return false;
    }
    return false;
}

// REG_SZ / REG_EXPAND_SZ / REG_MULTI_SZ value decoded to ASCII ("" when absent).
std::string regf_get_string(const std::vector<uint8_t>& hive, uint32_t nk_cell_off,
                            const std::string& val_name) {
    const uint8_t* nk = nullptr;
    size_t nk_len = 0;
    if (!regf_cell(hive, nk_cell_off, &nk, &nk_len) || nk_len < 0x2C || read_le16(nk) != 0x6B6E) {
        return "";
    }

    uint32_t val_count = read_le32(nk + 0x24);
    uint32_t val_list_off = read_le32(nk + 0x28);
    if (val_count == 0 || val_list_off == 0 || val_list_off == 0xFFFFFFFF) return "";

    const uint8_t* vl = nullptr;
    size_t vl_len = 0;
    if (!regf_cell(hive, val_list_off, &vl, &vl_len)) return "";

    for (uint32_t i = 0; i < val_count; ++i) {
        if (static_cast<size_t>(i + 1) * 4 > vl_len) break;
        uint32_t vk_off = read_le32(vl + i * 4);
        const uint8_t* vk = nullptr;
        size_t vk_len = 0;
        if (!regf_cell(hive, vk_off, &vk, &vk_len) || vk_len < 0x14 || read_le16(vk) != 0x6B76) continue;

        uint16_t nlen = read_le16(vk + 0x02);
        if (static_cast<size_t>(0x14) + nlen > vk_len) continue;
        std::string name(reinterpret_cast<const char*>(vk + 0x14), nlen);
        if (!string_iequal(name, val_name)) continue;

        uint32_t dlen = read_le32(vk + 0x04);
        uint32_t raw_len = dlen & 0x7FFFFFFF;
        const uint8_t* data_ptr = nullptr;
        size_t data_cap = 0;
        if (dlen & 0x80000000) {
            if (vk_len < 0x0C) return "";
            data_ptr = vk + 0x08;
            data_cap = vk_len - 0x08;
        } else {
            if (!regf_cell(hive, read_le32(vk + 0x08), &data_ptr, &data_cap)) return "";
        }
        if (!data_ptr || raw_len == 0) return "";
        if (raw_len > data_cap) raw_len = static_cast<uint32_t>(data_cap);

        std::string res;
        if (raw_len >= 2 && data_ptr[1] == 0) { // UTF-16LE
            for (uint32_t c = 0; c + 1 < raw_len; c += 2) {
                char ch = static_cast<char>(data_ptr[c]);
                if (ch == 0) break;
                res.push_back(ch);
            }
        } else {
            for (uint32_t c = 0; c < raw_len; ++c) {
                char ch = static_cast<char>(data_ptr[c]);
                if (ch == 0) break;
                res.push_back(ch);
            }
        }
        return res;
    }
    return "";
}

// Every value name carried by an nk cell, in stored order ("" omitted). Used by the
// read-only inspector to dump the contents of Services\<drv>\Parameters.
std::vector<std::string> regf_value_names(const std::vector<uint8_t>& hive, uint32_t nk_cell_off) {
    std::vector<std::string> names;
    const uint8_t* nk = nullptr;
    size_t nk_len = 0;
    if (!regf_cell(hive, nk_cell_off, &nk, &nk_len) || nk_len < 0x2C || read_le16(nk) != 0x6B6E) {
        return names;
    }

    const uint32_t val_count = read_le32(nk + 0x24);
    const uint32_t val_list_off = read_le32(nk + 0x28);
    if (val_count == 0 || val_list_off == 0 || val_list_off == 0xFFFFFFFF) return names;

    const uint8_t* vl = nullptr;
    size_t vl_len = 0;
    if (!regf_cell(hive, val_list_off, &vl, &vl_len)) return names;

    for (uint32_t i = 0; i < val_count; ++i) {
        if (static_cast<size_t>(i + 1) * 4 > vl_len) break;
        const uint32_t vk_off = read_le32(vl + i * 4);
        const uint8_t* vk = nullptr;
        size_t vk_len = 0;
        if (!regf_cell(hive, vk_off, &vk, &vk_len) || vk_len < 0x14 || read_le16(vk) != 0x6B76) continue;

        const uint16_t nlen = read_le16(vk + 0x02);
        if (static_cast<size_t>(0x14) + nlen > vk_len) continue;
        names.emplace_back(reinterpret_cast<const char*>(vk + 0x14), nlen);
    }
    return names;
}

// Decision core shared by every detection source: given the version evidence a key
// carries, decide Legacy / Modern / Unknown. Any piece of evidence may be absent.
GuestOsFamily classify_os_evidence(bool has_major, uint32_t major, bool has_minor, uint32_t minor,
                                   const std::string& build_sz, const std::string& version_sz) {
    uint32_t build = 0;
    if (!build_sz.empty()) {
        build = static_cast<uint32_t>(std::strtoul(build_sz.c_str(), nullptr, 10));
    }

    // Windows 10/11 spell their version as a DWORD pair; XP..8.1 only carry the
    // "CurrentVersion" string ("5.1", "6.1", "6.3", ...).
    if (has_major) {
        GuestOsFamily family = PnpDriverArmer::classify_os_version(major, has_minor ? minor : 0, build);
        if (family != GuestOsFamily::Unknown) return family;
    }

    if (!version_sz.empty()) {
        unsigned int v_major = 0;
        unsigned int v_minor = 0;
        if (std::sscanf(version_sz.c_str(), "%u.%u", &v_major, &v_minor) == 2) {
            GuestOsFamily family = PnpDriverArmer::classify_os_version(v_major, v_minor, build);
            if (family != GuestOsFamily::Unknown) return family;
        }
    }

    if (build != 0) {
        GuestOsFamily family = PnpDriverArmer::classify_os_version(0, 0, build);
        if (family != GuestOsFamily::Unknown) return family;
    }

    return GuestOsFamily::Unknown;
}

// Version evidence carried by a "CurrentVersion" style key -- either the SYSTEM hive's
// ControlSet00x\Control\Windows or the SOFTWARE hive's Microsoft\Windows NT\CurrentVersion.
// Both spell the evidence the same way, so one reader covers either file.
GuestOsFamily classify_from_version_key(const std::vector<uint8_t>& hive, uint32_t nk_off) {
    if (nk_off == 0xFFFFFFFF) return GuestOsFamily::Unknown;

    uint32_t major = 0;
    uint32_t minor = 0;
    const bool has_major = regf_get_dword(hive, nk_off, "CurrentMajorVersionNumber", &major);
    const bool has_minor = regf_get_dword(hive, nk_off, "CurrentMinorVersionNumber", &minor);

    GuestOsFamily family = classify_os_evidence(has_major, major, has_minor, minor,
                                                regf_get_string(hive, nk_off, "CurrentBuildNumber"),
                                                regf_get_string(hive, nk_off, "CurrentVersion"));
    if (family != GuestOsFamily::Unknown) return family;

    // A service pack only ever shipped on NT <= 6.1 (Windows 7 was the last Windows
    // release with service packs), so a non-zero CSDVersion is Legacy evidence on its own.
    uint32_t csd_version = 0;
    if (regf_get_dword(hive, nk_off, "CSDVersion", &csd_version) && csd_version != 0) {
        return GuestOsFamily::Legacy;
    }

    return GuestOsFamily::Unknown;
}

} // namespace: anonymous helpers end here -- the PnpDriverArmer member definitions that
// follow have to be declared in the enclosing cobdiskless namespace, not in an
// unnamed one. The anonymous namespace is reopened right after them.

// ---- SHA-256 (FIPS 180-4) ---------------------------------------------------------
// Used for the offline "is the staged .sys still the binary the DriverStore shipped?"
// identity check. Self-contained so the CLI, the armer and the tests agree on one digest.
namespace {
constexpr uint32_t sha256_k[64] = {
    0x428a2f98u, 0x71374491u, 0xb5c0fbcfu, 0xe9b5dba5u, 0x3956c25bu, 0x59f111f1u,
    0x923f82a4u, 0xab1c5ed5u, 0xd807aa98u, 0x12835b01u, 0x243185beu, 0x550c7dc3u,
    0x72be5d74u, 0x80deb1feu, 0x9bdc06a7u, 0xc19bf174u, 0xe49b69c1u, 0xefbe4786u,
    0x0fc19dc6u, 0x240ca1ccu, 0x2de92c6fu, 0x4a7484aau, 0x5cb0a9dcu, 0x76f988dau,
    0x983e5152u, 0xa831c66du, 0xb00327c8u, 0xbf597fc7u, 0xc6e00bf3u, 0xd5a79147u,
    0x06ca6351u, 0x14292967u, 0x27b70a85u, 0x2e1b2138u, 0x4d2c6dfcu, 0x53380d13u,
    0x650a7354u, 0x766a0abbu, 0x81c2c92eu, 0x92722c85u, 0xa2bfe8a1u, 0xa81a664bu,
    0xc24b8b70u, 0xc76c51a3u, 0xd192e819u, 0xd6990624u, 0xf40e3585u, 0x106aa070u,
    0x19a4c116u, 0x1e376c08u, 0x2748774cu, 0x34b0bcb5u, 0x391c0cb3u, 0x4ed8aa4au,
    0x5b9cca4fu, 0x682e6ff3u, 0x748f82eeu, 0x78a5636fu, 0x84c87814u, 0x8cc70208u,
    0x90befffau, 0xa4506cebu, 0xbef9a3f7u, 0xc67178f2u
};

constexpr uint32_t sha256_rotr(uint32_t x, uint32_t n) {
    return (x >> n) | (x << (32u - n));
}

// Streaming SHA-256: feed() accepts arbitrary chunks, finish() pads and returns the digest.
class Sha256 {
public:
    void feed(const uint8_t* data, size_t length) {
        for (size_t i = 0; i < length; ++i) {
            buffer_[buffer_len_++] = data[i];
            if (buffer_len_ == 64) {
                transform(buffer_);
                bit_len_ += 512u;
                buffer_len_ = 0;
            }
        }
    }

    void finish(uint8_t out[32]) {
        const uint64_t total_bits = bit_len_ + static_cast<uint64_t>(buffer_len_) * 8u;
        buffer_[buffer_len_++] = 0x80;
        if (buffer_len_ > 56) {
            while (buffer_len_ < 64) buffer_[buffer_len_++] = 0x00;
            transform(buffer_);
            buffer_len_ = 0;
        }
        while (buffer_len_ < 56) buffer_[buffer_len_++] = 0x00;
        for (int i = 7; i >= 0; --i) {
            buffer_[buffer_len_++] = static_cast<uint8_t>((total_bits >> (i * 8)) & 0xFFu);
        }
        transform(buffer_);

        for (int i = 0; i < 8; ++i) {
            out[i * 4 + 0] = static_cast<uint8_t>((state_[i] >> 24) & 0xFFu);
            out[i * 4 + 1] = static_cast<uint8_t>((state_[i] >> 16) & 0xFFu);
            out[i * 4 + 2] = static_cast<uint8_t>((state_[i] >> 8) & 0xFFu);
            out[i * 4 + 3] = static_cast<uint8_t>(state_[i] & 0xFFu);
        }
    }

private:
    void transform(const uint8_t block[64]) {
        uint32_t w[64];
        for (int i = 0; i < 16; ++i) {
            w[i] = (static_cast<uint32_t>(block[i * 4 + 0]) << 24) |
                   (static_cast<uint32_t>(block[i * 4 + 1]) << 16) |
                   (static_cast<uint32_t>(block[i * 4 + 2]) << 8) |
                   static_cast<uint32_t>(block[i * 4 + 3]);
        }
        for (int i = 16; i < 64; ++i) {
            const uint32_t s0 = sha256_rotr(w[i - 15], 7) ^ sha256_rotr(w[i - 15], 18) ^ (w[i - 15] >> 3);
            const uint32_t s1 = sha256_rotr(w[i - 2], 17) ^ sha256_rotr(w[i - 2], 19) ^ (w[i - 2] >> 10);
            w[i] = w[i - 16] + s0 + w[i - 7] + s1;
        }

        uint32_t a = state_[0], b = state_[1], c = state_[2], d = state_[3];
        uint32_t e = state_[4], f = state_[5], g = state_[6], h = state_[7];

        for (int i = 0; i < 64; ++i) {
            const uint32_t s1 = sha256_rotr(e, 6) ^ sha256_rotr(e, 11) ^ sha256_rotr(e, 25);
            const uint32_t ch = (e & f) ^ (~e & g);
            const uint32_t temp1 = h + s1 + ch + sha256_k[i] + w[i];
            const uint32_t s0 = sha256_rotr(a, 2) ^ sha256_rotr(a, 13) ^ sha256_rotr(a, 22);
            const uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
            const uint32_t temp2 = s0 + maj;

            h = g; g = f; f = e;
            e = d + temp1;
            d = c; c = b; b = a;
            a = temp1 + temp2;
        }

        state_[0] += a; state_[1] += b; state_[2] += c; state_[3] += d;
        state_[4] += e; state_[5] += f; state_[6] += g; state_[7] += h;
    }

    uint32_t state_[8] = {0x6a09e667u, 0xbb67ae85u, 0x3c6ef372u, 0xa54ff53au,
                          0x510e527fu, 0x9b05688cu, 0x1f83d9abu, 0x5be0cd19u};
    uint8_t buffer_[64]{};
    size_t buffer_len_{0};
    uint64_t bit_len_{0};
};

std::string to_hex_lower(const uint8_t* data, size_t length) {
    static const char* digits = "0123456789abcdef";
    std::string out;
    out.reserve(length * 2);
    for (size_t i = 0; i < length; ++i) {
        out.push_back(digits[(data[i] >> 4) & 0x0F]);
        out.push_back(digits[data[i] & 0x0F]);
    }
    return out;
}
} // namespace

std::string PnpDriverArmer::sha256_hex(const uint8_t* data, size_t length) {
    if (data == nullptr && length != 0) return "";
    Sha256 hasher;
    if (length != 0) hasher.feed(data, length);
    uint8_t digest[32];
    hasher.finish(digest);
    return to_hex_lower(digest, sizeof(digest));
}

std::string PnpDriverArmer::sha256_file(const std::filesystem::path& path) {
    std::error_code ec;
    if (!std::filesystem::is_regular_file(path, ec) || ec) return "";

    std::ifstream in(path, std::ios::binary);
    if (!in.is_open()) return "";

    Sha256 hasher;
    std::vector<uint8_t> chunk(64 * 1024);
    while (in.good()) {
        in.read(reinterpret_cast<char*>(chunk.data()), static_cast<std::streamsize>(chunk.size()));
        const std::streamsize got = in.gcount();
        if (got > 0) hasher.feed(chunk.data(), static_cast<size_t>(got));
        if (got < static_cast<std::streamsize>(chunk.size())) break;
    }
    uint8_t digest[32];
    hasher.finish(digest);
    return to_hex_lower(digest, sizeof(digest));
}

// ---- NIC vendor families -----------------------------------------------------------
// Only the Realtek <-> Intel conflict is in scope for the boot-start election: those are
// the two families `critical_boot_drivers()` stages together and the pair that raced each
// other on the M71s. Broadcom/Atheros/... stay untouched by the demotion pass.
namespace {
const std::vector<std::string>& realtek_service_family() {
    static const std::vector<std::string> services = {
        "rt640x64", "rtump64x64", "rtux64w10", "rt64win7",
    };
    return services;
}

const std::vector<std::string>& intel_service_family() {
    static const std::vector<std::string> services = {
        "e1d68x64", "e1r68x64", "e1i68x64", "e2f68", "e1c",
    };
    return services;
}

bool service_in_family(const std::vector<std::string>& family, const std::string& service_name) {
    return std::any_of(family.begin(), family.end(), [&](const std::string& entry) {
        return string_iequal(entry, service_name);
    });
}

// Hardware-ID / description evidence for one vendor family. Everything is matched
// case-insensitively against the concatenated text of DriverDesc, MatchingDeviceId and
// ComponentId, so both the INF spelling (PCI\VEN_10EC) and the class-key spelling
// (pci\ven_10ec) are covered.
bool text_is_realtek(const std::string& text) {
    const std::string lower = to_lower_copy(text);
    return lower.find("ven_10ec") != std::string::npos ||
           lower.find("rtl8") != std::string::npos ||
           lower.find("realtek") != std::string::npos;
}

bool text_is_intel(const std::string& text) {
    const std::string lower = to_lower_copy(text);
    return lower.find("ven_8086") != std::string::npos ||
           lower.find("intel(r)") != std::string::npos ||
           lower.find("intel ethernet") != std::string::npos;
}
} // namespace

bool PnpDriverArmer::is_realtek_service_name(const std::string& service_name) {
    return service_in_family(realtek_service_family(), service_name);
}

bool PnpDriverArmer::is_intel_service_name(const std::string& service_name) {
    return service_in_family(intel_service_family(), service_name);
}

std::string PnpDriverArmer::nic_profile_name(NicBootProfile profile) {
    switch (profile) {
        case NicBootProfile::Auto: return "auto";
        case NicBootProfile::Realtek: return "realtek";
        case NicBootProfile::Intel: return "intel";
        case NicBootProfile::Multi: return "multi";
    }
    return "auto";
}

NicBootProfile PnpDriverArmer::parse_nic_profile(const std::string& text, bool* ok) {
    const std::string lower = to_lower_copy(text);
    if (ok) *ok = true;
    if (lower.empty() || lower == "auto") return NicBootProfile::Auto;
    if (lower == "realtek" || lower == "rtl") return NicBootProfile::Realtek;
    if (lower == "intel" || lower == "e1d") return NicBootProfile::Intel;
    if (lower == "multi" || lower == "multi-nic") return NicBootProfile::Multi;
    if (ok) *ok = false;
    return NicBootProfile::Auto;
}

// ---- Offline PE identity: image reader, version resource, section table -----------
// Offline identity check for a staged .sys. Two things are extracted:
//
//   * the VS_VERSION_INFO resource -- the numeric dwFileVersionMS/LS + dwProductVersionMS/LS
//     from VS_FIXEDFILEINFO, plus the human readable StringFileInfo "FileVersion" /
//     "ProductVersion" strings when the resource ships them;
//   * the Section Table, so an incident instruction pointer (the M71s stop 0xA offset
//     0xE534) can be attributed to .text instead of being assumed to be code.
//
// Deliberately tolerant: anything that is not a PE image, has no version resource or is
// too large to be a driver binary yields an empty/invalid result and the caller reports
// "unknown".
namespace {

constexpr size_t kInvalidPeOffset = static_cast<size_t>(-1);

constexpr size_t pe_align4(size_t value) { return (value + 3u) & ~static_cast<size_t>(3u); }

// Read a whole PE image into `out` with the same bounds the version reader has always
// used (>= 0x40 so e_lfanew is addressable, <= 64 MiB so a bogus size cannot OOM).
bool pe_read_image_bytes(const std::filesystem::path& path, std::vector<uint8_t>* out) {
    if (out == nullptr) return false;
    out->clear();
    std::error_code ec;
    if (!std::filesystem::is_regular_file(path, ec)) return false;
    const std::uintmax_t size = std::filesystem::file_size(path, ec);
    if (ec || size < 0x40 || size > 64ull * 1024ull * 1024ull) return false;

    std::ifstream in(path, std::ios::binary);
    if (!in.is_open()) return false;
    out->assign(static_cast<size_t>(size), 0);
    in.read(reinterpret_cast<char*>(out->data()), static_cast<std::streamsize>(out->size()));
    if (in.gcount() != static_cast<std::streamsize>(out->size())) {
        out->clear();
        return false;
    }
    return true;
}

// MZ header -> PE\0\0 at e_lfanew; returns the signature offset or kInvalidPeOffset.
size_t pe_signature_offset(const std::vector<uint8_t>& bytes) {
    if (bytes.size() < 0x40) return kInvalidPeOffset;
    if (bytes[0] != 'M' || bytes[1] != 'Z') return kInvalidPeOffset;
    const uint32_t pe_off = static_cast<uint32_t>(bytes[0x3C]) |
                            (static_cast<uint32_t>(bytes[0x3D]) << 8) |
                            (static_cast<uint32_t>(bytes[0x3E]) << 16) |
                            (static_cast<uint32_t>(bytes[0x3F]) << 24);
    if (static_cast<size_t>(pe_off) + 4 > bytes.size()) return kInvalidPeOffset;
    if (!(bytes[pe_off] == 'P' && bytes[pe_off + 1] == 'E' &&
          bytes[pe_off + 2] == 0 && bytes[pe_off + 3] == 0)) {
        return kInvalidPeOffset;
    }
    return pe_off;
}

uint16_t pe_rd16(const std::vector<uint8_t>& bytes, size_t at) {
    if (at + 2 > bytes.size()) return 0;
    return static_cast<uint16_t>(bytes[at]) | (static_cast<uint16_t>(bytes[at + 1]) << 8);
}

uint32_t pe_rd32(const std::vector<uint8_t>& bytes, size_t at) {
    if (at + 4 > bytes.size()) return 0;
    return static_cast<uint32_t>(bytes[at]) | (static_cast<uint32_t>(bytes[at + 1]) << 8) |
           (static_cast<uint32_t>(bytes[at + 2]) << 16) |
           (static_cast<uint32_t>(bytes[at + 3]) << 24);
}

std::string pe_format_version(uint32_t ms, uint32_t ls) {
    return std::to_string(ms >> 16) + "." + std::to_string(ms & 0xFFFF) + "." +
           std::to_string(ls >> 16) + "." + std::to_string(ls & 0xFFFF);
}

// UTF-16LE -> ASCII. StringFileInfo keys/values are ASCII in every driver we care about;
// anything else becomes '?' instead of corrupting the report. When `next` is given it is
// set to the byte after the terminating NUL so the caller can continue walking.
std::string pe_utf16_to_ascii(const std::vector<uint8_t>& bytes, size_t begin, size_t end,
                              size_t* next) {
    std::string out;
    size_t i = begin;
    while (i + 1 < end) {
        const uint16_t ch = static_cast<uint16_t>(bytes[i]) |
                            (static_cast<uint16_t>(bytes[i + 1]) << 8);
        i += 2;
        if (ch == 0) break;
        out.push_back((ch >= 0x20 && ch < 0x7F) ? static_cast<char>(ch) : '?');
    }
    if (next != nullptr) *next = i;
    return out;
}

// Recursive VS_VERSION_INFO walker: collects the StringFileInfo "FileVersion" /
// "ProductVersion" strings. `ancestors` carries the keys of the enclosing nodes so a
// same-named key outside StringFileInfo can never be mistaken for a version.
void pe_walk_version_strings(const std::vector<uint8_t>& bytes, size_t node_off,
                             const std::vector<std::string>& ancestors, PeVersionInfo* info) {
    if (info == nullptr) return;
    if (node_off + 6 > bytes.size()) return;
    const uint32_t wLength = pe_rd16(bytes, node_off);
    const uint32_t wValueLength = pe_rd16(bytes, node_off + 2);
    const uint32_t wType = pe_rd16(bytes, node_off + 4);
    if (wLength < 6 || static_cast<size_t>(wLength) > bytes.size() - node_off) return;
    const size_t node_end = node_off + wLength;

    size_t after_key = 0;
    const std::string key = pe_utf16_to_ascii(bytes, node_off + 6, node_end, &after_key);
    if (after_key <= node_off || after_key >= node_end) return;

    size_t value_off = node_off + pe_align4(after_key - node_off);
    if (value_off >= node_end) return;

    // wValueLength is in characters (x2 bytes) for text nodes and in bytes for binary ones.
    size_t children_off = value_off;
    if (wValueLength > 0) {
        const size_t value_bytes = (wType == 1)
                                       ? static_cast<size_t>(wValueLength) * 2u
                                       : static_cast<size_t>(wValueLength);
        if (value_bytes > node_end - value_off) return;
        children_off = value_off + value_bytes;
    }
    children_off = node_off + pe_align4(children_off - node_off);
    if (children_off > node_end) children_off = node_end;

    if (wType == 1 && wValueLength > 0 &&
        (key == "FileVersion" || key == "ProductVersion")) {
        const bool under_string_file_info =
            std::find(ancestors.begin(), ancestors.end(), "StringFileInfo") != ancestors.end();
        if (under_string_file_info) {
            const size_t value_bytes = static_cast<size_t>(wValueLength) * 2u;
            if (value_bytes <= bytes.size() - value_off) {
                std::string text = pe_utf16_to_ascii(bytes, value_off, value_off + value_bytes,
                                                     nullptr);
                if (key == "FileVersion") {
                    if (info->file_version_string.empty()) info->file_version_string = text;
                } else if (info->product_version_string.empty()) {
                    info->product_version_string = text;
                }
            }
        }
    }

    std::vector<std::string> here = ancestors;
    here.push_back(key);

    size_t child = children_off;
    while (child + 6 <= node_end) {
        const uint32_t child_len = pe_rd16(bytes, child);
        if (child_len < 6 || static_cast<size_t>(child_len) > node_end - child) break;
        pe_walk_version_strings(bytes, child, here, info);
        const size_t next = pe_align4(child + child_len);
        if (next <= child) break;
        child = next;
    }
}

// The literal L"VS_VERSION_INFO" (NUL terminated) as it appears inside the resource.
const uint8_t kVsVersionInfoKey[] = {
    'V', 0, 'S', 0, '_', 0, 'V', 0, 'E', 0, 'R', 0, 'S', 0, 'I', 0, 'O', 0,
    'N', 0, '_', 0, 'I', 0, 'N', 0, 'F', 0, 'O', 0, 0, 0
};

PeVersionInfo pe_parse_version_info(const std::vector<uint8_t>& bytes) {
    PeVersionInfo info;
    if (pe_signature_offset(bytes) == kInvalidPeOffset) return info;

    // The version resource is the only place in a PE image where the 0xFEEF04BD
    // signature is followed by 0x00010000 (dwStrucVersion), so a bounded linear scan
    // finds it without having to walk the .rsrc directory tree.
    bool have_fixed = false;
    for (size_t i = 0; i + 24 <= bytes.size(); i += 4) {
        if (pe_rd32(bytes, i) != 0xFEEF04BDu || pe_rd32(bytes, i + 4) != 0x00010000u) continue;
        info.file_version = pe_format_version(pe_rd32(bytes, i + 8), pe_rd32(bytes, i + 12));
        info.product_version =
            pe_format_version(pe_rd32(bytes, i + 16), pe_rd32(bytes, i + 20));
        have_fixed = true;
        break;
    }
    if (!have_fixed) return info;
    info.valid = true;

    // StringFileInfo lives under the root VS_VERSION_INFO node that owns the blob above;
    // locate that node by its key and confirm it really contains the fixed info before
    // trusting the walk.
    for (size_t i = 6; i + sizeof(kVsVersionInfoKey) <= bytes.size(); ++i) {
        if (std::memcmp(&bytes[i], kVsVersionInfoKey, sizeof(kVsVersionInfoKey)) != 0) continue;
        const size_t root = i - 6;
        const uint32_t wLength = pe_rd16(bytes, root);
        if (wLength < 6 || static_cast<size_t>(wLength) > bytes.size() - root) break;
        const size_t value_off = root + pe_align4(6 + sizeof(kVsVersionInfoKey));
        if (pe_rd32(bytes, value_off) != 0xFEEF04BDu) continue;
        pe_walk_version_strings(bytes, root, {}, &info);
        break;
    }
    return info;
}

// Section Table walk (IMAGE_SECTION_HEADER, 40 bytes each, right after the optional
// header). Requires the optional-header magic so a PE signature inside arbitrary data
// cannot masquerade as an image with sections.
std::vector<PeSection> pe_parse_sections(const std::vector<uint8_t>& bytes) {
    std::vector<PeSection> sections;
    const size_t pe_off = pe_signature_offset(bytes);
    if (pe_off == kInvalidPeOffset) return sections;
    const size_t coff = pe_off + 4;
    if (coff + 20 > bytes.size()) return sections;

    const uint16_t section_count = pe_rd16(bytes, coff + 2);
    const uint16_t optional_size = pe_rd16(bytes, coff + 16);
    if (section_count == 0 || section_count > 96) return sections;

    const size_t optional = coff + 20;
    if (optional + 2 > bytes.size()) return sections;
    const uint16_t magic = pe_rd16(bytes, optional);
    if (magic != 0x10B && magic != 0x20B) return sections;

    const size_t table = optional + optional_size;
    if (table + static_cast<size_t>(section_count) * 40u > bytes.size()) return sections;

    sections.reserve(section_count);
    for (uint16_t i = 0; i < section_count; ++i) {
        const size_t entry = table + static_cast<size_t>(i) * 40u;
        PeSection section;
        for (size_t k = 0; k < 8; ++k) {
            const uint8_t c = bytes[entry + k];
            if (c == 0) break;
            section.name.push_back((c >= 0x20 && c < 0x7F) ? static_cast<char>(c) : '?');
        }
        section.virtual_size = pe_rd32(bytes, entry + 8);
        section.virtual_address = pe_rd32(bytes, entry + 12);
        section.raw_size = pe_rd32(bytes, entry + 16);
        section.characteristics = pe_rd32(bytes, entry + 36);
        sections.push_back(std::move(section));
    }
    return sections;
}

std::string read_pe_version_string(const std::filesystem::path& path) {
    std::vector<uint8_t> bytes;
    if (!pe_read_image_bytes(path, &bytes)) return "";
    return pe_parse_version_info(bytes).file_version;
}

// Active ControlSet name ("ControlSet001" / "CurrentControlSet") resolved from
// Select\Current, with the same fallbacks the arming pass uses. "" when none resolve.
std::string regf_control_set_name(const std::vector<uint8_t>& hive, const std::string& hint) {
    const uint32_t root = regf_root_offset(hive);
    if (root == 0xFFFFFFFF) return "";

    std::string cs = hint;
    if (cs.empty()) {
        const uint32_t select_off = regf_find_subkey(hive, root, "Select");
        uint32_t current = 0;
        if (select_off != 0xFFFFFFFF &&
            regf_get_dword(hive, select_off, "Current", &current) && current > 0) {
            char buf[32];
            std::snprintf(buf, sizeof(buf), "ControlSet%03u", current);
            cs = buf;
        }
    }

    if (!cs.empty() && regf_find_subkey(hive, root, cs) != 0xFFFFFFFF) return cs;
    if (regf_find_subkey(hive, root, "ControlSet001") != 0xFFFFFFFF) return "ControlSet001";
    if (regf_find_subkey(hive, root, "CurrentControlSet") != 0xFFFFFFFF) return "CurrentControlSet";
    return "";
}

// ---- NIC vendor evidence -----------------------------------------------------------
// Which vendor families the image itself proves are wired up, in two strictly separated
// tiers:
//
//   * Tier A ("hw_*") -- the adapter instances the Windows installer left under
//     Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}\<Index>, i.e. exactly the
//     devices the PnP manager enumerated as Network Adapters. This is the ONLY source
//     that counts as hardware: nothing outside that one class key is ever read, so a
//     chipset devnode (the Intel H61 PCI\VEN_8086 SMBus/LPC devices under Enum\PCI) or
//     any other parent PCI device can never be mistaken for a NIC.
//   * Tier B ("pkg_*") -- the Class = Net packages the DriverStore harvest found. A
//     staged package proves Windows once carried a driver, not that the silicon is on
//     the board, so it may only break a tie when Tier A says nothing at all.
//
// Used by both the profile election and the offline inspector so the two can never
// disagree about what the image contains.
struct NicVendorEvidence {
    bool hw_realtek{false};
    bool hw_intel{false};
    bool pkg_realtek{false};
    bool pkg_intel{false};

    bool realtek() const { return hw_realtek || pkg_realtek; }
    bool intel() const { return hw_intel || pkg_intel; }
    // True once a Net class adapter instance named a vendor family.
    bool has_hardware_evidence() const { return hw_realtek || hw_intel; }
};

void note_vendor_text(NicVendorEvidence& ev, const std::string& text, bool from_net_class) {
    if (text.empty()) return;
    bool& realtek = from_net_class ? ev.hw_realtek : ev.pkg_realtek;
    bool& intel = from_net_class ? ev.hw_intel : ev.pkg_intel;
    if (text_is_realtek(text)) realtek = true;
    if (text_is_intel(text)) intel = true;
}

// A Net class instance carries the miniport service it bound to (Service = rt640x64 /
// e1d68x64), which is exact family evidence that needs no DriverDesc spelling at all.
void note_service_family(NicVendorEvidence& ev, const std::string& service, bool from_net_class) {
    if (service.empty()) return;
    bool& realtek = from_net_class ? ev.hw_realtek : ev.pkg_realtek;
    bool& intel = from_net_class ? ev.hw_intel : ev.pkg_intel;
    if (PnpDriverArmer::is_realtek_service_name(service)) realtek = true;
    if (PnpDriverArmer::is_intel_service_name(service)) intel = true;
}

NicVendorEvidence collect_nic_vendor_evidence(const std::vector<uint8_t>& hive,
                                              const std::string& control_set_hint,
                                              const std::vector<NdisPackageInfo>& harvested) {
    NicVendorEvidence ev;

    // Tier A -- Network Adapter instances under Control\Class\{4d36e972-...} and nothing
    // else. Never Enum\PCI, never CriticalDeviceDatabase, never a parent devnode.
    const std::string cs = regf_control_set_name(hive, control_set_hint);
    if (!cs.empty()) {
        const uint32_t class_off = regf_open_path(
            hive, regf_root_offset(hive),
            cs + "\\Control\\Class\\" + NETWORK_CLASS_GUID);
        if (class_off != 0xFFFFFFFF) {
            regf_walk_subkeys(hive, class_off, [&](uint32_t instance_off) -> bool {
                std::string text = regf_get_string(hive, instance_off, "DriverDesc");
                text += " ";
                text += regf_get_string(hive, instance_off, "MatchingDeviceId");
                text += " ";
                text += regf_get_string(hive, instance_off, "ComponentId");
                note_vendor_text(ev, text, true);
                note_service_family(ev, regf_get_string(hive, instance_off, "Service"), true);
                return true; // keep walking -- we want every instance, not the first match
            });
        }
    }

    // Tier B -- DriverStore packages only.
    for (const auto& pkg : harvested) {
        note_service_family(ev, pkg.service_name, false);
        for (const auto& id : pkg.hardware_ids) note_vendor_text(ev, id, false);
    }

    return ev;
}

// Resolve NicBootProfile::Auto from Tier A (Net class adapter instances) alone.
// Returns NicBootProfile::Auto when no Net class instance names a vendor, which is the
// signal that the DriverStore fallback below may be consulted.
NicBootProfile elect_tier_a_profile(const NicVendorEvidence& ev) {
    if (ev.hw_realtek && ev.hw_intel) return NicBootProfile::Multi;
    if (ev.hw_realtek) return NicBootProfile::Realtek;
    if (ev.hw_intel) return NicBootProfile::Intel;
    return NicBootProfile::Auto;
}

// Human label for the Tier A verdict used in the stale-pin eviction log line
// ("Conflicting/stale profile pin 'intel' evicted by Tier A Realtek evidence").
const char* tier_a_profile_label(NicBootProfile profile) noexcept {
    switch (profile) {
        case NicBootProfile::Realtek: return "Realtek";
        case NicBootProfile::Intel:   return "Intel";
        case NicBootProfile::Multi:   return "Multi";
        case NicBootProfile::Auto:    break;
    }
    return "Auto";
}

// Resolve NicBootProfile::Auto from the evidence above.
NicBootProfile elect_nic_boot_profile(const NicVendorEvidence& ev) {
    // Tier A wins outright: the silicon that is actually wired up decides which miniport
    // owns Phase 0, whatever the DriverStore happens to carry. A net-class Realtek adapter
    // therefore resolves to Realtek even on an image that also stages Intel's inbox
    // e1d68x64 package -- which is exactly how rt640x64 used to end up demoted to
    // Start = 3 on a single-vendor Realtek board (M71s RTL8111E: image never boots again).
    const NicBootProfile tier_a = elect_tier_a_profile(ev);
    if (tier_a != NicBootProfile::Auto) return tier_a;

    // No Net class instance names a vendor. Packages may still elect Realtek (that choice
    // only ever demotes the Intel family) or Multi -- but never Intel: an Intel package in
    // the DriverStore is not proof of an Intel NIC, and electing Intel from it demotes
    // rt640x64 on the very boards this armer exists to protect. Keep every NIC driver
    // boot-started instead: demoting blind risks a 0x7B INACCESSIBLE_BOOT_DEVICE with
    // nothing left to diagnose, while pinning the profile is a one-flag fix.
    if (ev.pkg_realtek && ev.pkg_intel) return NicBootProfile::Multi;
    if (ev.pkg_realtek) return NicBootProfile::Realtek;
    return NicBootProfile::Multi;
}

// Profile a previous armer pass already wrote into this image, stored as
// <ControlSet>\Control\CobDiskless\NicBootProfile. Auto when absent or unreadable, so a
// missing/garbage pin can never force a demotion; re-arming an already-patched image
// reuses it instead of running a fresh (possibly different) election.
NicBootProfile read_pinned_nic_profile(const std::vector<uint8_t>& hive,
                                       const std::string& control_set_hint) {
    const std::string cs = regf_control_set_name(hive, control_set_hint);
    if (cs.empty()) return NicBootProfile::Auto;
    const uint32_t pin_off = regf_open_path(
        hive, regf_root_offset(hive), cs + "\\Control\\CobDiskless");
    if (pin_off == 0xFFFFFFFF) return NicBootProfile::Auto;

    const std::string pinned = regf_get_string(hive, pin_off, "NicBootProfile");
    if (pinned.empty()) return NicBootProfile::Auto;

    bool ok = false;
    const NicBootProfile parsed = PnpDriverArmer::parse_nic_profile(pinned, &ok);
    if (!ok || parsed == NicBootProfile::Auto) return NicBootProfile::Auto;
    return parsed;
}
} // namespace

// ---- Public entry points for the volume-root resolver ----------------------------
// Kept as PnpDriverArmer members so offline tooling (and the unit tests) can drive the
// exact same resolution the armer uses; the implementation lives with the other file
// helpers further up.

std::filesystem::path PnpDriverArmer::nt_volume_guid_root(const std::filesystem::path& hive_path) {
    std::string win_form = hive_path.string();
    for (char& c : win_form) {
        if (c == '/') c = '\\';
    }
    const size_t prefix = nt_volume_guid_prefix_len(win_form);
    if (prefix == 0) return {};
    std::string root = win_form.substr(0, prefix - 1);
    if (!root.empty() && root.back() == '\\') root.pop_back();
    return std::filesystem::path(root);
}

std::filesystem::path PnpDriverArmer::volume_root_from_hive(const std::filesystem::path& hive_path) {
    return resolve_volume_root_from_hive(hive_path);
}

NicBootProfile PnpDriverArmer::detect_nic_boot_profile(
    const std::vector<uint8_t>& hive_data,
    const std::vector<NdisPackageInfo>& harvested,
    const std::string& control_set
) {
    return elect_nic_boot_profile(collect_nic_vendor_evidence(hive_data, control_set, harvested));
}

std::string PnpDriverArmer::arch_name(GuestArch arch) {
    switch (arch) {
        case GuestArch::X64: return "x64";
        case GuestArch::X86: return "x86";
        case GuestArch::Unknown: break;
    }
    return "unknown";
}

GuestArch PnpDriverArmer::classify_pe_machine(uint16_t machine) {
    if (machine == PE_MACHINE_AMD64) return GuestArch::X64;
    if (machine == PE_MACHINE_I386) return GuestArch::X86;
    return GuestArch::Unknown;
}

GuestArch PnpDriverArmer::classify_volume_layout(bool has_syswow64, GuestArch pe_machine) {
    // 64-bit Windows always ships Windows\SysWOW64; a 32-bit install never does.
    if (has_syswow64) return GuestArch::X64;
    return pe_machine;
}

GuestArch PnpDriverArmer::detect_guest_arch(const std::filesystem::path& volume_path) {
    const std::filesystem::path windows_dir = locate_windows_dir(volume_path);
    if (windows_dir.empty()) return GuestArch::Unknown;

    const bool has_syswow64 = dir_exists_win32_or_std(windows_dir / "SysWOW64");

    GuestArch pe_machine = GuestArch::Unknown;
    uint16_t machine = 0;
    if (read_pe_machine(windows_dir / "System32" / "ntoskrnl.exe", &machine)) {
        pe_machine = classify_pe_machine(machine);
    }
    return classify_volume_layout(has_syswow64, pe_machine);
}

std::string PnpDriverArmer::os_family_name(GuestOsFamily family) {
    switch (family) {
        case GuestOsFamily::Legacy: return "legacy";
        case GuestOsFamily::Modern: return "modern";
        case GuestOsFamily::Unknown: break;
    }
    return "unknown";
}

// Windows 8 was the first release to drop the CriticalDeviceDatabase from the boot
// path; its RTM build number is the boundary between the two families.
namespace {
constexpr uint32_t NT62_BUILD_FLOOR = 9200; // Windows 8 RTM (Windows 7 is 7601)
} // namespace

GuestOsFamily PnpDriverArmer::classify_os_version(uint32_t major, uint32_t minor, uint32_t build) {
    if (major == 0) {
        // Build-number-only evidence (CurrentBuildNumber / kernel version resource).
        if (build == 0) return GuestOsFamily::Unknown;
        return build >= NT62_BUILD_FLOOR ? GuestOsFamily::Modern : GuestOsFamily::Legacy;
    }
    if (major <= 5) return GuestOsFamily::Legacy;              // NT 5.0/5.1/5.2: 2000 / XP / 2003
    if (major == 6) {
        if (minor >= 2) return GuestOsFamily::Modern;          // 6.2 / 6.3: Win8 / 8.1
        if (minor == 1) return GuestOsFamily::Legacy;          // 6.1: Win7 / 2008 R2
        // 6.0 (Vista / 2008) or a minor we never saw: the build number settles it.
        if (build != 0) return build >= NT62_BUILD_FLOOR ? GuestOsFamily::Modern
                                                         : GuestOsFamily::Legacy;
        return GuestOsFamily::Legacy;
    }
    return GuestOsFamily::Modern;                              // 10+ (Win10/11 report major 10)
}

GuestOsFamily PnpDriverArmer::detect_os_family_from_hive(const std::vector<uint8_t>& hive_data,
                                                         const std::string& control_set) {
    const uint32_t root = regf_root_offset(hive_data);
    if (root == 0xFFFFFFFF) return GuestOsFamily::Unknown;

    // 1. The active ControlSet's Control\Windows key (SYSTEM hive).
    std::string cs = control_set;
    if (cs.empty()) {
        const uint32_t select_off = regf_find_subkey(hive_data, root, "Select");
        uint32_t current = 0;
        if (select_off != 0xFFFFFFFF &&
            regf_get_dword(hive_data, select_off, "Current", &current) && current > 0) {
            char buf[32];
            std::snprintf(buf, sizeof(buf), "ControlSet%03u", current);
            cs = buf;
        }
    }

    uint32_t cs_off = cs.empty() ? 0xFFFFFFFF : regf_find_subkey(hive_data, root, cs);
    if (cs_off == 0xFFFFFFFF) cs_off = regf_find_subkey(hive_data, root, "ControlSet001");
    if (cs_off == 0xFFFFFFFF) cs_off = regf_find_subkey(hive_data, root, "CurrentControlSet");

    if (cs_off != 0xFFFFFFFF) {
        const uint32_t windows_off = regf_open_path(hive_data, cs_off, "Control\\Windows");
        const GuestOsFamily family = classify_from_version_key(hive_data, windows_off);
        if (family != GuestOsFamily::Unknown) return family;
    }

    // 2. Microsoft\Windows NT\CurrentVersion at the hive root -- this is where the
    //    SOFTWARE hive keeps the same evidence, so one reader serves both files.
    const uint32_t cv_off = regf_open_path(hive_data, root, "Microsoft\\Windows NT\\CurrentVersion");
    return classify_from_version_key(hive_data, cv_off);
}

GuestOsFamily PnpDriverArmer::detect_os_family_from_kernel(const std::filesystem::path& kernel_path) {
    std::ifstream in(kernel_path, std::ios::binary);
    if (!in.is_open()) return GuestOsFamily::Unknown;

    // Only trust a version blob that sits in a real PE image.
    uint8_t dos_header[64] = {0};
    in.read(reinterpret_cast<char*>(dos_header), sizeof(dos_header));
    if (in.gcount() != static_cast<std::streamsize>(sizeof(dos_header))) return GuestOsFamily::Unknown;
    if (dos_header[0] != 'M' || dos_header[1] != 'Z') return GuestOsFamily::Unknown;

    const uint32_t lfanew = read_le32(&dos_header[0x3C]);
    if (lfanew < 0x40 || lfanew > (1u << 20)) return GuestOsFamily::Unknown;
    in.seekg(static_cast<std::streamoff>(lfanew), std::ios::beg);
    uint8_t sig[4] = {0};
    in.read(reinterpret_cast<char*>(sig), sizeof(sig));
    if (in.gcount() != 4 || sig[0] != 'P' || sig[1] != 'E' || sig[2] != 0 || sig[3] != 0) {
        return GuestOsFamily::Unknown;
    }

    in.clear();
    in.seekg(0, std::ios::end);
    const std::streamoff file_size = in.tellg();
    if (file_size <= 0 || file_size > static_cast<std::streamoff>(64ll << 20)) {
        return GuestOsFamily::Unknown;
    }
    in.seekg(0, std::ios::beg);
    std::vector<uint8_t> bytes(static_cast<size_t>(file_size));
    in.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    if (in.gcount() != static_cast<std::streamsize>(bytes.size())) return GuestOsFamily::Unknown;

    // Every version resource embeds a VS_FIXEDFILEINFO block: signature 0xFEEF04BD
    // followed by dwStrucVersion 0x00010000, then dwFileVersionMS / dwFileVersionLS.
    for (size_t i = 0x40; i + 16 <= bytes.size(); i += 4) {
        if (read_le32(&bytes[i]) != 0xFEEF04BDu || read_le32(&bytes[i + 4]) != 0x00010000u) continue;

        const uint32_t ms = read_le32(&bytes[i + 8]);
        const uint32_t ls = read_le32(&bytes[i + 12]);
        const uint32_t major = ms >> 16;
        const uint32_t minor = ms & 0xFFFFu;
        const uint32_t build = ls >> 16;
        // Version sanity window: a stray match elsewhere in the image is discarded.
        if (major < 5 || major > 12 || minor > 32 || build > 2000000) continue;

        const GuestOsFamily family = classify_os_version(major, minor, build);
        if (family != GuestOsFamily::Unknown) return family;
    }
    return GuestOsFamily::Unknown;
}

GuestOsFamily PnpDriverArmer::detect_guest_os_family(const std::filesystem::path& volume_path) {
    const std::filesystem::path windows_dir = locate_windows_dir(volume_path);
    if (windows_dir.empty()) return GuestOsFamily::Unknown;
    const std::filesystem::path config_dir = windows_dir / "System32" / "config";

    // 1. SYSTEM hive: ControlSet00x\Control\Windows.
    auto system_hive = read_hive_file(config_dir / "SYSTEM");
    if (system_hive.is_ok()) {
        const GuestOsFamily family = detect_os_family_from_hive(system_hive.value());
        if (family != GuestOsFamily::Unknown) return family;
    }

    // 2. SOFTWARE hive: Microsoft\Windows NT\CurrentVersion.
    auto software_hive = read_hive_file(config_dir / "SOFTWARE");
    if (software_hive.is_ok()) {
        const GuestOsFamily family = detect_os_family_from_hive(software_hive.value());
        if (family != GuestOsFamily::Unknown) return family;
    }

    // 3. The version resource of the kernel that is actually going to boot.
    return detect_os_family_from_kernel(windows_dir / "System32" / "ntoskrnl.exe");
}

bool PnpDriverArmer::is_virtual_adapter_name(const std::string& adapter_name) {
    if (adapter_name.empty()) return false;
    const std::string lower = to_lower_copy(adapter_name);

    // ROOT\... hardware IDs / package names: software-enumerated devices that only
    // exist because a driver install created them (root\* in the blacklist).
    if (lower.find("root\\") != std::string::npos) return true;

    // Virtual / software adapters. Matched as substrings so that both the package
    // folder ("vboxnetadp.inf_amd64_...", "vmnetadapter.inf_...") and the service or
    // binary ("VBoxNetAdp", "vmnetadapter", "tap0901", "tuntap", "openvpn-dco",
    // "ndiswan", "rasman") are caught in any casing.
    static const char* const kVirtualAdapterTokens[] = {
        "vboxnetadp", // Oracle VirtualBox host-only adapter
        "vmnet",      // VMware VMnetNIC
        "tap",        // TAP-Windows / OpenVPN TAP (tap0901)
        "tun",        // TUN (tuntap) software adapter
        "openvpn",    // OpenVPN adapters
        "ndiswan",    // MS NDISWAN WAN miniport
        "rasman"      // RAS/PPP software link
    };
    for (const char* token : kVirtualAdapterTokens) {
        if (lower.find(token) != std::string::npos) return true;
    }
    return false;
}

bool PnpDriverArmer::is_physical_ndis_package(const NdisPackageInfo& package) {
    // Physical hardware is always identified by a PCI VEN/DEV hardware ID; a package
    // without one (INF missing/compressed, USB/RNDIS/ROOT-only device) is never armed
    // as boot-critical network hardware.
    if (package.hardware_ids.empty()) return false;
    // ROOT\ enumeration wins even for hybrid packages that also list a PCI ID.
    if (package.has_root_id) return false;
    if (is_virtual_adapter_name(package.package_dir_name)) return false;
    if (is_virtual_adapter_name(package.service_name)) return false;
    if (is_virtual_adapter_name(package.driver_file)) return false;
    return true;
}

std::vector<NdisPackageInfo> PnpDriverArmer::harvest_ndis_packages(
    const std::filesystem::path& volume_path,
    std::vector<std::string>* warnings
) {
    std::vector<NdisPackageInfo> packages;
    auto warn = [&](const std::string& w) {
        if (warnings) {
            warnings->push_back(w);
            Logger::default_logger().warn("PNP", "[PNP] " + w);
        }
    };

    const std::filesystem::path windows_dir = locate_windows_dir(volume_path);
    if (windows_dir.empty()) {
        warn("No Windows directory found, skipping NDIS driver harvest for: " + volume_path.string());
        return packages;
    }

    const std::filesystem::path file_repo = windows_dir / "System32" / "DriverStore" / "FileRepository";
    if (!dir_exists_win32_or_std(file_repo)) {
        warn("DriverStore FileRepository not found, no NDIS drivers harvested: " + file_repo.string());
        return packages;
    }

    const GuestArch guest_arch = detect_guest_arch(volume_path);
    std::vector<std::string> seen_services;

    for (const auto& entry : list_directory_entries(file_repo)) {
        if (!entry.is_directory) continue;
        const std::string folder_lower = to_lower_copy(entry.filename);

        NdisPackageInfo pkg;
        pkg.package_dir_name = entry.filename;
        pkg.package_dir = entry.path;
        pkg.arch = arch_from_package_name(folder_lower);

        // Architecture filter: a x64 guest stages _amd64_ packages, an x86 guest _x86_ ones.
        if (guest_arch != GuestArch::Unknown && pkg.arch != GuestArch::Unknown &&
            pkg.arch != guest_arch) {
            continue;
        }

        // 1. Classification: prefer the INF (Class = Net / Net ClassGuid).
        InfMetadata meta;
        bool have_inf = false;
        bool net_inf = false;
        for (const auto& file_entry : list_directory_entries(entry.path)) {
            if (file_entry.is_directory) continue;
            const std::string file_lower = to_lower_copy(file_entry.filename);
            if (!ends_with_ci(file_lower, ".inf")) continue;

            std::string text;
            if (!read_text_file(file_entry.path, &text)) continue;
            InfMetadata candidate = parse_ndis_inf(text);
            have_inf = true;
            if (candidate.class_net) {
                meta = std::move(candidate);
                pkg.inf_name = file_entry.filename;
                net_inf = true;
                break;
            }
        }
        if (!have_inf && !folder_name_looks_network(folder_lower)) {
            continue; // neither an INF nor a known network INF prefix
        }
        if (have_inf && !net_inf) {
            continue; // INF says Class != Net
        }

        // 2. Locate the .sys payload inside the package folder.
        std::vector<std::string> sys_files;
        for (const auto& file_entry : list_directory_entries(entry.path)) {
            if (file_entry.is_directory) continue;
            if (ends_with_ci(to_lower_copy(file_entry.filename), ".sys")) {
                sys_files.push_back(file_entry.filename);
            }
        }

        const std::string folder_stem = folder_lower.substr(0, folder_lower.find(".inf"));
        auto pick_sys = [&](const std::string& wanted) -> std::string {
            for (const auto& s : sys_files) {
                if (string_iequal(s, wanted)) return s;
            }
            return "";
        };

        std::string driver_file;
        if (!meta.service_name.empty()) {
            driver_file = pick_sys(meta.service_name + ".sys");
        }
        if (driver_file.empty()) {
            driver_file = pick_sys(folder_stem + ".sys");
        }
        if (driver_file.empty() && sys_files.size() == 1) {
            driver_file = sys_files.front();
        }

        // 3. Service name: INF AddService first, else the driver binary basename.
        std::string service_name = meta.service_name;
        if (service_name.empty() && !driver_file.empty()) {
            service_name = driver_file.substr(0, driver_file.find('.'));
        }
        if (service_name.empty()) {
            continue; // no service to arm
        }

        const std::string service_lower = to_lower_copy(service_name);
        if (std::find(seen_services.begin(), seen_services.end(), service_lower) != seen_services.end()) {
            continue; // already harvested from another package folder
        }

        pkg.service_name = service_name;
        pkg.driver_file = driver_file;
        if (!driver_file.empty()) {
            pkg.source_sys = entry.path / driver_file;
            pkg.image_path = "system32\\drivers\\" + driver_file;
        } else {
            pkg.image_path = "system32\\drivers\\" + service_name + ".sys";
        }
        pkg.group = meta.group.empty() ? std::string("NDIS") : meta.group;
        pkg.has_tag = meta.has_tag;
        pkg.tag = meta.tag;
        pkg.hardware_ids = meta.hardware_ids;
        pkg.has_root_id = meta.has_root_id;

        // 4. Physical-hardware gate: virtual / software adapters (VBoxNetAdp, vmnet,
        //    TAP/TUN, OpenVPN, NDISWAN, rasman, ROOT\*) and packages without a PCI
        //    VEN/DEV hardware ID are never boot-armed. Start = 0 plus a
        //    CriticalDeviceDatabase binding on them would only give the PnP manager
        //    something to fail on during Phase 0.
        if (!is_physical_ndis_package(pkg)) {
            Logger::default_logger().info(
                "PNP", "[PNP] Skipping virtual/non-physical adapter package " +
                       pkg.package_dir_name + " (service " + pkg.service_name +
                       (pkg.hardware_ids.empty() ? ", no PCI hardware ID" : "") +
                       (pkg.has_root_id ? ", ROOT\\ enumerated" : "") + ")");
            continue;
        }

        seen_services.push_back(service_lower);
        packages.push_back(std::move(pkg));
    }

    std::sort(packages.begin(), packages.end(),
              [](const NdisPackageInfo& a, const NdisPackageInfo& b) {
                  return a.package_dir_name < b.package_dir_name;
              });
    return packages;
}

bool PnpDriverArmer::stage_harvested_drivers(
    const std::filesystem::path& system32_dir,
    const std::vector<NdisPackageInfo>& packages,
    std::vector<std::string>& warnings,
    std::vector<std::string>* staged_out
) {
    if (packages.empty()) return true;

    std::filesystem::path drivers_dir;
    if (string_iequal(system32_dir.filename().string(), "drivers")) {
        drivers_dir = system32_dir;
    } else if (string_iequal(system32_dir.filename().string(), "System32")) {
        drivers_dir = system32_dir / "drivers";
    } else {
        drivers_dir = system32_dir / "System32" / "drivers";
    }

    if (!ensure_directory_win32_or_std(drivers_dir)) {
        warnings.push_back("Could not create drivers directory: " + drivers_dir.string());
        return false;
    }

    bool all_ok = true;
    for (const auto& pkg : packages) {
        if (pkg.driver_file.empty() || pkg.source_sys.empty()) continue;

        const std::filesystem::path target = drivers_dir / pkg.driver_file;
        if (file_exists_win32_or_std(target)) {
            // Safe staging: the guest already ships this binary. A pre-installed driver
            // is known to work on this image, so the inbox DriverStore copy is skipped
            // instead of overwriting it.
            Logger::default_logger().info("PNP", "[PNP] Driver already on guest disk, not overwriting: " +
                                          target.string());
            continue;
        }

        if (!file_exists_win32_or_std(pkg.source_sys)) {
            std::string warn = "Harvested driver payload missing: " + pkg.source_sys.string();
            warnings.push_back(warn);
            Logger::default_logger().warn("PNP", "[PNP] " + warn);
            all_ok = false;
            continue;
        }

        if (copy_file_win32_or_std(pkg.source_sys, target, false)) {
            if (staged_out) staged_out->push_back(pkg.driver_file);
            Logger::default_logger().info("PNP", "[PNP] Auto-staged harvested NDIS driver: " +
                                          pkg.driver_file + " (package " + pkg.package_dir_name + ")");
        } else {
            std::string warn = "Failed to stage harvested driver " + pkg.driver_file +
                               " into " + drivers_dir.string();
            warnings.push_back(warn);
            Logger::default_logger().warn("PNP", "[PNP] " + warn);
            all_ok = false;
        }
    }
    return all_ok;
}

namespace { // anonymous helpers resume (service configuration constants below)

// -----------------------------------------------------------------------------
// Windows 10/11 service configuration constants used when arming boot drivers
// -----------------------------------------------------------------------------
constexpr uint32_t SERVICE_START_BOOT     = 0x00000000; // SERVICE_BOOT_START
constexpr uint32_t SERVICE_START_DEMAND   = 0x00000003; // SERVICE_DEMAND_START
constexpr uint32_t SERVICE_START_DISABLED = 0x00000004; // SERVICE_DISABLED
constexpr uint32_t SERVICE_TYPE_KERNEL    = 0x00000001; // SERVICE_KERNEL_DRIVER
constexpr uint32_t SERVICE_ERROR_NORMAL   = 0x00000001; // SERVICE_ERROR_NORMAL

// REG_MULTI_SZ -- used for the empty PagingFiles / ExistingPageFiles lists that take
// the paging file off the iSCSI boot volume.
constexpr uint32_t REG_MULTI_SZ_TYPE      = 0x00000007; // REG_MULTI_SZ

// CM_SERVICE_NETWORK_BOOT_LOAD (BootFlags) -- promotes a driver to network-boot critical
// so it is loaded before the boot volume is available.
//
// Windows 10/11 ignores SYSTEM\CurrentControlSet\Control\CriticalDeviceDatabase (deprecated
// since Windows 8): without this flag the kernel still raises 0x7B INACCESSIBLE_BOOT_DEVICE
// even when Start = 0, because the NIC driver is never marked as boot-critical.
constexpr uint32_t CM_SERVICE_NETWORK_BOOT_LOAD = 0x00000001;

constexpr const char* NDIS_GROUP_NAME = "NDIS";

struct DriverServiceInfo {
    std::string name;
    std::string display_name;
    std::string group;
    std::string image_path;
    uint32_t type{SERVICE_TYPE_KERNEL};
    uint32_t start{SERVICE_START_BOOT};
    uint32_t error_control{SERVICE_ERROR_NORMAL};
    uint32_t boot_flags{CM_SERVICE_NETWORK_BOOT_LOAD};
};

DriverServiceInfo get_driver_service_info(std::string_view svc) {
    DriverServiceInfo info;
    info.name = std::string(svc);
    info.type = SERVICE_TYPE_KERNEL;               // SERVICE_KERNEL_DRIVER
    info.start = SERVICE_START_BOOT;               // SERVICE_BOOT_START
    info.error_control = SERVICE_ERROR_NORMAL;     // SERVICE_ERROR_NORMAL
    info.boot_flags = CM_SERVICE_NETWORK_BOOT_LOAD;

    if (string_iequal(svc, "rt640x64")) {
        info.display_name = "Realtek RT640 Gigabit Ethernet NIC Driver";
        info.group = "NDIS";
        info.image_path = "system32\\drivers\\rt640x64.sys";
    } else if (string_iequal(svc, "rtump64x64")) {
        info.display_name = "Realtek RTUMP USB Ethernet Driver";
        info.group = "NDIS";
        info.image_path = "system32\\drivers\\rtump64x64.sys";
    } else if (string_iequal(svc, "rtux64w10")) {
        info.display_name = "Realtek RTUX USB Ethernet Driver";
        info.group = "NDIS";
        info.image_path = "system32\\drivers\\rtux64w10.sys";
    } else if (string_iequal(svc, "rt64win7")) {
        info.display_name = "Realtek RT64 Ethernet Driver";
        info.group = "NDIS";
        info.image_path = "system32\\drivers\\rt64win7.sys";
    } else if (string_iequal(svc, "e1d68x64")) {
        info.display_name = "Intel(R) Gigabit Adapter NDIS 6.x Driver";
        info.group = "NDIS";
        info.image_path = "system32\\drivers\\e1d68x64.sys";
    } else if (string_iequal(svc, "e1r68x64")) {
        info.display_name = "Intel(R) Gigabit Network Connection Driver";
        info.group = "NDIS";
        info.image_path = "system32\\drivers\\e1r68x64.sys";
    } else if (string_iequal(svc, "e1i68x64")) {
        info.display_name = "Intel(R) PCI-E Gigabit Ethernet Driver";
        info.group = "NDIS";
        info.image_path = "system32\\drivers\\e1i68x64.sys";
    } else if (string_iequal(svc, "e2f68")) {
        info.display_name = "Intel(R) Ethernet Controller I225-V Driver";
        info.group = "NDIS";
        info.image_path = "system32\\drivers\\e2f68.sys";
    } else if (string_iequal(svc, "e1c")) {
        info.display_name = "Intel(R) Network Connection Driver";
        info.group = "NDIS";
        info.image_path = "system32\\drivers\\e1c.sys";
    } else if (string_iequal(svc, "b57nd64a")) {
        info.display_name = "Broadcom NetXtreme Gigabit Ethernet Driver";
        info.group = "NDIS";
        info.image_path = "system32\\drivers\\b57nd64a.sys";
    } else if (string_iequal(svc, "k1116x64")) {
        info.display_name = "Qualcomm Atheros Gigabit Ethernet Driver";
        info.group = "NDIS";
        info.image_path = "system32\\drivers\\k1116x64.sys";
    } else if (string_iequal(svc, "msiscsi")) {
        info.display_name = "Microsoft iSCSI Initiator Driver";
        info.group = "Boot Bus Extender";
        info.image_path = "system32\\drivers\\msiscsi.sys";
    } else if (string_iequal(svc, "Tcpip")) {
        info.display_name = "TCP/IP Protocol Driver";
        info.group = "PNP_TDI";
        info.image_path = "system32\\drivers\\tcpip.sys";
    } else if (string_iequal(svc, "NDIS")) {
        info.display_name = "Network Driver Interface Specification";
        info.group = "NDIS";
        info.image_path = "system32\\drivers\\ndis.sys";
    } else if (string_iequal(svc, "iscsiprt")) {
        info.display_name = "iSCSI Port Driver";
        info.group = "SCSI miniport";
        info.image_path = "system32\\drivers\\iscsiprt.sys";
    } else {
        info.display_name = std::string(svc) + " Driver";
        info.group = "NDIS";
        info.image_path = "system32\\drivers\\" + std::string(svc) + ".sys";
    }
    return info;
}

// A service belongs to the network boot path when its canonical load group is NDIS
// (NIC miniport drivers and NDIS itself). Those are the ones that must carry BootFlags.
bool is_network_boot_service(std::string_view svc) noexcept {
    return string_iequal(get_driver_service_info(svc).group, NDIS_GROUP_NAME);
}

// Core Windows iSCSI boot stack services that must be boot-start for a diskless hand-off.
// Resolved under the active ControlSet (Select\Current).
struct IscsiStackService {
    const char* service;
    bool require_network_boot_flag; // also needs BootFlags = CM_SERVICE_NETWORK_BOOT_LOAD
};

const std::vector<IscsiStackService>& iscsi_boot_stack_services() {
    static const std::vector<IscsiStackService> stack = {
        {"msiscsi", true},  // Start = 0, BootFlags = 0x00000001
        {"Tcpip",   false}, // Start = 0
        {"ndis",    false}, // Start = 0 (matches the on-disk NDIS key case-insensitively)
    };
    return stack;
}

// Appends an allocated cell (aligned to 8 bytes) to the hive buffer and returns cell offset (relative to 0x1000)
uint32_t allocate_cell(std::vector<uint8_t>& hive_data, size_t payload_size) {
    size_t cell_size = (4 + payload_size + 7) & ~7;
    uint32_t hbins_size = read_le32(&hive_data[0x28]);

    if (hive_data.size() > 0x1000 && 0x1000 + hbins_size > hive_data.size()) {
        hbins_size = static_cast<uint32_t>(hive_data.size() - 0x1000);
    }

    // 1. Scan existing hbins for a suitable free cell
    uint32_t scan_off = 0;
    while (scan_off + 0x20 < hbins_size && 0x1000 + scan_off + 0x20 <= hive_data.size()) {
        if (std::memcmp(&hive_data[0x1000 + scan_off], "hbin", 4) != 0) {
            break;
        }
        uint32_t hbin_len = read_le32(&hive_data[0x1000 + scan_off + 0x08]);
        if (hbin_len < 0x20 || scan_off + hbin_len > hbins_size) {
            break;
        }

        uint32_t cell_cursor = scan_off + 0x20;
        uint32_t hbin_end = scan_off + hbin_len;

        while (cell_cursor + 4 <= hbin_end && 0x1000 + cell_cursor + 4 <= hive_data.size()) {
            int32_t raw_csize = static_cast<int32_t>(read_le32(&hive_data[0x1000 + cell_cursor]));
            if (raw_csize == 0) break;

            if (raw_csize > 0) {
                uint32_t free_len = static_cast<uint32_t>(raw_csize);
                if (free_len < 8 || cell_cursor + free_len > hbin_end) break;
                if (free_len >= cell_size) {
                    if (free_len >= cell_size + 8) {
                        uint32_t rem = free_len - static_cast<uint32_t>(cell_size);
                        write_le32(&hive_data[0x1000 + cell_cursor], static_cast<uint32_t>(-static_cast<int32_t>(cell_size)));
                        write_le32(&hive_data[0x1000 + cell_cursor + cell_size], rem);
                    } else {
                        write_le32(&hive_data[0x1000 + cell_cursor], static_cast<uint32_t>(-raw_csize));
                    }
                    std::memset(&hive_data[0x1000 + cell_cursor + 4], 0, cell_size - 4);
                    return cell_cursor;
                }
                cell_cursor += free_len;
            } else {
                uint32_t alloc_len = static_cast<uint32_t>(-raw_csize);
                if (alloc_len < 8 || cell_cursor + alloc_len > hbin_end) break;
                cell_cursor += alloc_len;
            }
        }

        scan_off += hbin_len;
    }

    // 2. No free cell found: allocate a new 4096-aligned hbin chunk
    size_t needed_hbin = (0x20 + cell_size + 4095) & ~4095;
    uint32_t new_hbin_off = hbins_size;
    size_t needed_total = 0x1000 + new_hbin_off + needed_hbin;

    if (needed_total > hive_data.size()) {
        hive_data.resize(needed_total, 0);
    }

    std::memcpy(&hive_data[0x1000 + new_hbin_off], "hbin", 4);
    write_le32(&hive_data[0x1000 + new_hbin_off + 0x04], new_hbin_off);
    write_le32(&hive_data[0x1000 + new_hbin_off + 0x08], static_cast<uint32_t>(needed_hbin));

    uint32_t allocated_cell_off = new_hbin_off + 0x20;
    write_le32(&hive_data[0x1000 + allocated_cell_off], static_cast<uint32_t>(-static_cast<int32_t>(cell_size)));
    std::memset(&hive_data[0x1000 + allocated_cell_off + 4], 0, cell_size - 4);

    if (needed_hbin > 0x20 + cell_size + 4) {
        uint32_t rem_off = allocated_cell_off + static_cast<uint32_t>(cell_size);
        uint32_t rem_size = static_cast<uint32_t>(needed_hbin - (0x20 + cell_size));
        write_le32(&hive_data[0x1000 + rem_off], rem_size);
    }

    uint32_t new_total_hbins = new_hbin_off + static_cast<uint32_t>(needed_hbin);
    write_le32(&hive_data[0x28], new_total_hbins);

    return allocated_cell_off;
}

} // namespace

std::string PnpDriverArmReport::summary() const {
    std::ostringstream ss;
    ss << "=== CobDiskless PNP Driver Arming Report ===\n";
    ss << "Target Path:       " << target_path.string() << "\n";
    ss << "Status:            " << (success ? "SUCCESS" : "SKIPPED / PENDING") << "\n";
    if (!control_set.empty()) {
        ss << "Active ControlSet: " << control_set << "\n";
    }
    ss << "Network BootFlags: " << (boot_flags_armed ? "ARMED (0x1)" : "NOT ARMED") << "\n";
    ss << "iSCSI Boot Stack:  " << (iscsi_stack_armed ? "ARMED (Start=0)" : "NOT ARMED") << "\n";
    if (crash_dump_disabled || paging_files_cleared || tcpip_offload_disabled || vbox_lwf_disabled ||
        disk_timeout_armed) {
        ss << "Stage 15 Crash Control: " << (crash_dump_disabled ? "DISABLED (CrashDumpEnabled=0)" : "NOT DISABLED") << "\n";
        ss << "Stage 15 Paging File:   " << (paging_files_cleared ? "CLEARED (PagingFiles empty)" : "NOT CLEARED") << "\n";
        ss << "Stage 15 Tcpip Offload: " << (tcpip_offload_disabled ? "KILLED (DisableTaskOffload=1)" : "NOT KILLED") << "\n";
        ss << "Stage 15 VBoxNetLwf:    " << (vbox_lwf_disabled ? "NEUTRALISED (Start=4 / absent)" : "ACTIVE") << "\n";
        ss << "Stage 15 disk Timeout:  " << (disk_timeout_armed ? "EXTENDED (TimeOutValue=60)" : "NOT EXTENDED") << "\n";
    }
    ss << "Armed Services (" << armed_services.size() << "): ";
    for (size_t i = 0; i < armed_services.size(); ++i) {
        if (i > 0) ss << ", ";
        ss << armed_services[i];
    }
    ss << "\n";
    if (!modified_services.empty()) {
        ss << "Modified Keys (" << modified_services.size() << "): ";
        for (size_t i = 0; i < modified_services.size(); ++i) {
            if (i > 0) ss << ", ";
            ss << modified_services[i];
        }
        ss << "\n";
    }
    if (!injected_services.empty()) {
        ss << "Injected Keys (" << injected_services.size() << "): ";
        for (size_t i = 0; i < injected_services.size(); ++i) {
            if (i > 0) ss << ", ";
            ss << injected_services[i];
        }
        ss << "\n";
    }
    if (!missing_services.empty()) {
        ss << "Unmatched Drivers (" << missing_services.size() << "): ";
        for (size_t i = 0; i < missing_services.size(); ++i) {
            if (i > 0) ss << ", ";
            ss << missing_services[i];
        }
        ss << "\n";
    }
    if (!cddb_bindings.empty()) {
        ss << "Injected CDDB Bindings (" << cddb_bindings.size() << "): ";
        for (size_t i = 0; i < cddb_bindings.size(); ++i) {
            if (i > 0) ss << ", ";
            ss << cddb_bindings[i];
        }
        ss << "\n";
    }
    if (!guest_arch.empty()) {
        ss << "Guest Arch:        " << guest_arch << "\n";
    }
    if (!guest_os_family.empty()) {
        ss << "Guest OS Family:   " << guest_os_family << "\n";
    }
    if (!nic_profile.empty()) {
        ss << "NIC Boot Profile:  " << nic_profile << "\n";
    }
    if (!demoted_services.empty()) {
        ss << "Demoted Services (" << demoted_services.size() << ", Start=3): ";
        for (size_t i = 0; i < demoted_services.size(); ++i) {
            if (i > 0) ss << ", ";
            ss << demoted_services[i];
        }
        ss << "\n";
    }
    if (!service_parameters_purged.empty()) {
        ss << "Purged Service Parameters (" << service_parameters_purged.size() << "): ";
        for (size_t i = 0; i < service_parameters_purged.size(); ++i) {
            if (i > 0) ss << ", ";
            ss << service_parameters_purged[i];
        }
        ss << "\n";
    }
    if (!cddb_purged.empty()) {
        ss << "Purged CDDB Keys (" << cddb_purged.size() << "): ";
        for (size_t i = 0; i < cddb_purged.size(); ++i) {
            if (i > 0) ss << ", ";
            ss << cddb_purged[i];
        }
        ss << "\n";
    }
    if (!harvested_packages.empty()) {
        ss << "Harvested NDIS Packages (" << harvested_packages.size() << "): ";
        for (size_t i = 0; i < harvested_packages.size(); ++i) {
            if (i > 0) ss << ", ";
            ss << harvested_packages[i];
        }
        ss << "\n";
    }
    if (!staged_binaries.empty()) {
        ss << "Staged Drivers (" << staged_binaries.size() << "): ";
        for (size_t i = 0; i < staged_binaries.size(); ++i) {
            if (i > 0) ss << ", ";
            ss << staged_binaries[i];
        }
        ss << "\n";
    }
    for (const auto& w : warnings) {
        ss << "  [WARN] " << w << "\n";
    }
    if (!message.empty()) {
        ss << "Message:           " << message << "\n";
    }
    return ss.str();
}

const std::vector<std::string>& PnpDriverArmer::critical_boot_services() {
    static const std::vector<std::string> services = {
        // Core iSCSI / Network
        "msiscsi",
        "Tcpip",
        "NDIS",
        "iscsiprt",
        // Intel NIC Drivers
        "e1d68x64",
        "e1r68x64",
        "e1i68x64",
        "e2f68",
        "e1c",
        // Realtek NIC Drivers
        "rt640x64",
        "rtump64x64",
        "rtux64w10",
        "rt64win7",
        // Broadcom / Atheros
        "b57nd64a",
        "k1116x64"
    };
    return services;
}

const std::vector<std::string>& PnpDriverArmer::critical_boot_drivers() {
    static const std::vector<std::string> drivers = {
        "rt640x64.sys",
        "e1d68x64.sys"
    };
    return drivers;
}

bool PnpDriverArmer::stage_critical_boot_drivers(
    const std::filesystem::path& system32_dir,
    std::vector<std::string>& warnings
) {
    std::filesystem::path drivers_dir = (system32_dir.filename() == "drivers") ?
                                        system32_dir :
                                        (system32_dir / "drivers");
    bool all_ok = true;
    for (const auto& drv : critical_boot_drivers()) {
        if (!verify_or_stage_driver_file(drivers_dir, drv, warnings)) {
            all_ok = false;
        }
    }
    return all_ok;
}

uint32_t PnpDriverArmer::calculate_regf_header_checksum(const uint8_t* header_bytes) {
    uint32_t checksum = 0;
    for (size_t i = 0; i < 0x1FC; i += 4) {
        checksum ^= read_le32(&header_bytes[i]);
    }
    return checksum;
}

Result<PnpDriverArmReport> PnpDriverArmer::arm_hive_buffer(
    std::vector<uint8_t>& hive_data,
    const std::vector<NdisPackageInfo>& harvested,
    GuestOsFamily os_family,
    NicBootProfile profile
) {
    if (hive_data.size() < 8192) {
        return Error(ErrorCode::InvalidConfiguration, "Hive buffer too small to be a valid Windows registry hive");
    }

    // Verify "regf" signature
    if (hive_data[0] != 'r' || hive_data[1] != 'e' || hive_data[2] != 'g' || hive_data[3] != 'f') {
        return Error(ErrorCode::InvalidConfiguration, "Invalid hive header: missing 'regf' signature");
    }

    // Verify "hbin" signature at offset 0x1000
    if (hive_data.size() < 0x1020 || std::memcmp(&hive_data[0x1000], "hbin", 4) != 0) {
        return Error(ErrorCode::InvalidConfiguration, "Invalid hive header: missing 'hbin' signature at offset 0x1000");
    }

    uint32_t root_cell_off = read_le32(&hive_data[0x24]);
    if (root_cell_off < 0x20 || 0x1000 + root_cell_off + 0x50 > hive_data.size()) {
        return Error(ErrorCode::InvalidConfiguration, "Invalid root cell offset in hive header");
    }

    // REGF base-block sequence numbers (RFC-style layout):
    //   0x04 Primary Sequence Number
    //   0x08 Secondary Sequence Number
    // A hive is CLEAN iff the two are equal. Windows leaves them unequal when it
    // shuts down dirty (Fast Startup / hiberboot, crash, or power loss), in which
    // case SYSTEM.LOG1 / SYSTEM.LOG2 hold records that the NT kernel will replay
    // over this file during HvLoadHive -- which would wipe anything we change
    // offline. Detect that state up front so we can force the header clean on
    // flush and report it instead of silently losing our writes on boot.
    const uint32_t primary_seq_on_entry = read_le32(&hive_data[0x04]);
    const uint32_t secondary_seq_on_entry = read_le32(&hive_data[0x08]);
    const bool hive_dirty_on_entry = (primary_seq_on_entry != secondary_seq_on_entry);

    auto get_cell_size = [&](uint32_t cell_off) -> size_t {
        if (cell_off > hive_data.size() || 0x1000 + cell_off + 4 > hive_data.size()) return 0;
        int32_t csize = static_cast<int32_t>(read_le32(&hive_data[0x1000 + cell_off]));
        if (csize >= 0) return 0; // Free cell
        size_t alloc_len = static_cast<size_t>(-csize);
        if (0x1000 + cell_off + alloc_len > hive_data.size() || alloc_len < 4) return 0;
        return alloc_len - 4;
    };

    auto get_cell_payload = [&](uint32_t cell_off) -> uint8_t* {
        if (get_cell_size(cell_off) == 0) return nullptr;
        return &hive_data[0x1000 + cell_off + 4];
    };

    uint8_t* root_nk = get_cell_payload(root_cell_off);
    if (!root_nk || read_le16(root_nk) != 0x6B6E) {
        return Error(ErrorCode::InvalidConfiguration, "Corrupted root cell: missing 'nk' signature");
    }

    // Helper to find a subkey cell by name inside an nk cell
    auto find_subkey = [&](uint32_t nk_cell_off, const std::string& name) -> uint32_t {
        return regf_find_subkey(hive_data, nk_cell_off, name);
    };

    // Helper to get all child subkey cells under an nk cell
    auto get_all_subkeys = [&](uint32_t nk_cell_off) -> std::vector<uint32_t> {
        return regf_list_subkeys(hive_data, nk_cell_off);
    };

    // Helper to find or create a subkey cell under an nk cell
    auto get_or_create_subkey = [&](uint32_t parent_nk_off, const std::string& name) -> uint32_t {
        uint32_t existing = find_subkey(parent_nk_off, name);
        if (existing != 0xFFFFFFFF) {
            return existing;
        }

        uint8_t* parent_nk = get_cell_payload(parent_nk_off);
        if (!parent_nk || read_le16(parent_nk) != 0x6B6E) return 0xFFFFFFFF;

        uint32_t subkey_count = read_le32(parent_nk + 0x14);
        uint32_t subkey_list_off = read_le32(parent_nk + 0x1C);

        uint32_t new_nk_off = allocate_cell(hive_data, 0x4C + name.size());
        uint8_t* new_nk = get_cell_payload(new_nk_off);
        if (!new_nk) return 0xFFFFFFFF;

        write_le16(new_nk + 0x00, 0x6B6E);
        write_le16(new_nk + 0x02, 0x0020);
        write_le32(new_nk + 0x10, parent_nk_off);
        write_le32(new_nk + 0x14, 0);
        write_le32(new_nk + 0x1C, 0xFFFFFFFF);
        write_le32(new_nk + 0x24, 0);
        write_le32(new_nk + 0x28, 0xFFFFFFFF);
        write_le16(new_nk + 0x48, static_cast<uint16_t>(name.size()));
        std::memcpy(new_nk + 0x4C, name.data(), name.size());

        std::string hash = name.substr(0, 4);
        while (hash.size() < 4) hash.push_back(' ');

        if (subkey_count == 0 || subkey_list_off == 0 || subkey_list_off == 0xFFFFFFFF) {
            uint32_t new_sl_off = allocate_cell(hive_data, 4 + 1 * 8);
            uint8_t* new_sl = get_cell_payload(new_sl_off);
            if (!new_sl) return 0xFFFFFFFF;

            write_le16(new_sl + 0x00, 0x666C);
            write_le16(new_sl + 0x02, 1);
            write_le32(new_sl + 0x04, new_nk_off);
            std::memcpy(new_sl + 0x08, hash.data(), 4);

            parent_nk = get_cell_payload(parent_nk_off);
            if (parent_nk) {
                write_le32(parent_nk + 0x14, 1);
                write_le32(parent_nk + 0x1C, new_sl_off);
                write_le32(parent_nk + 0x34, static_cast<uint32_t>(name.size()));
            }
        } else {
            uint8_t* old_sl = get_cell_payload(subkey_list_off);
            if (!old_sl) return 0xFFFFFFFF;
            uint16_t sig = read_le16(old_sl);
            uint16_t old_count = read_le16(old_sl + 0x02);

            if (sig == 0x666C || sig == 0x686C) {
                uint32_t new_sl_off = allocate_cell(hive_data, 4 + (old_count + 1) * 8);
                uint8_t* new_sl = get_cell_payload(new_sl_off);
                old_sl = get_cell_payload(subkey_list_off);
                if (!new_sl || !old_sl) return 0xFFFFFFFF;

                write_le16(new_sl + 0x00, sig);
                write_le16(new_sl + 0x02, old_count + 1);
                std::memcpy(new_sl + 0x04, old_sl + 0x04, old_count * 8);
                write_le32(new_sl + 0x04 + old_count * 8, new_nk_off);
                std::memcpy(new_sl + 0x08 + old_count * 8, hash.data(), 4);

                parent_nk = get_cell_payload(parent_nk_off);
                if (parent_nk) {
                    write_le32(parent_nk + 0x14, old_count + 1);
                    write_le32(parent_nk + 0x1C, new_sl_off);
                    uint32_t max_name = read_le32(parent_nk + 0x34);
                    write_le32(parent_nk + 0x34, std::max(max_name, static_cast<uint32_t>(name.size())));
                }
            } else if (sig == 0x696C) {
                uint32_t new_sl_off = allocate_cell(hive_data, 4 + (old_count + 1) * 4);
                uint8_t* new_sl = get_cell_payload(new_sl_off);
                old_sl = get_cell_payload(subkey_list_off);
                if (!new_sl || !old_sl) return 0xFFFFFFFF;

                write_le16(new_sl + 0x00, 0x696C);
                write_le16(new_sl + 0x02, old_count + 1);
                std::memcpy(new_sl + 0x04, old_sl + 0x04, old_count * 4);
                write_le32(new_sl + 0x04 + old_count * 4, new_nk_off);

                parent_nk = get_cell_payload(parent_nk_off);
                if (parent_nk) {
                    write_le32(parent_nk + 0x14, old_count + 1);
                    write_le32(parent_nk + 0x1C, new_sl_off);
                    uint32_t max_name = read_le32(parent_nk + 0x34);
                    write_le32(parent_nk + 0x34, std::max(max_name, static_cast<uint32_t>(name.size())));
                }
            } else if (sig == 0x6972) { // "ri" root index
                uint16_t ri_count = old_count;
                if (ri_count > 0) {
                    uint32_t last_leaf_off = read_le32(old_sl + 0x04 + (ri_count - 1) * 4);
                    uint8_t* last_leaf = get_cell_payload(last_leaf_off);
                    if (last_leaf) {
                        uint16_t leaf_sig = read_le16(last_leaf);
                        uint16_t leaf_count = read_le16(last_leaf + 0x02);
                        if (leaf_sig == 0x666C || leaf_sig == 0x686C) {
                            uint32_t new_leaf_off = allocate_cell(hive_data, 4 + (leaf_count + 1) * 8);
                            uint8_t* new_leaf = get_cell_payload(new_leaf_off);
                            last_leaf = get_cell_payload(last_leaf_off);
                            if (new_leaf && last_leaf) {
                                write_le16(new_leaf + 0x00, leaf_sig);
                                write_le16(new_leaf + 0x02, leaf_count + 1);
                                std::memcpy(new_leaf + 0x04, last_leaf + 0x04, leaf_count * 8);
                                write_le32(new_leaf + 0x04 + leaf_count * 8, new_nk_off);
                                std::memcpy(new_leaf + 0x08 + leaf_count * 8, hash.data(), 4);

                                old_sl = get_cell_payload(subkey_list_off);
                                if (old_sl) {
                                    write_le32(old_sl + 0x04 + (ri_count - 1) * 4, new_leaf_off);
                                }
                                parent_nk = get_cell_payload(parent_nk_off);
                                if (parent_nk) {
                                    write_le32(parent_nk + 0x14, subkey_count + 1);
                                    uint32_t max_name = read_le32(parent_nk + 0x34);
                                    write_le32(parent_nk + 0x34, std::max(max_name, static_cast<uint32_t>(name.size())));
                                }
                            }
                        }
                    }
                }
            }
        }
        return new_nk_off;
    };

    // Helper to get DWORD value from an nk cell
    auto get_dword_value = [&](uint32_t nk_cell_off, const std::string& val_name, uint32_t* out_val) -> bool {
        return regf_get_dword(hive_data, nk_cell_off, val_name, out_val);
    };

    // Helper to get string value from an nk cell (handles both ASCII and UTF-16LE)
    auto get_string_value = [&](uint32_t nk_cell_off, const std::string& val_name) -> std::string {
        return regf_get_string(hive_data, nk_cell_off, val_name);
    };

    // Helper to remove a child subkey from its parent's index.
    //
    // The deleted nk cell and the superseded index cell stay allocated but become
    // unreferenced, which is the normal outcome of an offline hive edit: nothing walks
    // the tree backwards and the allocator only hands out cells marked free. The
    // survivors keep their original (already sorted) index order, so the rebuilt flat
    // "lf" list stays valid for the binary search the NT hive loader performs.
    auto delete_subkey = [&](uint32_t parent_nk_off, uint32_t child_nk_off,
                             const std::string& child_name) -> bool {
        std::string actual_name;
        if (!regf_nk_name(hive_data, child_nk_off, &actual_name) ||
            !string_iequal(actual_name, child_name)) {
            return false; // refuse to unlink an offset that is not the key we were told about
        }

        uint8_t* parent_nk = get_cell_payload(parent_nk_off);
        if (!parent_nk || read_le16(parent_nk) != 0x6B6E) return false;

        const uint32_t subkey_count = read_le32(parent_nk + 0x14);
        const uint32_t subkey_list_off = read_le32(parent_nk + 0x1C);
        if (subkey_count == 0 || subkey_list_off == 0 || subkey_list_off == 0xFFFFFFFF) return false;

        std::vector<uint32_t> survivors = get_all_subkeys(parent_nk_off);
        auto doomed = std::find(survivors.begin(), survivors.end(), child_nk_off);
        if (doomed == survivors.end()) return false;
        survivors.erase(doomed);

        if (survivors.empty()) {
            parent_nk = get_cell_payload(parent_nk_off);
            if (!parent_nk) return false;
            write_le32(parent_nk + 0x14, 0);
            write_le32(parent_nk + 0x1C, 0xFFFFFFFF);
            return true;
        }

        uint32_t new_list_off = allocate_cell(hive_data, 4 + survivors.size() * 8);
        uint8_t* new_sl = get_cell_payload(new_list_off);
        if (!new_sl) return false;

        write_le16(new_sl + 0x00, 0x666C); // "lf"
        write_le16(new_sl + 0x02, static_cast<uint16_t>(survivors.size()));

        uint32_t max_name_len = 0;
        for (size_t i = 0; i < survivors.size(); ++i) {
            std::string survivor;
            const uint8_t* survivor_nk = nullptr;
            size_t survivor_len = 0;
            if (regf_cell(hive_data, survivors[i], &survivor_nk, &survivor_len) &&
                survivor_len >= 0x4C && read_le16(survivor_nk) == 0x6B6E) {
                uint16_t nlen = read_le16(survivor_nk + 0x48);
                if (static_cast<size_t>(0x4C) + nlen <= survivor_len) {
                    survivor.assign(reinterpret_cast<const char*>(survivor_nk + 0x4C), nlen);
                    max_name_len = std::max<uint32_t>(max_name_len, nlen);
                }
            }
            write_le32(new_sl + 0x04 + static_cast<uint32_t>(i) * 8, survivors[i]);
            char prefix[4] = {' ', ' ', ' ', ' '};
            for (size_t c = 0; c < survivor.size() && c < 4; ++c) {
                prefix[c] = survivor[c];
            }
            std::memcpy(new_sl + 0x08 + static_cast<uint32_t>(i) * 8, prefix, 4);
        }

        parent_nk = get_cell_payload(parent_nk_off);
        if (!parent_nk) return false;
        write_le32(parent_nk + 0x14, static_cast<uint32_t>(survivors.size()));
        write_le32(parent_nk + 0x1C, new_list_off);
        const uint32_t max_subkey_name = read_le32(parent_nk + 0x34);
        write_le32(parent_nk + 0x34, std::max(max_subkey_name, max_name_len));
        return true;
    };

    // Helper to remove one value from an nk cell.
    //
    // Same contract as delete_subkey: the vk cell and the superseded value list stay
    // allocated but unreferenced, the survivors keep their order (the value list has no
    // index to keep sorted) and the max-value-name hint is recomputed so a subsequent
    // reader never trusts a stale maximum.
    auto delete_value = [&](uint32_t nk_cell_off, const std::string& val_name) -> bool {
        uint8_t* nk = get_cell_payload(nk_cell_off);
        if (!nk || read_le16(nk) != 0x6B6E) return false;

        const uint32_t val_count = read_le32(nk + 0x24);
        const uint32_t val_list_off = read_le32(nk + 0x28);
        if (val_count == 0 || val_list_off == 0 || val_list_off == 0xFFFFFFFF) return false;

        uint8_t* vl = get_cell_payload(val_list_off);
        if (!vl) return false;

        std::vector<uint32_t> survivors;
        survivors.reserve(val_count);
        bool found = false;
        for (uint32_t i = 0; i < val_count; ++i) {
            const uint32_t vk_off = read_le32(vl + i * 4);
            uint8_t* vk = get_cell_payload(vk_off);
            if (!vk || read_le16(vk) != 0x6B76) continue;

            const uint16_t nlen = read_le16(vk + 0x02);
            std::string name(reinterpret_cast<const char*>(vk + 0x14), nlen);
            if (string_iequal(name, val_name)) {
                found = true;
                continue;
            }
            survivors.push_back(vk_off);
        }
        if (!found) return false;

        nk = get_cell_payload(nk_cell_off);
        if (!nk) return false;

        if (survivors.empty()) {
            write_le32(nk + 0x24, 0);
            write_le32(nk + 0x28, 0xFFFFFFFF);
            write_le32(nk + 0x3C, 0); // MaxKeyValueNameLength
            return true;
        }

        const uint32_t new_vlist_off = allocate_cell(hive_data, survivors.size() * 4);
        uint8_t* new_vl = get_cell_payload(new_vlist_off);
        if (!new_vl) return false;

        uint32_t max_value_name_len = 0;
        for (size_t i = 0; i < survivors.size(); ++i) {
            write_le32(new_vl + i * 4, survivors[i]);

            uint8_t* survivor_vk = get_cell_payload(survivors[i]);
            if (survivor_vk && read_le16(survivor_vk) == 0x6B76) {
                const uint16_t nlen = read_le16(survivor_vk + 0x02);
                max_value_name_len = std::max<uint32_t>(max_value_name_len, nlen);
            }
        }

        nk = get_cell_payload(nk_cell_off);
        if (!nk) return false;
        write_le32(nk + 0x24, static_cast<uint32_t>(survivors.size()));
        write_le32(nk + 0x28, new_vlist_off);
        write_le32(nk + 0x3C, max_value_name_len);
        return true;
    };

    // Helper to set or create a DWORD value on an nk cell
    auto set_or_create_dword = [&](uint32_t nk_cell_off, const std::string& val_name, uint32_t val) {
        uint8_t* nk = get_cell_payload(nk_cell_off);
        if (!nk || read_le16(nk) != 0x6B6E) return;

        uint32_t val_count = read_le32(nk + 0x24);
        uint32_t val_list_off = read_le32(nk + 0x28);

        if (val_count > 0 && val_list_off != 0 && val_list_off != 0xFFFFFFFF) {
            uint8_t* vl = get_cell_payload(val_list_off);
            if (vl) {
                for (uint32_t i = 0; i < val_count; ++i) {
                    uint32_t vk_off = read_le32(vl + i * 4);
                    uint8_t* vk = get_cell_payload(vk_off);
                    if (!vk || read_le16(vk) != 0x6B76) continue;

                    uint16_t nlen = read_le16(vk + 0x02);
                    std::string name(reinterpret_cast<const char*>(vk + 0x14), nlen);
                    if (string_iequal(name, val_name)) {
                        // Found existing value -> force to inline DWORD
                        write_le32(vk + 0x04, 0x80000004);
                        write_le32(vk + 0x08, val);
                        write_le32(vk + 0x0C, 4); // REG_DWORD
                        return;
                    }
                }
            }
        }

        // Value not found -> allocate new vk cell and new value list
        uint32_t vk_off = allocate_cell(hive_data, 20 + val_name.size());
        uint8_t* vk = get_cell_payload(vk_off);
        if (!vk) return;

        write_le16(vk + 0x00, 0x6B76); // "vk"
        write_le16(vk + 0x02, static_cast<uint16_t>(val_name.size()));
        write_le32(vk + 0x04, 0x80000004); // 4 bytes inline
        write_le32(vk + 0x08, val);
        write_le32(vk + 0x0C, 4); // REG_DWORD
        write_le16(vk + 0x10, 1); // ASCII
        write_le16(vk + 0x12, 0);
        std::memcpy(vk + 0x14, val_name.data(), val_name.size());

        // Allocate new value list cell
        uint32_t new_vlist_off = allocate_cell(hive_data, (val_count + 1) * 4);
        uint8_t* new_vl = get_cell_payload(new_vlist_off);
        if (!new_vl) return;

        if (val_count > 0 && val_list_off != 0 && val_list_off != 0xFFFFFFFF) {
            uint8_t* old_vl = get_cell_payload(val_list_off);
            if (old_vl) {
                std::memcpy(new_vl, old_vl, val_count * 4);
            }
        }
        write_le32(new_vl + val_count * 4, vk_off);

        // Update nk cell pointers
        nk = get_cell_payload(nk_cell_off);
        if (nk) {
            write_le32(nk + 0x24, val_count + 1);
            write_le32(nk + 0x28, new_vlist_off);
            uint32_t max_name = read_le32(nk + 0x3C);
            write_le32(nk + 0x3C, std::max(max_name, static_cast<uint32_t>(val_name.size())));
            uint32_t max_data = read_le32(nk + 0x40);
            write_le32(nk + 0x40, std::max(max_data, 4u));
        }
    };

    // Helper to set or create a string value on an nk cell (REG_SZ = 1, REG_EXPAND_SZ = 2)
    auto set_or_create_string = [&](uint32_t nk_cell_off, const std::string& val_name, const std::string& val, uint32_t reg_type = 1) {
        uint8_t* nk = get_cell_payload(nk_cell_off);
        if (!nk || read_le16(nk) != 0x6B6E) return;

        uint32_t val_count = read_le32(nk + 0x24);
        uint32_t val_list_off = read_le32(nk + 0x28);

        // UTF-16LE null-terminated data
        std::vector<uint8_t> u16_data;
        u16_data.reserve((val.size() + 1) * 2);
        for (char c : val) {
            u16_data.push_back(static_cast<uint8_t>(c));
            u16_data.push_back(0);
        }
        u16_data.push_back(0);
        u16_data.push_back(0);

        if (val_count > 0 && val_list_off != 0 && val_list_off != 0xFFFFFFFF) {
            uint8_t* vl = get_cell_payload(val_list_off);
            if (vl) {
                for (uint32_t i = 0; i < val_count; ++i) {
                    uint32_t vk_off = read_le32(vl + i * 4);
                    uint8_t* vk = get_cell_payload(vk_off);
                    if (!vk || read_le16(vk) != 0x6B76) continue;

                    uint16_t nlen = read_le16(vk + 0x02);
                    std::string name(reinterpret_cast<const char*>(vk + 0x14), nlen);
                    if (string_iequal(name, val_name)) {
                        // Found existing value -> allocate new data cell and update vk
                        uint32_t data_off = allocate_cell(hive_data, u16_data.size());
                        uint8_t* dp = get_cell_payload(data_off);
                        if (dp) {
                            std::memcpy(dp, u16_data.data(), u16_data.size());
                        }
                        vk = get_cell_payload(vk_off);
                        if (vk) {
                            write_le32(vk + 0x04, static_cast<uint32_t>(u16_data.size()));
                            write_le32(vk + 0x08, data_off);
                            write_le32(vk + 0x0C, reg_type);
                        }
                        nk = get_cell_payload(nk_cell_off);
                        if (nk) {
                            uint32_t max_data = read_le32(nk + 0x40);
                            write_le32(nk + 0x40, std::max(max_data, static_cast<uint32_t>(u16_data.size())));
                        }
                        return;
                    }
                }
            }
        }

        // Value not found -> allocate data cell, vk cell, and new value list
        uint32_t data_off = allocate_cell(hive_data, u16_data.size());
        uint8_t* dp = get_cell_payload(data_off);
        if (dp) {
            std::memcpy(dp, u16_data.data(), u16_data.size());
        }

        uint32_t vk_off = allocate_cell(hive_data, 20 + val_name.size());
        uint8_t* vk = get_cell_payload(vk_off);
        if (!vk) return;

        write_le16(vk + 0x00, 0x6B76); // "vk"
        write_le16(vk + 0x02, static_cast<uint16_t>(val_name.size()));
        write_le32(vk + 0x04, static_cast<uint32_t>(u16_data.size()));
        write_le32(vk + 0x08, data_off);
        write_le32(vk + 0x0C, reg_type); // 1 = REG_SZ, 2 = REG_EXPAND_SZ
        write_le16(vk + 0x10, 1); // ASCII name
        write_le16(vk + 0x12, 0);
        std::memcpy(vk + 0x14, val_name.data(), val_name.size());

        // Allocate new value list cell
        uint32_t new_vlist_off = allocate_cell(hive_data, (val_count + 1) * 4);
        uint8_t* new_vl = get_cell_payload(new_vlist_off);
        if (!new_vl) return;

        if (val_count > 0 && val_list_off != 0 && val_list_off != 0xFFFFFFFF) {
            uint8_t* old_vl = get_cell_payload(val_list_off);
            if (old_vl) {
                std::memcpy(new_vl, old_vl, val_count * 4);
            }
        }
        write_le32(new_vl + val_count * 4, vk_off);

        // Update nk cell pointers
        nk = get_cell_payload(nk_cell_off);
        if (nk) {
            write_le32(nk + 0x24, val_count + 1);
            write_le32(nk + 0x28, new_vlist_off);
            uint32_t max_name = read_le32(nk + 0x3C);
            write_le32(nk + 0x3C, std::max(max_name, static_cast<uint32_t>(val_name.size())));
            uint32_t max_data = read_le32(nk + 0x40);
            write_le32(nk + 0x40, std::max(max_data, static_cast<uint32_t>(u16_data.size())));
        }
    };

    PnpDriverArmReport report;
    report.control_set = "ControlSet001"; // Default fallback
    report.hive_dirty_on_entry = hive_dirty_on_entry;
    if (hive_dirty_on_entry) {
        report.warnings.push_back(
            "Hive was dirty on entry (Primary Sequence " + std::to_string(primary_seq_on_entry) +
            " != Secondary Sequence " + std::to_string(secondary_seq_on_entry) +
            "); SYSTEM.LOG transaction logs present and would replay on boot unless the "
            "header is forced clean before the offline changes are committed");
    }

    // 1. Locate active ControlSet via Select\Current
    uint32_t select_off = find_subkey(root_cell_off, "Select");
    if (select_off != 0xFFFFFFFF) {
        uint32_t current_val = 0;
        if (get_dword_value(select_off, "Current", &current_val) && current_val > 0) {
            char buf[32];
            std::snprintf(buf, sizeof(buf), "ControlSet%03u", current_val);
            report.control_set = buf;
        }
    }

    uint32_t ccs_off = find_subkey(root_cell_off, report.control_set);
    if (ccs_off == 0xFFFFFFFF) {
        // The control set Select\Current points at is absent. Fall back, but keep the
        // label matching whichever key was actually resolved so the report never
        // claims we armed ControlSet001 when the writes landed somewhere else.
        ccs_off = find_subkey(root_cell_off, "ControlSet001");
        if (ccs_off != 0xFFFFFFFF) {
            report.control_set = "ControlSet001";
        } else {
            ccs_off = find_subkey(root_cell_off, "CurrentControlSet");
            if (ccs_off != 0xFFFFFFFF) {
                report.control_set = "CurrentControlSet";
            }
        }
    }

    if (ccs_off == 0xFFFFFFFF) {
        report.message = "Could not locate active ControlSet or CurrentControlSet in hive";
        report.warnings.push_back("ControlSet key not found in offline hive");
        return Error(ErrorCode::InvalidConfiguration, "Could not locate active ControlSet or CurrentControlSet in hive");
    }

    uint32_t services_off = find_subkey(ccs_off, "Services");
    if (services_off == 0xFFFFFFFF) {
        report.message = "Services key not found in " + report.control_set;
        report.warnings.push_back("Services key not found in offline hive");
        return Error(ErrorCode::InvalidConfiguration, "Services key not found in " + report.control_set);
    }

    // ---- NIC boot-start profile election -------------------------------------------
    //
    // This runs BEFORE the first cell of this pass is written, on the pristine hive: the
    // guest's original hardware state has to be read first, otherwise a previous pass's
    // own injected Services\rt640x64 / Services\e1d68x64 keys -- or the generic multi-NIC
    // template services created further down -- would feed the election back to itself.
    //
    // Forcing rt640x64 (Realtek) AND e1d68x64 (Intel) to Start = 0 at the same time makes
    // Windows run DriverEntry + miniport initialization for silicon that is not on the
    // board (ThinkCentre M71s, single-vendor RTL8111E: stop 0xA at Phase 0). Only the
    // adapter instances under Control\Class\{4d36e972-...} count as hardware; a chipset
    // devnode under Enum\PCI never does. An image this armer already patched keeps the
    // profile it was patched with instead of being re-elected on every auto-arm.
    //
    // Writes the resolved profile back to <ControlSet>\Control\CobDiskless\NicBootProfile
    // so auto_arm_vhd_on_boot can reuse it next launch.
    auto pin_nic_boot_profile = [&](NicBootProfile resolved) {
        if (resolved == NicBootProfile::Auto) return;
        uint32_t ctl_off = find_subkey(ccs_off, "Control");
        if (ctl_off == 0xFFFFFFFF) ctl_off = get_or_create_subkey(ccs_off, "Control");
        if (ctl_off == 0xFFFFFFFF) {
            report.warnings.push_back("Could not create Control to pin the NIC boot profile");
            return;
        }
        const uint32_t pin_off = get_or_create_subkey(ctl_off, "CobDiskless");
        if (pin_off == 0xFFFFFFFF) {
            report.warnings.push_back("Could not create Control\\CobDiskless to pin the NIC boot profile");
            return;
        }
        set_or_create_string(pin_off, "NicBootProfile", nic_profile_name(resolved),
                             1 /* REG_SZ */);
    };

    const NicVendorEvidence nic_evidence =
        collect_nic_vendor_evidence(hive_data, report.control_set, harvested);

    NicBootProfile effective_profile = profile;
    if (profile == NicBootProfile::Auto) {
        const NicBootProfile pinned = read_pinned_nic_profile(hive_data, report.control_set);
        // A pin is a *memory* of an earlier pass, not evidence about this image. When the
        // image's own Net class adapters contradict it -- the M71s incident: an earlier
        // build wrote NicBootProfile = "intel" on a single-vendor RTL8111E board, and every
        // later auto-arm trusted it, demoted rt640x64 to Start = 3 and never recovered --
        // the pin is stale and is thrown away before it can lock the VHD in that state.
        const NicBootProfile tier_a = elect_tier_a_profile(nic_evidence);
        if (pinned != NicBootProfile::Auto && tier_a != NicBootProfile::Auto &&
            tier_a != pinned) {
            Logger::default_logger().info(
                "PNP",
                "[PNP] Conflicting/stale profile pin '" + nic_profile_name(pinned) +
                    "' evicted by Tier A " + tier_a_profile_label(tier_a) +
                    " evidence; re-running election against Control\\Class\\" +
                    NETWORK_CLASS_GUID);
            effective_profile = elect_nic_boot_profile(nic_evidence);
        } else if (pinned != NicBootProfile::Auto) {
            effective_profile = pinned;
            Logger::default_logger().info(
                "PNP",
                "[PNP] Image already patched with NIC boot profile " + nic_profile_name(pinned) +
                    "; reusing it instead of re-electing (pass --nic-profile to change it).");
        } else {
            effective_profile = elect_nic_boot_profile(nic_evidence);
            if (!nic_evidence.realtek() && !nic_evidence.intel() &&
                find_subkey(services_off, "rt640x64") != 0xFFFFFFFF &&
                find_subkey(services_off, "e1d68x64") != 0xFFFFFFFF) {
                // No vendor evidence at all. Keep every NIC driver boot-started rather than
                // guessing: demoting on absent evidence risks a 0x7B
                // INACCESSIBLE_BOOT_DEVICE with nothing left to diagnose, and pinning the
                // profile afterwards is a one-flag fix. The operator is told instead.
                report.warnings.push_back(
                    std::string("No NIC vendor bindings found under Control\\Class\\") +
                    NETWORK_CLASS_GUID + " and no Realtek/Intel DriverStore package; rt640x64 "
                    "and e1d68x64 both stay boot-start. Pass --nic-profile realtek|intel to "
                    "pin a single boot NIC.");
            }
        }
    }
    report.nic_profile = nic_profile_name(effective_profile);
    // Always written, explicit profile or not: an explicit choice (cobdiskless.conf
    // nic_profile / --nic-profile) must overwrite whatever an earlier pass pinned, so the
    // next auto-arm cannot resurrect the old value.
    pin_nic_boot_profile(effective_profile);

    // 1b. Guest OS family: decides whether this hive may carry CriticalDeviceDatabase
    //     bindings at all. A caller that already resolved the family from the mounted
    //     volume (ntoskrnl.exe / SOFTWARE hive) wins; otherwise read the version values
    //     out of this very hive. No version evidence anywhere falls back to Legacy,
    //     which keeps the NT 5.x/6.1 0x7B protection that has always been applied here.
    const GuestOsFamily os_family_resolved = (os_family != GuestOsFamily::Unknown)
        ? os_family
        : detect_os_family_from_hive(hive_data, report.control_set);
    report.guest_os_family = os_family_name(os_family_resolved);
    Logger::default_logger().info(
        "PNP",
        "[PNP] Guest OS family: " + report.guest_os_family + " (" +
            (os_family_resolved == GuestOsFamily::Modern
                 ? "NT 6.2+ -> CriticalDeviceDatabase skipped and purged"
                 : "NT 5.x/6.1 -> CriticalDeviceDatabase bindings required for 0x7B") +
            ")");

    // 2. Arm critical boot storage and network services
    const auto& targets = critical_boot_services();

    // Realtek PHY power-saving / link-reset prevention.
    // Injects anti-reset parameters (*EEE, AdvancedEEE, PowerSavingMode,
    // ReduceSpeedOnPowerDown, AutoDisableGigabit, GigaLite, *FlowControl, *WaitAutoNegComplete, etc.)
    // as well as auxiliary string properties to completely prevent Phase 0 PHY carrier drop.
    //
    // Two safety gates apply to every one of those writes (ThinkCentre M71s stop 0xA):
    //   * type      -- a "*" keyword is always written as REG_SZ, never REG_DWORD, because
    //                  NDIS parses it through the miniport's advanced-property string
    //                  descriptor at DISPATCH_LEVEL;
    //   * OS family -- NDIS 6.30+ keywords (*EEE, *GreenEthernet) are dropped entirely for
    //                  legacy (NT <= 6.1) guests, whose NDIS stack does not know them.
    // Adapter instance keys add a third gate: the Ndi\params schema check below.
    const bool reject_modern_ndis = (os_family_resolved == GuestOsFamily::Legacy);

    auto write_anti_flap_string = [&](uint32_t key_off, const char* name) {
        set_or_create_string(key_off, name, "0", 1 /* REG_SZ */);
    };

    auto write_anti_flap_value = [&](uint32_t key_off, const char* name, uint32_t dword_value) {
        if (is_asterisk_keyword(name)) {
            set_or_create_string(key_off, name, "0", 1 /* REG_SZ */);
        } else {
            set_or_create_dword(key_off, name, dword_value);
        }
    };

    // No schema to consult: the driver's own Parameters key is a flat default store.
    auto apply_anti_flap_to_key = [&](uint32_t key_off) {
        for (const char* sz_name : REALTEK_ANTI_FLAP_STRINGS) {
            if (reject_modern_ndis && is_modern_ndis_keyword(sz_name)) continue;
            write_anti_flap_string(key_off, sz_name);
        }
        for (const auto& dw : REALTEK_ANTI_FLAP_DWORDS) {
            if (reject_modern_ndis && is_modern_ndis_keyword(dw.name)) continue;
            write_anti_flap_value(key_off, dw.name, dw.value);
        }
    };

    // Schema-gated writes for an adapter instance key under
    // Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}\<Index>:
    // <Index>\Ndi\params\<ParamName> is the miniport's own declaration of which advanced
    // properties it implements. A parameter that is not declared there is not supported by
    // that driver/hardware combination -- forcing it anyway is exactly what tripped the
    // RTL8111E Rev 06's unsupported-EEE path during Phase 0 -- so it is skipped and logged.
    auto apply_anti_flap_to_adapter_key = [&](uint32_t adapter_off, const std::string& index_name) {
        const uint32_t ndi_off = find_subkey(adapter_off, "Ndi");
        const uint32_t params_off =
            (ndi_off != 0xFFFFFFFF) ? find_subkey(ndi_off, "params") : 0xFFFFFFFF;
        auto declares = [&](const char* name) -> bool {
            return params_off != 0xFFFFFFFF && find_subkey(params_off, name) != 0xFFFFFFFF;
        };
        auto note_not_declared = [&](const char* name) {
            Logger::default_logger().info(
                "PNP",
                "[PNP] Adapter " + index_name + " does not declare " + std::string(name) +
                    " in Ndi\\params; skipping injection.");
        };
        auto note_legacy_guest = [&](const char* name) {
            Logger::default_logger().info(
                "PNP",
                "[PNP] Adapter " + index_name + ": " + std::string(name) +
                    " is an NDIS 6.30+ keyword; skipped for legacy guest (NT <= 6.1).");
        };

        size_t injected = 0;
        for (const char* sz_name : REALTEK_ANTI_FLAP_STRINGS) {
            if (reject_modern_ndis && is_modern_ndis_keyword(sz_name)) {
                note_legacy_guest(sz_name);
                continue;
            }
            if (!declares(sz_name)) {
                note_not_declared(sz_name);
                continue;
            }
            write_anti_flap_string(adapter_off, sz_name);
            ++injected;
        }
        for (const auto& dw : REALTEK_ANTI_FLAP_DWORDS) {
            if (reject_modern_ndis && is_modern_ndis_keyword(dw.name)) {
                note_legacy_guest(dw.name);
                continue;
            }
            if (is_ndi_advanced_property(dw.name) && !declares(dw.name)) {
                note_not_declared(dw.name);
                continue;
            }
            write_anti_flap_value(adapter_off, dw.name, dw.value);
            ++injected;
        }
        if (injected > 0) {
            Logger::default_logger().info(
                "PNP",
                "[PNP] Injected Realtek anti-flap parameters into network adapter instance " +
                    index_name + " (" + std::to_string(injected) +
                    " schema-validated writes, Ndi\\params checked)");
        }
    };

    auto apply_realtek_parameters = [&](uint32_t service_off) {
        uint32_t param_off = get_or_create_subkey(service_off, "Parameters");
        if (param_off == 0xFFFFFFFF) return;
        apply_anti_flap_to_key(param_off);
    };

    // ---- NIC boot-start profile election -------------------------------------------
    // Already resolved above (report.nic_profile), before any cell of this pass existed.

    // Realtek miniports parse their hardware configuration from the adapter instance key
    // under Control\Class\{4d36e972-...}\<Index> only -- the flat
    // Services\<realtek>\Parameters key is not part of their DriverEntry parse path. Any
    // value parked there (an earlier pass, or a generic INF template) is dead weight the
    // miniport may still walk during early DriverEntry, so it is removed, never written.
    auto purge_service_parameters = [&](const std::string& svc) {
        const uint32_t svc_off = find_subkey(services_off, svc);
        if (svc_off == 0xFFFFFFFF) return;
        const uint32_t params_off = find_subkey(svc_off, "Parameters");
        if (params_off == 0xFFFFFFFF) return;

        bool removed_any = false;
        for (const auto& dw : REALTEK_ANTI_FLAP_DWORDS) {
            if (delete_value(params_off, dw.name)) removed_any = true;
        }
        for (const char* sz : REALTEK_ANTI_FLAP_STRINGS) {
            if (delete_value(params_off, sz)) removed_any = true;
        }
        if (!removed_any) return;

        // Drop the subkey itself once the armer was the only author left in it. Anything a
        // real driver INF owns under the same key (other values, sub-subkeys) is left
        // alone -- this pass only ever takes back what it wrote.
        if (regf_value_names(hive_data, params_off).empty() &&
            get_all_subkeys(params_off).empty()) {
            delete_subkey(svc_off, params_off, "Parameters");
        }
        report.service_parameters_purged.push_back("Services\\" + svc + "\\Parameters");
        Logger::default_logger().info(
            "PNP",
            "[PNP] Purged flat anti-flap values from Services\\" + svc +
                "\\Parameters (Realtek reads Control\\Class\\" + std::string(NETWORK_CLASS_GUID) + ")");
    };

    // Anti-flap / power-saving suppression is a property of the NIC miniport, not of a
    // vendor: every NDIS miniport service (Intel, Broadcom, Atheros, Marvell, Aquantia, ...)
    // gets the same Parameters overrides. NDIS itself and the iSCSI stack are
    // infrastructure drivers and are left alone. The Realtek family is the exception: it
    // reads Control\Class only, so its flat Parameters key is purged instead of armed.
    auto apply_service_anti_flap = [&](uint32_t service_off, const std::string& svc) {
        if (!is_network_boot_service(svc) || string_iequal(svc, "NDIS")) return;
        if (is_realtek_service_name(svc)) {
            purge_service_parameters(svc);
            return;
        }
        apply_realtek_parameters(service_off);
    };

    for (const auto& svc : targets) {
        uint32_t svc_off = find_subkey(services_off, svc);
        if (svc_off != 0xFFFFFFFF) {
            // Service exists -> promote it to a boot-critical network driver:
            //   Start = 0 (SERVICE_BOOT_START)
            //   Type = 1 (SERVICE_KERNEL_DRIVER), ErrorControl = 1 (SERVICE_ERROR_NORMAL)
            //   Group = <canonical load group> ("NDIS" for NIC drivers)
            //   BootFlags = 1 (CM_SERVICE_NETWORK_BOOT_LOAD) -- required by Windows 10/11,
            //   which no longer derives boot-critical status from the CriticalDeviceDatabase.
            const auto info = get_driver_service_info(svc);
            set_or_create_dword(svc_off, "Start", SERVICE_START_BOOT);
            set_or_create_dword(svc_off, "Type", SERVICE_TYPE_KERNEL);
            set_or_create_dword(svc_off, "ErrorControl", SERVICE_ERROR_NORMAL);
            set_or_create_dword(svc_off, "BootFlags", CM_SERVICE_NETWORK_BOOT_LOAD);
            set_or_create_string(svc_off, "Group", info.group, 1 /* REG_SZ */);
            report.modified_services.push_back(svc);
            report.armed_services.push_back(svc);

            // NIC driver link-flap prevention
            apply_service_anti_flap(svc_off, svc);
        } else {
            // Does not exist -> CREATE IT from scratch!
            uint32_t new_svc_off = get_or_create_subkey(services_off, svc);
            if (new_svc_off != 0xFFFFFFFF) {
                const auto info = get_driver_service_info(svc);
                set_or_create_string(new_svc_off, "DisplayName", info.display_name, 1 /* REG_SZ */);
                set_or_create_dword(new_svc_off, "Type", info.type);
                set_or_create_dword(new_svc_off, "Start", info.start);
                set_or_create_dword(new_svc_off, "ErrorControl", info.error_control);
                set_or_create_string(new_svc_off, "Group", info.group, 1 /* REG_SZ */);
                set_or_create_string(new_svc_off, "ImagePath", info.image_path, 2 /* REG_EXPAND_SZ */);
                set_or_create_dword(new_svc_off, "BootFlags", info.boot_flags);

                apply_service_anti_flap(new_svc_off, svc);

                report.injected_services.push_back(svc);
                report.armed_services.push_back(svc);
            } else {
                report.missing_services.push_back(svc);
            }
        }
    }

    // 2a-0. Universal NDIS harvest: arm every network driver package discovered in the
    //       guest DriverStore\FileRepository with the same boot-start treatment as the
    //       built-in list (Start = 0, Type = 1, ErrorControl = 1, Group = NDIS,
    //       BootFlags = 1) plus the anti-flap Parameters overrides.
    for (const auto& pkg : harvested) {
        if (pkg.service_name.empty()) continue;
        // Hard safety net: never boot-arm a virtual/software miniport (Start = 0 on a
        // TAP/VPN/WAN/VM adapter is pure Phase 0 failure surface), whoever supplied
        // the package list.
        if (!is_physical_ndis_package(pkg)) {
            Logger::default_logger().info("PNP", "[PNP] Refusing to arm non-physical adapter service: " +
                                          pkg.service_name + " (package " + pkg.package_dir_name + ")");
            continue;
        }
        const std::string& svc = pkg.service_name;

        const bool already_armed = std::any_of(
            report.armed_services.begin(), report.armed_services.end(),
            [&](const std::string& s) { return string_iequal(s, svc); });

        uint32_t svc_off = find_subkey(services_off, svc);
        if (already_armed) {
            if (svc_off != 0xFFFFFFFF) {
                apply_service_anti_flap(svc_off, svc);
                if (pkg.has_tag) set_or_create_dword(svc_off, "Tag", pkg.tag);
            }
            continue;
        }

        const DriverServiceInfo info = get_driver_service_info(svc);
        const std::string group = pkg.group.empty() ? info.group : pkg.group;

        if (svc_off != 0xFFFFFFFF) {
            set_or_create_dword(svc_off, "Start", SERVICE_START_BOOT);
            set_or_create_dword(svc_off, "Type", SERVICE_TYPE_KERNEL);
            set_or_create_dword(svc_off, "ErrorControl", SERVICE_ERROR_NORMAL);
            set_or_create_dword(svc_off, "BootFlags", CM_SERVICE_NETWORK_BOOT_LOAD);
            set_or_create_string(svc_off, "Group", group, 1 /* REG_SZ */);
            if (pkg.has_tag) set_or_create_dword(svc_off, "Tag", pkg.tag);
            apply_service_anti_flap(svc_off, svc);
            report.modified_services.push_back(svc);
            report.armed_services.push_back(svc);
        } else {
            uint32_t new_svc_off = get_or_create_subkey(services_off, svc);
            if (new_svc_off != 0xFFFFFFFF) {
                set_or_create_string(new_svc_off, "DisplayName", info.display_name, 1 /* REG_SZ */);
                set_or_create_dword(new_svc_off, "Type", info.type);
                set_or_create_dword(new_svc_off, "Start", info.start);
                set_or_create_dword(new_svc_off, "ErrorControl", info.error_control);
                set_or_create_string(new_svc_off, "Group", group, 1 /* REG_SZ */);
                set_or_create_string(new_svc_off, "ImagePath",
                                     pkg.image_path.empty() ? info.image_path : pkg.image_path,
                                     2 /* REG_EXPAND_SZ */);
                set_or_create_dword(new_svc_off, "BootFlags", info.boot_flags);
                if (pkg.has_tag) set_or_create_dword(new_svc_off, "Tag", pkg.tag);
                apply_service_anti_flap(new_svc_off, svc);
                svc_off = new_svc_off;

                report.injected_services.push_back(svc);
                report.armed_services.push_back(svc);
            } else {
                report.missing_services.push_back(svc);
                continue;
            }
        }
        Logger::default_logger().info("PNP", "[PNP] Armed harvested NDIS driver service: " + svc +
                                      " (package " + pkg.package_dir_name + ")");
    }

    // 2a-0. Decouple multi-NIC boot-start enforcement.
    //
    //       Under a single-vendor profile the losing family is demoted to
    //       SERVICE_DEMAND_START (Start = 3). PnP still starts it the moment an adapter of
    //       that vendor shows up on the bus, it simply never runs during Phase 0 -- so a
    //       board with a single-vendor PHY stops initializing a miniport for silicon it
    //       does not have (the M71s stop 0xA). BootFlags goes with it: that flag only
    //       means anything on a boot-start service. Nothing here ever creates a
    //       losing-family service that the hive did not already carry.
    if (effective_profile == NicBootProfile::Realtek || effective_profile == NicBootProfile::Intel) {
        const std::vector<std::string>& losing_family =
            (effective_profile == NicBootProfile::Realtek) ? intel_service_family()
                                                           : realtek_service_family();
        for (const std::string& svc : losing_family) {
            const uint32_t svc_off = find_subkey(services_off, svc);
            if (svc_off == 0xFFFFFFFF) continue;
            set_or_create_dword(svc_off, "Start", SERVICE_START_DEMAND);
            set_or_create_dword(svc_off, "BootFlags", 0);
            report.demoted_services.push_back(svc);
            Logger::default_logger().info(
                "PNP",
                "[PNP] Demoted non-boot NIC service " + svc +
                    " to Start = 3 (SERVICE_DEMAND_START) under profile " + report.nic_profile);
        }
    }

    auto was_demoted = [&](const std::string& s) {
        return std::any_of(report.demoted_services.begin(), report.demoted_services.end(),
                           [&](const std::string& d) { return string_iequal(d, s); });
    };

    // 2a. Verify BootFlags (CM_SERVICE_NETWORK_BOOT_LOAD) landed on every network service.
    //     On Windows 10/11 this -- not the CriticalDeviceDatabase -- is what makes pci.sys
    //     hand the NIC to its boot-start driver before the boot volume is online.
    {
        std::vector<std::string> boot_flag_targets = targets;
        for (const auto& pkg : harvested) {
            if (!pkg.service_name.empty() && is_physical_ndis_package(pkg)) {
                boot_flag_targets.push_back(pkg.service_name);
            }
        }

        bool network_flags_armed = true;
        for (const auto& svc : boot_flag_targets) {
            if (!is_network_boot_service(svc)) continue;
            // A service deliberately demoted out of Phase 0 is no longer a network
            // boot-load candidate; checking it would report a failure we just created.
            if (was_demoted(svc)) continue;
            uint32_t net_svc_off = find_subkey(services_off, svc);
            uint32_t boot_flags = 0;
            if (net_svc_off == 0xFFFFFFFF ||
                !get_dword_value(net_svc_off, "BootFlags", &boot_flags) ||
                boot_flags != CM_SERVICE_NETWORK_BOOT_LOAD) {
                network_flags_armed = false;
                report.warnings.push_back("BootFlags (0x1 / CM_SERVICE_NETWORK_BOOT_LOAD) not armed for network service: " + svc);
            }
        }
        report.boot_flags_armed = network_flags_armed;
    }

    // 2b. Realtek Anti-Flap Parameter Injection:
    //     Under the resolved active ControlSet (report.control_set), navigate to:
    //     Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}
    //     Enumerate all subkeys (0000, 0001, 0002, etc.).
    //     Check if DriverDesc contains "Realtek", "RTL", or if MatchingDeviceId contains "VEN_10EC".
    //     For matching instances, inject/overwrite the anti-flap values that disable the PHY
    //     reset -- but only the ones <Index>\Ndi\params declares (schema gate) and only as
    //     REG_SZ when the name is an NDIS standardized "*" keyword (type gate).
    uint32_t control_off = find_subkey(ccs_off, "Control");
    if (control_off != 0xFFFFFFFF) {
        uint32_t class_off = find_subkey(control_off, "Class");
        if (class_off != 0xFFFFFFFF) {
            uint32_t net_class_off = find_subkey(class_off, "{4d36e972-e325-11ce-bfc1-08002be10318}");
            if (net_class_off != 0xFFFFFFFF) {
                auto adapter_cells = get_all_subkeys(net_class_off);
                for (uint32_t adapter_off : adapter_cells) {
                    std::string desc = get_string_value(adapter_off, "DriverDesc");
                    std::string mid = get_string_value(adapter_off, "MatchingDeviceId");
                    std::string cid = get_string_value(adapter_off, "ComponentId");
                    bool is_matching = string_contains_ci(desc, "Realtek") ||
                                       string_contains_ci(desc, "RTL") ||
                                       string_contains_ci(mid, "VEN_10EC") ||
                                       is_realtek_string(desc) ||
                                       is_realtek_string(mid) ||
                                       is_realtek_string(cid);
                    if (is_matching) {
                        std::string index_name;
                        if (!regf_nk_name(hive_data, adapter_off, &index_name)) {
                            index_name = std::to_string(adapter_off);
                        }
                        apply_anti_flap_to_adapter_key(adapter_off, index_name);
                    }
                }
            }
        }
    }

    // 2b-2. Flat Realtek service Parameters purge (Services\<realtek family>\Parameters):
    //       The mirroring that used to live here -- copying REALTEK_ANTI_FLAP_STRINGS into
    //       Services\rt640x64\Parameters as a "global fallback" -- is wrong. The Realtek
    //       miniport reads its hardware configuration from
    //       Control\Class\{4d36e972-...}\<Index> and never consults that flat key, so
    //       whatever an earlier pass parked there is parsed during early DriverEntry with
    //       no schema to validate it against. It is removed on every pass instead of being
    //       written, which makes re-arming self-healing.
    for (const std::string& svc : realtek_service_family()) {
        purge_service_parameters(svc);
    }

    // 2c. CriticalDeviceDatabase (CDDB) hardware ID bindings -- gated on the guest OS family.
    //
    //     Legacy (NT 5.x / 6.1: XP, 2003, Vista, Win7): Phase 0 resolves the boot NIC
    //     through Control\CriticalDeviceDatabase. Without a pci#ven_* entry binding the
    //     device straight to its miniport, pci.sys hands the NIC over too late for the
    //     iSCSI stack to come up -- the classic 0x7B INACCESSIBLE_BOOT_DEVICE. Bindings
    //     are REQUIRED here.
    //
    //     Modern (NT 6.2+: Win8, 8.1, 10, 11): PnP resolves boot drivers dynamically from
    //     the DriverStore and has not consulted the CDDB for years. A pci#ven_* entry there
    //     fabricates a ghost devnode that is enumerated before the real device, and the
    //     half-initialised NDIS miniport it drags in is what blows up with ndis.sys 0xD1.
    //     On a Modern target injection is therefore skipped entirely and any pci#ven_*
    //     binding left behind by an earlier armer pass (or by an NT5-era install) is purged.
    auto service_armed = [&](const std::string& svc) {
        return std::any_of(report.armed_services.begin(), report.armed_services.end(),
                           [&](const std::string& s) { return string_iequal(s, svc); });
    };

    uint32_t cddb_off = 0xFFFFFFFF;
    bool cddb_structure_ok = true;
    // Hardware IDs bound during this pass; a static binding always wins over a harvested
    // one so the well-known fallbacks keep their original service.
    std::vector<std::string> bound_hardware_ids;

    auto inject_cddb_binding = [&](const std::string& hardware_id, const std::string& service) {
        for (const auto& bound : bound_hardware_ids) {
            if (string_iequal(bound, hardware_id)) return;
        }

        if (cddb_off == 0xFFFFFFFF) {
            uint32_t ctl_off = get_or_create_subkey(ccs_off, "Control");
            if (ctl_off != 0xFFFFFFFF) {
                cddb_off = get_or_create_subkey(ctl_off, "CriticalDeviceDatabase");
            }
            if (cddb_off == 0xFFFFFFFF) {
                cddb_structure_ok = false;
                report.warnings.push_back("Could not create Control\\CriticalDeviceDatabase in " + report.control_set);
            }
        }
        if (!cddb_structure_ok) return;

        uint32_t hwid_off = get_or_create_subkey(cddb_off, hardware_id);
        if (hwid_off == 0xFFFFFFFF) {
            report.warnings.push_back("Could not create CriticalDeviceDatabase subkey: " + hardware_id);
            return;
        }

        set_or_create_string(hwid_off, "Service", service, 1 /* REG_SZ */);
        set_or_create_string(hwid_off, "ClassGUID", NETWORK_CLASS_GUID, 1 /* REG_SZ */);
        bound_hardware_ids.push_back(hardware_id);

        std::string binding_desc = hardware_id + " -> " + service;
        if (std::find(report.cddb_bindings.begin(), report.cddb_bindings.end(), binding_desc) == report.cddb_bindings.end()) {
            report.cddb_bindings.push_back(binding_desc);
            Logger::default_logger().info("PNP", "[PNP] Injected CDDB binding: " + binding_desc);
        }
    };

    if (os_family_resolved == GuestOsFamily::Modern) {
        // ---- NT 6.2+: do not inject, and purge whatever an earlier pass left behind ----
        const uint32_t cddb_ctl_off = find_subkey(ccs_off, "Control");
        cddb_off = (cddb_ctl_off != 0xFFFFFFFF)
            ? find_subkey(cddb_ctl_off, "CriticalDeviceDatabase")
            : 0xFFFFFFFF;

        if (cddb_off != 0xFFFFFFFF) {
            // Gather the victims first: every delete rebuilds the parent's index, so the
            // list of names has to be stable across those rebuilds.
            std::vector<std::string> poisoned;
            for (uint32_t hwid_off : get_all_subkeys(cddb_off)) {
                std::string hwid;
                if (!regf_nk_name(hive_data, hwid_off, &hwid)) continue;
                if (to_lower_copy(hwid).rfind("pci#ven_", 0) == 0) {
                    poisoned.push_back(hwid);
                }
            }

            for (const std::string& hwid : poisoned) {
                const uint32_t hwid_off = find_subkey(cddb_off, hwid);
                if (hwid_off == 0xFFFFFFFF || !delete_subkey(cddb_off, hwid_off, hwid)) {
                    report.warnings.push_back(
                        "Could not purge poisoned CriticalDeviceDatabase binding: " + hwid);
                    continue;
                }
                report.cddb_purged.push_back(hwid);
                Logger::default_logger().info(
                    "PNP",
                    "[PNP] Purged poisoned CDDB binding (NT 6.2+ does not use the CriticalDeviceDatabase): " +
                        hwid);
            }
        }

        if (!report.cddb_purged.empty()) {
            Logger::default_logger().info(
                "PNP",
                "[PNP] Cleared " + std::to_string(report.cddb_purged.size()) +
                    " poisoned pci#ven_* CriticalDeviceDatabase key(s) from " + report.control_set);
        }
    } else {
        for (const auto& binding : critical_device_database_bindings()) {
            if (!service_armed(binding.service) && !string_iequal(binding.service, "rt640x64")) {
                // Never bind a hardware ID to a service we could not arm: the PnP manager
                // would fail the device start instead of falling back.
                continue;
            }
            inject_cddb_binding(binding.hardware_id, binding.service);
        }

        // 2c-2. Bind every PCI hardware ID harvested from the DriverStore packages to the
        //       service discovered for that package, so pci.sys hands the device straight
        //       to the right vendor driver during Phase 0 (multi-vendor guests).
        for (const auto& pkg : harvested) {
            if (pkg.service_name.empty() || pkg.hardware_ids.empty()) continue;
            // Software/virtual miniports never receive a CriticalDeviceDatabase binding.
            if (!is_physical_ndis_package(pkg)) continue;
            if (!service_armed(pkg.service_name)) continue;
            for (const auto& hardware_id : pkg.hardware_ids) {
                inject_cddb_binding(hardware_id, pkg.service_name);
            }
        }
    }

    // 2d. Arm and verify the core Windows iSCSI boot stack under the active ControlSet.
    //     Windows 10/11 no longer consults the CriticalDeviceDatabase, so boot-critical
    //     status comes solely from Start = 0 plus BootFlags on these service keys.
    {
        bool stack_ok = true;
        for (const auto& entry : iscsi_boot_stack_services()) {
            uint32_t stack_off = find_subkey(services_off, entry.service);
            if (stack_off == 0xFFFFFFFF) {
                stack_ok = false;
                report.warnings.push_back(std::string("iSCSI boot stack service missing from ") +
                                          report.control_set + "\\Services: " + entry.service);
                continue;
            }

            // msiscsi: Start = 0 + BootFlags = 0x1; Tcpip / ndis: Start = 0
            set_or_create_dword(stack_off, "Start", SERVICE_START_BOOT);
            if (entry.require_network_boot_flag) {
                set_or_create_dword(stack_off, "BootFlags", CM_SERVICE_NETWORK_BOOT_LOAD);
            }

            uint32_t start = 0xFFFFFFFF;
            if (!get_dword_value(stack_off, "Start", &start) || start != SERVICE_START_BOOT) {
                stack_ok = false;
            }
            if (entry.require_network_boot_flag) {
                uint32_t boot_flags = 0;
                if (!get_dword_value(stack_off, "BootFlags", &boot_flags) ||
                    boot_flags != CM_SERVICE_NETWORK_BOOT_LOAD) {
                    stack_ok = false;
                }
            }
        }
        report.iscsi_stack_armed = stack_ok;
        if (!stack_ok) {
            report.warnings.push_back("Core iSCSI boot stack (msiscsi/Tcpip/ndis) could not be fully armed for boot-start");
        }
    }

    // 2e. Boot Stage 15 stability: crash-dump stack, paging file, global task offload and
    //     VirtualBox lightweight filters.
    //
    //     At Stage 15 Windows initialises the Crash Control dump stack
    //     (dump_msiscsi / dump_ndis / dump_netio) and the paging file on the boot volume.
    //     Neither has a dump driver that is safe to drive while the same NIC is carrying
    //     the live iSCSI session, and both raise page faults / DMA completions at
    //     DISPATCH_LEVEL against buffers ndis.sys still treats as boot-time -- which is
    //     where the Stage 15 ndis.sys 0xD1 (DRIVER_IRQL_NOT_LESS_OR_EQUAL) comes from.
    {
        // (1) Control\CrashControl: never build a dump stack, never auto-reboot, and make
        //     the BSOD print its four hex bugcheck arguments for field debugging.
        uint32_t control_root = (control_off != 0xFFFFFFFF)
            ? control_off
            : get_or_create_subkey(ccs_off, "Control");
        uint32_t crash_off = (control_root != 0xFFFFFFFF)
            ? get_or_create_subkey(control_root, "CrashControl")
            : 0xFFFFFFFF;

        bool crash_ok = false;
        if (crash_off != 0xFFFFFFFF) {
            // 0 = "None": dump_ndis.sys / dump_netio.sys are never initialised.
            set_or_create_dword(crash_off, "CrashDumpEnabled", 0);
            set_or_create_dword(crash_off, "LogEvent", 0);
            set_or_create_dword(crash_off, "SendAlert", 0);
            set_or_create_dword(crash_off, "AutoReboot", 0);        // stop the reboot loop on a bugcheck
            set_or_create_dword(crash_off, "DisplayParameters", 1); // BSOD shows the 4 hex arguments

            uint32_t v = 0xFFFFFFFF;
            crash_ok = get_dword_value(crash_off, "CrashDumpEnabled", &v) && v == 0 &&
                       get_dword_value(crash_off, "LogEvent", &v) && v == 0 &&
                       get_dword_value(crash_off, "SendAlert", &v) && v == 0 &&
                       get_dword_value(crash_off, "AutoReboot", &v) && v == 0 &&
                       get_dword_value(crash_off, "DisplayParameters", &v) && v == 1;
        }
        report.crash_dump_disabled = crash_ok;
        if (!crash_ok) {
            report.warnings.push_back("CrashControl could not be neutralised (dump stack may still load) in " +
                                      report.control_set);
        }

        // (2) Session Manager\Memory Management: take the paging file off the boot
        //     volume. Paging over an active iSCSI session with no dedicated dump driver
        //     is what turns an ordinary page fault into an instant ndis.sys 0xD1.
        uint32_t mm_off = 0xFFFFFFFF;
        if (control_root != 0xFFFFFFFF) {
            uint32_t session_mgr_off = get_or_create_subkey(control_root, "Session Manager");
            if (session_mgr_off != 0xFFFFFFFF) {
                mm_off = get_or_create_subkey(session_mgr_off, "Memory Management");
            }
        }
        bool paging_ok = false;
        if (mm_off != 0xFFFFFFFF) {
            set_or_create_string(mm_off, "PagingFiles", "", REG_MULTI_SZ_TYPE);
            set_or_create_string(mm_off, "ExistingPageFiles", "", REG_MULTI_SZ_TYPE);
            paging_ok = get_string_value(mm_off, "PagingFiles").empty() &&
                        get_string_value(mm_off, "ExistingPageFiles").empty();
        }
        report.paging_files_cleared = paging_ok;
        if (!paging_ok) {
            report.warnings.push_back("Paging file could not be cleared on the boot volume in " + report.control_set);
        }

        // (3) Services\Tcpip\Parameters: global task-offload kill switch. This is a kernel
        //     wide override, so it silences LSO/checksum offload for every NIC -- including
        //     the one the iSCSI boot session runs on -- without needing per-driver tuning.
        uint32_t tcpip_svc_off = (services_off != 0xFFFFFFFF)
            ? get_or_create_subkey(services_off, "Tcpip")
            : 0xFFFFFFFF;
        uint32_t tcpip_params_off = (tcpip_svc_off != 0xFFFFFFFF)
            ? get_or_create_subkey(tcpip_svc_off, "Parameters")
            : 0xFFFFFFFF;
        bool offload_ok = false;
        if (tcpip_params_off != 0xFFFFFFFF) {
            set_or_create_dword(tcpip_params_off, "DisableTaskOffload", 1);
            set_or_create_dword(tcpip_params_off, "EnableRSS", 0);
            set_or_create_dword(tcpip_params_off, "EnableTCPA", 0);

            uint32_t v = 0xFFFFFFFF;
            offload_ok = get_dword_value(tcpip_params_off, "DisableTaskOffload", &v) && v == 1 &&
                         get_dword_value(tcpip_params_off, "EnableRSS", &v) && v == 0 &&
                         get_dword_value(tcpip_params_off, "EnableTCPA", &v) && v == 0;
        }
        report.tcpip_offload_disabled = offload_ok;
        if (!offload_ok) {
            report.warnings.push_back("Tcpip task-offload kill switch could not be applied in " + report.control_set);
        }

        // (4) Services\VBoxNetLwf: the VirtualBox NDIS 6 lightweight filter sits in the
        //     middle of every packet path and is a known Stage 15 0xD1 trigger. Disable it
        //     when present -- never create the key when it is not.
        uint32_t vbox_lwf_off = (services_off != 0xFFFFFFFF)
            ? find_subkey(services_off, "VBoxNetLwf")
            : 0xFFFFFFFF;
        bool vbox_ok = true;
        if (vbox_lwf_off != 0xFFFFFFFF) {
            set_or_create_dword(vbox_lwf_off, "Start", SERVICE_START_DISABLED);
            uint32_t start = 0xFFFFFFFF;
            vbox_ok = get_dword_value(vbox_lwf_off, "Start", &start) && start == SERVICE_START_DISABLED;
        }
        report.vbox_lwf_disabled = vbox_ok;
        if (!vbox_ok) {
            report.warnings.push_back("VirtualBox NDIS lightweight filter (VBoxNetLwf) could not be disabled in " +
                                      report.control_set);
        }

        // (5) Services\disk\TimeOutValue: the disk class driver's per-I/O timeout in
        //     seconds. Windows defaults to 10-30s, which is shorter than a routine STP
        //     reconvergence, a switch-port flap or a burst of iSCSI retransmits on the
        //     storage network. When the boot LUN is a network disk, that stall is not a
        //     slow disk -- it is a bugcheck: 0x7A KERNEL_DATA_INPAGE_ERROR (the page file
        //     could not be paged in) or 0x7B INACCESSIBLE_BOOT_DEVICE (the boot volume
        //     went away mid-read). 60s rides out any transient without ever masking a
        //     genuinely dead target for long enough to matter.
        uint32_t disk_svc_off = (services_off != 0xFFFFFFFF)
            ? get_or_create_subkey(services_off, "disk")
            : 0xFFFFFFFF;
        bool disk_timeout_ok = false;
        if (disk_svc_off != 0xFFFFFFFF) {
            set_or_create_dword(disk_svc_off, "TimeOutValue", 60);
            uint32_t v = 0xFFFFFFFF;
            disk_timeout_ok = get_dword_value(disk_svc_off, "TimeOutValue", &v) && v == 60;
        }
        report.disk_timeout_armed = disk_timeout_ok;
        if (!disk_timeout_ok) {
            report.warnings.push_back("disk service TimeOutValue could not be raised to 60s in " +
                                      report.control_set);
        }
    }

    // 3. Cleanly flush and update header sequence numbers and checksum.
    //
    // Forcing Primary == Secondary is what marks the hive CLEAN. The NT kernel's
    // hive loader (HvLoadHive) only replays SYSTEM.LOG1/SYSTEM.LOG2 when the two
    // sequence numbers disagree, so synchronising them here is what guarantees the
    // offline driver-arming changes below are not rolled back during Phase 0.
    uint32_t prim_seq = read_le32(&hive_data[0x04]);
    prim_seq++;
    write_le32(&hive_data[0x04], prim_seq);
    write_le32(&hive_data[0x08], prim_seq); // Synchronize secondary_seq to prevent dirty transaction log replay

    // Ensure the base block length field at offset 0x28 (HbinsDataSize) precisely reflects
    // the total allocated hbin data size (hive_data.size() minus the 4096-byte base block)
    // before calculating the header XOR checksum at offset 0x1FC.
    if (hive_data.size() >= 0x1000) {
        uint32_t actual_hbins_size = static_cast<uint32_t>(hive_data.size() - 0x1000);
        uint32_t current_hbins_data_size = read_le32(&hive_data[0x28]);
        if (actual_hbins_size != current_hbins_data_size && actual_hbins_size > 0) {
            write_le32(&hive_data[0x28], actual_hbins_size);
        }
    }

    uint32_t csum = calculate_regf_header_checksum(hive_data.data());
    write_le32(&hive_data[0x1FC], csum);

    // Every path that reaches this point has mutated hive_data, so the header is
    // guaranteed clean before the caller writes the buffer back to disk.
    report.hive_cleaned_on_exit = hive_dirty_on_entry;

    report.success = true;
    report.message = "Successfully armed " + std::to_string(report.armed_services.size()) +
                     " boot driver services in " + report.control_set +
                     " (" + std::to_string(report.modified_services.size()) + " modified, " +
                     std::to_string(report.injected_services.size()) + " injected from scratch, " +
                     std::to_string(report.cddb_bindings.size()) + " CDDB hardware ID bindings" +
                     ", OS family " + report.guest_os_family + ", CDDB " +
                     (os_family_resolved == GuestOsFamily::Modern
                          ? (report.cddb_purged.empty()
                                 ? "skipped"
                                 : "skipped and " + std::to_string(report.cddb_purged.size()) +
                                       " poisoned key(s) purged")
                          : "injected") +
                     (harvested.empty() ? "" : ", " + std::to_string(harvested.size()) + " harvested NDIS package(s)") +
                     (report.boot_flags_armed ? ", network BootFlags armed" : ", network BootFlags NOT armed") +
                     (report.iscsi_stack_armed ? ", iSCSI boot stack armed" : ", iSCSI boot stack NOT armed") +
                     ((report.crash_dump_disabled && report.paging_files_cleared && report.tcpip_offload_disabled)
                          ? ", Stage 15 crash dump/paging file/offload neutralised"
                          : ", Stage 15 crash dump/paging file/offload fixes NOT fully applied") +
                      ", NIC boot profile " + report.nic_profile +
                      (report.demoted_services.empty()
                           ? ""
                           : ", " + std::to_string(report.demoted_services.size()) +
                                 " NIC service(s) demoted to Start=3") +
                      (report.service_parameters_purged.empty()
                           ? ""
                           : ", " + std::to_string(report.service_parameters_purged.size()) +
                                 " flat service Parameters key(s) purged") + ")";
    return report;
}

bool PnpDriverArmer::verify_or_stage_driver_file(
    const std::filesystem::path& drivers_dir,
    const std::string& driver_file,
    std::vector<std::string>& warnings
) {
#if defined(_WIN32) || defined(__CYGWIN__) || defined(__MSYS__)
    enable_token_privilege(L"SeBackupPrivilege");
    enable_token_privilege(L"SeRestorePrivilege");
#endif

    std::filesystem::path actual_drivers_dir;
    std::filesystem::path system32_dir;
    std::string dir_name = drivers_dir.filename().string();
    if (string_iequal(dir_name, "drivers")) {
        actual_drivers_dir = drivers_dir;
        system32_dir = drivers_dir.parent_path();
    } else if (string_iequal(dir_name, "System32")) {
        system32_dir = drivers_dir;
        actual_drivers_dir = system32_dir / "drivers";
    } else {
        actual_drivers_dir = drivers_dir / "drivers";
        system32_dir = drivers_dir;
    }

    std::filesystem::path target = actual_drivers_dir / driver_file;
    if (file_exists_win32_or_std(target)) {
        // Safe staging: the guest already carries this driver binary. The pre-installed
        // file is accepted as-is -- an inbox DriverStore package must never overwrite a
        // binary that is already part of a working image.
        Logger::default_logger().info("PNP", "[PNP] Driver binary already on guest disk, keeping it: " +
                                      target.string());
        return true;
    }

    ensure_directory_win32_or_std(actual_drivers_dir);

    std::string stem = driver_file;
    auto dot_pos = stem.find('.');
    if (dot_pos != std::string::npos) {
        stem = stem.substr(0, dot_pos);
    }
    std::string stem_lower = stem;
    std::transform(stem_lower.begin(), stem_lower.end(), stem_lower.begin(),
                   [](unsigned char c){ return static_cast<char>(std::tolower(c)); });

    // Step A (DriverStore Auto-Harvest): Search <VolumePath>\Windows\System32\DriverStore\FileRepository
    // recursively for directory patterns matching the driver name (e.g. rt640x64.inf_*).
    std::filesystem::path file_repo = system32_dir / "DriverStore" / "FileRepository";
    if (!dir_exists_win32_or_std(file_repo)) {
        if (dir_exists_win32_or_std(drivers_dir.parent_path() / "DriverStore" / "FileRepository")) {
            file_repo = drivers_dir.parent_path() / "DriverStore" / "FileRepository";
        } else if (dir_exists_win32_or_std(drivers_dir / "DriverStore" / "FileRepository")) {
            file_repo = drivers_dir / "DriverStore" / "FileRepository";
        }
    }

    if (dir_exists_win32_or_std(file_repo)) {
        std::filesystem::path harvested_driver;

        std::function<void(const std::filesystem::path&, int)> search_repo =
            [&](const std::filesystem::path& dir, int depth) {
                if (!harvested_driver.empty() || depth > 4) return;
                auto entries = list_directory_entries(dir);

                // Priority 1: Check if driver_file is directly in this directory
                for (const auto& entry : entries) {
                    if (!entry.is_directory && string_iequal(entry.filename, driver_file)) {
                        harvested_driver = entry.path;
                        return;
                    }
                }

                // Priority 2: Recurse into directories matching pattern first
                std::vector<std::filesystem::path> matching_dirs;
                std::vector<std::filesystem::path> other_dirs;

                for (const auto& entry : entries) {
                    if (entry.is_directory) {
                        std::string entry_lower = entry.filename;
                        std::transform(entry_lower.begin(), entry_lower.end(), entry_lower.begin(),
                                       [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
                        if (entry_lower.find(stem_lower) != std::string::npos) {
                            matching_dirs.push_back(entry.path);
                        } else {
                            other_dirs.push_back(entry.path);
                        }
                    }
                }

                for (const auto& md : matching_dirs) {
                    search_repo(md, depth + 1);
                    if (!harvested_driver.empty()) return;
                }
                for (const auto& od : other_dirs) {
                    search_repo(od, depth + 1);
                    if (!harvested_driver.empty()) return;
                }
            };

        search_repo(file_repo, 0);

        if (!harvested_driver.empty() && file_exists_win32_or_std(harvested_driver)) {
            if (copy_file_win32_or_std(harvested_driver, target, false)) {
                std::cout << "[INFO] Auto-staged missing boot driver: " << driver_file << " -> Windows\\System32\\drivers\\" << std::endl;
                Logger::default_logger().info("PNP", "[INFO] Auto-staged missing boot driver: " + driver_file + " -> Windows\\System32\\drivers\\");
                return true;
            }
        }
    }

    // Step B (Host Depot Fallback): If not in guest DriverStore, check ./drivers/<driver.sys> on the host.
    // If present, copy it into <VolumePath>\Windows\System32\drivers\<driver.sys>.
    const std::vector<std::filesystem::path> host_candidates = {
        std::filesystem::path("./drivers") / driver_file,
        std::filesystem::path("drivers") / driver_file,
        std::filesystem::current_path() / "drivers" / driver_file,
        std::filesystem::path("../drivers") / driver_file,
        std::filesystem::path("C:\\Windows\\System32\\drivers") / driver_file
    };

    for (const auto& host_path : host_candidates) {
        if (file_exists_win32_or_std(host_path)) {
            if (copy_file_win32_or_std(host_path, target, false)) {
                std::cout << "[INFO] Auto-staged missing boot driver: " << driver_file << " -> Windows\\System32\\drivers\\" << std::endl;
                Logger::default_logger().info("PNP", "[INFO] Auto-staged missing boot driver: " + driver_file + " -> Windows\\System32\\drivers\\");
                return true;
            }
        }
    }

    // Host DriverStore\FileRepository extended fallback
    std::filesystem::path host_repo = "C:\\Windows\\System32\\DriverStore\\FileRepository";
    if (dir_exists_win32_or_std(host_repo)) {
        auto entries = list_directory_entries(host_repo);
        for (const auto& entry : entries) {
            if (entry.is_directory) {
                std::string entry_lower = entry.filename;
                std::transform(entry_lower.begin(), entry_lower.end(), entry_lower.begin(),
                               [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
                if (entry_lower.find(stem_lower) != std::string::npos) {
                    std::filesystem::path candidate = entry.path / driver_file;
                    if (file_exists_win32_or_std(candidate)) {
                        if (copy_file_win32_or_std(candidate, target, false)) {
                            std::cout << "[INFO] Auto-staged missing boot driver: " << driver_file << " -> Windows\\System32\\drivers\\" << std::endl;
                            Logger::default_logger().info("PNP", "[INFO] Auto-staged missing boot driver: " + driver_file + " -> Windows\\System32\\drivers\\");
                            return true;
                        }
                    }
                }
            }
        }
    }

    std::string warn = "Driver file " + driver_file + " not found in image drivers directory (" +
                       actual_drivers_dir.string() + "), image DriverStore, or host depot";
    warnings.push_back(warn);
    Logger::default_logger().warn("PNP", "[PNP] " + warn);
    return false;
}

Result<PnpDriverArmReport> PnpDriverArmer::arm_offline_system_hive(
    const std::filesystem::path& hive_path,
    NicBootProfile profile
) {
    auto read_res = read_hive_file(hive_path);
    if (!read_res.is_ok()) {
        return read_res.error();
    }
    std::vector<uint8_t> buffer = std::move(read_res.value());

    // Locate the Windows hierarchy first: guest architecture detection and the universal
    // NDIS (Class = Net) harvest must run before the hive is armed so every discovered
    // vendor driver is written in the same pass.
    const auto config_dir = hive_path.parent_path();
    const auto system32_dir = config_dir.parent_path();
    const auto drivers_dir = system32_dir / "drivers";

    bool is_windows_tree = false;
    const std::string cfg_name = config_dir.filename().string();
    const std::string s32_name = system32_dir.filename().string();
    if (string_iequal(cfg_name, "config") && string_iequal(s32_name, "System32")) {
        is_windows_tree = true;
    } else if (dir_exists_win32_or_std(drivers_dir)) {
        is_windows_tree = true;
    }

    GuestArch guest_arch = GuestArch::Unknown;
    GuestOsFamily os_family = GuestOsFamily::Unknown;
    std::vector<NdisPackageInfo> harvested;
    std::vector<std::string> harvest_warnings;
    if (is_windows_tree) {
        // The mounted volume root the harvester and the OS-family classifier work on is
        // resolved by walking up from the hive (drive letter, \\?\Volume{...}\ GUID path,
        // directory) until the Windows directory above it appears -- never by subtracting
        // a fixed number of components, which is what handed an empty "" to
        // harvest_ndis_packages() / detect_guest_os_family() and disabled both for the
        // whole pass.
        const std::filesystem::path volume_root = volume_root_from_hive(hive_path);
        if (volume_root.empty()) {
            const std::string msg =
                "Could not resolve a volume root above " + hive_path.string() +
                "; NDIS driver harvest and OS family classification skipped for this pass";
            harvest_warnings.push_back(msg);
            Logger::default_logger().warn("PNP", "[PNP] " + msg);
        } else {
            Logger::default_logger().info(
                "PNP", "[PNP] Volume root for harvest/OS detection: " + volume_root.string());
            guest_arch = detect_guest_arch(volume_root);
            os_family = detect_guest_os_family(volume_root);
            harvested = harvest_ndis_packages(volume_root, &harvest_warnings);
        }
    }

    // The volume-derived OS family decides CriticalDeviceDatabase handling; when the
    // volume carried no version evidence at all, arm_hive_buffer falls back to reading
    // the version values out of the hive itself.
    auto arm_res = arm_hive_buffer(buffer, harvested, os_family, profile);
    if (!arm_res.is_ok()) {
        return arm_res.error();
    }

    auto& rep = arm_res.value();
    if (!rep.success) {
        return Error(ErrorCode::InvalidConfiguration, "Failed to arm SYSTEM hive: " + rep.message);
    }
    rep.target_path = hive_path;
    if (is_windows_tree) {
        rep.guest_arch = arch_name(guest_arch);
        for (const auto& pkg : harvested) {
            rep.harvested_packages.push_back(pkg.package_dir_name);
        }
        rep.warnings.insert(rep.warnings.end(), harvest_warnings.begin(), harvest_warnings.end());
    }

    // Check for dirty transaction-log siblings on entry (they will be unlinked or truncated on flush).
    for (const std::string& suffix : {std::string(".LOG"), std::string(".LOG0"), std::string(".LOG1"), std::string(".LOG2")}) {
        std::filesystem::path log_path = hive_path.string() + suffix;
#if defined(_WIN32) || defined(__CYGWIN__) || defined(__MSYS__)
        const std::wstring wlog = to_native_win_path(log_path);
        DWORD attr = GetFileAttributesW(wlog.c_str());
        if (attr != INVALID_FILE_ATTRIBUTES) {
            rep.warnings.push_back(
                "Dirty hive transaction log detected: " + log_path.filename().string() +
                " (will be unlinked/truncated on flush to prevent Phase 0 rollback)");
        }
#else
        std::error_code log_ec;
        if (std::filesystem::is_regular_file(log_path, log_ec) &&
            std::filesystem::file_size(log_path, log_ec) > 0) {
            rep.warnings.push_back(
                "Dirty hive transaction log detected: " + log_path.filename().string() +
                " (will be unlinked/truncated on flush to prevent Phase 0 rollback)");
        }
#endif
    }

    // Stage driver binaries if located within a Windows installation hierarchy
    if (is_windows_tree) {
        stage_critical_boot_drivers(system32_dir, rep.warnings);
        // Copy every harvested NDIS package payload straight into System32\drivers
        // (CopyFileW) so the freshly armed services resolve their ImagePath on boot.
        stage_harvested_drivers(system32_dir, harvested, rep.warnings, &rep.staged_binaries);
        for (const auto& inj : rep.injected_services) {
            verify_or_stage_driver_file(drivers_dir, inj + ".sys", rep.warnings);
        }
    }

    // Flush modified hive cleanly back to file
    auto write_res = write_hive_file(hive_path, buffer);
    if (!write_res.is_ok()) {
        return write_res.error();
    }

    // Truncate / delete transaction logs (SYSTEM.LOG, SYSTEM.LOG1, SYSTEM.LOG2, etc.)
    // If SYSTEM.LOG1 or SYSTEM.LOG2 exist from an ungraceful shutdown, HvLoadHive
    // may attempt a journal replay during Phase 0 and silently revert our edits.
    // Unlinking or truncating them guarantees no journal replay occurs.
    const std::vector<std::string> log_suffixes = {
        ".LOG", ".LOG1", ".LOG2", ".LOG0",
        ".log", ".log1", ".log2", ".log0"
    };
    for (const auto& suffix : log_suffixes) {
        std::filesystem::path log_path = hive_path.string() + suffix;
#if defined(_WIN32) || defined(__CYGWIN__) || defined(__MSYS__)
        const std::wstring wlog = to_native_win_path(log_path);
        DWORD attr = GetFileAttributesW(wlog.c_str());
        if (attr != INVALID_FILE_ATTRIBUTES) {
            HANDLE hLog = CreateFileW(wlog.c_str(), GENERIC_WRITE,
                                      FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                                      NULL, TRUNCATE_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            if (hLog != INVALID_HANDLE_VALUE) {
                CloseHandle(hLog);
            }
            if (DeleteFileW(wlog.c_str())) {
                rep.warnings.push_back("Unlinked transaction log: " + log_path.filename().string());
            } else {
                rep.warnings.push_back("Truncated transaction log to 0 bytes: " + log_path.filename().string());
            }
            Logger::default_logger().info("PNP", "[PNP] Cleaned up transaction log: " + log_path.filename().string());
        }
#else
        std::error_code log_ec;
        if (std::filesystem::exists(log_path, log_ec)) {
            std::filesystem::remove(log_path, log_ec);
            if (log_ec) {
                // If unlink fails (e.g. file locked or permissions), truncate to 0 bytes
                std::ofstream log_trunc(log_path, std::ios::binary | std::ios::trunc);
                log_trunc.close();
                rep.warnings.push_back("Truncated transaction log to 0 bytes: " + log_path.filename().string());
            } else {
                rep.warnings.push_back("Unlinked transaction log: " + log_path.filename().string());
            }
            Logger::default_logger().info("PNP", "[PNP] Cleaned up transaction log: " + log_path.filename().string());
        }
#endif
    }

    Logger::default_logger().info("PNP", "[PNP] Cleanly armed offline hive: " + hive_path.string() +
                                  " (" + std::to_string(rep.armed_services.size()) + " services armed in " + rep.control_set + ")");
    if (is_windows_tree) {
        Logger::default_logger().info("PNP", "[PNP] Guest OS architecture: " + rep.guest_arch +
                                      " for " + system32_dir.parent_path().string());
        if (!rep.harvested_packages.empty()) {
            std::string list;
            for (size_t i = 0; i < rep.harvested_packages.size(); ++i) {
                if (i > 0) list += ", ";
                list += rep.harvested_packages[i];
            }
            Logger::default_logger().info("PNP", "[PNP] Harvested " + std::to_string(rep.harvested_packages.size()) +
                                          " NDIS driver package(s) from FileRepository: " + list);
        }
        if (!rep.staged_binaries.empty()) {
            std::string list;
            for (size_t i = 0; i < rep.staged_binaries.size(); ++i) {
                if (i > 0) list += ", ";
                list += rep.staged_binaries[i];
            }
            Logger::default_logger().info("PNP", "[PNP] Staged " + std::to_string(rep.staged_binaries.size()) +
                                          " harvested driver binary(s) into System32\\drivers: " + list);
        }
    }
    if (!rep.modified_services.empty()) {
        std::string list;
        for (size_t i = 0; i < rep.modified_services.size(); ++i) {
            if (i > 0) list += ", ";
            list += rep.modified_services[i];
        }
        Logger::default_logger().info("PNP", "[PNP] Modified existing driver keys (" +
                                      std::to_string(rep.modified_services.size()) + ") in " + rep.control_set + ": " + list);
    }
    if (!rep.injected_services.empty()) {
        std::string list;
        for (size_t i = 0; i < rep.injected_services.size(); ++i) {
            if (i > 0) list += ", ";
            list += rep.injected_services[i];
        }
        Logger::default_logger().info("PNP", "[PNP] Injected missing driver keys from scratch (" +
                                      std::to_string(rep.injected_services.size()) + ") into " + rep.control_set + ": " + list);
    }
    if (rep.boot_flags_armed) {
        Logger::default_logger().info("PNP", "[PNP] Network boot-critical flags armed in " + rep.control_set +
                                      " (BootFlags = 0x1 / CM_SERVICE_NETWORK_BOOT_LOAD on every NDIS service)");
    } else {
        Logger::default_logger().warn("PNP", "[PNP] BootFlags = 0x1 missing on one or more network services in " + rep.control_set);
    }
    if (rep.iscsi_stack_armed) {
        Logger::default_logger().info("PNP", "[PNP] Core iSCSI boot stack armed in " + rep.control_set +
                                      " (msiscsi Start=0 BootFlags=0x1, Tcpip Start=0, ndis Start=0)");
    } else {
        Logger::default_logger().warn("PNP", "[PNP] Core iSCSI boot stack (msiscsi/Tcpip/ndis) not fully armed in " + rep.control_set);
    }
    if (rep.crash_dump_disabled || rep.paging_files_cleared || rep.tcpip_offload_disabled || rep.vbox_lwf_disabled) {
        Logger::default_logger().info("PNP", "[PNP] Boot Stage 15 neutralised in " + rep.control_set +
                                      " (CrashControl dump stack " + std::string(rep.crash_dump_disabled ? "off" : "NOT off") +
                                      ", boot paging file " + std::string(rep.paging_files_cleared ? "cleared" : "NOT cleared") +
                                      ", Tcpip task offload " + std::string(rep.tcpip_offload_disabled ? "killed" : "NOT killed") +
                                      ", VBoxNetLwf " + std::string(rep.vbox_lwf_disabled ? "disabled/absent" : "ACTIVE") + ")");
    }
    if (!rep.cddb_bindings.empty()) {
        std::string list;
        for (size_t i = 0; i < rep.cddb_bindings.size(); ++i) {
            if (i > 0) list += ", ";
            list += rep.cddb_bindings[i];
        }
        Logger::default_logger().info("PNP", "[PNP] Injected " + std::to_string(rep.cddb_bindings.size()) +
                                      " CriticalDeviceDatabase hardware ID bindings into " + rep.control_set + ": " + list);
    }
    return rep;
}

Result<PnpDriverArmReport> PnpDriverArmer::arm_loaded_registry_key(
    const std::string& subkey_path,
    NicBootProfile profile
) {
    PnpDriverArmReport report;
    report.control_set = "ControlSet001";

#if defined(_WIN32)
    HKEY hRoot = HKEY_LOCAL_MACHINE;
    std::string base_key = subkey_path;
    while (!base_key.empty() && (base_key.front() == '\\' || base_key.front() == '/')) {
        base_key.erase(0, 1);
    }
    if (base_key.rfind("HKLM\\", 0) == 0) {
        base_key.erase(0, 5);
    }

    HKEY hBase = nullptr;
    if (RegOpenKeyExA(hRoot, base_key.c_str(), 0, KEY_READ | KEY_WRITE, &hBase) != ERROR_SUCCESS) {
        report.message = "Failed to open registry subkey: " + subkey_path;
        return report;
    }

    // Read Select\Current
    HKEY hSelect = nullptr;
    if (RegOpenKeyExA(hBase, "Select", 0, KEY_READ, &hSelect) == ERROR_SUCCESS) {
        DWORD current = 0;
        DWORD type = REG_DWORD;
        DWORD cb = sizeof(current);
        if (RegQueryValueExA(hSelect, "Current", nullptr, &type, reinterpret_cast<LPBYTE>(&current), &cb) == ERROR_SUCCESS && current > 0) {
            char buf[32];
            std::snprintf(buf, sizeof(buf), "ControlSet%03u", current);
            report.control_set = buf;
        }
        RegCloseKey(hSelect);
    }

    std::string services_path = base_key + "\\" + report.control_set + "\\Services";
    const auto& targets = critical_boot_services();

    // 1b. Guest OS family of the loaded hive. The same evidence the offline path reads
    //     (ControlSet00x\Control\Windows, then Microsoft\Windows NT\CurrentVersion)
    //     decides whether CriticalDeviceDatabase bindings are safe on this target.
    GuestOsFamily os_family = GuestOsFamily::Unknown;
    {
        auto read_dword = [&](const std::string& path, const char* name, DWORD* out) -> bool {
            HKEY hKey = nullptr;
            if (RegOpenKeyExA(hRoot, path.c_str(), 0, KEY_READ, &hKey) != ERROR_SUCCESS) return false;
            DWORD type = 0;
            DWORD cb = sizeof(*out);
            const bool ok = RegQueryValueExA(hKey, name, nullptr, &type,
                                             reinterpret_cast<LPBYTE>(out), &cb) == ERROR_SUCCESS &&
                            type == REG_DWORD;
            RegCloseKey(hKey);
            return ok;
        };
        auto read_string = [&](const std::string& path, const char* name) -> std::string {
            HKEY hKey = nullptr;
            if (RegOpenKeyExA(hRoot, path.c_str(), 0, KEY_READ, &hKey) != ERROR_SUCCESS) return "";
            std::string value;
            DWORD type = 0;
            DWORD cb = 0;
            if (RegQueryValueExA(hKey, name, nullptr, &type, nullptr, &cb) == ERROR_SUCCESS &&
                (type == REG_SZ || type == REG_EXPAND_SZ) && cb > 0) {
                std::vector<char> buf(cb + 1, 0);
                if (RegQueryValueExA(hKey, name, nullptr, &type,
                                     reinterpret_cast<LPBYTE>(buf.data()), &cb) == ERROR_SUCCESS) {
                    value.assign(buf.data());
                }
            }
            RegCloseKey(hKey);
            return value;
        };
        auto classify_version_key = [&](const std::string& path) -> GuestOsFamily {
            DWORD major = 0;
            DWORD minor = 0;
            const bool has_major = read_dword(path, "CurrentMajorVersionNumber", &major);
            const bool has_minor = read_dword(path, "CurrentMinorVersionNumber", &minor);
            return classify_os_evidence(has_major, major, has_minor, minor,
                                        read_string(path, "CurrentBuildNumber"),
                                        read_string(path, "CurrentVersion"));
        };

        os_family = classify_version_key(base_key + "\\" + report.control_set +
                                         "\\Control\\Windows");
        if (os_family == GuestOsFamily::Unknown) {
            os_family = classify_version_key(base_key + "\\Microsoft\\Windows NT\\CurrentVersion");
        }
        report.guest_os_family = os_family_name(os_family);
        Logger::default_logger().info(
            "PNP",
            "[PNP] Guest OS family: " + report.guest_os_family + " (" +
                (os_family == GuestOsFamily::Modern
                     ? "NT 6.2+ -> CriticalDeviceDatabase skipped and purged"
                     : "NT 5.x/6.1 -> CriticalDeviceDatabase bindings required for 0x7B") +
                ")");
    }

    // Anti-flap write policy shared by every write site below (the offline path carries the
    // same two gates -- see arm_hive_buffer):
    //   * a "*" keyword is always REG_SZ, because NDIS parses it through the miniport's
    //     advanced-property string descriptor at DISPATCH_LEVEL; a REG_DWORD there is the
    //     Phase-0 stop 0xA (IRQL_NOT_LESS_OR_EQUAL, Arg1 = 0x8);
    //   * NDIS 6.30+ keywords (*EEE, *GreenEthernet) are dropped for legacy guests.
    const bool reject_modern_ndis = (os_family == GuestOsFamily::Legacy);

    auto write_anti_flap_string = [&](HKEY hKey, const char* name) {
        const char kZero[] = "0";
        RegSetValueExA(hKey, name, 0, REG_SZ, reinterpret_cast<const BYTE*>(kZero), sizeof(kZero));
    };
    auto write_anti_flap_value = [&](HKEY hKey, const char* name, uint32_t dword_value) {
        if (is_asterisk_keyword(name)) {
            const char kZero[] = "0";
            RegSetValueExA(hKey, name, 0, REG_SZ, reinterpret_cast<const BYTE*>(kZero), sizeof(kZero));
        } else {
            RegSetValueExA(hKey, name, 0, REG_DWORD,
                           reinterpret_cast<const BYTE*>(&dword_value), sizeof(dword_value));
        }
    };

    // Flat driver Parameters key: no Ndi\params schema lives here, so only the type and
    // OS-family gates apply.
    auto apply_anti_flap_to_params_key = [&](HKEY hParams) {
        for (const char* sz_name : REALTEK_ANTI_FLAP_STRINGS) {
            if (reject_modern_ndis && is_modern_ndis_keyword(sz_name)) continue;
            write_anti_flap_string(hParams, sz_name);
        }
        for (const auto& dw : REALTEK_ANTI_FLAP_DWORDS) {
            if (reject_modern_ndis && is_modern_ndis_keyword(dw.name)) continue;
            write_anti_flap_value(hParams, dw.name, dw.value);
        }
    };

    // Adapter instance key: only write a parameter the miniport declares under
    // <Index>\Ndi\params\<ParamName>; anything else is unsupported by that driver and is
    // skipped with an operator-visible log line.
    auto apply_anti_flap_to_instance_key = [&](HKEY hInst, const std::string& index_name) {
        auto declares = [&](const char* name) -> bool {
            HKEY hSchema = nullptr;
            const std::string schema_path = std::string("Ndi\\params\\") + name;
            if (RegOpenKeyExA(hInst, schema_path.c_str(), 0, KEY_READ, &hSchema) !=
                ERROR_SUCCESS) {
                return false;
            }
            RegCloseKey(hSchema);
            return true;
        };
        auto note_not_declared = [&](const char* name) {
            Logger::default_logger().info(
                "PNP",
                "[PNP] Adapter " + index_name + " does not declare " + std::string(name) +
                    " in Ndi\\params; skipping injection.");
        };
        auto note_legacy_guest = [&](const char* name) {
            Logger::default_logger().info(
                "PNP",
                "[PNP] Adapter " + index_name + ": " + std::string(name) +
                    " is an NDIS 6.30+ keyword; skipped for legacy guest (NT <= 6.1).");
        };

        size_t injected = 0;
        for (const char* sz_name : REALTEK_ANTI_FLAP_STRINGS) {
            if (reject_modern_ndis && is_modern_ndis_keyword(sz_name)) {
                note_legacy_guest(sz_name);
                continue;
            }
            if (!declares(sz_name)) {
                note_not_declared(sz_name);
                continue;
            }
            write_anti_flap_string(hInst, sz_name);
            ++injected;
        }
        for (const auto& dw : REALTEK_ANTI_FLAP_DWORDS) {
            if (reject_modern_ndis && is_modern_ndis_keyword(dw.name)) {
                note_legacy_guest(dw.name);
                continue;
            }
            if (is_ndi_advanced_property(dw.name) && !declares(dw.name)) {
                note_not_declared(dw.name);
                continue;
            }
            write_anti_flap_value(hInst, dw.name, dw.value);
            ++injected;
        }
        if (injected > 0) {
            Logger::default_logger().info(
                "PNP",
                "[PNP] Injected Realtek anti-flap parameters into network adapter instance " +
                    index_name + " (" + std::to_string(injected) +
                    " schema-validated writes, Ndi\\params checked)");
        }
    };

    // ---- NIC boot-start profile election (loaded-registry path) --------------------
    // Same evidence the offline buffer path reads, and read at the same point: before a
    // single service key is created below, on the registry as the guest left it. Only the
    // adapter instances under Control\Class\{4d36e972-...} count as hardware -- a parent
    // PCI devnode (Intel H61 VEN_8086 chipset functions) is never consulted -- so a
    // single-vendor board never ends up with both miniports at Start = 0, and a Realtek
    // adapter always wins over an inbox Intel package.
    NicVendorEvidence nic_evidence;
    {
        const std::string live_class_path = base_key + "\\" + report.control_set +
                                            "\\Control\\Class\\" + NETWORK_CLASS_GUID;
        HKEY hLiveClass = nullptr;
        if (RegOpenKeyExA(hRoot, live_class_path.c_str(), 0, KEY_READ, &hLiveClass) == ERROR_SUCCESS) {
            char inst_name[256];
            DWORD idx = 0;
            DWORD name_len = sizeof(inst_name);
            while (RegEnumKeyExA(hLiveClass, idx++, inst_name, &name_len,
                                 nullptr, nullptr, nullptr, nullptr) == ERROR_SUCCESS) {
                name_len = sizeof(inst_name);
                HKEY hInst = nullptr;
                if (RegOpenKeyExA(hLiveClass, inst_name, 0, KEY_READ, &hInst) != ERROR_SUCCESS) {
                    continue;
                }
                std::string text;
                for (const char* vname : {"DriverDesc", "MatchingDeviceId", "ComponentId"}) {
                    char buf[512] = {0};
                    DWORD type = 0;
                    DWORD cb = sizeof(buf) - 1;
                    if (RegQueryValueExA(hInst, vname, nullptr, &type,
                                         reinterpret_cast<LPBYTE>(buf), &cb) == ERROR_SUCCESS) {
                        text += " ";
                        text += buf;
                    }
                }
                std::string service;
                {
                    char buf[256] = {0};
                    DWORD type = 0;
                    DWORD cb = sizeof(buf) - 1;
                    if (RegQueryValueExA(hInst, "Service", nullptr, &type,
                                         reinterpret_cast<LPBYTE>(buf), &cb) == ERROR_SUCCESS) {
                        service = buf;
                    }
                }
                RegCloseKey(hInst);
                note_vendor_text(nic_evidence, text, true);
                note_service_family(nic_evidence, service, true);
            }
            RegCloseKey(hLiveClass);
        }
    }

    // <ControlSet>\Control\CobDiskless\NicBootProfile written by an earlier pass.
    auto read_live_pinned_profile = [&]() -> NicBootProfile {
        const std::string pin_path = base_key + "\\" + report.control_set + "\\Control\\CobDiskless";
        HKEY hPin = nullptr;
        if (RegOpenKeyExA(hRoot, pin_path.c_str(), 0, KEY_READ, &hPin) != ERROR_SUCCESS) {
            return NicBootProfile::Auto;
        }
        char buf[64] = {0};
        DWORD type = 0;
        DWORD cb = sizeof(buf) - 1;
        const bool got = RegQueryValueExA(hPin, "NicBootProfile", nullptr, &type,
                                          reinterpret_cast<LPBYTE>(buf), &cb) == ERROR_SUCCESS;
        RegCloseKey(hPin);
        if (!got) return NicBootProfile::Auto;
        bool ok = false;
        const NicBootProfile parsed = PnpDriverArmer::parse_nic_profile(buf, &ok);
        if (!ok || parsed == NicBootProfile::Auto) return NicBootProfile::Auto;
        return parsed;
    };

    auto write_live_pinned_profile = [&](NicBootProfile resolved) {
        if (resolved == NicBootProfile::Auto) return;
        const std::string pin_path = base_key + "\\" + report.control_set + "\\Control\\CobDiskless";
        HKEY hPin = nullptr;
        if (RegCreateKeyExA(hRoot, pin_path.c_str(), 0, nullptr, 0, KEY_SET_VALUE,
                            nullptr, &hPin, nullptr) != ERROR_SUCCESS) {
            report.warnings.push_back("Could not create " + pin_path + " to pin the NIC boot profile");
            return;
        }
        const std::string name = nic_profile_name(resolved);
        RegSetValueExA(hPin, "NicBootProfile", 0, REG_SZ,
                       reinterpret_cast<const BYTE*>(name.c_str()),
                       static_cast<DWORD>(name.size() + 1));
        RegCloseKey(hPin);
    };

    NicBootProfile effective_profile = profile;
    if (profile == NicBootProfile::Auto) {
        const NicBootProfile pinned = read_live_pinned_profile();
        // Same eviction contract as the offline path: a pin written by an earlier build
        // never outranks what this image's own Net class adapters say today.
        const NicBootProfile tier_a = elect_tier_a_profile(nic_evidence);
        if (pinned != NicBootProfile::Auto && tier_a != NicBootProfile::Auto &&
            tier_a != pinned) {
            Logger::default_logger().info(
                "PNP",
                "[PNP] Conflicting/stale profile pin '" + nic_profile_name(pinned) +
                    "' evicted by Tier A " + tier_a_profile_label(tier_a) +
                    " evidence; re-running election against Control\\Class\\" +
                    NETWORK_CLASS_GUID);
            effective_profile = elect_nic_boot_profile(nic_evidence);
        } else if (pinned != NicBootProfile::Auto) {
            effective_profile = pinned;
            Logger::default_logger().info(
                "PNP",
                "[PNP] Image already patched with NIC boot profile " + nic_profile_name(pinned) +
                    "; reusing it instead of re-electing (pass --nic-profile to change it).");
        } else {
            effective_profile = elect_nic_boot_profile(nic_evidence);
            if (!nic_evidence.realtek() && !nic_evidence.intel()) {
                report.warnings.push_back(
                    std::string("No NIC vendor bindings found under Control\\Class\\") +
                    NETWORK_CLASS_GUID + " and no Realtek/Intel evidence; rt640x64 and e1d68x64 "
                    "both stay boot-start. Pass --nic-profile realtek|intel to pin a single boot NIC.");
            }
        }
    }
    report.nic_profile = nic_profile_name(effective_profile);
    // Unconditional: an explicit --nic-profile / nic_profile= setting rewrites the pin.
    write_live_pinned_profile(effective_profile);

    // Realtek miniports read their hardware configuration from the adapter instance key
    // under Control\Class only; the flat Services\<realtek>\Parameters key is not part of
    // their DriverEntry parse path, so armer-written values there are removed instead.
    auto purge_service_parameters_live = [&](const std::string& svc) {
        const std::string svc_path = services_path + "\\" + svc;
        HKEY hSvc = nullptr;
        if (RegOpenKeyExA(hRoot, svc_path.c_str(), 0, KEY_READ | KEY_WRITE | KEY_ENUMERATE_SUB_KEYS,
                          &hSvc) != ERROR_SUCCESS) {
            return;
        }
        HKEY hParam = nullptr;
        if (RegOpenKeyExA(hSvc, "Parameters", 0, KEY_READ | KEY_WRITE | KEY_ENUMERATE_SUB_KEYS,
                          &hParam) != ERROR_SUCCESS) {
            RegCloseKey(hSvc);
            return;
        }

        bool removed_any = false;
        auto remove_value = [&](const char* name) {
            if (RegDeleteValueA(hParam, name) == ERROR_SUCCESS) removed_any = true;
        };
        for (const auto& dw : REALTEK_ANTI_FLAP_DWORDS) remove_value(dw.name);
        for (const char* sz : REALTEK_ANTI_FLAP_STRINGS) remove_value(sz);

        // Drop the subkey itself once nothing else lives in it -- the armer was the only
        // author there. Anything a real INF owns under the same key is left untouched.
        if (removed_any) {
            char child[256];
            DWORD child_len = sizeof(child);
            const bool has_subkeys =
                RegEnumKeyExA(hParam, 0, child, &child_len, nullptr, nullptr, nullptr,
                              nullptr) == ERROR_SUCCESS;
            DWORD values = 0;
            const bool info_ok =
                RegQueryInfoKeyA(hParam, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr,
                                 &values, nullptr, nullptr, nullptr, nullptr) == ERROR_SUCCESS;
            RegCloseKey(hParam);
            if (!has_subkeys && info_ok && values == 0) {
                RegDeleteKeyA(hSvc, "Parameters");
            }

            report.service_parameters_purged.push_back("Services\\" + svc + "\\Parameters");
            Logger::default_logger().info(
                "PNP",
                "[PNP] Purged flat anti-flap values from Services\\" + svc +
                    "\\Parameters (Realtek reads Control\\Class\\" +
                    std::string(NETWORK_CLASS_GUID) + ")");
        } else {
            RegCloseKey(hParam);
        }
        RegCloseKey(hSvc);
    };

    for (const auto& svc : targets) {
        std::string svc_path = services_path + "\\" + svc;
        HKEY hSvc = nullptr;
        DWORD disposition = 0;
        if (RegCreateKeyExA(hRoot, svc_path.c_str(), 0, nullptr, 0,
                            KEY_ALL_ACCESS, nullptr, &hSvc, &disposition) != ERROR_SUCCESS) {
            if (RegCreateKeyExA(hRoot, svc_path.c_str(), 0, nullptr, 0,
                                KEY_SET_VALUE | KEY_CREATE_SUB_KEY | KEY_QUERY_VALUE,
                                nullptr, &hSvc, &disposition) != ERROR_SUCCESS) {
                report.missing_services.push_back(svc);
                continue;
            }
        }

        if (disposition == REG_CREATED_NEW_KEY) {
            // Injected from scratch! Populate all values for the driver
            const auto& info = get_driver_service_info(svc);
            RegSetValueExA(hSvc, "DisplayName", 0, REG_SZ,
                           reinterpret_cast<const BYTE*>(info.display_name.c_str()),
                           static_cast<DWORD>(info.display_name.size() + 1));
            RegSetValueExA(hSvc, "Type", 0, REG_DWORD,
                           reinterpret_cast<const BYTE*>(&info.type), sizeof(info.type));
            RegSetValueExA(hSvc, "Start", 0, REG_DWORD,
                           reinterpret_cast<const BYTE*>(&info.start), sizeof(info.start));
            RegSetValueExA(hSvc, "ErrorControl", 0, REG_DWORD,
                           reinterpret_cast<const BYTE*>(&info.error_control), sizeof(info.error_control));
            RegSetValueExA(hSvc, "Group", 0, REG_SZ,
                           reinterpret_cast<const BYTE*>(info.group.c_str()),
                           static_cast<DWORD>(info.group.size() + 1));
            RegSetValueExA(hSvc, "ImagePath", 0, REG_EXPAND_SZ,
                           reinterpret_cast<const BYTE*>(info.image_path.c_str()),
                           static_cast<DWORD>(info.image_path.size() + 1));
            RegSetValueExA(hSvc, "BootFlags", 0, REG_DWORD,
                           reinterpret_cast<const BYTE*>(&info.boot_flags), sizeof(info.boot_flags));

            report.injected_services.push_back(svc);
            report.armed_services.push_back(svc);
        } else {
            // Key already existed -> promote it to a boot-critical network driver:
            // Start = 0 (SERVICE_BOOT_START), Type = 1 (SERVICE_KERNEL_DRIVER),
            // ErrorControl = 1 (SERVICE_ERROR_NORMAL), Group = <canonical load group>,
            // BootFlags = 1 (CM_SERVICE_NETWORK_BOOT_LOAD, required by Windows 10/11).
            const auto info = get_driver_service_info(svc);
            DWORD start = SERVICE_START_BOOT;
            DWORD type = info.type;
            DWORD error_control = info.error_control;
            DWORD boot_flags = CM_SERVICE_NETWORK_BOOT_LOAD;
            RegSetValueExA(hSvc, "Start", 0, REG_DWORD, reinterpret_cast<const BYTE*>(&start), sizeof(start));
            RegSetValueExA(hSvc, "Type", 0, REG_DWORD, reinterpret_cast<const BYTE*>(&type), sizeof(type));
            RegSetValueExA(hSvc, "ErrorControl", 0, REG_DWORD, reinterpret_cast<const BYTE*>(&error_control), sizeof(error_control));
            RegSetValueExA(hSvc, "BootFlags", 0, REG_DWORD, reinterpret_cast<const BYTE*>(&boot_flags), sizeof(boot_flags));
            RegSetValueExA(hSvc, "Group", 0, REG_SZ,
                           reinterpret_cast<const BYTE*>(info.group.c_str()),
                           static_cast<DWORD>(info.group.size() + 1));
            report.modified_services.push_back(svc);
            report.armed_services.push_back(svc);
        }

        // Same rule as the offline path: anti-flap / power-saving suppression belongs to
        // every NIC miniport (NDIS load group, minus the NDIS driver itself), not to one
        // vendor. The Realtek family is the exception -- it reads Control\Class only, so
        // its flat Parameters key is purged rather than armed.
        if (is_network_boot_service(svc) && !string_iequal(svc, "NDIS")) {
            if (is_realtek_service_name(svc)) {
                purge_service_parameters_live(svc);
            } else {
                HKEY hParam = nullptr;
                if (RegCreateKeyExA(hSvc, "Parameters", 0, nullptr, 0, KEY_SET_VALUE, nullptr, &hParam, nullptr) == ERROR_SUCCESS) {
                    apply_anti_flap_to_params_key(hParam);
                    RegCloseKey(hParam);
                }
            }
        }

        RegCloseKey(hSvc);
    }

    // Decouple multi-NIC boot-start enforcement: the losing vendor family is demoted to
    // SERVICE_DEMAND_START so Phase 0 never initializes a miniport for silicon that is
    // not on the board. Never creates a losing-family service that was absent.
    if (effective_profile == NicBootProfile::Realtek || effective_profile == NicBootProfile::Intel) {
        const std::vector<std::string>& losing_family =
            (effective_profile == NicBootProfile::Realtek) ? intel_service_family()
                                                           : realtek_service_family();
        for (const std::string& svc : losing_family) {
            HKEY hDemote = nullptr;
            if (RegOpenKeyExA(hRoot, (services_path + "\\" + svc).c_str(), 0, KEY_READ | KEY_WRITE,
                              &hDemote) != ERROR_SUCCESS) {
                continue;
            }
            DWORD start = SERVICE_START_DEMAND;
            DWORD boot_flags = 0;
            RegSetValueExA(hDemote, "Start", 0, REG_DWORD,
                           reinterpret_cast<const BYTE*>(&start), sizeof(start));
            RegSetValueExA(hDemote, "BootFlags", 0, REG_DWORD,
                           reinterpret_cast<const BYTE*>(&boot_flags), sizeof(boot_flags));
            RegCloseKey(hDemote);
            report.demoted_services.push_back(svc);
            Logger::default_logger().info(
                "PNP",
                "[PNP] Demoted non-boot NIC service " + svc +
                    " to Start = 3 (SERVICE_DEMAND_START) under profile " + report.nic_profile);
        }
    }

    // Shared DWORD helpers for the verification passes below
    auto read_dword = [&](HKEY hKey, const char* value_name, DWORD* out) -> bool {
        DWORD type = 0;
        DWORD cb = sizeof(DWORD);
        return RegQueryValueExA(hKey, value_name, nullptr, &type,
                                reinterpret_cast<LPBYTE>(out), &cb) == ERROR_SUCCESS &&
               type == REG_DWORD;
    };
    auto write_dword = [&](HKEY hKey, const char* value_name, DWORD value) {
        RegSetValueExA(hKey, value_name, 0, REG_DWORD,
                       reinterpret_cast<const BYTE*>(&value), sizeof(value));
    };

    // Verify BootFlags (CM_SERVICE_NETWORK_BOOT_LOAD) on every network service
    {
        bool network_flags_armed = true;
        auto was_demoted = [&](const std::string& s) {
            return std::any_of(report.demoted_services.begin(), report.demoted_services.end(),
                               [&](const std::string& d) { return string_iequal(d, s); });
        };
        for (const auto& svc : targets) {
            if (!is_network_boot_service(svc)) continue;
            // Deliberately demoted out of Phase 0 -> no longer a boot-load candidate.
            if (was_demoted(svc)) continue;
            HKEY hNet = nullptr;
            DWORD boot_flags = 0;
            if (RegOpenKeyExA(hRoot, (services_path + "\\" + svc).c_str(), 0, KEY_READ, &hNet) != ERROR_SUCCESS) {
                network_flags_armed = false;
                report.warnings.push_back("BootFlags (0x1 / CM_SERVICE_NETWORK_BOOT_LOAD) not armed for network service: " + svc);
                continue;
            }
            if (!read_dword(hNet, "BootFlags", &boot_flags) || boot_flags != CM_SERVICE_NETWORK_BOOT_LOAD) {
                network_flags_armed = false;
                report.warnings.push_back("BootFlags (0x1 / CM_SERVICE_NETWORK_BOOT_LOAD) not armed for network service: " + svc);
            }
            RegCloseKey(hNet);
        }
        report.boot_flags_armed = network_flags_armed;
    }

    // Inspect network adapter class instances
    std::string net_class_path = base_key + "\\" + report.control_set + "\\Control\\Class\\{4d36e972-e325-11ce-bfc1-08002be10318}";
    HKEY hClass = nullptr;
    if (RegOpenKeyExA(hRoot, net_class_path.c_str(), 0, KEY_READ, &hClass) == ERROR_SUCCESS) {
        char subkey_name[256];
        DWORD idx = 0;
        DWORD name_len = sizeof(subkey_name);
        while (RegEnumKeyExA(hClass, idx++, subkey_name, &name_len, nullptr, nullptr, nullptr, nullptr) == ERROR_SUCCESS) {
            name_len = sizeof(subkey_name);
            std::string inst_path = net_class_path + "\\" + subkey_name;
            HKEY hInst = nullptr;
            if (RegOpenKeyExA(hRoot, inst_path.c_str(), 0, KEY_READ | KEY_SET_VALUE, &hInst) == ERROR_SUCCESS) {
                auto check_val = [&](const char* vname) -> std::string {
                    char val_buf[512] = {0};
                    DWORD type = 0;
                    DWORD cb = sizeof(val_buf) - 1;
                    if (RegQueryValueExA(hInst, vname, nullptr, &type, reinterpret_cast<LPBYTE>(val_buf), &cb) == ERROR_SUCCESS) {
                        return std::string(val_buf);
                    }
                    return "";
                };
                std::string desc = check_val("DriverDesc");
                std::string mid = check_val("MatchingDeviceId");
                std::string cid = check_val("ComponentId");
                bool is_matching = string_contains_ci(desc, "Realtek") ||
                                   string_contains_ci(desc, "RTL") ||
                                   string_contains_ci(mid, "VEN_10EC") ||
                                   is_realtek_string(desc) ||
                                   is_realtek_string(mid) ||
                                   is_realtek_string(cid);
                if (is_matching) {
                    apply_anti_flap_to_instance_key(hInst, subkey_name);
                }
                RegCloseKey(hInst);
            }
        }
        RegCloseKey(hClass);
    }

    // Flat Realtek service Parameters purge (loaded-registry path). The mirroring that
    // used to live here is wrong for the same reason as offline: the Realtek miniport
    // reads Control\Class\<instance>, never Services\rt640x64\Parameters.
    for (const std::string& svc : realtek_service_family()) {
        purge_service_parameters_live(svc);
    }

    // CriticalDeviceDatabase (CDDB) hardware ID bindings, gated on the guest OS family
    // exactly like the offline path (arm_hive_buffer):
    //   Legacy (NT 5.x / 6.1) needs them, or pci.sys binds the boot NIC too late (0x7B).
    //   Modern (NT 6.2+) must not carry them -- a pci#ven_* entry there fabricates a ghost
    //   devnode whose half-initialised miniport is the ndis.sys 0xD1 source -- so instead
    //   of injecting, any such binding left behind by an earlier pass is purged.
    if (os_family == GuestOsFamily::Modern) {
        const std::string cddb_root_path = base_key + "\\" + report.control_set +
                                           "\\Control\\CriticalDeviceDatabase";
        HKEY hCddbRoot = nullptr;
        if (RegOpenKeyExA(hRoot, cddb_root_path.c_str(), 0, KEY_READ, &hCddbRoot) == ERROR_SUCCESS) {
            // Collect first: the purge happens after enumeration, never during it.
            std::vector<std::string> poisoned;
            char child_name[512];
            for (DWORD index = 0;; ++index) {
                DWORD name_len = static_cast<DWORD>(sizeof(child_name));
                const LONG rc = RegEnumKeyExA(hCddbRoot, index, child_name, &name_len, nullptr,
                                              nullptr, nullptr, nullptr);
                if (rc == ERROR_NO_MORE_ITEMS) break;
                if (rc != ERROR_SUCCESS) break;
                const std::string child(child_name, name_len);
                if (to_lower_copy(child).rfind("pci#ven_", 0) == 0) {
                    poisoned.push_back(child);
                }
            }
            RegCloseKey(hCddbRoot);

            for (const std::string& child : poisoned) {
                const std::string child_path = cddb_root_path + "\\" + child;
                if (RegDeleteKeyA(hRoot, child_path.c_str()) == ERROR_SUCCESS) {
                    report.cddb_purged.push_back(child);
                    Logger::default_logger().info(
                        "PNP",
                        "[PNP] Purged poisoned CDDB binding (NT 6.2+ does not use the CriticalDeviceDatabase): " +
                            child);
                } else {
                    report.warnings.push_back(
                        "Could not purge poisoned CriticalDeviceDatabase binding: " + child);
                }
            }
            if (!report.cddb_purged.empty()) {
                Logger::default_logger().info(
                    "PNP",
                    "[PNP] Cleared " + std::to_string(report.cddb_purged.size()) +
                        " poisoned pci#ven_* CriticalDeviceDatabase key(s) from " +
                        report.control_set);
            }
        }
    } else {
        auto service_armed = [&](const char* svc) {
            return std::any_of(report.armed_services.begin(), report.armed_services.end(),
                               [&](const std::string& s) { return string_iequal(s, svc); });
        };

        for (const auto& binding : critical_device_database_bindings()) {
            if (!service_armed(binding.service) && !string_iequal(binding.service, "rt640x64")) continue;

            std::string cddb_key_path = base_key + "\\" + report.control_set +
                                        "\\Control\\CriticalDeviceDatabase\\" + binding.hardware_id;
            HKEY hCddb = nullptr;
            DWORD disposition = 0;
            if (RegCreateKeyExA(hRoot, cddb_key_path.c_str(), 0, nullptr, 0,
                                KEY_SET_VALUE | KEY_QUERY_VALUE, nullptr,
                                &hCddb, &disposition) != ERROR_SUCCESS) {
                report.warnings.push_back("Failed to create CriticalDeviceDatabase key: " + cddb_key_path);
                continue;
            }

            RegSetValueExA(hCddb, "Service", 0, REG_SZ,
                           reinterpret_cast<const BYTE*>(binding.service),
                           static_cast<DWORD>(std::strlen(binding.service) + 1));
            RegSetValueExA(hCddb, "ClassGUID", 0, REG_SZ,
                           reinterpret_cast<const BYTE*>(NETWORK_CLASS_GUID),
                           static_cast<DWORD>(std::strlen(NETWORK_CLASS_GUID) + 1));
            RegCloseKey(hCddb);

            std::string binding_desc = std::string(binding.hardware_id) + " -> " + binding.service;
            report.cddb_bindings.push_back(binding_desc);
            Logger::default_logger().info("PNP", "[PNP] Injected CDDB binding: " + binding_desc);
        }
    }

    // Arm and verify the core Windows iSCSI boot stack under the active ControlSet.
    // Windows 10/11 no longer consults the CriticalDeviceDatabase (deprecated since
    // Windows 8), so boot-critical status comes solely from Start = 0 plus BootFlags.
    {
        bool stack_ok = true;
        for (const auto& entry : iscsi_boot_stack_services()) {
            HKEY hStack = nullptr;
            DWORD disposition = 0;
            if (RegCreateKeyExA(hRoot, (services_path + "\\" + entry.service).c_str(), 0, nullptr, 0,
                                KEY_SET_VALUE | KEY_QUERY_VALUE, nullptr,
                                &hStack, &disposition) != ERROR_SUCCESS) {
                stack_ok = false;
                report.warnings.push_back("iSCSI boot stack service missing from " + services_path + ": " + entry.service);
                continue;
            }

            // msiscsi: Start = 0 + BootFlags = 0x1; Tcpip / ndis: Start = 0
            write_dword(hStack, "Start", SERVICE_START_BOOT);
            if (entry.require_network_boot_flag) {
                write_dword(hStack, "BootFlags", CM_SERVICE_NETWORK_BOOT_LOAD);
            }

            DWORD start = 0xFFFFFFFF;
            if (!read_dword(hStack, "Start", &start) || start != SERVICE_START_BOOT) {
                stack_ok = false;
            }
            if (entry.require_network_boot_flag) {
                DWORD boot_flags = 0;
                if (!read_dword(hStack, "BootFlags", &boot_flags) ||
                    boot_flags != CM_SERVICE_NETWORK_BOOT_LOAD) {
                    stack_ok = false;
                }
            }
            RegCloseKey(hStack);
        }
        report.iscsi_stack_armed = stack_ok;
        if (!stack_ok) {
            report.warnings.push_back("Core iSCSI boot stack (msiscsi/Tcpip/ndis) could not be fully armed for boot-start");
        }
    }

    RegFlushKey(hBase);
    RegCloseKey(hBase);

    report.success = true;
    report.message = "Successfully armed loaded registry hive at " + subkey_path +
                     " (" + std::to_string(report.modified_services.size()) + " modified, " +
                     std::to_string(report.injected_services.size()) + " injected, " +
                     std::to_string(report.cddb_bindings.size()) + " CDDB hardware ID bindings" +
                     ", OS family " + report.guest_os_family + ", CDDB " +
                     (os_family == GuestOsFamily::Modern
                          ? (report.cddb_purged.empty()
                                 ? "skipped"
                                 : "skipped and " + std::to_string(report.cddb_purged.size()) +
                                       " poisoned key(s) purged")
                          : "injected") +
                     (report.boot_flags_armed ? ", network BootFlags armed" : ", network BootFlags NOT armed") +
                     (report.iscsi_stack_armed ? ", iSCSI boot stack armed" : ", iSCSI boot stack NOT armed") + ")";
    Logger::default_logger().info("PNP", std::string("[PNP] Network boot-critical flags ") +
                                  (report.boot_flags_armed ? "armed" : "NOT armed") +
                                  " (BootFlags = 0x1 / CM_SERVICE_NETWORK_BOOT_LOAD) in loaded hive " + report.control_set);
    Logger::default_logger().info("PNP", std::string("[PNP] Core iSCSI boot stack ") +
                                  (report.iscsi_stack_armed ? "armed" : "NOT armed") +
                                  " (msiscsi/Tcpip/ndis) in loaded hive " + report.control_set);
    if (!report.modified_services.empty()) {
        std::string list;
        for (size_t i = 0; i < report.modified_services.size(); ++i) {
            if (i > 0) list += ", ";
            list += report.modified_services[i];
        }
        Logger::default_logger().info("PNP", "[PNP] Modified existing driver keys in loaded hive " + report.control_set + ": " + list);
    }
    if (!report.injected_services.empty()) {
        std::string list;
        for (size_t i = 0; i < report.injected_services.size(); ++i) {
            if (i > 0) list += ", ";
            list += report.injected_services[i];
        }
        Logger::default_logger().info("PNP", "[PNP] Injected missing driver keys from scratch into loaded hive " + report.control_set + ": " + list);
    }
#else
    report.message = "Loaded registry key modification is only supported on Windows hosts";
#endif
    return report;
}

#if defined(_WIN32) || defined(__CYGWIN__) || defined(__MSYS__)
// Attaches a VHD/VHDX through the VirtDisk API and locates the Windows SYSTEM hive on
// one of the volumes it exposes. The image stays attached for the object's lifetime so a
// caller can read the hive *and* hash the driver files on the same volume; the destructor
// detaches and closes the handle.
//
// This is the single mount implementation shared by arm_vhd_image() and
// inspect_vhd_image(), so arming and inspection can never disagree about what a target
// image contains.
class MountedVhdVolume {
public:
    explicit MountedVhdVolume(const std::filesystem::path& vhd_path) {
        enable_token_privilege(L"SeManageVolumePrivilege");
        enable_token_privilege(L"SeBackupPrivilege");
        enable_token_privilege(L"SeRestorePrivilege");

        VIRTUAL_STORAGE_TYPE storage_type{};
        storage_type.DeviceId = VIRTUAL_STORAGE_TYPE_DEVICE_UNKNOWN;
        storage_type.VendorId = VIRTUAL_STORAGE_TYPE_VENDOR_MICROSOFT_VAL;

        OPEN_VIRTUAL_DISK_PARAMETERS open_params{};
        open_params.Version = OPEN_VIRTUAL_DISK_VERSION_1;
        open_params.Version1.RWDepth = 1;

        std::wstring native_vhd = to_native_win_path(vhd_path);

        DWORD open_status = OpenVirtualDisk(
            &storage_type, native_vhd.c_str(), VIRTUAL_DISK_ACCESS_ALL,
            OPEN_VIRTUAL_DISK_FLAG_NONE, &open_params, &handle_);
        if (open_status != ERROR_SUCCESS) {
            open_status = OpenVirtualDisk(
                &storage_type, native_vhd.c_str(),
                static_cast<VIRTUAL_DISK_ACCESS_MASK>(VIRTUAL_DISK_ACCESS_ATTACH_RO |
                                                      VIRTUAL_DISK_ACCESS_GET_INFO |
                                                      VIRTUAL_DISK_ACCESS_DETACH),
                OPEN_VIRTUAL_DISK_FLAG_NONE, &open_params, &handle_);
        }
        if (open_status != ERROR_SUCCESS || handle_ == INVALID_HANDLE_VALUE) {
            handle_ = INVALID_HANDLE_VALUE;
            return;
        }

        ATTACH_VIRTUAL_DISK_PARAMETERS attach_params{};
        attach_params.Version = ATTACH_VIRTUAL_DISK_VERSION_1;
        const DWORD attach_status = AttachVirtualDisk(
            handle_, NULL, ATTACH_VIRTUAL_DISK_FLAG_NO_DRIVE_LETTER, 0, &attach_params, NULL);
        if (attach_status != ERROR_SUCCESS) {
            warnings_.push_back("AttachVirtualDisk returned error " + std::to_string(attach_status) +
                                " (elevation or SeManageVolumePrivilege may be required)");
            CloseHandle(handle_);
            handle_ = INVALID_HANDLE_VALUE;
            return;
        }
        attached_ = true;

        // GetVirtualDiskPhysicalPath() returns \\.\PhysicalDriveX; the volume scan below
        // keeps only the volumes whose disk extents live on that disk.
        WCHAR phys_path[MAX_PATH] = {0};
        ULONG phys_path_size = sizeof(phys_path);
        DWORD path_status = GetVirtualDiskPhysicalPath(handle_, &phys_path_size, phys_path);

        DWORD disk_number = MAXDWORD;
        if (path_status == ERROR_SUCCESS) {
            std::wstring wphys(phys_path);
            const size_t pd_pos = wphys.rfind(L"PhysicalDrive");
            if (pd_pos != std::wstring::npos) {
                try {
                    disk_number = std::stoul(wphys.substr(pd_pos + 13));
                } catch (...) {}
            }
            if (disk_number == MAXDWORD) {
                HANDLE hDisk = CreateFileW(phys_path, 0, FILE_SHARE_READ | FILE_SHARE_WRITE,
                                           NULL, OPEN_EXISTING, 0, NULL);
                if (hDisk != INVALID_HANDLE_VALUE) {
                    STORAGE_DEVICE_NUMBER sdn{};
                    DWORD returned = 0;
                    if (DeviceIoControl(hDisk, IOCTL_STORAGE_GET_DEVICE_NUMBER, NULL, 0, &sdn,
                                        sizeof(sdn), &returned, NULL)) {
                        disk_number = sdn.DeviceNumber;
                    }
                    CloseHandle(hDisk);
                }
            }
        }

        WCHAR volume_name[MAX_PATH] = {0};
        HANDLE hFindVol = FindFirstVolumeW(volume_name, ARRAYSIZE(volume_name));
        if (hFindVol != INVALID_HANDLE_VALUE) {
            do {
                std::wstring vol_device = volume_name;
                if (!vol_device.empty() && vol_device.back() == L'\\') {
                    vol_device.pop_back();
                }

                HANDLE hVol = CreateFileW(vol_device.c_str(), 0,
                                          FILE_SHARE_READ | FILE_SHARE_WRITE, NULL,
                                          OPEN_EXISTING, 0, NULL);
                if (hVol != INVALID_HANDLE_VALUE) {
                    BYTE extents_buf[sizeof(VOLUME_DISK_EXTENTS) + 16 * sizeof(DISK_EXTENT)] = {0};
                    VOLUME_DISK_EXTENTS* extents =
                        reinterpret_cast<VOLUME_DISK_EXTENTS*>(extents_buf);
                    DWORD bytes_ret = 0;
                    if (DeviceIoControl(hVol, IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS, NULL, 0,
                                        extents, sizeof(extents_buf), &bytes_ret, NULL)) {
                        for (DWORD i = 0; i < extents->NumberOfDiskExtents; ++i) {
                            if (extents->Extents[i].DiskNumber != disk_number) continue;
                            const std::wstring candidate_sys =
                                std::wstring(volume_name) + L"Windows\\System32\\config\\SYSTEM";
                            const DWORD attr = GetFileAttributesW(candidate_sys.c_str());
                            if (attr != INVALID_FILE_ATTRIBUTES && !(attr & FILE_ATTRIBUTE_DIRECTORY)) {
                                hive_path_ = candidate_sys;
                                // <Volume>\Windows\System32\config\SYSTEM -> <Volume>
                                volume_root_ = hive_path_.parent_path()
                                                   .parent_path()
                                                   .parent_path()
                                                   .parent_path();
                            }
                            break;
                        }
                    }
                    CloseHandle(hVol);
                }

                if (!hive_path_.empty()) break;
            } while (FindNextVolumeW(hFindVol, volume_name, ARRAYSIZE(volume_name)));

            FindVolumeClose(hFindVol);
        }

        if (hive_path_.empty()) {
            warnings_.push_back("VirtDisk attached disk " + std::to_string(disk_number) +
                                " but no Windows SYSTEM hive was found on any volume.");
        }
    }

    ~MountedVhdVolume() {
        if (handle_ != INVALID_HANDLE_VALUE) {
            if (attached_) {
                DetachVirtualDisk(handle_, DETACH_VIRTUAL_DISK_FLAG_NONE, 0);
                std::this_thread::sleep_for(std::chrono::milliseconds(50));
            }
            CloseHandle(handle_);
        }
    }

    MountedVhdVolume(const MountedVhdVolume&) = delete;
    MountedVhdVolume& operator=(const MountedVhdVolume&) = delete;

    bool attached() const { return attached_; }
    bool found_hive() const { return !hive_path_.empty(); }
    const std::filesystem::path& hive_path() const { return hive_path_; }
    const std::filesystem::path& volume_root() const { return volume_root_; }
    const std::vector<std::string>& warnings() const { return warnings_; }

private:
    HANDLE handle_{INVALID_HANDLE_VALUE};
    bool attached_{false};
    std::filesystem::path hive_path_;
    std::filesystem::path volume_root_;
    std::vector<std::string> warnings_;
};
#endif

Result<PnpDriverArmReport> PnpDriverArmer::arm_vhd_image(
    const std::filesystem::path& vhd_path,
    NicBootProfile profile
) {
    std::error_code ec;
    if (!std::filesystem::exists(vhd_path, ec)) {
        return Error(ErrorCode::StorageFailure, "Target file not found: " + vhd_path.string());
    }

    // Direct registry hive file check
    std::ifstream test_in(vhd_path, std::ios::binary);
    if (test_in.is_open()) {
        char sig[4] = {0};
        test_in.read(sig, 4);
        test_in.close();
        if (std::memcmp(sig, "regf", 4) == 0) {
            auto arm_res = arm_offline_system_hive(vhd_path, profile);
            if (arm_res.is_ok()) {
                std::cout << "[INFO] Auto-armed offline SYSTEM hive for image: " << vhd_path.filename().string() << std::endl;
                Logger::default_logger().info("PNP", "[INFO] Auto-armed offline SYSTEM hive for image: " + vhd_path.filename().string());
            }
            return arm_res;
        }
    }

    PnpDriverArmReport report;
    report.target_path = vhd_path;

#if defined(_WIN32) || defined(__CYGWIN__) || defined(__MSYS__)
    // 1. Automated VHD Mount & Hive Discovery (VirtDisk API). MountedVhdVolume is the
    //    single mount implementation shared with inspect_vhd_image(); it detaches when
    //    the scope below is left (return or fall-through).
    {
        MountedVhdVolume mounted(vhd_path);
        for (const std::string& w : mounted.warnings()) {
            report.warnings.push_back(w);
        }

        if (mounted.found_hive()) {
            const std::filesystem::path& found_hive_path = mounted.hive_path();

            // Stage critical boot drivers into mounted volume
            std::filesystem::path system32_dir = found_hive_path.parent_path().parent_path();
            stage_critical_boot_drivers(system32_dir, report.warnings);

            // If a raw .vhd has companion .LOG1 or .LOG2 files inside the volume, wipe/truncate them
            std::wstring config_dir = found_hive_path.parent_path().wstring();
            for (const auto& log_name : {L"SYSTEM.LOG1", L"SYSTEM.LOG2", L"SYSTEM.LOG", L"SYSTEM.LOG0"}) {
                std::wstring log_file = config_dir + L"\\" + log_name;
                DWORD attr = GetFileAttributesW(log_file.c_str());
                if (attr != INVALID_FILE_ATTRIBUTES) {
                    HANDLE hTrunc = CreateFileW(log_file.c_str(), GENERIC_WRITE,
                                                FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                                                NULL, TRUNCATE_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
                    if (hTrunc != INVALID_HANDLE_VALUE) {
                        CloseHandle(hTrunc);
                    }
                    DeleteFileW(log_file.c_str());
                }
            }

            // Execute PnpDriverArmer Automatically: Invoke PnpDriverArmer::arm_offline_system_hive(system_hive_path)
            auto arm_res = arm_offline_system_hive(found_hive_path, profile);
            if (arm_res.is_ok()) {
                report = arm_res.value();
                report.target_path = vhd_path;
                report.message += " (via VirtDisk mounted volume " + found_hive_path.string() + ")";

                // Print [INFO] Auto-armed offline SYSTEM hive for image: <vhd_name> to the server console
                std::cout << "[INFO] Auto-armed offline SYSTEM hive for image: " << vhd_path.filename().string() << std::endl;
                Logger::default_logger().info("PNP", "[INFO] Auto-armed offline SYSTEM hive for image: " + vhd_path.filename().string());

                // Clean Dismount & target hand-off happen when ~MountedVhdVolume runs.
                return report;
            }
        }
    }
#endif

    // Check if Windows installation is mounted under any available drive letters
    for (char d = 'C'; d <= 'Z'; ++d) {
        std::filesystem::path test_hive = std::string(1, d) + ":\\Windows\\System32\\config\\SYSTEM";
        if (d != 'C' && std::filesystem::exists(test_hive, ec)) {
            auto arm_res = arm_offline_system_hive(test_hive, profile);
            if (arm_res.is_ok()) {
                report = arm_res.value();
                report.target_path = vhd_path;
                report.message += " (via mounted drive " + std::string(1, d) + ":)";
                std::cout << "[INFO] Auto-armed offline SYSTEM hive for image: " << vhd_path.filename().string() << std::endl;
                Logger::default_logger().info("PNP", "[INFO] Auto-armed offline SYSTEM hive for image: " + vhd_path.filename().string());
                return report;
            }
        }
    }

#if defined(_WIN32) || defined(__CYGWIN__) || defined(__MSYS__)
    // Automated VHD inspection/arming workflow via PowerShell Mount-DiskImage fallback
    auto base64_encode = [](const std::vector<uint8_t>& in) -> std::string {
        static const char tbl[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        std::string out;
        int val = 0, valb = -6;
        for (uint8_t c : in) {
            val = (val << 8) + c;
            valb += 8;
            while (valb >= 0) {
                out.push_back(tbl[(val >> valb) & 0x3F]);
                valb -= 6;
            }
        }
        if (valb > -6) out.push_back(tbl[((val << 8) >> (valb + 8)) & 0x3F]);
        while (out.size() % 4) out.push_back('=');
        return out;
    };

    std::string ps_script = "$vhd = '" + vhd_path.string() + "'; "
                            "$m = Mount-DiskImage -ImagePath $vhd -PassThru -ErrorAction SilentlyContinue; "
                            "if ($m) { "
                            "  $disk = $m | Get-Disk; "
                            "  $vols = $disk | Get-Partition | Get-Volume | Where-Object DriveLetter; "
                            "  foreach ($v in $vols) { "
                            "    $h = \"$($v.DriveLetter):\\Windows\\System32\\config\\SYSTEM\"; "
                            "    if (Test-Path $h) { Write-Output \"FOUND:$h\"; break; } "
                            "  } "
                            "  Dismount-DiskImage -ImagePath $vhd -ErrorAction SilentlyContinue; "
                            "} else { Write-Output 'MOUNT_FAILED'; }";

    std::vector<uint8_t> u16_bytes;
    u16_bytes.reserve(ps_script.size() * 2);
    for (char c : ps_script) {
        u16_bytes.push_back(static_cast<uint8_t>(c));
        u16_bytes.push_back(0);
    }
    std::string cmd = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64_encode(u16_bytes);

    FILE* fp = POPEN_FUNC(cmd.c_str(), "r");
    if (fp) {
        char line[512];
        std::string out;
        while (fgets(line, sizeof(line), fp)) {
            out += line;
        }
        PCLOSE_FUNC(fp);

        auto found_pos = out.find("FOUND:");
        if (found_pos != std::string::npos) {
            std::string hive_p = out.substr(found_pos + 6);
            while (!hive_p.empty() && (hive_p.back() == '\r' || hive_p.back() == '\n' || hive_p.back() == ' ')) {
                hive_p.pop_back();
            }
            if (std::filesystem::exists(hive_p, ec)) {
                auto arm_res = arm_offline_system_hive(hive_p, profile);
                if (arm_res.is_ok()) {
                    report = arm_res.value();
                    report.target_path = vhd_path;
                    report.message += " (via PowerShell mounted image " + hive_p + ")";
                    std::cout << "[INFO] Auto-armed offline SYSTEM hive for image: " << vhd_path.filename().string() << std::endl;
                    Logger::default_logger().info("PNP", "[INFO] Auto-armed offline SYSTEM hive for image: " + vhd_path.filename().string());
                    return report;
                }
            }
        }
        if (out.find("MOUNT_FAILED") != std::string::npos) {
            report.warnings.push_back("VHD mounting requires elevation or virtual disk service access. Skipping offline mount without error.");
        }
    }
#endif

    report.success = true;
    report.message = "VHD inspection complete (image armed or non-Windows partition layout)";
    return report;
}

Result<PnpDriverArmReport> PnpDriverArmer::ensure_image_armed(const std::filesystem::path& image_path) {
    if (!path_exists_win32_or_std(image_path)) {
        return Error(ErrorCode::StorageFailure, "Image path does not exist: " + image_path.string());
    }

    // Check if image_path is directly a mounted volume or Windows directory
    std::filesystem::path candidate_sys = image_path / "Windows" / "System32" / "config" / "SYSTEM";
    if (!file_exists_win32_or_std(candidate_sys)) {
        candidate_sys = image_path / "System32" / "config" / "SYSTEM";
    }
    if (file_exists_win32_or_std(candidate_sys)) {
        std::filesystem::path sys32 = candidate_sys.parent_path().parent_path();
        PnpDriverArmReport rep;
        stage_critical_boot_drivers(sys32, rep.warnings);
        auto arm_res = arm_offline_system_hive(candidate_sys);
        if (arm_res.is_ok()) {
            return arm_res.value();
        }
        return arm_res;
    }

    std::string ext = image_path.extension().string();
    for (auto& c : ext) {
        c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    }

    if (ext == ".vhd" || ext == ".vhdx" || image_path.filename() == "SYSTEM") {
        auto arm_res = arm_vhd_image(image_path);
        if (arm_res.is_ok()) {
            const auto& rep = arm_res.value();
            if (!rep.armed_services.empty()) {
                Logger::default_logger().info("PNP", "[PNP] Successfully armed " +
                    std::to_string(rep.armed_services.size()) + " critical boot driver services for: " + image_path.filename().string() +
                    " (" + std::to_string(rep.modified_services.size()) + " modified, " +
                    std::to_string(rep.injected_services.size()) + " injected from scratch)");
                if (!rep.injected_services.empty()) {
                    std::string list;
                    for (size_t i = 0; i < rep.injected_services.size(); ++i) {
                        if (i > 0) list += ", ";
                        list += rep.injected_services[i];
                    }
                    Logger::default_logger().info("PNP", "[PNP] Injected missing driver keys: " + list);
                }
            } else {
                Logger::default_logger().info("PNP", "[PNP] Automated PNP driver arming verified for: " + image_path.filename().string());
            }
            return rep;
        }
        return arm_res;
    }

    PnpDriverArmReport rep;
    rep.success = true;
    rep.target_path = image_path;
    rep.message = "Image format " + ext + " does not require Windows PNP driver injection";
    return rep;
}

std::vector<uint8_t> PnpDriverArmer::create_synthetic_system_hive(
    uint32_t current_control_set,
    const std::vector<std::pair<std::string, uint32_t>>& services_with_initial_start,
    const std::vector<SyntheticNetAdapter>& net_adapters,
    const std::string& current_version,
    const std::vector<SyntheticServiceParameter>& service_parameters,
    const std::vector<std::string>& pci_devnode_ids
) {
    constexpr size_t HIVE_SIZE = 65536; // 4096 header + 61440 hbin
    std::vector<uint8_t> hive(HIVE_SIZE, 0);

    // 1. Regf Header (0x0000 .. 0x0FFF)
    std::memcpy(&hive[0x00], "regf", 4);
    write_le32(&hive[0x04], 1); // primary_seq
    write_le32(&hive[0x08], 1); // secondary_seq
    write_le32(&hive[0x14], 1); // major_version
    write_le32(&hive[0x18], 3); // minor_version
    write_le32(&hive[0x1C], 0); // normal hive
    write_le32(&hive[0x20], 1); // format
    write_le32(&hive[0x24], 0x20); // root cell offset (relative to 0x1000)
    write_le32(&hive[0x28], static_cast<uint32_t>(HIVE_SIZE - 0x1000)); // hbins_data_size
    write_le32(&hive[0x2C], 1); // clustering
    std::memcpy(&hive[0x30], "SYSTEM", 6);

    // 2. Hbin Header at 0x1000
    std::memcpy(&hive[0x1000], "hbin", 4);
    write_le32(&hive[0x1004], 0); // offset from first hbin
    write_le32(&hive[0x1008], static_cast<uint32_t>(HIVE_SIZE - 0x1000)); // hbin size

    // Current cell allocation pointer starts at 0x20 past 0x1000
    uint32_t alloc_ptr = 0x20;

    auto make_cell = [&](size_t payload_size) -> uint32_t {
        size_t csize = (4 + payload_size + 7) & ~7;
        uint32_t off = alloc_ptr;
        alloc_ptr += static_cast<uint32_t>(csize);
        write_le32(&hive[0x1000 + off], static_cast<uint32_t>(-static_cast<int32_t>(csize)));
        return off;
    };

    auto make_str_val = [&](const std::string& vname, const std::string& vval) -> uint32_t {
        std::vector<uint8_t> u16;
        u16.reserve((vval.size() + 1) * 2);
        for (char c : vval) {
            u16.push_back(static_cast<uint8_t>(c));
            u16.push_back(0);
        }
        u16.push_back(0);
        u16.push_back(0);

        uint32_t data_off = make_cell(u16.size());
        std::memcpy(&hive[0x1000 + data_off + 4], u16.data(), u16.size());

        uint32_t vk_off = make_cell(20 + vname.size());
        uint8_t* vk = &hive[0x1000 + vk_off + 4];
        write_le16(vk + 0x00, 0x6B76);
        write_le16(vk + 0x02, static_cast<uint16_t>(vname.size()));
        write_le32(vk + 0x04, static_cast<uint32_t>(u16.size()));
        write_le32(vk + 0x08, data_off);
        write_le32(vk + 0x0C, 1); // REG_SZ
        write_le16(vk + 0x10, 1); // ASCII
        std::memcpy(vk + 0x14, vname.data(), vname.size());
        return vk_off;
    };

    auto make_dword_val = [&](const std::string& vname, uint32_t vval) -> uint32_t {
        uint32_t vk_off = make_cell(20 + vname.size());
        uint8_t* vk = &hive[0x1000 + vk_off + 4];
        write_le16(vk + 0x00, 0x6B76);
        write_le16(vk + 0x02, static_cast<uint16_t>(vname.size()));
        write_le32(vk + 0x04, 0x80000004); // 4 bytes inline
        write_le32(vk + 0x08, vval);
        write_le32(vk + 0x0C, 4); // REG_DWORD
        write_le16(vk + 0x10, 1); // ASCII
        std::memcpy(vk + 0x14, vname.data(), vname.size());
        return vk_off;
    };

    auto make_nk = [&](const std::string& name) -> uint32_t {
        uint32_t off = make_cell(0x4C + name.size());
        uint8_t* nk = &hive[0x1000 + off + 4];
        write_le16(nk + 0x00, 0x6B6E);
        write_le16(nk + 0x02, 0x0020);
        write_le16(nk + 0x48, static_cast<uint16_t>(name.size()));
        std::memcpy(nk + 0x4C, name.data(), name.size());
        return off;
    };

    auto link_children = [&](uint32_t parent_off, const std::vector<uint32_t>& children,
                             const std::vector<std::string>& child_names) {
        uint32_t sl_off = make_cell(4 + children.size() * 8);
        uint8_t* sl = &hive[0x1000 + sl_off + 4];
        write_le16(sl + 0x00, 0x666C); // "lf"
        write_le16(sl + 0x02, static_cast<uint16_t>(children.size()));
        for (size_t i = 0; i < children.size(); ++i) {
            write_le32(sl + 0x04 + static_cast<uint32_t>(i) * 8, children[i]);
            std::string prefix = child_names[i].substr(0, 4);
            while (prefix.size() < 4) prefix.push_back(' ');
            std::memcpy(sl + 0x08 + static_cast<uint32_t>(i) * 8, prefix.data(), 4);
        }
        uint8_t* parent_nk = &hive[0x1000 + parent_off + 4];
        write_le32(parent_nk + 0x14, static_cast<uint32_t>(children.size()));
        write_le32(parent_nk + 0x1C, sl_off);
    };

    // Attach the OS version evidence ("6.1" = Win7 -> Legacy, "10.0" = Win10/11 -> Modern)
    // to a key: the classic CurrentVersion string plus the DWORD pair Windows 10+ uses and
    // a matching CurrentBuildNumber, so every detection source sees the same release.
    auto seed_version_values = [&](uint32_t target_nk_off) {
        if (current_version.empty()) return;

        unsigned int major = 0;
        unsigned int minor = 0;
        const bool parsed = std::sscanf(current_version.c_str(), "%u.%u", &major, &minor) == 2;

        std::vector<uint32_t> val_offsets;
        val_offsets.push_back(make_str_val("CurrentVersion", current_version));
        if (parsed) {
            val_offsets.push_back(make_dword_val("CurrentMajorVersionNumber", major));
            val_offsets.push_back(make_dword_val("CurrentMinorVersionNumber", minor));
            const std::string build =
                (major >= 10) ? "19041" : ((major == 6 && minor >= 2) ? "9600" : "7601");
            val_offsets.push_back(make_str_val("CurrentBuildNumber", build));
        }

        uint32_t vl_off = make_cell(val_offsets.size() * 4);
        for (size_t vi = 0; vi < val_offsets.size(); ++vi) {
            write_le32(&hive[0x1000 + vl_off + 4 + vi * 4], val_offsets[vi]);
        }
        uint8_t* target_nk = &hive[0x1000 + target_nk_off + 4];
        write_le32(target_nk + 0x24, static_cast<uint32_t>(val_offsets.size()));
        write_le32(target_nk + 0x28, vl_off);
    };

    // Create root nk cell ($$$PROTO.HIV)
    uint32_t root_off = make_cell(0x4C + 11);
    uint8_t* root_nk = &hive[0x1000 + root_off + 4];
    write_le16(root_nk + 0x00, 0x6B6E); // "nk"
    write_le16(root_nk + 0x02, 0x002C); // root key + ASCII
    write_le16(root_nk + 0x48, 11);     // name_len
    std::memcpy(root_nk + 0x4C, "$$$PROTO.HIV", 11);

    // Create Select nk cell
    uint32_t select_off = make_cell(0x4C + 6);
    uint8_t* select_nk = &hive[0x1000 + select_off + 4];
    write_le16(select_nk + 0x00, 0x6B6E);
    write_le16(select_nk + 0x02, 0x0020);
    write_le16(select_nk + 0x48, 6);
    std::memcpy(select_nk + 0x4C, "Select", 6);

    // Create Current vk cell under Select
    uint32_t cur_vk_off = make_cell(20 + 7);
    uint8_t* cur_vk = &hive[0x1000 + cur_vk_off + 4];
    write_le16(cur_vk + 0x00, 0x6B76); // "vk"
    write_le16(cur_vk + 0x02, 7);      // name_len
    write_le32(cur_vk + 0x04, 0x80000004); // inline 4 bytes
    write_le32(cur_vk + 0x08, current_control_set);
    write_le32(cur_vk + 0x0C, 4); // REG_DWORD
    write_le16(cur_vk + 0x10, 1); // ASCII
    std::memcpy(cur_vk + 0x14, "Current", 7);

    // Select value list
    uint32_t sel_vl_off = make_cell(4);
    write_le32(&hive[0x1000 + sel_vl_off + 4], cur_vk_off);
    write_le32(select_nk + 0x24, 1); // 1 value
    write_le32(select_nk + 0x28, sel_vl_off);

    // Create ControlSet00X nk cell
    char ccs_name[32];
    std::snprintf(ccs_name, sizeof(ccs_name), "ControlSet%03u", current_control_set);
    size_t ccs_len = std::strlen(ccs_name);

    uint32_t ccs_off = make_cell(0x4C + ccs_len);
    uint8_t* ccs_nk = &hive[0x1000 + ccs_off + 4];
    write_le16(ccs_nk + 0x00, 0x6B6E);
    write_le16(ccs_nk + 0x02, 0x0020);
    write_le16(ccs_nk + 0x48, static_cast<uint16_t>(ccs_len));
    std::memcpy(ccs_nk + 0x4C, ccs_name, ccs_len);

    // Root subkey list: Select + ControlSet00X, plus Microsoft when the OS version is
    // seeded -- that is the root path the SOFTWARE hive carries its version under
    // (Microsoft\Windows NT\CurrentVersion), so one synthetic file stands in for both.
    std::vector<uint32_t> root_children = {select_off, ccs_off};
    std::vector<std::string> root_child_names = {"Select", ccs_name};

    if (!current_version.empty()) {
        const uint32_t microsoft_off = make_nk("Microsoft");
        const uint32_t winnt_off = make_nk("Windows NT");
        const uint32_t version_off = make_nk("CurrentVersion");
        seed_version_values(version_off);
        link_children(winnt_off, {version_off}, {"CurrentVersion"});
        link_children(microsoft_off, {winnt_off}, {"Windows NT"});
        root_children.push_back(microsoft_off);
        root_child_names.emplace_back("Microsoft");
    }
    // Optional Enum\PCI devnodes: the parent PCI hardware IDs Windows records for devices
    // that are NOT network adapters (Intel H61 chipset functions, SMBus, SATA, ...). Seeded
    // so a test can prove the profile election never reads outside
    // Control\Class\{4d36e972-...}.
    if (!pci_devnode_ids.empty()) {
        const uint32_t enum_off = make_nk("Enum");
        const uint32_t pci_off = make_nk("PCI");
        std::vector<uint32_t> dev_offsets;
        std::vector<std::string> dev_names;
        dev_offsets.reserve(pci_devnode_ids.size());
        dev_names.reserve(pci_devnode_ids.size());
        for (const std::string& id : pci_devnode_ids) {
            dev_offsets.push_back(make_nk(id));
            dev_names.push_back(id);
        }
        link_children(pci_off, dev_offsets, dev_names);
        link_children(enum_off, {pci_off}, {"PCI"});
        root_children.push_back(enum_off);
        root_child_names.emplace_back("Enum");
    }

    link_children(root_off, root_children, root_child_names);

    // Optional Control hierarchy: net adapter instances and/or the seeded OS version.
    // The Control subkey list is written once at the end, when every child is known.
    uint32_t ctrl_off = 0xFFFFFFFF;
    std::vector<uint32_t> ctrl_children;
    std::vector<std::string> ctrl_child_names;

    if (!net_adapters.empty()) {
        ctrl_off = make_nk("Control");

        uint32_t class_off = make_nk("Class");
        ctrl_children.push_back(class_off);
        ctrl_child_names.emplace_back("Class");
        uint8_t* class_nk = &hive[0x1000 + class_off + 4];

        const std::string net_class_guid = "{4d36e972-e325-11ce-bfc1-08002be10318}";
        uint32_t net_class_off = make_cell(0x4C + net_class_guid.size());
        uint8_t* net_class_nk = &hive[0x1000 + net_class_off + 4];
        write_le16(net_class_nk + 0x00, 0x6B6E);
        write_le16(net_class_nk + 0x02, 0x0020);
        write_le16(net_class_nk + 0x48, static_cast<uint16_t>(net_class_guid.size()));
        std::memcpy(net_class_nk + 0x4C, net_class_guid.data(), net_class_guid.size());

        uint32_t class_sl_off = make_cell(4 + 1 * 8);
        uint8_t* class_sl = &hive[0x1000 + class_sl_off + 4];
        write_le16(class_sl + 0x00, 0x666C);
        write_le16(class_sl + 0x02, 1);
        write_le32(class_sl + 0x04, net_class_off);
        std::memcpy(class_sl + 0x08, "{4d3", 4);
        write_le32(class_nk + 0x14, 1);
        write_le32(class_nk + 0x1C, class_sl_off);

        std::vector<uint32_t> adapter_offsets;
        for (const auto& adapter : net_adapters) {
            uint32_t a_off = make_cell(0x4C + adapter.subkey_name.size());
            uint8_t* a_nk = &hive[0x1000 + a_off + 4];
            write_le16(a_nk + 0x00, 0x6B6E);
            write_le16(a_nk + 0x02, 0x0020);
            write_le16(a_nk + 0x48, static_cast<uint16_t>(adapter.subkey_name.size()));
            std::memcpy(a_nk + 0x4C, adapter.subkey_name.data(), adapter.subkey_name.size());

            std::vector<uint32_t> val_offsets;
            if (!adapter.driver_desc.empty()) {
                val_offsets.push_back(make_str_val("DriverDesc", adapter.driver_desc));
            }
            if (!adapter.matching_device_id.empty()) {
                val_offsets.push_back(make_str_val("MatchingDeviceId", adapter.matching_device_id));
            }
            if (!adapter.component_id.empty()) {
                val_offsets.push_back(make_str_val("ComponentId", adapter.component_id));
            }
            if (!adapter.service.empty()) {
                val_offsets.push_back(make_str_val("Service", adapter.service));
            }

            if (!val_offsets.empty()) {
                uint32_t vl_off = make_cell(val_offsets.size() * 4);
                for (size_t vi = 0; vi < val_offsets.size(); ++vi) {
                    write_le32(&hive[0x1000 + vl_off + 4 + vi * 4], val_offsets[vi]);
                }
                write_le32(a_nk + 0x24, static_cast<uint32_t>(val_offsets.size()));
                write_le32(a_nk + 0x28, vl_off);
            }

            // <Index>\Ndi\params\<ParamName>: the advanced properties this miniport
            // advertises. PnpDriverArmer only writes a parameter declared here, so a test
            // can model a driver whose older PHY silicon does not support *EEE.
            if (!adapter.ndi_params.empty()) {
                std::vector<uint32_t> param_offsets;
                std::vector<std::string> param_names;
                param_offsets.reserve(adapter.ndi_params.size());
                param_names.reserve(adapter.ndi_params.size());
                for (const std::string& param_name : adapter.ndi_params) {
                    param_offsets.push_back(make_nk(param_name));
                    param_names.push_back(param_name);
                }
                const uint32_t params_off = make_nk("params");
                link_children(params_off, param_offsets, param_names);
                const uint32_t ndi_off = make_nk("Ndi");
                link_children(ndi_off, {params_off}, {"params"});
                link_children(a_off, {ndi_off}, {"Ndi"});
            }

            adapter_offsets.push_back(a_off);
        }

        if (!adapter_offsets.empty()) {
            uint32_t net_sl_off = make_cell(4 + adapter_offsets.size() * 8);
            uint8_t* net_sl = &hive[0x1000 + net_sl_off + 4];
            write_le16(net_sl + 0x00, 0x666C);
            write_le16(net_sl + 0x02, static_cast<uint16_t>(adapter_offsets.size()));
            for (size_t ai = 0; ai < adapter_offsets.size(); ++ai) {
                write_le32(net_sl + 0x04 + ai * 8, adapter_offsets[ai]);
                std::string prefix = net_adapters[ai].subkey_name.substr(0, 4);
                while (prefix.size() < 4) prefix.push_back(' ');
                std::memcpy(net_sl + 0x08 + ai * 8, prefix.data(), 4);
            }
            write_le32(net_class_nk + 0x14, static_cast<uint32_t>(adapter_offsets.size()));
            write_le32(net_class_nk + 0x1C, net_sl_off);
        }
    }

    // Control\Windows: the OS version the offline family detector reads out of the
    // SYSTEM hive. Seeded even when no net adapters were requested.
    if (!current_version.empty()) {
        if (ctrl_off == 0xFFFFFFFF) {
            ctrl_off = make_nk("Control");
        }
        const uint32_t windows_off = make_nk("Windows");
        seed_version_values(windows_off);
        ctrl_children.push_back(windows_off);
        ctrl_child_names.emplace_back("Windows");
    }
    if (ctrl_off != 0xFFFFFFFF) {
        link_children(ctrl_off, ctrl_children, ctrl_child_names);
    }

    // Create Services nk cell under ControlSet00X
    uint32_t svc_off = make_cell(0x4C + 8);
    uint8_t* svc_nk = &hive[0x1000 + svc_off + 4];
    write_le16(svc_nk + 0x00, 0x6B6E);
    write_le16(svc_nk + 0x02, 0x0020);
    write_le16(svc_nk + 0x48, 8);
    std::memcpy(svc_nk + 0x4C, "Services", 8);

    // ControlSet subkey list pointing to Control (if present) and Services
    if (ctrl_off != 0xFFFFFFFF) {
        uint32_t ccs_sublist_off = make_cell(4 + 2 * 8);
        uint8_t* ccs_sl = &hive[0x1000 + ccs_sublist_off + 4];
        write_le16(ccs_sl + 0x00, 0x666C); // "lf"
        write_le16(ccs_sl + 0x02, 2);
        write_le32(ccs_sl + 0x04, ctrl_off);
        std::memcpy(ccs_sl + 0x08, "Cont", 4);
        write_le32(ccs_sl + 0x0C, svc_off);
        std::memcpy(ccs_sl + 0x10, "Serv", 4);

        write_le32(ccs_nk + 0x14, 2);
        write_le32(ccs_nk + 0x1C, ccs_sublist_off);
    } else {
        uint32_t ccs_sublist_off = make_cell(4 + 1 * 8);
        uint8_t* ccs_sl = &hive[0x1000 + ccs_sublist_off + 4];
        write_le16(ccs_sl + 0x00, 0x666C); // "lf"
        write_le16(ccs_sl + 0x02, 1);
        write_le32(ccs_sl + 0x04, svc_off);
        std::memcpy(ccs_sl + 0x08, "Serv", 4);

        write_le32(ccs_nk + 0x14, 1);
        write_le32(ccs_nk + 0x1C, ccs_sublist_off);
    }

    // Add service keys under Services
    std::vector<uint32_t> svc_child_offsets;
    for (const auto& [svc_name, init_start] : services_with_initial_start) {
        uint32_t s_off = make_cell(0x4C + svc_name.size());
        uint8_t* s_nk = &hive[0x1000 + s_off + 4];
        write_le16(s_nk + 0x00, 0x6B6E);
        write_le16(s_nk + 0x02, 0x0020);
        write_le16(s_nk + 0x48, static_cast<uint16_t>(svc_name.size()));
        std::memcpy(s_nk + 0x4C, svc_name.data(), svc_name.size());

        // Value "Start" = init_start
        uint32_t start_vk_off = make_cell(20 + 5);
        uint8_t* start_vk = &hive[0x1000 + start_vk_off + 4];
        write_le16(start_vk + 0x00, 0x6B76);
        write_le16(start_vk + 0x02, 5); // "Start"
        write_le32(start_vk + 0x04, 0x80000004);
        write_le32(start_vk + 0x08, init_start);
        write_le32(start_vk + 0x0C, 4); // REG_DWORD
        write_le16(start_vk + 0x10, 1);
        std::memcpy(start_vk + 0x14, "Start", 5);

        uint32_t s_vl_off = make_cell(4);
        write_le32(&hive[0x1000 + s_vl_off + 4], start_vk_off);
        write_le32(s_nk + 0x24, 1);
        write_le32(s_nk + 0x28, s_vl_off);

        svc_child_offsets.push_back(s_off);
    }

    if (!svc_child_offsets.empty()) {
        uint32_t svc_sl_off = make_cell(4 + svc_child_offsets.size() * 8);
        uint8_t* svc_sl = &hive[0x1000 + svc_sl_off + 4];
        write_le16(svc_sl + 0x00, 0x666C); // "lf"
        write_le16(svc_sl + 0x02, static_cast<uint16_t>(svc_child_offsets.size()));
        for (size_t i = 0; i < svc_child_offsets.size(); ++i) {
            write_le32(svc_sl + 0x04 + i * 8, svc_child_offsets[i]);
            std::string prefix = services_with_initial_start[i].first.substr(0, 4);
            while (prefix.size() < 4) prefix.push_back(' ');
            std::memcpy(svc_sl + 0x08 + i * 8, prefix.data(), 4);
        }
        write_le32(svc_nk + 0x14, static_cast<uint32_t>(svc_child_offsets.size()));
        write_le32(svc_nk + 0x1C, svc_sl_off);
    }

    // Optional pre-seed of <service>\Parameters. Reproduces the state an earlier armer pass
    // left under the flat Realtek key (Services\rt640x64\Parameters) so the purge path can
    // be exercised without running the armer twice -- the armer itself never creates this
    // key for the Realtek family.
    if (!service_parameters.empty()) {
        std::vector<uint32_t> params_off_by_service(services_with_initial_start.size(),
                                                    0xFFFFFFFF);
        std::vector<std::vector<uint32_t>> values_by_service(services_with_initial_start.size());

        for (const auto& seed : service_parameters) {
            size_t index = services_with_initial_start.size();
            for (size_t si = 0; si < services_with_initial_start.size(); ++si) {
                if (services_with_initial_start[si].first == seed.service) {
                    index = si;
                    break;
                }
            }
            if (index == services_with_initial_start.size()) continue;

            if (params_off_by_service[index] == 0xFFFFFFFF) {
                params_off_by_service[index] = make_nk("Parameters");
                link_children(svc_child_offsets[index], {params_off_by_service[index]},
                              {"Parameters"});
            }
            values_by_service[index].push_back(seed.is_dword
                                                   ? make_dword_val(seed.name, seed.dword)
                                                   : make_str_val(seed.name, seed.text));
        }

        for (size_t si = 0; si < services_with_initial_start.size(); ++si) {
            if (params_off_by_service[si] == 0xFFFFFFFF) continue;
            const std::vector<uint32_t>& values = values_by_service[si];
            if (values.empty()) continue;

            const uint32_t params_off = params_off_by_service[si];
            const uint32_t vl_off = make_cell(values.size() * 4);
            for (size_t vi = 0; vi < values.size(); ++vi) {
                write_le32(&hive[0x1000 + vl_off + 4 + vi * 4], values[vi]);
            }
            uint8_t* params_nk = &hive[0x1000 + params_off + 4];
            write_le32(params_nk + 0x24, static_cast<uint32_t>(values.size()));
            write_le32(params_nk + 0x28, vl_off);
        }
    }

    // Mark remaining space in hbin as a free cell
    if (alloc_ptr < (HIVE_SIZE - 0x1000)) {
        size_t free_size = (HIVE_SIZE - 0x1000) - alloc_ptr;
        write_le32(&hive[0x1000 + alloc_ptr], static_cast<uint32_t>(free_size));
    }

    // Compute checksum
    uint32_t csum = calculate_regf_header_checksum(hive.data());
    write_le32(&hive[0x1FC], csum);

    return hive;
}

// ---- Offline hive inspection (read-only diagnostics) -------------------------------
//
// Nothing below mutates the hive: this is the "before" half of the
// inspect -> fix-boot-conflicts -> re-inspect workflow that replaces mounting the target
// volume by hand.

namespace {

// <Volume>\Windows\System32\DriverStore\FileRepository\*\[*\]rt640x64.sys -- the DriverStore
// copy a staged .sys is supposed to be byte-identical to. Two levels of package nesting
// covers both the flat (netrtl8168.inf_amd64_x\rt640x64.sys) and the nested
// (netrtl8168.inf_amd64_x\NetAdapterCard\rt640x64.sys) layouts. Packages are visited in
// sorted order so the answer is deterministic when more than one carries the file.
std::filesystem::path find_driver_store_source(const std::filesystem::path& volume_path,
                                               const std::string& driver_file) {
    std::error_code ec;
    const std::filesystem::path repo = volume_path / "Windows" / "System32" /
                                       "DriverStore" / "FileRepository";
    if (!std::filesystem::is_directory(repo, ec)) return {};

    const std::filesystem::directory_iterator dir_end;
    std::vector<std::filesystem::path> packages;
    for (std::filesystem::directory_iterator it(repo, ec); !ec && it != dir_end; it.increment(ec)) {
        std::error_code type_ec;
        if (it->is_directory(type_ec)) packages.push_back(it->path());
    }
    std::sort(packages.begin(), packages.end());

    for (const auto& pkg : packages) {
        const std::filesystem::path direct = pkg / driver_file;
        if (std::filesystem::is_regular_file(direct, ec)) return direct;
    }
    for (const auto& pkg : packages) {
        std::vector<std::filesystem::path> children;
        for (std::filesystem::directory_iterator it(pkg, ec); !ec && it != dir_end; it.increment(ec)) {
            std::error_code type_ec;
            if (it->is_directory(type_ec)) children.push_back(it->path());
        }
        std::sort(children.begin(), children.end());
        for (const auto& child : children) {
            const std::filesystem::path nested = child / driver_file;
            if (std::filesystem::is_regular_file(nested, ec)) return nested;
        }
    }
    return {};
}

std::string start_value_label(int32_t start) {
    switch (start) {
        case 0: return "0 (SERVICE_BOOT_START)";
        case 1: return "1 (SERVICE_SYSTEM_START)";
        case 2: return "2 (SERVICE_AUTO_START)";
        case 3: return "3 (SERVICE_DEMAND_START)";
        case 4: return "4 (SERVICE_DISABLED)";
        default: return std::to_string(start) + " (<absent or unknown>)";
    }
}

std::string join_names(const std::vector<std::string>& names, const char* sep) {
    std::string out;
    for (size_t i = 0; i < names.size(); ++i) {
        if (i > 0) out += sep;
        out += names[i];
    }
    return out;
}
} // namespace

std::string PnpHiveInspectionReport::summary() const {
    std::ostringstream ss;
    ss << "=== CobDiskless Offline SYSTEM Hive Inspection ===\n";
    ss << "Hive:        " << (hive_path.empty() ? std::string("<memory buffer>") : hive_path.string()) << "\n";
    ss << "Volume:      " << (volume_path.empty() ? std::string("<not provided -- hash/version checks skipped>")
                                                  : volume_path.string()) << "\n";
    ss << "ControlSet:  " << (control_set.empty() ? std::string("<none resolved>") : control_set) << "\n";
    ss << "Guest OS:    " << (guest_os_family.empty() ? std::string("unknown") : guest_os_family) << "\n";
    ss << "Status:      " << (success ? "OK" : "FAILED") << "\n";
    if (!message.empty()) ss << "Message:     " << message << "\n";

    ss << "\n-- NIC / boot driver services (" << nic_services.size() << ") --\n";
    for (const auto& svc : nic_services) {
        ss << "  Services\\" << svc.service_name << ": ";
        if (!svc.present) {
            ss << "ABSENT\n";
            continue;
        }
        ss << "Start=" << start_value_label(svc.start);
        if (!svc.group.empty()) ss << ", Group=" << svc.group;
        ss << ", BootFlags=" << (svc.has_boot_flags ? std::to_string(svc.boot_flags)
                                                    : std::string("ABSENT"));
        if (svc.has_parameters) {
            ss << ", Parameters=(" << svc.parameter_values.size() << " value(s), "
               << svc.parameter_subkeys.size() << " subkey(s))";
            if (!svc.parameter_values.empty()) {
                ss << " [" << join_names(svc.parameter_values, ", ") << "]";
            }
        } else {
            ss << ", Parameters=ABSENT";
        }
        ss << "\n";
    }

    ss << "\n-- Net class bindings (Control\\Class\\" << NETWORK_CLASS_GUID << ") --\n";
    if (net_adapters.empty()) {
        ss << "  (no adapter instance carries a DriverDesc/MatchingDeviceId/ComponentId)\n";
    }
    for (const auto& ad : net_adapters) {
        ss << "  " << (ad.subkey.empty() ? std::string("?") : ad.subkey) << ": ";
        ss << "DriverDesc='" << ad.driver_desc << "'";
        ss << ", MatchingDeviceId='" << ad.matching_device_id << "'";
        ss << ", ComponentId='" << ad.component_id << "'\n";
    }

    ss << "\n-- Driver binary identity (" << driver_files.size() << ") --\n";
    if (driver_files.empty()) {
        ss << "  (no volume provided -- skipped)\n";
    }
    for (const auto& df : driver_files) {
        ss << "  " << df.driver_file << ":\n";
        ss << "    deployed : " << (df.deployed_present ? df.deployed.string() : std::string("<missing>"));
        if (df.deployed_present) {
            ss << " sha256=" << (df.deployed_sha256.empty() ? "<unreadable>" : df.deployed_sha256)
               << " version=" << (df.deployed_version.empty() ? "<unknown>" : df.deployed_version);
        }
        ss << "\n";
        ss << "    source   : " << (df.source_present ? df.source.string() : std::string("<not found in DriverStore>"));
        if (df.source_present) {
            ss << " sha256=" << (df.source_sha256.empty() ? "<unreadable>" : df.source_sha256)
               << " version=" << (df.source_version.empty() ? "<unknown>" : df.source_version);
        }
        ss << "\n";
        ss << "    verdict  : " << (df.identical ? "MATCH" : "MISMATCH / UNVERIFIABLE") << "\n";
    }

    ss << "\n-- Findings (" << findings.size() << ") --\n";
    if (findings.empty()) ss << "  (none)\n";
    for (const auto& line : findings) ss << "  * " << line << "\n";

    return ss.str();
}

Result<PnpHiveInspectionReport> PnpDriverArmer::inspect_hive_buffer(
    const std::vector<uint8_t>& hive_data,
    const std::filesystem::path& hive_path,
    const std::filesystem::path& volume_path
) {
    PnpHiveInspectionReport report;
    report.hive_path = hive_path;
    report.volume_path = volume_path;

    if (hive_data.size() < 8192) {
        return Error(ErrorCode::InvalidConfiguration,
                     "Hive buffer too small to be a valid Windows registry hive");
    }
    if (hive_data[0] != 'r' || hive_data[1] != 'e' || hive_data[2] != 'g' || hive_data[3] != 'f') {
        return Error(ErrorCode::InvalidConfiguration,
                     "Invalid hive header: missing 'regf' signature");
    }

    const uint32_t root = regf_root_offset(hive_data);
    if (root == 0xFFFFFFFF) {
        return Error(ErrorCode::InvalidConfiguration, "Invalid root cell offset in hive header");
    }

    report.control_set = regf_control_set_name(hive_data, "");
    const uint32_t cs_off = report.control_set.empty()
                                ? 0xFFFFFFFF
                                : regf_find_subkey(hive_data, root, report.control_set);
    if (cs_off == 0xFFFFFFFF) {
        report.success = false;
        report.message = "No ControlSet / CurrentControlSet found in this SYSTEM hive";
        report.findings.push_back("FATAL: no active ControlSet -- nothing in this hive can be armed");
        return report;
    }

    report.guest_os_family = os_family_name(detect_os_family_from_hive(hive_data, report.control_set));

    // ---- 1. NIC / boot driver services: Start, Group, BootFlags and the flat
    //         Services\<drv>\Parameters key a rogue pass may have injected values into.
    const uint32_t services_off = regf_find_subkey(hive_data, cs_off, "Services");

    std::vector<std::string> watch = critical_boot_services();
    if (services_off != 0xFFFFFFFF) {
        regf_walk_subkeys(hive_data, services_off, [&](uint32_t svc_off) -> bool {
            std::string name;
            if (!regf_nk_name(hive_data, svc_off, &name) || name.empty()) return true;
            const std::string group = regf_get_string(hive_data, svc_off, "Group");
            const bool relevant =
                string_iequal(group, "NDIS") || is_realtek_service_name(name) ||
                is_intel_service_name(name);
            if (!relevant) return true;
            const bool already_watched = std::any_of(
                watch.begin(), watch.end(), [&](const std::string& w) { return string_iequal(w, name); });
            if (!already_watched) watch.push_back(name);
            return true;
        });
    }

    for (const std::string& name : watch) {
        NicServiceInspection svc;
        svc.service_name = name;
        const uint32_t svc_off = (services_off == 0xFFFFFFFF)
                                     ? 0xFFFFFFFF
                                     : regf_find_subkey(hive_data, services_off, name);
        if (svc_off == 0xFFFFFFFF) {
            report.nic_services.push_back(svc);
            continue;
        }

        svc.present = true;
        uint32_t start = 0;
        if (regf_get_dword(hive_data, svc_off, "Start", &start)) {
            svc.start = static_cast<int32_t>(start);
        }
        svc.group = regf_get_string(hive_data, svc_off, "Group");
        uint32_t boot_flags = 0;
        if (regf_get_dword(hive_data, svc_off, "BootFlags", &boot_flags)) {
            svc.has_boot_flags = true;
            svc.boot_flags = boot_flags;
        }

        const uint32_t params_off = regf_find_subkey(hive_data, svc_off, "Parameters");
        if (params_off != 0xFFFFFFFF) {
            svc.has_parameters = true;
            svc.parameter_values = regf_value_names(hive_data, params_off);
            for (uint32_t child_off : regf_list_subkeys(hive_data, params_off)) {
                std::string child_name;
                if (regf_nk_name(hive_data, child_off, &child_name) && !child_name.empty()) {
                    svc.parameter_subkeys.push_back(child_name);
                }
            }
        }
        report.nic_services.push_back(svc);
    }

    for (const auto& svc : report.nic_services) {
        if (!svc.present) {
            if (is_realtek_service_name(svc.service_name) || is_intel_service_name(svc.service_name)) {
                report.findings.push_back("Services\\" + svc.service_name +
                                          ": ABSENT (not staged in this image)");
            }
            continue;
        }
        std::string line = "Services\\" + svc.service_name + ": Start=" + start_value_label(svc.start);
        if (!svc.group.empty()) line += ", Group=" + svc.group;
        if (svc.has_boot_flags) line += ", BootFlags=" + std::to_string(svc.boot_flags);
        line += svc.has_parameters
                    ? (", Parameters present (" + join_names(svc.parameter_values, ", ") + ")")
                    : ", Parameters absent";
        report.findings.push_back(line);
    }

    // The incident pair: two vendor families at Start = 0 at the same time.
    auto service_state = [&](const std::string& name, bool* present, int32_t* start) {
        *present = false;
        *start = -1;
        for (const auto& svc : report.nic_services) {
            if (!string_iequal(svc.service_name, name)) continue;
            *present = svc.present;
            *start = svc.start;
            return;
        }
    };

    bool rt_present = false;
    bool intel_present = false;
    int32_t rt_start = -1;
    int32_t intel_start = -1;
    service_state("rt640x64", &rt_present, &rt_start);
    service_state("e1d68x64", &intel_present, &intel_start);

    if (rt_present && intel_present && rt_start == 0 && intel_start == 0) {
        report.findings.push_back(
            "BOOT CONFLICT: rt640x64 AND e1d68x64 are both Start=0 (SERVICE_BOOT_START) -- "
            "Phase 0 will run miniport DriverEntry for silicon that may not be on the board "
            "(stop 0xA). Run cob-armer --fix-boot-conflicts or pass --nic-profile.");
    }
    if (rt_present && rt_start == 0) {
        for (const auto& svc : report.nic_services) {
            if (!string_iequal(svc.service_name, "rt640x64")) continue;
            if (svc.has_parameters) {
                report.findings.push_back(
                    "HAZARD: Services\\rt640x64\\Parameters exists (" +
                    join_names(svc.parameter_values, ", ") +
                    "). The Realtek miniport reads Control\\Class only; these values are "
                    "parsed during DriverEntry with no schema to validate them against.");
            } else {
                report.findings.push_back("Services\\rt640x64\\Parameters absent (expected).");
            }
        }
    }

    // ---- 2. Hardware bindings the installer left under the Net class key.
    const uint32_t net_class_off =
        regf_open_path(hive_data, cs_off, std::string("Control\\Class\\") + NETWORK_CLASS_GUID);
    if (net_class_off != 0xFFFFFFFF) {
        regf_walk_subkeys(hive_data, net_class_off, [&](uint32_t instance_off) -> bool {
            NetAdapterInspection ad;
            regf_nk_name(hive_data, instance_off, &ad.subkey);
            ad.driver_desc = regf_get_string(hive_data, instance_off, "DriverDesc");
            ad.matching_device_id = regf_get_string(hive_data, instance_off, "MatchingDeviceId");
            ad.component_id = regf_get_string(hive_data, instance_off, "ComponentId");
            if (ad.driver_desc.empty() && ad.matching_device_id.empty() && ad.component_id.empty()) {
                return true;
            }
            report.net_adapters.push_back(ad);
            report.findings.push_back(
                "Control\\Class\\" + std::string(NETWORK_CLASS_GUID) + "\\" + ad.subkey +
                ": DriverDesc='" + ad.driver_desc + "', MatchingDeviceId='" +
                ad.matching_device_id + "', ComponentId='" + ad.component_id + "'");
            return true;
        });
    }
    if (report.net_adapters.empty()) {
        report.findings.push_back(
            std::string("No hardware binding found under Control\\Class\\") + NETWORK_CLASS_GUID +
            " -- the image carries no NIC vendor evidence, so the boot-start profile "
            "cannot be narrowed from the hive alone.");
    }

    // ---- 3. Hash / version identity of the staged .sys against its DriverStore source.
    if (!volume_path.empty()) {
        const std::filesystem::path drivers_dir =
            volume_path / "Windows" / "System32" / "drivers";
        for (const std::string& driver_file : critical_boot_drivers()) {
            DriverFileInspection df;
            df.driver_file = driver_file;
            df.service_name = driver_file.size() > 4 ? driver_file.substr(0, driver_file.size() - 4)
                                                     : driver_file;

            df.deployed = drivers_dir / driver_file;
            std::error_code ec;
            df.deployed_present = std::filesystem::is_regular_file(df.deployed, ec);
            if (df.deployed_present) {
                df.deployed_sha256 = sha256_file(df.deployed);
                df.deployed_version = read_pe_version_string(df.deployed);
            }

            df.source = find_driver_store_source(volume_path, driver_file);
            df.source_present = !df.source.empty();
            if (df.source_present) {
                df.source_sha256 = sha256_file(df.source);
                df.source_version = read_pe_version_string(df.source);
            }

            df.identical = df.deployed_present && df.source_present &&
                           !df.deployed_sha256.empty() && !df.source_sha256.empty() &&
                           df.deployed_sha256 == df.source_sha256;
            report.driver_files.push_back(df);

            std::string verdict;
            if (!df.deployed_present) {
                verdict = "staged copy MISSING at " + df.deployed.string();
            } else if (!df.source_present) {
                verdict = "no DriverStore source found for " + driver_file +
                          " (staged copy sha256=" + df.deployed_sha256 + ")";
            } else if (df.identical) {
                verdict = "MATCH -- staged copy is byte-identical to the DriverStore source";
            } else {
                verdict = "MISMATCH -- staged copy sha256=" + df.deployed_sha256 +
                          " differs from DriverStore source sha256=" + df.source_sha256;
            }
            report.findings.push_back(driver_file + ": " + verdict);
        }
    }

    report.success = true;
    report.message = "Inspected " + report.control_set + ": " +
                     std::to_string(report.nic_services.size()) + " service(s), " +
                     std::to_string(report.net_adapters.size()) + " net class binding(s), " +
                     std::to_string(report.driver_files.size()) + " driver binary check(s)";
    return report;
}

Result<PnpHiveInspectionReport> PnpDriverArmer::inspect_offline_hive(
    const std::filesystem::path& hive_path,
    const std::filesystem::path& volume_path
) {
    auto read_res = read_hive_file(hive_path);
    if (!read_res.is_ok()) {
        return read_res.error();
    }

    std::filesystem::path vol = volume_path;
    if (vol.empty()) {
        // <Volume>\Windows\System32\config\SYSTEM -> <Volume>, so the hash/version half
        // of the report works without the operator having to name the mount point.
        const std::filesystem::path config_dir = hive_path.parent_path();
        const std::filesystem::path system32_dir = config_dir.parent_path();
        if (string_iequal(config_dir.filename().string(), "config") &&
            string_iequal(system32_dir.filename().string(), "System32")) {
            vol = system32_dir.parent_path().parent_path();
        }
    }
    return inspect_hive_buffer(read_res.value(), hive_path, vol);
}

Result<PnpHiveInspectionReport> PnpDriverArmer::inspect_vhd_image(
    const std::filesystem::path& image_path
) {
    std::error_code ec;
    if (!std::filesystem::exists(image_path, ec)) {
        return Error(ErrorCode::StorageFailure, "Target file not found: " + image_path.string());
    }

    // 1. A raw SYSTEM hive handed straight to the CLI.
    {
        std::ifstream in(image_path, std::ios::binary);
        if (in.is_open()) {
            char sig[4] = {0};
            in.read(sig, 4);
            in.close();
            if (std::memcmp(sig, "regf", 4) == 0) {
                return inspect_offline_hive(image_path);
            }
        }
    }

    // 2. An already-mounted volume (or an expanded Windows directory).
    const std::filesystem::path direct = image_path / "Windows" / "System32" / "config" / "SYSTEM";
    if (std::filesystem::is_regular_file(direct, ec)) {
        return inspect_offline_hive(direct, image_path);
    }
    const std::filesystem::path bare = image_path / "System32" / "config" / "SYSTEM";
    if (std::filesystem::is_regular_file(bare, ec)) {
        return inspect_offline_hive(bare, image_path);
    }

    // 3. A raw .vhd/.vhdx: attach it, read the hive and hash the driver files while the
    //    volume is live, then detach. MountedVhdVolume is shared with arm_vhd_image().
#if defined(_WIN32) || defined(__CYGWIN__) || defined(__MSYS__)
    MountedVhdVolume mounted(image_path);
    if (mounted.found_hive()) {
        auto result = inspect_offline_hive(mounted.hive_path(), mounted.volume_root());
        if (result.is_ok()) {
            for (const std::string& w : mounted.warnings()) {
                result.value().findings.push_back("mount: " + w);
            }
        }
        return result;
    }
    std::string reason = "no Windows SYSTEM hive found in " + image_path.string();
    if (!mounted.warnings().empty()) reason += " (" + mounted.warnings().front() + ")";
    return Error(ErrorCode::StorageFailure, reason);
#else
    return Error(ErrorCode::UnsupportedOperation,
                 "Raw VHD/VHDX images can only be inspected on a Windows host; pass a "
                 "SYSTEM hive or a mounted volume root instead: " + image_path.string());
#endif
}

Result<PnpDriverArmReport> PnpDriverArmer::fix_boot_conflicts_offline_hive(
    const std::filesystem::path& hive_path,
    NicBootProfile profile
) {
    // ---- Resolve which vendor family owns Phase 0 ---------------------------------
    // Auto looks at the image's own bindings; a hive that carries no vendor evidence at
    // all is repaired with the Realtek layout, which is what the single-vendor boards in
    // the field (M71s / RTL8111E) need.
    NicBootProfile effective = profile;
    if (effective == NicBootProfile::Auto) {
        auto pre_res = read_hive_file(hive_path);
        NicVendorEvidence ev;
        if (pre_res.is_ok()) {
            ev = collect_nic_vendor_evidence(pre_res.value(), "", {});
        }
        if (ev.realtek() && !ev.intel()) {
            effective = NicBootProfile::Realtek;
        } else if (ev.intel() && !ev.realtek()) {
            effective = NicBootProfile::Intel;
        } else {
            effective = NicBootProfile::Realtek;
        }
    }

    // ---- (1) demote the losing family, (3) purge the flat Realtek Parameters key,
    //      (4) flush with synchronized sequence numbers and truncated .LOG1/.LOG2. All of
    //      that is the ordinary arming pass, driven by the single-vendor profile.
    auto arm_res = arm_offline_system_hive(hive_path, effective);
    if (!arm_res.is_ok()) {
        return arm_res.error();
    }
    auto& report = arm_res.value();
    report.nic_profile = nic_profile_name(effective);

    // ---- (2) verify the selected primary survived as a boot-start NDIS driver -------
    auto verify_res = read_hive_file(hive_path);
    if (!verify_res.is_ok()) {
        report.success = false;
        report.message = "Boot conflict fix written, but the hive could not be re-read for verification";
        return report;
    }

    const std::vector<uint8_t>& buf = verify_res.value();
    const uint32_t root = regf_root_offset(buf);
    const std::string cs = regf_control_set_name(buf, report.control_set);
    const uint32_t cs_off = cs.empty() ? 0xFFFFFFFF : regf_find_subkey(buf, root, cs);
    const uint32_t services_off = (cs_off == 0xFFFFFFFF)
                                      ? 0xFFFFFFFF
                                      : regf_find_subkey(buf, cs_off, "Services");

    auto read_service = [&](const std::string& name, int32_t* start, std::string* group) -> bool {
        if (services_off == 0xFFFFFFFF) return false;
        const uint32_t svc_off = regf_find_subkey(buf, services_off, name);
        if (svc_off == 0xFFFFFFFF) return false;
        uint32_t value = 0xFFFFFFFF;
        if (regf_get_dword(buf, svc_off, "Start", &value)) {
            *start = static_cast<int32_t>(value);
        }
        if (group) *group = regf_get_string(buf, svc_off, "Group");
        return true;
    };

    bool ok = true;
    const std::string primary = (effective == NicBootProfile::Intel) ? "e1d68x64" : "rt640x64";

    int32_t primary_start = -1;
    std::string primary_group;
    if (!read_service(primary, &primary_start, &primary_group) ||
        primary_start != static_cast<int32_t>(SERVICE_START_BOOT) ||
        !string_iequal(primary_group, "NDIS")) {
        ok = false;
        report.warnings.push_back("Verification failed: Services\\" + primary +
                                  " is not Start=0 with Group=NDIS (Start=" +
                                  std::to_string(primary_start) + ", Group='" + primary_group + "')");
    }

    if (effective == NicBootProfile::Realtek || effective == NicBootProfile::Intel) {
        const std::vector<std::string>& losing =
            (effective == NicBootProfile::Realtek) ? intel_service_family()
                                                   : realtek_service_family();
        for (const std::string& svc : losing) {
            int32_t start = -1;
            if (!read_service(svc, &start, nullptr)) continue;
            if (start != static_cast<int32_t>(SERVICE_START_DEMAND)) {
                ok = false;
                report.warnings.push_back("Verification failed: Services\\" + svc +
                                          " did not demote to Start=3 (Start=" +
                                          std::to_string(start) + ")");
            }
        }
    }

    // (3) No armer-owned anti-flap value may survive under the flat Realtek key.
    for (const std::string& svc : realtek_service_family()) {
        if (services_off == 0xFFFFFFFF) break;
        const uint32_t svc_off = regf_find_subkey(buf, services_off, svc);
        if (svc_off == 0xFFFFFFFF) continue;
        const uint32_t params_off = regf_find_subkey(buf, svc_off, "Parameters");
        if (params_off == 0xFFFFFFFF) continue;

        const std::vector<std::string> names = regf_value_names(buf, params_off);
        std::vector<std::string> leftovers;
        for (const auto& dw : REALTEK_ANTI_FLAP_DWORDS) {
            const bool present = std::any_of(names.begin(), names.end(),
                                             [&](const std::string& n) { return string_iequal(n, dw.name); });
            if (present) leftovers.push_back(dw.name);
        }
        for (const char* sz : REALTEK_ANTI_FLAP_STRINGS) {
            const bool present = std::any_of(names.begin(), names.end(),
                                             [&](const std::string& n) { return string_iequal(n, sz); });
            if (present) leftovers.push_back(sz);
        }
        if (!leftovers.empty()) {
            ok = false;
            report.warnings.push_back("Verification failed: Services\\" + svc +
                                      "\\Parameters still carries armer anti-flap value(s): " +
                                      join_names(leftovers, ", "));
        }
    }

    report.success = ok;
    report.message =
        (ok ? "Boot conflicts fixed" : "Boot conflict fix written but verification FAILED") +
        std::string(": ") + primary + " at Start=0 with Group=NDIS, " +
        std::to_string(report.demoted_services.size()) + " losing-vendor service(s) demoted to "
        "Start=3, " + std::to_string(report.service_parameters_purged.size()) +
        " flat service Parameters key(s) purged, hive flushed with synchronized sequence "
        "numbers and truncated .LOG/.LOG1/.LOG2";
    if (!ok) {
        Logger::default_logger().info("PNP", "[PNP] --fix-boot-conflicts verification FAILED: " +
                                          report.message);
    }
    return report;
}

// ---- Faulting-driver triage and DriverStore rollback ------------------------------
//
// Implements the M71s stop 0xA workflow (faulting RIP 0xFFFFF80750ACE534 == RVA 0xE534
// inside rt640x64.sys):
//
//   1. identify the staged binary -- FileVersion, ProductVersion, SHA-256, section table;
//   2. attribute the faulting offset by mapping 0xE534 onto the section table instead of
//      assuming it is code;
//   3. find the older DriverStore package (the 9.1.408.x / 10.1.x inbox and OEM builds
//      that still bring up RTL8111E Rev 06 PHYs) and, on request, roll it into place.
//
// Step 3 is the ONE code path in this file allowed to overwrite an existing staged .sys.
// stage_harvested_drivers() and friends still refuse to, because replacing a driver that
// already boots is exactly what put the M71s in the debugger.

namespace {

// Case-insensitive glob supporting '*' and '?' only -- enough for the FileRepository
// folder patterns (netrt640*.inf_*, netrtl8168*.inf_*) without pulling in <regex>.
bool match_wildcard_ci(const std::string& pattern, const std::string& text) {
    const std::string p = to_lower_copy(pattern);
    const std::string t = to_lower_copy(text);
    size_t pi = 0;
    size_t ti = 0;
    size_t star = std::string::npos;
    size_t mark = 0;
    while (ti < t.size()) {
        if (pi < p.size() && (p[pi] == '?' || p[pi] == t[ti])) {
            ++pi;
            ++ti;
        } else if (pi < p.size() && p[pi] == '*') {
            star = pi++;
            mark = ti;
        } else if (star != std::string::npos) {
            pi = star + 1;
            ti = ++mark;
        } else {
            return false;
        }
    }
    while (pi < p.size() && p[pi] == '*') ++pi;
    return pi == p.size();
}

// Path components that identify Windows plumbing rather than the volume itself. Walking
// them off the end of the operator's argument lets one resolver accept a volume root, an
// expanded Windows directory, System32, System32\drivers, a SYSTEM hive or a .sys.
bool is_windows_path_component(const std::string& name) {
    return string_iequal(name, "drivers") || string_iequal(name, "System32") ||
           string_iequal(name, "config") || string_iequal(name, "Windows") ||
           string_iequal(name, "WinNT");
}

// "a.b.c.d" -> 64-bit sort key with each component in 16 bits. Returns false when the
// string is not a dotted numeric version, so unknown versions are never ranked (and never
// assumed to be legacy-safe).
bool version_sort_key(const std::string& text, uint64_t* key) {
    if (key == nullptr) return false;
    *key = 0;
    if (text.empty()) return false;

    uint64_t packed = 0;
    size_t pos = 0;
    for (unsigned component = 0; component < 4; ++component) {
        const size_t start = pos;
        while (pos < text.size() &&
               std::isdigit(static_cast<unsigned char>(text[pos])) != 0) {
            ++pos;
        }
        if (pos == start) return false;
        unsigned long value = 0;
        try {
            value = std::stoul(text.substr(start, pos - start));
        } catch (...) {
            return false;
        }
        if (value > 0xFFFFul) return false;
        packed = (packed << 16) | static_cast<uint64_t>(value);
        if (pos >= text.size()) break;
        if (text[pos] != '.') return false;
        ++pos;
    }
    // A 2- or 3-part version is padded with zeroes so it sorts next to "a.b.0.0".
    for (unsigned filled = static_cast<unsigned>(std::count(text.begin(), text.end(), '.')) + 1;
         filled < 4; ++filled) {
        packed <<= 16;
    }
    *key = packed;
    return true;
}

std::string hex_u32(uint32_t value) {
    std::ostringstream oss;
    oss << "0x" << std::uppercase << std::hex << value;
    return oss.str();
}

// Turns whatever the operator handed the CLI -- a volume root, an expanded Windows
// directory, System32[\drivers], the .sys itself, a SYSTEM hive, or a .vhd/.vhdx -- into
// the volume that owns <driver_file> plus the path of the active binary. A disk image is
// attached here and detached again when the scope object dies, so callers can read and
// write the volume for the whole duration of the operation.
class DriverTargetScope {
public:
    DriverTargetScope() = default;
    DriverTargetScope(const DriverTargetScope&) = delete;
    DriverTargetScope& operator=(const DriverTargetScope&) = delete;

    // `driver_file` is the binary to look for; a .sys argument overrides it.
    bool open(const std::filesystem::path& target, const std::string& driver_file);

    const std::filesystem::path& volume_root() const { return volume_root_; }
    const std::filesystem::path& active_path() const { return active_path_; }
    const std::string& driver_file() const { return driver_file_; }
    const std::string& error() const { return error_; }
    const std::vector<std::string>& warnings() const { return warnings_; }

private:
    bool attach_image(const std::filesystem::path& image);

    std::filesystem::path volume_root_;
    std::filesystem::path active_path_;
    std::string driver_file_;
    std::string error_;
    std::vector<std::string> warnings_;
#if defined(_WIN32) || defined(__CYGWIN__) || defined(__MSYS__)
    // Keeps the VirtDisk attach alive for the whole inspect/restore call.
    std::unique_ptr<MountedVhdVolume> mount_;
#endif
};

bool DriverTargetScope::attach_image(const std::filesystem::path& image) {
#if defined(_WIN32) || defined(__CYGWIN__) || defined(__MSYS__)
    mount_ = std::make_unique<MountedVhdVolume>(image);
    warnings_ = mount_->warnings();
    if (!mount_->attached()) {
        error_ = "Cannot attach " + image.string() + " as a virtual disk";
        if (!warnings_.empty()) error_ += " (" + warnings_.front() + ")";
        mount_.reset();
        return false;
    }
    if (mount_->volume_root().empty()) {
        error_ = "No Windows SYSTEM hive found in " + image.string() +
                 "; attach the image and pass its volume root instead";
        mount_.reset();
        return false;
    }
    volume_root_ = mount_->volume_root();
    return true;
#else
    error_ = "Raw VHD/VHDX targets require a Windows host; pass a mounted volume root "
             "instead: " + image.string();
    return false;
#endif
}

bool DriverTargetScope::open(const std::filesystem::path& target,
                             const std::string& driver_file) {
    namespace fs = std::filesystem;
    driver_file_ = driver_file.empty() ? std::string("rt640x64.sys") : driver_file;
    if (target.empty()) {
        error_ = "No target given.";
        return false;
    }

    std::error_code ec;
    if (fs::is_regular_file(target, ec)) {
        const std::string name = target.filename().string();
        const std::string lowered = to_lower_copy(name);
        if (ends_with_ci(lowered, ".sys")) {
            // The operator pointed at a specific binary: that becomes the driver we triage
            // and the volume is derived from the directory it lives in.
            driver_file_ = name;
            volume_root_ = target.parent_path();
        } else if (string_iequal(name, "SYSTEM")) {
            volume_root_ = target.parent_path();
        } else if (ends_with_ci(lowered, ".vhd") || ends_with_ci(lowered, ".vhdx") ||
                   ends_with_ci(lowered, ".avhd") || ends_with_ci(lowered, ".avhdx")) {
            if (!attach_image(target)) return false;
        } else {
            error_ = "Expected a volume root, a .sys, a SYSTEM hive or a .vhd/.vhdx, got: " +
                     target.string();
            return false;
        }
    } else if (fs::is_directory(target, ec)) {
        volume_root_ = target;
    } else {
        error_ = "Target not found: " + target.string();
        return false;
    }

    // Walk the Windows plumbing off the end (drivers -> System32 -> Windows -> volume).
    // The attached volume root already ends at the mount point, so this is a no-op there.
    while (!volume_root_.empty() &&
           is_windows_path_component(volume_root_.filename().string())) {
        const std::filesystem::path parent = volume_root_.parent_path();
        if (parent == volume_root_) break;
        volume_root_ = parent;
    }
    if (volume_root_.empty()) {
        error_ = "Cannot derive a Windows volume root from " + target.string();
        return false;
    }

    const fs::path system32 = volume_root_ / "Windows" / "System32";
    if (!fs::is_directory(system32, ec)) {
        error_ = target.string() + " is not a Windows volume (missing " + system32.string() + ")";
        return false;
    }
    active_path_ = system32 / "drivers" / driver_file_;
    return true;
}

} // namespace

std::string PnpDriverArmer::normalize_hardware_id(const std::string& hardware_id) {
    std::string s = to_lower_copy(trim_copy(hardware_id));
    if (s.size() >= 2 && (s.front() == '"' || s.front() == '\'') && s.back() == s.front()) {
        s = trim_copy(s.substr(1, s.size() - 2));
    }
    if (s.rfind("pci\\", 0) != 0 && s.rfind("pci#", 0) != 0) return s;
    if (s.rfind("pci\\", 0) == 0) s[3] = '#';

    // Keep only the VEN/DEV fields: SUBSYS, REV and CC suffixes are dropped the same way
    // extract_pci_hardware_ids() drops them, so CLI input and INF output compare equal.
    std::string out = "pci#";
    bool wrote = false;
    size_t cursor = 4;
    while (cursor <= s.size()) {
        const size_t amp = s.find('&', cursor);
        const std::string part =
            s.substr(cursor, (amp == std::string::npos ? s.size() : amp) - cursor);
        if (part.rfind("ven_", 0) == 0 || part.rfind("dev_", 0) == 0) {
            if (wrote) out.push_back('&');
            out += part;
            wrote = true;
        }
        if (amp == std::string::npos) break;
        cursor = amp + 1;
    }
    return wrote ? out : s;
}

std::string PnpDriverArmer::generic_realtek_gbe_hw_id() {
    // RTL8111E, RTL8111H and RTL8168 all enumerate as the same generic device id, which is
    // why an inbox driver written for one boots the other -- and why the rollback can prove
    // compatibility from the INF alone.
    return "PCI\\VEN_10EC&DEV_8168";
}

bool PnpDriverArmer::legacy_compatible_driver_version(const std::string& file_version) {
    // Realtek's GbE lineages that matter here:
    //   9.1.408.x   -- the OEM build Lenovo shipped with the M71s (RTL8111E Rev 06 safe)
    //   10.1.x      -- the Windows inbox build (also safe)
    //   10.35+      -- the current build, whose PHY bring-up dereferences a null handle on
    //                  RTL8111E Rev 06: the stop 0xA whose faulting address ends in 0xE534.
    // Anything strictly below 10.35 is therefore considered safe for the legacy silicon;
    // an empty or unparseable version is never assumed safe.
    uint64_t key = 0;
    if (!version_sort_key(file_version, &key)) return false;
    const unsigned major = static_cast<unsigned>(key >> 48);
    const unsigned minor = static_cast<unsigned>((key >> 32) & 0xFFFFu);
    return major < 10u || (major == 10u && minor < 35u);
}

PeVersionInfo PnpDriverArmer::parse_pe_version_info(const std::vector<uint8_t>& bytes) {
    return pe_parse_version_info(bytes);
}

PeVersionInfo PnpDriverArmer::read_pe_version_info(const std::filesystem::path& path) {
    std::vector<uint8_t> bytes;
    if (!pe_read_image_bytes(path, &bytes)) return PeVersionInfo{};
    return pe_parse_version_info(bytes);
}

std::vector<PeSection> PnpDriverArmer::parse_pe_sections(const std::vector<uint8_t>& bytes) {
    return pe_parse_sections(bytes);
}

std::vector<PeSection> PnpDriverArmer::read_pe_sections(const std::filesystem::path& path) {
    std::vector<uint8_t> bytes;
    if (!pe_read_image_bytes(path, &bytes)) return {};
    return pe_parse_sections(bytes);
}

int PnpDriverArmer::find_section_index_for_rva(const std::vector<PeSection>& sections,
                                               uint32_t rva) {
    for (size_t i = 0; i < sections.size(); ++i) {
        const PeSection& section = sections[i];
        // The loader maps max(VirtualSize, SizeOfRawData) rounded up to the section
        // alignment, so the file-aligned tail still counts as part of the section.
        const uint32_t span = std::max(section.virtual_size, section.raw_size);
        if (span == 0) continue;
        if (rva >= section.virtual_address &&
            static_cast<uint32_t>(rva - section.virtual_address) < span) {
            return static_cast<int>(i);
        }
    }
    return -1;
}

std::vector<DriverPackageCandidate> PnpDriverArmer::scan_driver_packages(
    const std::filesystem::path& volume_path,
    const std::string& driver_file,
    const std::string& target_hw_id
) {
    std::vector<DriverPackageCandidate> out;
    if (volume_path.empty() || driver_file.empty()) return out;

    std::error_code dir_ec;
    const std::filesystem::path repo =
        volume_path / "Windows" / "System32" / "DriverStore" / "FileRepository";
    if (!std::filesystem::is_directory(repo, dir_ec)) return out;

    const std::string target =
        normalize_hardware_id(target_hw_id.empty() ? generic_realtek_gbe_hw_id() : target_hw_id);

    // netrt640*.inf_* are the Realtek packages this incident is about; netrtl8168*.inf_*
    // is the name Windows' own inbox Realtek GbE driver ships under, which is precisely
    // the "Windows inbox driver" half of the rollback request.
    std::vector<std::filesystem::path> packages;
    std::filesystem::directory_iterator dir_end;
    for (std::filesystem::directory_iterator it(repo, dir_ec); !dir_ec && it != dir_end;
         it.increment(dir_ec)) {
        std::error_code type_ec;
        if (!it->is_directory(type_ec)) continue;
        const std::string name = it->path().filename().string();
        if (match_wildcard_ci("netrt640*.inf_*", name) ||
            match_wildcard_ci("netrtl8168*.inf_*", name)) {
            packages.push_back(it->path());
        }
    }
    std::sort(packages.begin(), packages.end());

    auto find_below = [&](const std::filesystem::path& dir,
                          const std::string& leaf) -> std::filesystem::path {
        const std::filesystem::path direct = dir / leaf;
        if (file_exists_win32_or_std(direct)) return direct;
        std::error_code ec;
        std::vector<std::filesystem::path> children;
        std::filesystem::directory_iterator end;
        for (std::filesystem::directory_iterator it(dir, ec); !ec && it != end; it.increment(ec)) {
            std::error_code type_ec;
            if (it->is_directory(type_ec)) children.push_back(it->path());
        }
        std::sort(children.begin(), children.end());
        for (const auto& child : children) {
            const std::filesystem::path candidate = child / leaf;
            if (file_exists_win32_or_std(candidate)) return candidate;
        }
        return {};
    };

    for (const auto& package : packages) {
        const std::filesystem::path sys = find_below(package, driver_file);
        if (sys.empty()) continue;

        DriverPackageCandidate candidate;
        candidate.package_dir = package;
        candidate.package_dir_name = package.filename().string();
        candidate.sys_path = sys;
        candidate.present = true;

        std::vector<uint8_t> bytes;
        if (pe_read_image_bytes(sys, &bytes)) {
            const PeVersionInfo version = pe_parse_version_info(bytes);
            candidate.file_version = version.file_version;
            candidate.product_version = version.product_version;
            candidate.size = bytes.size();
            candidate.sha256 = sha256_hex(bytes.data(), bytes.size());
        } else {
            std::error_code size_ec;
            candidate.size = static_cast<uint64_t>(std::filesystem::file_size(sys, size_ec));
            candidate.sha256 = sha256_file(sys);
        }
        candidate.legacy_compatible = legacy_compatible_driver_version(candidate.file_version);

        // FileRepository keeps the INF uncompressed next to the payload. Without a readable
        // INF the hardware-id claim cannot be made, so the package stays ineligible rather
        // than being rolled in on a guess.
        {
            std::error_code ec;
            std::vector<std::filesystem::path> flat;
            std::filesystem::directory_iterator end;
            for (std::filesystem::directory_iterator it(package, ec); !ec && it != end;
                 it.increment(ec)) {
                std::error_code type_ec;
                if (it->is_directory(type_ec)) continue;
                if (ends_with_ci(to_lower_copy(it->path().filename().string()), ".inf")) {
                    flat.push_back(it->path());
                }
            }
            if (flat.empty()) {
                std::vector<std::filesystem::path> children;
                for (std::filesystem::directory_iterator it(package, ec); !ec && it != end;
                     it.increment(ec)) {
                    std::error_code type_ec;
                    if (it->is_directory(type_ec)) children.push_back(it->path());
                }
                std::sort(children.begin(), children.end());
                for (const auto& child : children) {
                    std::filesystem::directory_iterator child_end;
                    for (std::filesystem::directory_iterator it(child, ec); !ec && it != child_end;
                         it.increment(ec)) {
                        std::error_code child_type_ec;
                        if (it->is_directory(child_type_ec)) continue;
                        if (ends_with_ci(to_lower_copy(it->path().filename().string()), ".inf")) {
                            flat.push_back(it->path());
                        }
                    }
                }
            }
            std::sort(flat.begin(), flat.end());
            if (!flat.empty()) candidate.inf_path = flat.front();
        }

        if (!candidate.inf_path.empty()) {
            std::string text;
            if (read_text_file(candidate.inf_path, &text)) {
                candidate.inf_readable = true;
                candidate.hardware_ids = extract_pci_hardware_ids(text);
                candidate.supports_target_hw_id =
                    std::find(candidate.hardware_ids.begin(), candidate.hardware_ids.end(),
                              target) != candidate.hardware_ids.end();
            }
        }
        out.push_back(std::move(candidate));
    }
    return out;
}

bool PnpDriverArmer::select_driver_rollback_candidate(
    const std::vector<DriverPackageCandidate>& candidates,
    const std::string& target_hw_id,
    size_t* chosen_index,
    std::string* reason
) {
    const std::string target =
        normalize_hardware_id(target_hw_id.empty() ? generic_realtek_gbe_hw_id() : target_hw_id);
    if (chosen_index != nullptr) *chosen_index = static_cast<size_t>(-1);
    if (reason != nullptr) reason->clear();

    std::vector<size_t> legacy;
    bool declares_target_but_modern = false;
    for (size_t i = 0; i < candidates.size(); ++i) {
        const DriverPackageCandidate& candidate = candidates[i];
        if (!candidate.present) continue;
        const bool declares =
            std::find(candidate.hardware_ids.begin(), candidate.hardware_ids.end(), target) !=
            candidate.hardware_ids.end();
        if (!declares) continue;
        // Recomputed here rather than trusting the cached flag so the policy is a pure
        // function of the version string the candidate actually carries.
        if (legacy_compatible_driver_version(candidate.file_version)) {
            legacy.push_back(i);
        } else {
            declares_target_but_modern = true;
        }
    }

    if (legacy.empty()) {
        if (reason != nullptr) {
            *reason = declares_target_but_modern
                          ? "every package declaring " + target +
                                " is FileVersion 10.35 or newer (RTL8111E Rev 06 unsafe)"
                          : "no package declaring " + target + " among " +
                                std::to_string(candidates.size()) + " candidate(s)";
        }
        return false;
    }

    // Legacy-compatible first, oldest within that group; ties break on hash and then on
    // package name so the answer never depends on directory iteration order.
    std::sort(legacy.begin(), legacy.end(), [&](size_t a, size_t b) {
        const DriverPackageCandidate& left = candidates[a];
        const DriverPackageCandidate& right = candidates[b];
        uint64_t left_key = 0;
        uint64_t right_key = 0;
        const bool left_ok = version_sort_key(left.file_version, &left_key);
        const bool right_ok = version_sort_key(right.file_version, &right_key);
        if (left_ok != right_ok) return left_ok;      // parseable versions rank first
        if (left_ok && left_key != right_key) return left_key < right_key;
        if (left.sha256 != right.sha256) return left.sha256 < right.sha256;
        return left.package_dir_name < right.package_dir_name;
    });

    if (chosen_index != nullptr) *chosen_index = legacy.front();
    return true;
}

Result<DriverRestoreReport> PnpDriverArmer::restore_inbox_driver(
    const std::filesystem::path& image_or_volume,
    const std::string& driver_file,
    const std::string& target_hw_id
) {
    DriverRestoreReport report;
    report.driver_file = driver_file.empty() ? std::string("rt640x64.sys") : driver_file;
    report.target_hw_id = normalize_hardware_id(
        target_hw_id.empty() ? generic_realtek_gbe_hw_id() : target_hw_id);

    DriverTargetScope target;
    if (!target.open(image_or_volume, report.driver_file)) {
        return Error(ErrorCode::StorageFailure, target.error());
    }
    report.driver_file = target.driver_file();  // a .sys argument overrides the default
    report.volume_path = target.volume_root();
    report.active_path = target.active_path();
    report.warnings = target.warnings();

    report.candidates = scan_driver_packages(report.volume_path, report.driver_file,
                                             report.target_hw_id);

    size_t chosen = static_cast<size_t>(-1);
    std::string reason;
    if (!select_driver_rollback_candidate(report.candidates, report.target_hw_id, &chosen,
                                          &reason)) {
        report.success = false;
        report.message = "No RTL8111E-compatible package for " + report.driver_file + ": " + reason;
        report.warnings.push_back(report.message);
        Logger::default_logger().info("PNP", "[PNP] --restore-inbox-driver refused: " +
                                                 report.message);
        return report;
    }

    const DriverPackageCandidate& selected = report.candidates[chosen];
    report.selected_package = selected.package_dir_name;
    report.restored_from = selected.sys_path;

    std::error_code ec;
    const bool active_present = std::filesystem::is_regular_file(report.active_path, ec);
    if (active_present) {
        report.previous_version = read_pe_version_string(report.active_path);
        report.previous_sha256 = sha256_file(report.active_path);
    }

    auto finish = [&](bool copied) {
        report.performed = copied;
        report.restored_sha256 = copied ? sha256_file(report.active_path) : report.previous_sha256;
        report.restored_version =
            copied ? read_pe_version_string(report.active_path) : report.previous_version;
        report.restored_supports_hw_id = selected.supports_target_hw_id &&
                                         report.restored_sha256 == selected.sha256;
        report.restored_is_legacy_compatible =
            legacy_compatible_driver_version(report.restored_version);
        report.success = report.restored_supports_hw_id && report.restored_is_legacy_compatible;

        std::ostringstream oss;
        oss << report.driver_file << ": "
            << (report.previous_version.empty() ? (active_present ? "unknown" : "absent")
                                                : report.previous_version)
            << " -> "
            << (report.restored_version.empty() ? "unknown" : report.restored_version)
            << " from " << selected.package_dir_name << (copied ? " (restored)"
                                                                : " (already in place)")
            << ", declares " << report.target_hw_id;
        report.message = oss.str();
        if (!report.restored_supports_hw_id) {
            report.warnings.push_back(
                "Post-restore verification failed: the active binary is not byte-identical to " +
                selected.package_dir_name);
        }
        if (!report.restored_is_legacy_compatible) {
            report.warnings.push_back(
                "Post-restore verification failed: FileVersion " +
                (report.restored_version.empty() ? std::string("unknown")
                                                 : report.restored_version) +
                " is not below the 10.35 legacy ceiling");
        }
        Logger::default_logger().info("PNP", "[PNP] " + report.message);
        return report;
    };

    // Idempotent: the active binary already IS the package we would roll in.
    if (active_present && !report.previous_sha256.empty() &&
        report.previous_sha256 == selected.sha256) {
        return finish(false);
    }

    // Keep the outgoing binary so the rollback itself is reversible.
    if (active_present) {
        report.backup_path =
            report.active_path.parent_path() / (report.driver_file + ".prev");
        if (!copy_file_win32_or_std(report.active_path, report.backup_path, true)) {
            report.warnings.push_back("Could not back up the active binary to " +
                                      report.backup_path.string());
        }
    }

    if (!copy_file_win32_or_std(selected.sys_path, report.active_path, true)) {
        report.success = false;
        report.message = "Failed to copy " + selected.sys_path.string() + " over " +
                         report.active_path.string();
        report.warnings.push_back(report.message);
        Logger::default_logger().info("PNP", "[PNP] --restore-inbox-driver FAILED: " +
                                                 report.message);
        return report;
    }

    return finish(true);
}

Result<DriverBinaryInspection> PnpDriverArmer::inspect_driver_binary(
    const std::filesystem::path& image_or_volume,
    uint32_t rva,
    const std::string& driver_file
) {
    DriverTargetScope target;
    if (!target.open(image_or_volume, driver_file)) {
        return Error(ErrorCode::StorageFailure, target.error());
    }

    DriverBinaryInspection report;
    report.driver_file = target.driver_file();
    report.volume_path = target.volume_root();
    report.driver_path = target.active_path();
    report.rva = rva;
    report.rva_checked = true;

    std::error_code ec;
    report.present = std::filesystem::is_regular_file(report.driver_path, ec);
    if (!report.present) {
        report.findings.push_back(report.driver_path.string() + ": MISSING");
        report.message = "Active driver binary not found: " + report.driver_path.string();
        report.success = false;
        return report;
    }
    report.size = std::filesystem::file_size(report.driver_path, ec);
    report.sha256 = sha256_file(report.driver_path);

    std::vector<uint8_t> bytes;
    if (!pe_read_image_bytes(report.driver_path, &bytes)) {
        report.findings.push_back(report.driver_path.string() + ": not readable as a PE image");
        report.message = "Could not read " + report.driver_path.string();
        report.success = false;
        return report;
    }

    report.pe_valid = pe_signature_offset(bytes) != kInvalidPeOffset;
    const PeVersionInfo version = pe_parse_version_info(bytes);
    report.file_version = version.file_version;
    report.product_version = version.product_version;
    report.file_version_string = version.file_version_string;
    report.product_version_string = version.product_version_string;
    report.sections = pe_parse_sections(bytes);

    report.findings.push_back("FileVersion: " +
                              (report.file_version.empty() ? std::string("unknown")
                                                           : report.file_version));
    report.findings.push_back("ProductVersion: " +
                              (report.product_version.empty() ? std::string("unknown")
                                                              : report.product_version));
    if (!report.file_version_string.empty() &&
        report.file_version_string != report.file_version) {
        report.findings.push_back("FileVersion (StringFileInfo): " + report.file_version_string);
    }
    if (!report.product_version_string.empty() &&
        report.product_version_string != report.product_version) {
        report.findings.push_back("ProductVersion (StringFileInfo): " +
                                  report.product_version_string);
    }
    report.findings.push_back("SHA-256: " + report.sha256);

    for (const PeSection& section : report.sections) {
        report.findings.push_back("section " + section.name + " RVA " +
                                  hex_u32(section.virtual_address) + " virtual size " +
                                  hex_u32(section.virtual_size));
    }

    const int section_index = find_section_index_for_rva(report.sections, rva);
    const std::string rva_hex = hex_u32(rva);
    if (section_index < 0) {
        report.rva_section.clear();
        report.rva_in_text = false;
        report.findings.push_back("RVA " + rva_hex + " is not covered by any section");
    } else {
        report.rva_section = report.sections[static_cast<size_t>(section_index)].name;
        report.rva_in_text = string_iequal(report.rva_section, ".text");
        if (report.rva_in_text) {
            report.findings.push_back("RVA " + rva_hex + " falls inside .text (code)");
        } else {
            report.findings.push_back("HAZARD: RVA " + rva_hex + " falls inside " +
                                      report.rva_section + ", not .text");
        }
    }

    report.candidates = scan_driver_packages(report.volume_path, report.driver_file,
                                             generic_realtek_gbe_hw_id());
    if (report.candidates.empty()) {
        report.findings.push_back("No netrt640*/netrtl8168* DriverStore package found");
    } else {
        for (const DriverPackageCandidate& candidate : report.candidates) {
            std::string line = "DriverStore " + candidate.package_dir_name + ": FileVersion " +
                               (candidate.file_version.empty() ? std::string("unknown")
                                                               : candidate.file_version);
            if (!candidate.inf_readable) {
                line += ", INF unreadable (hardware id not verifiable)";
            } else if (candidate.supports_target_hw_id) {
                line += ", declares " + generic_realtek_gbe_hw_id();
            } else {
                line += ", hardware id not declared";
            }
            line += candidate.legacy_compatible ? ", legacy-compatible"
                                                : ", FileVersion 10.35 or newer";
            report.findings.push_back(line);
        }
        size_t chosen = static_cast<size_t>(-1);
        std::string reason;
        if (select_driver_rollback_candidate(report.candidates, "", &chosen, &reason)) {
            report.findings.push_back("rollback candidate: " +
                                      report.candidates[chosen].package_dir_name +
                                      " (FileVersion " +
                                      report.candidates[chosen].file_version + ")");
        } else {
            report.findings.push_back("no eligible rollback candidate: " + reason);
        }
    }

    report.success = report.pe_valid;
    report.message = report.summary();
    Logger::default_logger().info("PNP", "[PNP] Inspected " + report.driver_path.string() +
                                             ": " + report.message);
    for (const std::string& finding : report.findings) {
        Logger::default_logger().info("PNP", "[PNP]   " + finding);
    }
    return report;
}

std::string DriverBinaryInspection::summary() const {
    std::ostringstream oss;
    oss << driver_file;
    if (!present) {
        oss << ": MISSING at " << driver_path.string();
        return oss.str();
    }
    oss << " FileVersion " << (file_version.empty() ? std::string("unknown") : file_version)
        << ", ProductVersion "
        << (product_version.empty() ? std::string("unknown") : product_version) << ", " << size
        << " bytes, sha256 " << sha256;
    if (rva_checked) {
        const std::string rva_hex = hex_u32(rva);
        if (rva_section.empty()) {
            oss << ", " << rva_hex << " outside every section";
        } else if (rva_in_text) {
            oss << ", " << rva_hex << " inside .text";
        } else {
            oss << ", " << rva_hex << " inside " << rva_section << " (NOT .text)";
        }
    }
    return oss.str();
}

std::string DriverRestoreReport::summary() const {
    std::ostringstream oss;
    oss << driver_file;
    if (selected_package.empty()) {
        oss << ": " << (message.empty() ? std::string("no eligible package") : message);
        return oss.str();
    }
    oss << " " << (previous_version.empty() ? std::string("absent") : previous_version) << " -> "
        << (restored_version.empty() ? std::string("unknown") : restored_version) << " from "
        << selected_package << (performed ? " (restored)" : " (already in place)");
    return oss.str();
}

} // namespace cobdiskless
